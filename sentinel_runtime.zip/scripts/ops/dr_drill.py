from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
import tempfile
import zipfile
from pathlib import Path
from typing import Any

from core.storage.engine import DatabaseEngine
from repositories.v2.common import json_dump, new_id, utc_iso


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_sqlite(path: Path) -> int:
    connection = sqlite3.connect(path)
    try:
        result = connection.execute("PRAGMA integrity_check").fetchone()
        if not result or str(result[0]).lower() != "ok":
            raise RuntimeError(f"SQLite integrity check failed: {result}")
        tables = connection.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()
        return int((tables or [0])[0])
    finally:
        connection.close()


def extract_candidate(backup: Path, target: Path) -> Path:
    if backup.suffix.lower() == ".zip":
        with zipfile.ZipFile(backup) as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError(f"corrupt backup member: {bad}")
            candidates = [name for name in archive.namelist() if name.lower().endswith((".sqlite3", ".db", ".sqlite"))]
            if not candidates:
                raise RuntimeError("backup contains no SQLite database")
            name = candidates[0]
            destination = target / Path(name).name
            with archive.open(name) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)
            return destination
    destination = target / backup.name
    shutil.copy2(backup, destination)
    return destination


def run_drill(backup: Path, *, record: bool = True) -> dict[str, Any]:
    started = utc_iso(); run_id = new_id("dr")
    result: dict[str, Any] = {"id": run_id, "backup_key": str(backup), "status": "running", "started_at": started}
    try:
        if not backup.is_file():
            raise FileNotFoundError(backup)
        checksum = sha256(backup)
        with tempfile.TemporaryDirectory(prefix="sentinel-dr-") as temp_dir:
            candidate = extract_candidate(backup, Path(temp_dir))
            records_verified = verify_sqlite(candidate)
            engine = DatabaseEngine(database_url="", sqlite_path=candidate)
            engine.ensure_schema()
            if not engine.healthcheck():
                raise RuntimeError("restored normalized schema healthcheck failed")
        result.update({"status": "passed", "checksum": checksum, "records_verified": records_verified, "finished_at": utc_iso(), "error": ""})
    except Exception as exc:
        result.update({"status": "failed", "checksum": "", "records_verified": 0, "finished_at": utc_iso(), "error": f"{exc.__class__.__name__}: {exc}"})
    if record:
        try:
            from core.storage.engine import normalized_engine
            engine = normalized_engine()
            with engine.transaction() as cursor:
                cursor.execute(
                    """INSERT INTO v8_recovery_runs(id,backup_key,status,started_at,finished_at,checksum,records_verified,error,payload)
                       VALUES(?,?,?,?,?,?,?,?,?)""",
                    (result["id"], result["backup_key"], result["status"], result["started_at"], result["finished_at"],
                     result["checksum"], result["records_verified"], result["error"], json_dump(result)),
                )
        except Exception:
            result["recording_error"] = True
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Perform an isolated SENTINEL backup restore drill")
    parser.add_argument("backup", type=Path)
    parser.add_argument("--no-record", action="store_true")
    args = parser.parse_args()
    result = run_drill(args.backup.resolve(), record=not args.no_record)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["status"] == "passed" else 1)


if __name__ == "__main__":
    main()
