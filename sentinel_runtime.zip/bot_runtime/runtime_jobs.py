"""Feature-owned Telegram handlers extracted from the v7 runtime: runtime_jobs."""

import json

from bot_runtime import shared as _shared

globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

from core.smart_logging import install_smart_logging
from jobs.receipt_maintenance import cleanup_orphan_receipts
from modules.ai_signal_lab import process_pending_shadow_scans, promote_candidate_to_review
from modules.job_control import apply_persisted_job_controls
from modules.notification_digest import (
    build_user_digest,
    claim_due_user_digests,
    mark_user_digest_delivery,
    render_user_digest,
)
from modules.operations_intelligence import run_safe_self_healing
from services.automation_v2_dispatcher import automation_v2_runtime_job
from services.signal_projection_service import project_signal_update


async def kpi_admin_home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    snapshot = kpi_team_dashboard(await async_snapshot())
    text = (
        "🎯 <b>KPI Trader · مدیریت عملکرد تحلیلگران</b>\n\n"
        f"تسک فعال: <b>{snapshot['active_tasks']}</b> · عقب‌افتاده: <b>{snapshot['overdue_tasks']}</b>\n"
        f"در انتظار بررسی: <b>{snapshot['pending_reviews']}</b>\n"
        f"تأییدشده: <b>{snapshot['approved_submissions']}</b> · ردشده: <b>{snapshot['rejected_submissions']}</b>\n"
        f"امتیاز اعطاشده: <b>{snapshot['points_awarded']}</b>\n\n"
        "گردش کار: ساخت تسک → مشاهده و ارسال مدرک توسط تحلیلگر → بررسی ادمین → ثبت امتیاز در داشبورد تحلیلگر."
    )
    rows = [
        [InlineKeyboardButton("➕ ساخت تسک جدید", callback_data="kpi_task_new", style="success")],
        [
            InlineKeyboardButton(
                f"🕓 صف بررسی · {snapshot['pending_reviews']}",
                callback_data="kpi_review_queue",
                style="primary" if snapshot["pending_reviews"] else None,
            ),
            InlineKeyboardButton("📋 مدیریت تسک‌ها", callback_data="kpi_admin_tasks"),
        ],
        [
            InlineKeyboardButton("🏆 رتبه‌بندی تحلیلگران", callback_data="kpi_leaderboard"),
            InlineKeyboardButton("👥 داشبورد تحلیلگران", callback_data="sig_analysts"),
        ],
    ]
    if _is_owner_admin(query.from_user.id):
        rows.append(
            [
                InlineKeyboardButton(
                    "👑 تسک، دسترسی و امتیاز ادمین‌ها",
                    callback_data="owner_kpi_center",
                    style="primary",
                )
            ]
        )
    rows.append(
        [InlineKeyboardButton("↩️ سیگنال و کانال", callback_data="admin_cat:trading")]
    )
    await edit(query, text, rows)


async def kpi_task_new_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        (
            "➕ <b>ساخت تسک KPI Trader</b>\n\n"
            "اطلاعات را دقیقاً در چهار خط بفرستید:\n\n"
            "<code>عنوان فارسی\n"
            "English title\n"
            "10 | 2026-08-01 18:00 | all | signals | high | 10\n"
            "توضیح فارسی || English description</code>\n\n"
            "ترتیب خط سوم: <b>امتیاز | مهلت | تحلیلگران | دسته | اولویت | تعداد هدف</b>\n"
            "• برای بدون مهلت از <code>-</code> استفاده کنید.\n"
            "• تحلیلگران: <code>all</code> یا شناسه‌ها با کاما.\n"
            "• دسته‌ها: signals, market_research, risk, content, campaign, retention, sales_support, operations\n"
            "• اولویت: low, normal, high, critical"
        ),
        [[InlineKeyboardButton("انصراف", callback_data="a_kpi_trader")]],
    )
    return KPI_TASK_INPUT


def _parse_kpi_due(value: str) -> str | None:
    raw = str(value or "").strip()
    if raw in {"", "-", "none", "بدون"}:
        return None
    local = datetime.strptime(raw, "%Y-%m-%d %H:%M").replace(
        tzinfo=ZoneInfo(SETTINGS.timezone)
    )
    return local.astimezone(UTC).isoformat()


async def kpi_task_new_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return ConversationHandler.END
    try:
        lines = [line.strip() for line in str(update.effective_message.text or "").splitlines() if line.strip()]
        if len(lines) != 4:
            raise ValueError("پیام باید دقیقاً چهار خط داشته باشد.")
        title_fa, title_en = lines[0], lines[1]
        meta = [item.strip() for item in lines[2].split("|")]
        if len(meta) != 6:
            raise ValueError("خط سوم باید دقیقاً شش بخش داشته باشد.")
        points, due_raw, assignee_raw, category, priority, required_count = meta
        descriptions = [item.strip() for item in lines[3].split("||", 1)]
        if len(descriptions) != 2:
            raise ValueError("توضیح فارسی و انگلیسی را با || جدا کنید.")
        assignees = (
            []
            if assignee_raw.lower() == "all"
            else [item.strip() for item in assignee_raw.split(",") if item.strip()]
        )
        if assignees and any(not item.isdigit() for item in assignees):
            raise ValueError("شناسه تحلیلگران باید عددی باشد.")
        forced_assignee = str(
            context.user_data.get("kpi_forced_assignee") or ""
        ).strip()
        if forced_assignee:
            if not forced_assignee.isdigit():
                raise ValueError("شناسه ادمین هدف معتبر نیست.")
            assignees = [forced_assignee]
        due_at = _parse_kpi_due(due_raw)
        task = await async_with_db(
            lambda db: create_kpi_task(
                db,
                title_fa=title_fa,
                title_en=title_en,
                description_fa=descriptions[0],
                description_en=descriptions[1],
                points=int(points),
                created_by=update.effective_user.id,
                due_at=due_at,
                assignee_ids=assignees,
                category=category,
                priority=priority,
                required_count=int(required_count),
            )
        )
    except (ValueError, TypeError) as exc:
        return_callback = str(
            context.user_data.get("kpi_return_callback") or "a_kpi_trader"
        )
        await reply(
            update,
            f"❌ {esc(exc)}\n\nفرمت را اصلاح و دوباره ارسال کنید.",
            [[InlineKeyboardButton("انصراف", callback_data=return_callback)]],
        )
        return KPI_TASK_INPUT
    db = await async_snapshot()
    targets = [int(value) for value in task.get("assignee_ids", [])] or _kpi_trader_ids(db)
    for trader_id in targets:
        language = (await run_blocking(_language_for_user, trader_id))
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                chat_id=trader_id,
                text=(
                    f"🎯 <b>New KPI task</b>\n\n{esc(_kpi_task_title(task, language))}\n"
                    f"Score: <b>{int(task['points'])}</b>"
                    if language == "en"
                    else f"🎯 <b>تسک جدید KPI</b>\n\n{esc(_kpi_task_title(task, language))}\n"
                    f"امتیاز: <b>{int(task['points'])}</b>"
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("🎯 KPI Trader", callback_data="kpi_trader_home")]]
                ),
            )
        except TelegramError:
            logger.info("Could not notify KPI trader %s", trader_id)
    return_callback = str(
        context.user_data.pop("kpi_return_callback", "") or "a_kpi_trader"
    )
    context.user_data.pop("kpi_forced_assignee", None)
    await reply(
        update,
        f"✅ تسک <code>{task['id']}</code> ساخته و برای <b>{len(targets)}</b> تحلیلگر قابل مشاهده شد.",
        [
            [
                InlineKeyboardButton(
                    "👤 بازگشت به پرونده ادمین"
                    if return_callback.startswith("owner_kpi_admin:")
                    else "🎯 مدیریت KPI Trader",
                    callback_data=return_callback,
                )
            ]
        ],
    )
    return ConversationHandler.END


async def kpi_admin_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    tasks = [
        row for row in db.get("kpi_trader_tasks", []) if isinstance(row, dict)
    ]
    tasks.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    lines = ["📋 <b>تسک‌های KPI Trader</b>", ""]
    rows: list[list[InlineKeyboardButton]] = []
    for task in tasks[:30]:
        overdue = kpi_task_is_overdue(task)
        lines.append(
            f"{'🔴' if overdue else '•'} <code>{task['id']}</code> · "
            f"{esc(task.get('title_fa'))} · <b>{int(task.get('points', 0) or 0)}</b> امتیاز · "
            f"{_kpi_status_label(str(task.get('status')), 'fa')}"
        )
        rows.append(
            [
                InlineKeyboardButton(
                    f"{'🔴' if overdue else '🎯'} {str(task['id'])} · {str(task.get('title_fa') or '')[:35]}",
                    callback_data=f"kpi_admin_task:{task['id']}",
                )
            ]
        )
    if not tasks:
        lines.append("هنوز تسکی ساخته نشده است.")
    rows.append([InlineKeyboardButton("↩️ KPI Trader", callback_data="a_kpi_trader")])
    await edit(query, "\n".join(lines), rows)


async def kpi_admin_task_view(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    task_id = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    task = kpi_task_by_id(db, task_id)
    if not task:
        await query.answer("تسک پیدا نشد.", show_alert=True)
        return
    submissions = [
        row
        for row in db.get("kpi_trader_submissions", [])
        if isinstance(row, dict) and row.get("task_id") == task_id
    ]
    counts = Counter(str(row.get("status") or "") for row in submissions)
    commercial = kpi_task_business_totals(db, task_id)
    text = (
        _kpi_task_text(task, "fa")
        + "\n\n"
        + f"ارسال‌ها: <b>{len(submissions)}</b> · در بررسی: <b>{counts['pending']}</b> · "
        f"تأیید: <b>{counts['approved']}</b> · رد: <b>{counts['rejected']}</b>\n\n"
        f"اثر تجاری: درآمد <b>{commercial['revenue']:,}</b> · فروش <b>{commercial['sales']}</b> · "
        f"تمدید <b>{commercial['renewals']}</b> · لید <b>{commercial['leads']}</b>"
    )
    status = str(task.get("status") or "active")
    rows = [
        [
            InlineKeyboardButton(
                "⏸ توقف" if status == "active" else "▶️ فعال‌سازی",
                callback_data=f"kpi_task_status:{task_id}:{'paused' if status == 'active' else 'active'}",
            ),
            InlineKeyboardButton(
                "✅ بستن تسک",
                callback_data=f"kpi_task_status:{task_id}:closed",
                style="success",
            ),
        ],
        [InlineKeyboardButton("📈 ثبت نتیجه تجاری", callback_data=f"kpi_business:{task_id}")],
        [InlineKeyboardButton("🕓 صف بررسی", callback_data="kpi_review_queue")],
        [InlineKeyboardButton("↩️ فهرست تسک‌ها", callback_data="kpi_admin_tasks")],
    ]
    await edit(query, text, rows)


async def kpi_task_status_handler(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    _, task_id, status = str(query.data).split(":", 2)
    try:
        await async_with_db(
            lambda db: set_kpi_task_status(
                db, task_id, status, query.from_user.id
            )
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("وضعیت تسک تغییر کرد ✅")
    task = kpi_task_by_id(await async_snapshot(), task_id) or {}
    await edit(
        query,
        _kpi_task_text(task, "fa"),
        [[InlineKeyboardButton("↩️ فهرست تسک‌ها", callback_data="kpi_admin_tasks")]],
    )


async def kpi_business_outcome_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    task_id = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    task = kpi_task_by_id(db, task_id)
    if not task:
        await query.answer("تسک پیدا نشد.", show_alert=True)
        return ConversationHandler.END
    context.user_data["kpi_business_task_id"] = task_id
    await query.answer()
    await edit(
        query,
        (
            "📈 <b>ثبت نتیجه تجاری تسک</b>\n\n"
            f"{esc(task.get('title_fa') or task_id)}\n\n"
            "مقادیر را با | بفرستید:\n"
            "<code>درآمد | فروش | تمدید | لید | توضیح</code>\n\n"
            "نمونه:\n<code>2500000 | 3 | 2 | 18 | کمپین تمدید تیر</code>\n\n"
            "نتیجه به داشبورد همان تحلیلگر و داشبورد تجاری تیم متصل می‌شود."
        ),
        [[InlineKeyboardButton("انصراف", callback_data=f"kpi_admin_task:{task_id}")]],
    )
    return KPI_BUSINESS_OUTCOME_INPUT


async def kpi_business_outcome_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return ConversationHandler.END
    task_id = str(context.user_data.get("kpi_business_task_id") or "")
    try:
        parts = [part.strip() for part in str(update.effective_message.text or "").split("|", 4)]
        if len(parts) < 4:
            raise ValueError("چهار عدد درآمد، فروش، تمدید و لید لازم است.")
        values = [int(_ascii_digits(part).replace(",", "")) for part in parts[:4]]
        note = parts[4] if len(parts) > 4 else ""
        row = await async_with_db(
            lambda db: record_kpi_business_outcome(
                db,
                task_id=task_id,
                actor_id=update.effective_user.id,
                revenue=values[0],
                sales=values[1],
                renewals=values[2],
                leads=values[3],
                note=note,
            )
        )
        await async_with_db(
            lambda db: audit(
                db,
                update.effective_user.id,
                "kpi_business_outcome",
                str(row["id"]),
            )
        )
    except (ValueError, TypeError) as exc:
        await reply(
            update,
            f"❌ {esc(exc)}\n\nنمونه: <code>2500000 | 3 | 2 | 18 | توضیح</code>",
            [[InlineKeyboardButton("انصراف", callback_data=f"kpi_admin_task:{task_id}")]],
        )
        return KPI_BUSINESS_OUTCOME_INPUT
    context.user_data.pop("kpi_business_task_id", None)
    await reply(
        update,
        "✅ نتیجه تجاری ثبت و به داشبورد عملکرد تیم متصل شد.",
        [[InlineKeyboardButton("📋 بازگشت به تسک", callback_data=f"kpi_admin_task:{task_id}")]],
    )
    return ConversationHandler.END


async def kpi_review_queue(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    pending = [
        row
        for row in db.get("kpi_trader_submissions", [])
        if isinstance(row, dict) and row.get("status") == "pending"
    ]
    pending.sort(key=lambda row: str(row.get("submitted_at") or ""))
    lines = ["🕓 <b>صف بررسی KPI Trader</b>", ""]
    rows: list[list[InlineKeyboardButton]] = []
    for submission in pending[:30]:
        task = kpi_task_by_id(db, str(submission.get("task_id") or "")) or {}
        lines.append(
            f"• <code>{submission['id']}</code> · تحلیلگر <code>{submission['trader_id']}</code> · "
            f"{esc(task.get('title_fa') or submission.get('task_id'))}"
        )
        rows.append(
            [
                InlineKeyboardButton(
                    f"📝 {submission['id']} · {str(task.get('title_fa') or '')[:30]}",
                    callback_data=f"kpi_review_view:{submission['id']}",
                )
            ]
        )
    if not pending:
        lines.append("صف بررسی خالی است.")
    rows.append([InlineKeyboardButton("↩️ KPI Trader", callback_data="a_kpi_trader")])
    await edit(query, "\n".join(lines), rows)


async def kpi_review_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    if not context.user_data.pop("_kpi_quality_answered", False):
        await query.answer()
    submission_id = str(
        context.user_data.pop("_kpi_quality_submission_id", "")
        or str(query.data).split(":", 1)[1]
    )
    db = await async_snapshot()
    submission = kpi_submission_by_id(db, submission_id)
    if not submission:
        await query.answer("گزارش پیدا نشد.", show_alert=True)
        return
    task = kpi_task_by_id(db, str(submission.get("task_id") or "")) or {}
    evidence = submission.get("evidence") if isinstance(submission.get("evidence"), dict) else {}
    text = (
        "📝 <b>بررسی گزارش KPI</b>\n\n"
        f"شناسه: <code>{submission['id']}</code>\n"
        f"تحلیلگر: <code>{submission['trader_id']}</code>\n"
        f"تسک: <b>{esc(task.get('title_fa') or submission.get('task_id'))}</b>\n"
        f"امتیاز: <b>{int(task.get('points', 0) or 0)}</b>\n"
        f"نوع مدرک: <b>{esc(evidence.get('type') or 'text')}</b>\n"
        f"زمان ارسال: <b>{display_dt(submission.get('submitted_at'))}</b>\n\n"
        f"گزارش:\n{esc(submission.get('note') or 'بدون توضیح متنی')}\n\n"
        f"وضعیت: <b>{_kpi_status_label(str(submission.get('status')), 'fa')}</b>"
    )
    rows: list[list[InlineKeyboardButton]] = []
    if submission.get("status") == "pending":
        rows.append(
            [
                InlineKeyboardButton(
                    "🛡 بررسی گیت کیفیت و امتیاز",
                    callback_data=f"kpi_quality_gate:{submission_id}",
                    style="primary",
                ),
                InlineKeyboardButton(
                    "❌ رد با توضیح",
                    callback_data=f"kpi_review_reject:{submission_id}",
                    style="danger",
                ),
            ]
        )
    rows.append([InlineKeyboardButton("↩️ صف بررسی", callback_data="kpi_review_queue")])
    await edit(query, text, rows)


def _kpi_quality_gate_text(db: dict[str, Any], submission_id: str) -> str:
    gate = kpi_quality_gate_snapshot(db, submission_id)
    submission = kpi_submission_by_id(db, submission_id) or {}
    task = kpi_task_by_id(db, str(submission.get("task_id") or "")) or {}
    labels = {
        "evidence": "مدرک قابل بررسی",
        "complete": "خروجی کامل",
        "measurable": "نتیجه قابل اندازه‌گیری",
        "accurate": "دقت و صحت",
    }
    lines = [
        "🛡 <b>Task Quality Gate</b>",
        f"تسک: <b>{esc(task.get('title_fa') or task.get('id'))}</b>",
        f"تحلیلگر: <code>{esc(submission.get('trader_id'))}</code>",
        "",
    ]
    for key in KPI_QUALITY_CHECKS:
        lines.append(f"{'✅' if gate['checks'][key] else '⬜️'} {labels[key]} · ۲۰ امتیاز")
    lines.append(f"{'✅' if gate['on_time'] else '⛔'} تحویل به‌موقع · ۲۰ امتیاز")
    estimated = max(1, round(int(task.get("points", 0) or 0) * int(gate["score"]) / 100))
    lines.extend(
        [
            "",
            f"امتیاز کیفیت: <b>{int(gate['score'])}٪</b> · حداقل: <b>{int(gate['minimum_score'])}٪</b>",
            f"امتیاز قابل ثبت: <b>{estimated}</b> از <b>{int(task.get('points', 0) or 0)}</b>",
            f"وضعیت: <b>{'آماده تأیید ✅' if gate['ready'] else 'نیازمند تکمیل ⏳'}</b>",
        ]
    )
    return "\n".join(lines)


async def kpi_quality_gate_view(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    submission_id = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    try:
        gate = kpi_quality_gate_snapshot(db, submission_id)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    labels = {
        "evidence": "مدرک",
        "complete": "کامل",
        "measurable": "سنجش‌پذیر",
        "accurate": "دقیق",
    }
    rows = [
        [
            InlineKeyboardButton(
                f"{'✅' if gate['checks'][key] else '⬜️'} {labels[key]}",
                callback_data=f"kpi_quality_toggle:{submission_id}:{key}",
            )
            for key in KPI_QUALITY_CHECKS[index : index + 2]
        ]
        for index in range(0, len(KPI_QUALITY_CHECKS), 2)
    ]
    if gate["ready"]:
        rows.append(
            [
                InlineKeyboardButton(
                    "✅ تأیید نهایی و ثبت امتیاز",
                    callback_data=f"kpi_review_action:{submission_id}:approve",
                    style="success",
                )
            ]
        )
    rows.append([InlineKeyboardButton("↩️ گزارش", callback_data=f"kpi_review_view:{submission_id}")])
    await edit(query, _kpi_quality_gate_text(db, submission_id), rows)


async def kpi_quality_toggle_handler(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    _, submission_id, check = str(query.data).split(":", 2)
    try:
        await async_with_db(
            lambda db: toggle_kpi_quality_check(
                db,
                submission_id=submission_id,
                check=check,
                actor_id=query.from_user.id,
            )
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("ارزیابی کیفیت ذخیره شد")
    context.user_data["_kpi_quality_answered"] = True
    context.user_data["_kpi_quality_submission_id"] = submission_id
    await kpi_quality_gate_view(update, context)


async def _notify_kpi_review_result(
    context: ContextTypes.DEFAULT_TYPE,
    db: dict[str, Any],
    submission: dict[str, Any],
) -> None:
    trader_id = int(submission["trader_id"])
    language = user_language(db, trader_id) or "fa"
    task = kpi_task_by_id(db, str(submission.get("task_id") or "")) or {}
    approved = submission.get("status") == "approved"
    if language == "en":
        text = (
            f"{'✅' if approved else '❌'} <b>KPI task {'approved' if approved else 'needs revision'}</b>\n\n"
            f"{esc(_kpi_task_title(task, language))}\n"
            f"Score awarded: <b>{int(submission.get('points_awarded', 0) or 0)}</b>\n"
            f"Review note: {esc(submission.get('review_note') or '—')}"
        )
    else:
        text = (
            f"{'✅' if approved else '❌'} <b>تسک KPI {'تأیید شد' if approved else 'نیازمند اصلاح است'}</b>\n\n"
            f"{esc(_kpi_task_title(task, language))}\n"
            f"امتیاز ثبت‌شده: <b>{int(submission.get('points_awarded', 0) or 0)}</b>\n"
            f"نظر بررسی: {esc(submission.get('review_note') or '—')}"
        )
    try:
        await _telegram_request_with_button_fallback(
            context.bot.send_message,
            chat_id=trader_id,
            text=text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("🎯 KPI Trader", callback_data="kpi_trader_home")]]
            ),
        )
    except TelegramError:
        logger.warning("Could not notify KPI trader %s", trader_id, exc_info=True)


async def kpi_review_action(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    _, submission_id, action = str(query.data).split(":", 2)
    try:
        submission = await async_with_db(
            lambda db: review_kpi_submission(
                db,
                submission_id=submission_id,
                reviewer_id=query.from_user.id,
                approved=action == "approve",
                note="تأیید ادمین" if action == "approve" else "",
                owner_id=SETTINGS.admin_ids[0] if SETTINGS.admin_ids else None,
            )
        )
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("تأیید و امتیاز ثبت شد ✅", show_alert=True)
    db = await async_snapshot()
    await _notify_kpi_review_result(context, db, submission)
    await edit(
        query,
        (
            "✅ <b>گزارش تأیید شد</b>\n\n"
            f"امتیاز ثبت‌شده: <b>{int(submission.get('points_awarded', 0) or 0)}</b>\n"
            f"تحلیلگر: <code>{esc(submission.get('trader_id'))}</code>"
        ),
        [[InlineKeyboardButton("↩️ صف بررسی", callback_data="kpi_review_queue")]],
    )


async def kpi_review_reject_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    submission_id = str(query.data).split(":", 1)[1]
    context.user_data["kpi_reject_submission_id"] = submission_id
    await query.answer()
    await edit(
        query,
        "❌ <b>دلیل رد یا اصلاح موردنیاز را بنویسید</b>\n\nتحلیلگر این توضیح را دریافت می‌کند و می‌تواند دوباره مدرک ارسال کند.",
        [[InlineKeyboardButton("انصراف", callback_data=f"kpi_review_view:{submission_id}")]],
    )
    return KPI_REJECTION_INPUT


async def kpi_review_reject_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return ConversationHandler.END
    submission_id = str(context.user_data.pop("kpi_reject_submission_id", "") or "")
    note = str(update.effective_message.text or "").strip()
    if not submission_id or not note:
        await reply(update, "❌ دلیل رد نمی‌تواند خالی باشد.")
        return KPI_REJECTION_INPUT
    try:
        submission = await async_with_db(
            lambda db: review_kpi_submission(
                db,
                submission_id=submission_id,
                reviewer_id=update.effective_user.id,
                approved=False,
                note=note,
                owner_id=SETTINGS.admin_ids[0] if SETTINGS.admin_ids else None,
            )
        )
    except (ValueError, PermissionError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return ConversationHandler.END
    db = await async_snapshot()
    await _notify_kpi_review_result(context, db, submission)
    await reply(
        update,
        "✅ گزارش رد شد و توضیح برای تحلیلگر ارسال شد.",
        [[InlineKeyboardButton("🕓 صف بررسی", callback_data="kpi_review_queue")]],
    )
    return ConversationHandler.END


async def kpi_leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_KPI_TRADER_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    snapshot = kpi_team_dashboard(await async_snapshot())
    lines = ["🏆 <b>رتبه‌بندی KPI Trader</b>", ""]
    for index, row in enumerate(snapshot["traders"][:30], start=1):
        lines.append(
            f"{index}. <code>{row['trader_id']}</code> · امتیاز <b>{row['points_total']}</b> · "
            f"این ماه <b>{row['points_month']}</b> · تأیید <b>{row['approval_rate']:.1f}٪</b> · "
            f"به‌موقع <b>{row['on_time_rate']:.1f}٪</b>"
        )
    if not snapshot["traders"]:
        lines.append("هنوز امتیاز KPI ثبت نشده است.")
    await edit(
        query,
        "\n".join(lines),
        [[InlineKeyboardButton("↩️ KPI Trader", callback_data="a_kpi_trader")]],
    )


async def kpi_due_reminder_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    claimed = await async_with_db(claim_kpi_due_reminders)
    if not claimed:
        return
    db = await async_snapshot()
    for row in claimed:
        task = row.get("task") if isinstance(row.get("task"), dict) else {}
        reminder_key = str(row.get("reminder_key") or "")
        target_ids = [int(value) for value in task.get("assignee_ids", [])] or _kpi_trader_ids(db)
        for trader_id in target_ids:
            submission = trader_task_submission(db, str(task.get("id") or ""), trader_id)
            if submission and submission.get("status") in {"pending", "approved"}:
                continue
            language = user_language(db, trader_id) or "fa"
            overdue = reminder_key == "overdue"
            text = (
                (
                    "🔴 <b>KPI task overdue</b>\n\n"
                    if overdue
                    else "⏰ <b>KPI task deadline reminder</b>\n\n"
                )
                + f"{esc(_kpi_task_title(task, language))}\n"
                + f"Deadline: <b>{display_dt(task.get('due_at'))}</b>\n"
                + f"Score: <b>{int(task.get('points', 0) or 0)}</b>"
                if language == "en"
                else (
                    ("🔴 <b>تسک KPI عقب‌افتاده</b>\n\n" if overdue else "⏰ <b>یادآوری مهلت تسک KPI</b>\n\n")
                    + f"{esc(_kpi_task_title(task, language))}\n"
                    + f"مهلت: <b>{display_dt(task.get('due_at'))}</b>\n"
                    + f"امتیاز: <b>{int(task.get('points', 0) or 0)}</b>"
                )
            )
            try:
                await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    chat_id=trader_id,
                    text=text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("🎯 KPI Trader", callback_data="kpi_trader_home")]]
                    ),
                )
            except TelegramError:
                logger.info("Could not deliver KPI reminder to %s", trader_id)


async def signal_analysts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ANALYST_DASHBOARD):
        return
    query = update.callback_query
    await query.answer()
    rows_data = all_analyst_dashboards(await async_snapshot())
    lines = ["🏅 <b>فضای کاری تحلیل‌گران</b>", "", "برای مشاهده جزئیات هر تحلیلگر روی نام او بزنید."]
    buttons: list[list[InlineKeyboardButton]] = []
    for index, item in enumerate(rows_data[:20], start=1):
        kpi = item.get("kpi", {})
        lines.append(
            f"{index}. <b>{esc(item['display_name'])}</b> | {item['signals']} سیگنال | "
            f"وین‌ریت <b>{item['win_rate']:.1f}٪</b> | امید ریاضی <b>{item['expectancy_r']:+.2f}R</b> | "
            f"خالص <b>{item['net_r']:+.2f}R</b> | KPI <b>{int(kpi.get('points_total', 0) or 0)}</b>"
        )
        if str(item.get("admin_id", "")).isdigit():
            buttons.append([InlineKeyboardButton(f"👤 تحلیلگر {item['admin_id']}", callback_data=f"sig_analyst:{item['admin_id']}")])
    if not rows_data:
        lines.append("داده‌ای برای رتبه‌بندی وجود ندارد.")
    buttons.append(back("a_signal_results")[0])
    await edit(query, "\n".join(lines), buttons)


async def signal_analyst_detail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ANALYST_DASHBOARD):
        return
    query = update.callback_query
    await query.answer()
    admin_id = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    perf = analyst_dashboard(db, admin_id)
    kpi = perf.get("kpi", {})
    signals = perf.get("recent_signals", [])
    lines = [
        f"👤 <b>داشبورد تحلیلگر {esc(perf['display_name'])}</b>", "",
        f"کل سیگنال‌ها: <b>{perf['signals']}</b>",
        f"تسویه‌شده: <b>{perf['settled']}</b> | برد کامل/جزئی: <b>{perf['full_wins']}/{perf['partial_wins']}</b> | زیان: <b>{perf['losses']}</b>",
        f"وین‌ریت: <b>{perf['win_rate']:.1f}٪</b>",
        f"خالص: <b>{perf['net_r']:+.2f}R</b> | امید ریاضی: <b>{perf['expectancy_r']:+.2f}R</b>",
        f"Profit Factor: <b>{esc(perf['profit_factor'])}</b> | Max DD: <b>{perf['maximum_drawdown_r']:.2f}R</b>",
        f"ردشده: <b>{perf['rejected_signals']}</b> | ویرایش: <b>{perf['revisions']}</b>",
        f"میانه زمان بررسی: <b>{esc(perf['median_review_minutes'] or '—')} دقیقه</b>",
        "",
        "<b>KPI Trader</b>",
        f"امتیاز کل: <b>{int(kpi.get('points_total', 0) or 0)}</b> | این ماه: <b>{int(kpi.get('points_month', 0) or 0)}</b>",
        f"تأییدشده: <b>{int(kpi.get('approved', 0) or 0)}</b> | در بررسی: <b>{int(kpi.get('pending', 0) or 0)}</b> | ردشده: <b>{int(kpi.get('rejected', 0) or 0)}</b>",
        f"نرخ تأیید: <b>{float(kpi.get('approval_rate', 0) or 0):.1f}٪</b> | انجام به‌موقع: <b>{float(kpi.get('on_time_rate', 0) or 0):.1f}٪</b>",
        "⚠️ نمونه آماری کمتر از ۲۰ نتیجه است." if perf["sample_warning"] else "✅ حجم نمونه برای ارزیابی اولیه کافی است.",
        "", "<b>آخرین سیگنال‌ها</b>",
    ]
    for row in signals:
        lines.append(f"• #{signal_display_number(row)} | {esc(row.get('symbol'))} | {esc(signal_status_label(str(row.get('status') or 'open')))} | نسخه {int(row.get('revision', 1) or 1)}")
    await edit(query, "\n".join(lines), [[InlineKeyboardButton("🔙 تحلیل‌گران", callback_data="sig_analysts")]])


async def incident_center_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_INCIDENTS):
        return
    query = update.callback_query
    await query.answer()
    summary = incident_summary(await async_snapshot())
    lines = [
        "🚨 <b>مرکز رخدادهای عملیاتی</b>", "",
        f"رخداد باز: <b>{summary['open']}</b> | بحرانی: <b>{summary['critical']}</b> | هشدار: <b>{summary['warning']}</b>",
        f"تأییدشده و در حال بررسی: <b>{summary['acknowledged']}</b> | کل تاریخچه: <b>{summary['total']}</b>", "",
    ]
    buttons: list[list[InlineKeyboardButton]] = []
    for row in summary.get("latest", [])[:12]:
        status = str(row.get("status") or "open")
        if status == "resolved":
            continue
        lines.append(
            f"<b>#{row.get('id')} • {esc(row.get('severity'))}</b> | {esc(row.get('source'))}/{esc(row.get('kind'))}\n"
            f"{esc(str(row.get('detail') or '')[:180])} | تکرار: {int(row.get('count', 1) or 1)}"
        )
        buttons.append([
            InlineKeyboardButton("👁 در حال بررسی", callback_data=f"incident_ack:{row.get('id')}"),
            InlineKeyboardButton("✅ حل شد", callback_data=f"incident_resolve:{row.get('id')}"),
        ])
    if len(lines) == 4:
        lines.append("رخداد بازی ثبت نشده است.")
    buttons.extend([[InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_incidents")], back("admin_cat:system")[0]])
    await edit(query, "\n\n".join(lines), buttons)


async def incident_status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_INCIDENTS):
        return
    query = update.callback_query
    action, raw_id = str(query.data).split(":", 1)
    status = "acknowledged" if action.endswith("ack") else "resolved"
    try:
        await async_with_db(lambda db: update_incident_status(db, raw_id, status, query.from_user.id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("وضعیت رخداد بروزرسانی شد.")
    await incident_center_view(update, context)


async def trust_center_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TRUST_CENTER):
        return
    query = update.callback_query
    await query.answer()
    snapshot = await async_with_db(refresh_trust_center)
    markets = " | ".join(f"{esc(market_label(key))}: {value}" for key, value in snapshot.get("markets", {}).items()) or "بدون داده"
    await edit(
        query,
        "🔎 <b>مرکز شفافیت و اعتماد</b>\n\n"
        f"کل سیگنال‌ها: <b>{snapshot['total_signals']}</b> | فعال: <b>{snapshot['active_signals']}</b> | بسته: <b>{snapshot['closed_signals']}</b>\n"
        f"برد: <b>{snapshot['wins']}</b> | استاپ: <b>{snapshot['stops']}</b> | وین‌ریت: <b>{snapshot['win_rate']:.1f}٪</b>\n"
        f"میانگین ریسک: <b>{snapshot['average_risk']:.2f}٪</b> | میانگین R/R: <b>{snapshot['average_rr']:.2f}</b>\n"
        f"سیگنال ویرایش‌شده: <b>{snapshot['edited_signals']}</b>\n"
        f"بازارها: {markets}\n\n"
        f"<b>روش محاسبه</b>\n{esc(snapshot['methodology'])}\n\n"
        f"⚠️ {esc(snapshot['disclaimer'])}",
        [[InlineKeyboardButton("🔄 بروزرسانی", callback_data="a_trust_center")], back("admin_cat:analytics")[0]],
    )


def _campaign_category_rows() -> list[list[InlineKeyboardButton]]:
    return present_campaign_category_rows(back("a_campaigns"))


def _campaign_audience_rows() -> list[list[InlineKeyboardButton]]:
    return present_campaign_audience_rows(back("a_campaigns"))


def _campaign_detail_text(db: dict[str, Any], campaign: dict[str, Any]) -> str:
    return present_campaign_detail_text(db, campaign)


async def campaign_studio_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    campaigns = await async_read_db_section("marketing_campaigns")
    summary = campaign_studio_summary({"marketing_campaigns": campaigns})
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton("➕ ساخت کمپین جدید", callback_data="campaign_new")],
    ]
    for campaign in summary.get("latest", [])[:8]:
        status = {"draft": "📝", "scheduled": "⏰", "active": "🟢", "paused": "⏸", "completed": "✅"}.get(
            str(campaign.get("status")), "⚪"
        )
        rows.append(
            [
                InlineKeyboardButton(
                    f"{status} {str(campaign.get('name') or '')[:28]}",
                    callback_data=f"campaign_view:{campaign.get('id')}",
                )
            ]
        )
    rows.extend(
        [
            [InlineKeyboardButton("🔗 لینک‌های جذب کانال", callback_data="a_channel_attribution")],
            [InlineKeyboardButton("📈 Growth Link Lab", callback_data="a_growth_link_lab")],
            back("admin_cat:sales")[0],
        ]
    )
    await edit(
        query,
        "🚀 <b>استودیو کمپین SENTINEL</b>\n\n"
        f"کل کمپین‌ها: <b>{summary['total']}</b> | فعال: <b>{summary['active']}</b>\n"
        f"پیش‌نویس: <b>{summary['draft']}</b> | زمان‌بندی: <b>{summary['scheduled']}</b> | "
        f"متوقف: <b>{summary['paused']}</b>\n"
        f"تکمیل: <b>{summary['completed']}</b> | Dead-letter: <b>{summary['dead_letter']}</b>\n\n"
        "هر کمپین یک یا دو لینک اختصاصی قابل‌انتساب می‌سازد. لینک را در تبلیغات پخش کنید و "
        "ورود، عضویت، خرید، درآمد، CAC، ROI و ROAS را در Growth Link Lab ببینید.",
        rows,
    )
    return ConversationHandler.END


async def campaign_new_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["campaign_draft"] = {}
    await edit(
        query,
        "🚀 <b>کمپین جدید</b>\n\nنام داخلی و مشخص کمپین را ارسال کنید.\nمثال: <code>بازگشت مشتریان تابستان ۱۴۰۵</code>",
        back("a_campaigns"),
    )
    return CAMPAIGN_NAME_INPUT


async def campaign_name_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    name = " ".join(str(update.effective_message.text or "").strip().split())
    if not 3 <= len(name) <= 100:
        await reply(update, "❌ نام کمپین باید بین ۳ تا ۱۰۰ نویسه باشد.")
        return CAMPAIGN_NAME_INPUT
    context.user_data["campaign_draft"] = {"name": name}
    await reply(update, "دسته کمپین را انتخاب کنید:", _campaign_category_rows())
    return CAMPAIGN_CATEGORY_INPUT


async def campaign_category_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    query = update.callback_query
    category = str(query.data).split(":", 1)[1]
    if category not in CAMPAIGN_CATEGORIES:
        await query.answer("دسته نامعتبر است.", show_alert=True)
        return CAMPAIGN_CATEGORY_INPUT
    context.user_data.setdefault("campaign_draft", {})["category"] = category
    await query.answer()
    await edit(query, "گروه مخاطب کمپین را انتخاب کنید:", _campaign_audience_rows())
    return CAMPAIGN_AUDIENCE_INPUT


async def campaign_audience_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    query = update.callback_query
    audience = str(query.data).split(":", 1)[1]
    if audience not in CAMPAIGN_AUDIENCES:
        await query.answer("گروه مخاطب نامعتبر است.", show_alert=True)
        return CAMPAIGN_AUDIENCE_INPUT
    context.user_data.setdefault("campaign_draft", {})["audience"] = audience
    await query.answer()
    await edit(
        query,
        "🎁 <b>کد تخفیف کمپین</b>\n\n"
        "برای ساخت کد، اطلاعات را در یک خط بفرستید:\n"
        "<code>CODE | درصد | سقف استفاده | اعتبار روز</code>\n"
        "مثال: <code>SUMMER25 | 25 | 500 | 14</code>\n\n"
        "سقف استفاده صفر یعنی نامحدود.",
        [
            [InlineKeyboardButton("بدون کد تخفیف", callback_data="campaign_discount:none")],
            back("a_campaigns")[0],
        ],
    )
    return CAMPAIGN_DISCOUNT_INPUT


async def campaign_discount_none(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    query = update.callback_query
    context.user_data.setdefault("campaign_draft", {})["discount"] = None
    await query.answer()
    await edit(
        query,
        "✍️ متن کمپین را ارسال کنید.\n\nکد تخفیف و تاریخ اعتبار، در صورت وجود، خودکار به انتهای پیام اضافه می‌شود.",
        back("a_campaigns"),
    )
    return CAMPAIGN_MESSAGE_INPUT


async def campaign_discount_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|")]
    if len(parts) != 4:
        await reply(update, "❌ قالب صحیح: <code>CODE | درصد | سقف استفاده | اعتبار روز</code>")
        return CAMPAIGN_DISCOUNT_INPUT
    code = "".join(ch for ch in parts[0].upper() if ch.isalnum() or ch in {"-", "_"})
    try:
        percent, max_uses, days = (int(parts[1]), int(parts[2]), int(parts[3]))
    except ValueError:
        await reply(update, "❌ درصد، سقف استفاده و تعداد روز باید عدد صحیح باشند.")
        return CAMPAIGN_DISCOUNT_INPUT
    if not 4 <= len(code) <= 24 or not 1 <= percent <= 100 or not 0 <= max_uses <= 1_000_000 or not 1 <= days <= 3650:
        await reply(update, "❌ کد ۴ تا ۲۴ نویسه، درصد ۱ تا ۱۰۰ و اعتبار ۱ تا ۳۶۵۰ روز باشد.")
        return CAMPAIGN_DISCOUNT_INPUT
    context.user_data.setdefault("campaign_draft", {})["discount"] = {
        "code": code,
        "percent": percent,
        "max_uses": max_uses,
        "days": days,
    }
    await reply(
        update,
        "✍️ متن کمپین را ارسال کنید.\n\nکد تخفیف و تاریخ اعتبار خودکار به انتهای پیام اضافه می‌شود.",
        back("a_campaigns"),
    )
    return CAMPAIGN_MESSAGE_INPUT


async def campaign_message_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    message = str(update.effective_message.text or "").strip()
    if not 3 <= len(message) <= 3500:
        await reply(update, "❌ متن کمپین باید بین ۳ تا ۳۵۰۰ نویسه باشد.")
        return CAMPAIGN_MESSAGE_INPUT
    context.user_data.setdefault("campaign_draft", {})["message"] = message
    await reply(
        update,
        "🔗 <b>شناسه‌های توزیع لینک</b>\n\n"
        "اطلاعات را با این قالب بفرستید:\n"
        "<code>source | medium | creative | budget | advertiser</code>\n\n"
        "نمونه: <code>instagram | story | video-01 | 5000000 | Agency A</code>\n"
        "نام‌ها را کوتاه، انگلیسی و یکدست نگه دارید تا گزارش‌ها چندتکه نشوند.",
        back("a_campaigns"),
    )
    return CAMPAIGN_TRACKING_INPUT


async def campaign_tracking_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|")]
    if len(parts) not in {4, 5}:
        await reply(update, "❌ قالب صحیح: <code>source | medium | creative | budget | advertiser</code>")
        return CAMPAIGN_TRACKING_INPUT
    source, medium, creative = (part.lower().replace(" ", "_") for part in parts[:3])
    try:
        budget = int(parts[3].replace(",", ""))
    except ValueError:
        await reply(update, "❌ بودجه باید عدد صحیح و برحسب تومان باشد.")
        return CAMPAIGN_TRACKING_INPUT
    if (
        not re.fullmatch(r"[a-z0-9_-]{2,100}", source)
        or not re.fullmatch(r"[a-z0-9_-]{2,80}", medium)
        or not re.fullmatch(r"[a-z0-9_-]{2,120}", creative)
        or not 0 <= budget <= 10**15
    ):
        await reply(update, "❌ source/medium/creative فقط حروف انگلیسی، عدد، خط تیره یا زیرخط باشند.")
        return CAMPAIGN_TRACKING_INPUT
    context.user_data.setdefault("campaign_draft", {})["tracking"] = {
        "source": source,
        "medium": medium,
        "creative": creative,
        "budget": budget,
        "advertiser": parts[4] if len(parts) == 5 else "",
    }
    await reply(
        update,
        "📤 <b>نوع لینک کمپین را انتخاب کنید</b>\n\n"
        "ربات لینک اختصاصی و قابل‌اندازه‌گیری می‌سازد؛ شما آن را در رسانه انتخابی پخش می‌کنید.",
        [
            [InlineKeyboardButton("📝 فقط پیش‌نویس", callback_data="campaign_delivery:draft")],
            [
                InlineKeyboardButton("🤖 لینک ورود ربات", callback_data="campaign_delivery:link_bot"),
                InlineKeyboardButton("📢 لینک عضویت کانال", callback_data="campaign_delivery:link_channel"),
            ],
            [InlineKeyboardButton("🔗 ساخت هر دو لینک", callback_data="campaign_delivery:link_both")],
            back("a_campaigns")[0],
        ],
    )
    return CAMPAIGN_DELIVERY_INPUT


async def _dispatch_marketing_campaign(
    context: ContextTypes.DEFAULT_TYPE,
    campaign_id: str,
    actor_id: int,
) -> dict[str, Any]:
    return await dispatch_marketing_campaign(
        context.bot,
        campaign_id,
        actor_id,
        bot_username=_RUNTIME_BOT_USERNAME,
    )


async def campaign_delivery_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    query = update.callback_query
    delivery = str(query.data).split(":", 1)[1]
    if delivery not in {"draft", "link_bot", "link_channel", "link_both"}:
        await query.answer("مسیر انتشار نامعتبر است.", show_alert=True)
        return CAMPAIGN_DELIVERY_INPUT
    draft = dict(context.user_data.get("campaign_draft") or {})
    if not {"name", "category", "audience", "message"} <= set(draft):
        await query.answer("اطلاعات پیش‌نویس ناقص یا منقضی شده است.", show_alert=True)
        return ConversationHandler.END

    def create(db: dict[str, Any]) -> dict[str, Any]:
        control = control_module_state(db, "campaigns")
        today = utc_now().date().isoformat()
        created_today = sum(
            1
            for row in db.setdefault("marketing_campaigns", {}).values()
            if isinstance(row, dict) and str(row.get("created_at") or "").startswith(today)
        )
        if created_today >= int(control.get("daily_campaign_limit", 20) or 20):
            raise ValueError("سقف ساخت کمپین روزانه تکمیل شده است.")
        campaign = create_marketing_campaign(
            db,
            name=draft["name"],
            category=draft["category"],
            audience=draft["audience"],
            message=draft["message"],
            delivery=delivery,
            created_by=query.from_user.id,
            tracking=draft.get("tracking") if isinstance(draft.get("tracking"), dict) else {},
        )
        discount = draft.get("discount")
        if isinstance(discount, dict):
            item = create_public_discount(
                db,
                code=discount["code"],
                percent=int(discount["percent"]),
                starts_at=None,
                ends_at=utc_iso(utc_now() + timedelta(days=int(discount["days"]))),
                max_uses=int(discount["max_uses"]),
                one_per_user=True,
                created_by=query.from_user.id,
            )
            attach_campaign_discount(db, campaign["id"], item["code"], actor_id=query.from_user.id)
        audit(db, query.from_user.id, "campaign_created", campaign["id"])
        return dict(campaign)

    try:
        campaign = await async_with_db(create)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return CAMPAIGN_DELIVERY_INPUT
    context.user_data.pop("campaign_draft", None)
    if delivery == "draft":
        await query.answer("پیش‌نویس کمپین ذخیره شد ✅", show_alert=True)
        await edit(
            query,
            f"📝 <b>پیش‌نویس کمپین ذخیره شد</b>\n\nشناسه: <code>{esc(campaign['id'])}</code>",
            [[InlineKeyboardButton("مشاهده کمپین", callback_data=f"campaign_view:{campaign['id']}")], back("a_campaigns")[0]],
        )
        return ConversationHandler.END

    username = _RUNTIME_BOT_USERNAME or SETTINGS.bot_username
    if not username and delivery in {"link_bot", "link_both"}:
        try:
            username = _remember_runtime_bot_username((await context.bot.get_me()).username)
        except TelegramError:
            username = ""
    compact_id = str(campaign["id"]).split("-")[-1].lstrip("0") or "0"
    bot_link = f"https://t.me/{username}?start=cmp_{compact_id}" if username else ""
    channel_link = ""
    channel_link_id: int | str = ""
    if delivery in {"link_channel", "link_both"}:
        if not SETTINGS.public_channel_id:
            await query.answer("PUBLIC_CHANNEL_ID تنظیم نشده است؛ کمپین به‌صورت پیش‌نویس باقی ماند.", show_alert=True)
            return ConversationHandler.END
        try:
            invite = await context.bot.create_chat_invite_link(
                chat_id=SETTINGS.public_channel_id,
                name=f"{campaign['id']} {campaign['name']}"[:32],
            )
            channel_link = str(invite.invite_link)
            tracking = campaign.get("tracking", {})
            link_row = await async_with_db(
                lambda db: register_public_channel_link(
                    db,
                    name=str(campaign["name"])[:80],
                    invite_link=channel_link,
                    created_by=query.from_user.id,
                    channel_id=SETTINGS.public_channel_id,
                    campaign_id=str(campaign["id"]),
                    advertiser=str(tracking.get("advertiser") or ""),
                    source=str(tracking.get("source") or ""),
                    medium=str(tracking.get("medium") or ""),
                    creative=str(tracking.get("creative") or ""),
                    cost=int(tracking.get("budget", 0) or 0),
                )
            )
            channel_link_id = link_row["id"]
        except (TelegramError, ValueError) as exc:
            failure_detail = f"{campaign['id']}: {exc}"
            await async_with_db(
                lambda db, detail=failure_detail: record_incident(
                    db,
                    source="campaigns",
                    kind="tracking_link_create_failed",
                    detail=detail,
                    severity="warning",
                )
            )
            await query.answer("ساخت لینک کانال ناموفق بود؛ دسترسی ادمین ربات را بررسی کنید.", show_alert=True)
            return ConversationHandler.END
    campaign = await async_with_db(
        lambda db: activate_link_campaign(
            db,
            campaign["id"],
            actor_id=query.from_user.id,
            bot_link=bot_link,
            channel_link=channel_link,
            channel_link_id=channel_link_id,
        )
    )
    tracking = campaign.get("tracking", {})
    link_lines = []
    if bot_link:
        link_lines.append(f"🤖 لینک ربات:\n<code>{esc(bot_link)}</code>")
    if channel_link:
        link_lines.append(f"📢 لینک کانال:\n<code>{esc(channel_link)}</code>")
    await query.answer("کمپین لینک‌محور فعال شد ✅", show_alert=True)
    await edit(
        query,
        "✅ <b>کمپین لینک‌محور فعال شد</b>\n\n"
        f"شناسه: <code>{esc(campaign['id'])}</code>\n"
        f"Source: <code>{esc(tracking.get('source'))}</code> | Medium: <code>{esc(tracking.get('medium'))}</code>\n"
        f"Creative: <code>{esc(tracking.get('creative'))}</code> | Budget: <b>{int(tracking.get('budget', 0)):,}</b>\n\n"
        + "\n\n".join(link_lines)
        + "\n\nاین لینک‌ها را پخش کنید؛ ورود، خرید، درآمد، CAC و ROAS در Growth Link Lab اندازه‌گیری می‌شوند.",
        [
            [InlineKeyboardButton("📈 گزارش کمپین", callback_data=f"campaign_view:{campaign['id']}")],
            [InlineKeyboardButton("📊 Growth Link Lab", callback_data="a_growth_link_lab")],
            back("a_campaigns")[0],
        ],
    )
    return ConversationHandler.END


async def campaign_schedule_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    query = update.callback_query
    campaign_id = str(query.data).split(":", 1)[1]
    campaign = campaign_by_id(await async_snapshot(), campaign_id)
    if campaign is None:
        await query.answer("کمپین پیدا نشد.", show_alert=True)
        return ConversationHandler.END
    if str(campaign.get("delivery") or "draft") == "draft":
        await query.answer("ابتدا مسیر انتشار را انتخاب کنید.", show_alert=True)
        return ConversationHandler.END
    context.user_data["campaign_schedule_id"] = campaign_id
    await query.answer()
    await edit(
        query,
        "⏰ <b>زمان‌بندی کمپین</b>\n\n"
        "زمان محلی تهران و اولویت را بفرستید:\n"
        "<code>2026-08-01 21:30 | 3</code>\n\n"
        "اولویت از ۱ تا ۵ است. برای انتشار چند دقیقه بعد نیز می‌توانید بنویسید:\n"
        "<code>15 | 5</code>",
        back(f"campaign_view:{campaign_id}"),
    )
    return CAMPAIGN_SCHEDULE_INPUT


async def campaign_schedule_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return ConversationHandler.END
    campaign_id = str(context.user_data.get("campaign_schedule_id") or "")
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|")]
    if not campaign_id or not 1 <= len(parts) <= 2:
        await reply(update, "❌ اطلاعات زمان‌بندی ناقص است.")
        return CAMPAIGN_SCHEDULE_INPUT
    try:
        priority = int(parts[1]) if len(parts) == 2 else 3
        if not 1 <= priority <= 5:
            raise ValueError("اولویت باید بین ۱ تا ۵ باشد.")
        if parts[0].isdigit():
            minutes = int(parts[0])
            if not 1 <= minutes <= 525_600:
                raise ValueError("فاصله زمانی باید بین ۱ دقیقه تا یک سال باشد.")
            scheduled_at = utc_now() + timedelta(minutes=minutes)
        else:
            local = datetime.strptime(parts[0], "%Y-%m-%d %H:%M").replace(
                tzinfo=ZoneInfo("Asia/Tehran")
            )
            scheduled_at = local.astimezone(UTC)
        campaign = await async_with_db(
            lambda db: schedule_campaign(
                db,
                campaign_id,
                scheduled_at,
                actor_id=update.effective_user.id,
                priority=priority,
            )
        )
        await async_with_db(
            lambda db: audit(
                db,
                update.effective_user.id,
                "campaign_scheduled",
                f"{campaign_id}:{campaign.get('scheduled_for')}:p{priority}",
            )
        )
    except (ValueError, TypeError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CAMPAIGN_SCHEDULE_INPUT
    context.user_data.pop("campaign_schedule_id", None)
    await reply(
        update,
        "✅ کمپین زمان‌بندی شد.\n\n"
        f"زمان UTC: <code>{esc(campaign.get('scheduled_for'))}</code>\n"
        f"اولویت: <b>{priority}</b>\n"
        "در خرابی موقت، ارسال با Backoff نمایی دوباره تلاش می‌شود.",
        [[InlineKeyboardButton("مشاهده کمپین", callback_data=f"campaign_view:{campaign_id}")], back("a_campaigns")[0]],
    )
    return ConversationHandler.END


async def campaign_detail_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return
    query = update.callback_query
    campaign_id = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    campaign = campaign_by_id(db, campaign_id)
    if campaign is None:
        await query.answer("کمپین پیدا نشد.", show_alert=True)
        return
    await query.answer()
    primary_actions = [
        InlineKeyboardButton("📊 گزارش", callback_data=f"campaign_report:{campaign['id']}")
    ]
    if PERMISSION_CHANNEL_ATTRIBUTION in (await run_blocking(_admin_granted_permissions, query.from_user.id)):
        primary_actions.append(
            InlineKeyboardButton("🔗 لینک جذب", callback_data=f"campaign_link:{campaign['id']}")
        )
    rows: list[list[InlineKeyboardButton]] = [primary_actions]
    if campaign.get("status") == "draft" and campaign.get("delivery") != "draft":
        rows.append(
            [
                InlineKeyboardButton("🔎 انتشار اکنون", callback_data=f"campaign_preview:{campaign['id']}"),
                InlineKeyboardButton("⏰ زمان‌بندی", callback_data=f"campaign_schedule:{campaign['id']}"),
            ]
        )
    if campaign.get("status") == "scheduled":
        rows.append(
            [
                InlineKeyboardButton("🚀 انتشار اکنون", callback_data=f"campaign_preview:{campaign['id']}"),
                InlineKeyboardButton("🕒 تغییر زمان", callback_data=f"campaign_schedule:{campaign['id']}"),
            ]
        )
    if campaign.get("status") == "paused":
        rows.append([InlineKeyboardButton("▶️ ادامه کمپین", callback_data=f"campaign_status:{campaign['id']}:active")])
    if campaign.get("status") == "draft" and campaign.get("delivery") == "draft":
        rows.append(
            [InlineKeyboardButton("➕ ساخت کمپین لینک‌محور جدید", callback_data="campaign_new")]
        )
    if campaign.get("status") == "active":
        rows.append([InlineKeyboardButton("⏸ توقف کمپین", callback_data=f"campaign_status:{campaign['id']}:paused")])
    if campaign.get("status") not in {"completed", "cancelled", "archived"}:
        rows.append(
            [
                InlineKeyboardButton("✅ تکمیل", callback_data=f"campaign_status:{campaign['id']}:completed"),
                InlineKeyboardButton("❌ لغو", callback_data=f"campaign_status:{campaign['id']}:cancelled"),
            ]
        )
    rows.extend([[InlineKeyboardButton("🔄 تازه‌سازی", callback_data=f"campaign_view:{campaign['id']}")], back("a_campaigns")[0]])
    await edit(query, _campaign_detail_text(db, campaign), rows)


async def campaign_preview_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return
    query = update.callback_query
    campaign_id = str(query.data).split(":", 1)[1]
    try:
        preview = await async_with_db(lambda db: campaign_preview(db, campaign_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    campaign = preview["campaign"]
    await query.answer()
    await edit(
        query,
        "🔎 <b>پیش‌نمایش نهایی کمپین</b>\n\n"
        f"نام: <b>{esc(campaign.get('name'))}</b>\n"
        f"مخاطبان تخمینی: <b>{int(preview['audience_size']):,}</b>\n"
        f"مسیر انتشار: <b>{esc(campaign.get('delivery'))}</b>\n\n"
        f"{esc(preview['delivery_text'])}\n\n"
        "ارسال این نسخه در برابر لمس یا درخواست تکراری محافظت شده است.",
        [
            [InlineKeyboardButton("✅ تأیید و انتشار", callback_data=f"campaign_dispatch:{campaign_id}")],
            [InlineKeyboardButton("⏰ زمان‌بندی انتشار", callback_data=f"campaign_schedule:{campaign_id}")],
            [InlineKeyboardButton("↩️ بازگشت بدون انتشار", callback_data=f"campaign_view:{campaign_id}")],
        ],
    )


async def campaign_dispatch_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return
    query = update.callback_query
    campaign_id = str(query.data).split(":", 1)[1]
    try:
        result = await _dispatch_marketing_campaign(context, campaign_id, query.from_user.id)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    if result.get("duplicate"):
        await query.answer("این نسخه قبلاً منتشر یا در حال انتشار است؛ ارسال تکراری انجام نشد.", show_alert=True)
    else:
        await query.answer(
            f"ارسال انجام شد؛ خطا: {len(result.get('errors', []))}",
            show_alert=True,
        )
    campaign = campaign_by_id(await async_snapshot(), campaign_id)
    if campaign is not None:
        await edit(
            query,
            _campaign_detail_text(await async_snapshot(), campaign),
            [[InlineKeyboardButton("📊 گزارش و جزئیات", callback_data=f"campaign_view:{campaign_id}")], back("a_campaigns")[0]],
        )


async def campaign_set_delivery_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return
    query = update.callback_query
    _, campaign_id, delivery = str(query.data).split(":", 2)
    try:
        await async_with_db(
            lambda db: set_campaign_delivery(
                db,
                campaign_id,
                delivery,
                actor_id=query.from_user.id,
            )
        )
        preview = await async_with_db(lambda db: campaign_preview(db, campaign_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("مسیر انتشار ثبت شد؛ پیش‌نمایش را تأیید کنید.", show_alert=True)
    await edit(
        query,
        "🔎 <b>پیش‌نمایش نهایی کمپین</b>\n\n"
        f"مخاطبان تخمینی: <b>{int(preview['audience_size']):,}</b>\n"
        f"مسیر انتشار: <b>{esc(delivery)}</b>\n\n"
        f"{esc(preview['delivery_text'])}\n\n"
        "با تأیید، این نسخه فقط یک‌بار صف‌بندی یا منتشر می‌شود.",
        [
            [InlineKeyboardButton("✅ تأیید و انتشار", callback_data=f"campaign_dispatch:{campaign_id}")],
            [InlineKeyboardButton("⏰ زمان‌بندی انتشار", callback_data=f"campaign_schedule:{campaign_id}")],
            [InlineKeyboardButton("↩️ بازگشت به کمپین", callback_data=f"campaign_view:{campaign_id}")],
        ],
    )


async def campaign_status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return
    query = update.callback_query
    _, campaign_id, status = str(query.data).split(":", 2)
    try:
        await async_with_db(
            lambda db: set_campaign_status(db, campaign_id, status, actor_id=query.from_user.id)
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("وضعیت کمپین بروزرسانی شد.", show_alert=True)
    campaign = campaign_by_id(await async_snapshot(), campaign_id)
    if campaign is not None:
        await edit(
            query,
            _campaign_detail_text(await async_snapshot(), campaign),
            [[InlineKeyboardButton("📊 گزارش و جزئیات", callback_data=f"campaign_view:{campaign_id}")], back("a_campaigns")[0]],
        )


async def campaign_report_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CAMPAIGNS):
        return
    query = update.callback_query
    campaign_id = str(query.data).split(":", 1)[1]
    try:
        report = marketing_campaign_report(await async_snapshot(), campaign_id)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    campaign = report["campaign"]
    await query.answer()
    await edit(
        query,
        f"📊 <b>گزارش کمپین {esc(campaign.get('name'))}</b>\n\n"
        f"مخاطب هدف: <b>{report['audience_size']:,}</b>\n"
        f"ارسال مستقیم موفق: <b>{report['sent']:,}</b> | ناموفق: <b>{report['failed']:,}</b> | مسدود: <b>{report['blocked']:,}</b>\n"
        f"لینک‌های قابل‌اندازه‌گیری: <b>{report['tracking_links']}</b> | ورودی یکتا: <b>{report['tracked_visits']:,}</b>\n"
        f"ورودی کانال: <b>{report['channel_joins']:,}</b> | اعضای منتسب فعال: <b>{report['active_attributed_members']:,}</b>\n"
        f"خرید تأییدشده: <b>{report['approved_orders']:,}</b>\n"
        f"نرخ تبدیل: <b>{report['conversion_rate']:.2f}٪</b>\n"
        f"درآمد منتسب: <b>{report['revenue']:,}</b> تومان\n"
        f"هزینه: <b>{report['cost']:,}</b> تومان | CAC: <b>{report['cac']:,.0f}</b>\n"
        f"ROAS: <b>{report['roas']:.2f}x</b> | ROI: <b>{report['roi']:.1f}٪</b>\n"
        f"تخفیف اعطاشده: <b>{report['discount_total']:,}</b> تومان",
        [[InlineKeyboardButton("🔄 تازه‌سازی", callback_data=f"campaign_report:{campaign_id}")], back(f"campaign_view:{campaign_id}")[0]],
    )


async def campaign_tracking_link_create(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CHANNEL_ATTRIBUTION):
        return
    query = update.callback_query
    campaign_id = str(query.data).split(":", 1)[1]
    campaign = campaign_by_id(await async_snapshot(), campaign_id)
    if campaign is None:
        await query.answer("کمپین پیدا نشد.", show_alert=True)
        return
    if not SETTINGS.public_channel_id:
        await query.answer("PUBLIC_CHANNEL_ID تنظیم نشده است.", show_alert=True)
        return
    try:
        invite = await context.bot.create_chat_invite_link(
            chat_id=SETTINGS.public_channel_id,
            name=str(campaign.get("name") or "SENTINEL campaign")[:32],
        )

        def store(db: dict[str, Any]) -> dict[str, Any]:
            link = register_public_channel_link(
                db,
                name=f"{campaign.get('name')} / campaign",
                invite_link=invite.invite_link,
                created_by=query.from_user.id,
                channel_id=SETTINGS.public_channel_id,
                campaign_id=campaign_id,
                advertiser="SENTINEL",
                source="campaign",
                medium="telegram_invite",
                creative=str(campaign.get("name") or "")[:120],
            )
            row = campaign_by_id(db, campaign_id)
            if row is not None and link["id"] not in row.setdefault("tracking_link_ids", []):
                row["tracking_link_ids"].append(link["id"])
                row["updated_at"] = utc_iso()
            audit(db, query.from_user.id, "campaign_tracking_link", f"{campaign_id}:{link['id']}")
            return link

        link = await async_with_db(store)
    except TelegramError as exc:
        await query.answer(f"ساخت لینک ناموفق بود: {exc}", show_alert=True)
        return
    await query.answer("لینک اختصاصی کمپین ساخته شد.", show_alert=True)
    await edit(
        query,
        f"🔗 <b>لینک جذب کمپین ساخته شد</b>\n\n"
        f"نام: <b>{esc(link['name'])}</b>\n"
        f"لینک: {esc(link['invite_link'])}\n\n"
        "ورود، خروج، عضو فعال، ثبت‌نام و خریدهای پس از ورود از این لینک در گزارش ثبت می‌شوند.",
        [
            [InlineKeyboardButton("📊 گزارش لینک", callback_data=f"channel_link_view:{link['id']}")],
            back(f"campaign_view:{campaign_id}")[0],
        ],
    )


async def channel_attribution_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CHANNEL_ATTRIBUTION):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    links = await async_read_db_section("public_channel_links")
    summary = public_channel_attribution_summary({"public_channel_links": links})
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton("➕ ساخت لینک جدید", callback_data="channel_link_new")],
        [InlineKeyboardButton("📈 Growth Link Lab", callback_data="a_growth_link_lab")],
    ]
    for link in summary.get("latest", [])[:10]:
        status = "🟢" if link.get("status") == "active" else "⚪"
        rows.append(
            [
                InlineKeyboardButton(
                    f"{status} {str(link.get('name') or '')[:24]} • {int(link.get('unique_join_count', 0) or 0)}",
                    callback_data=f"channel_link_view:{link.get('id')}",
                )
            ]
        )
    if PERMISSION_CAMPAIGNS in (await run_blocking(_admin_granted_permissions, query.from_user.id)):
        rows.append([InlineKeyboardButton("🚀 استودیو کمپین", callback_data="a_campaigns")])
    rows.append(back("admin_cat:sales")[0])
    await edit(
        query,
        "🔗 <b>لینک‌های جذب کانال عمومی</b>\n\n"
        f"کل لینک‌ها: <b>{summary['total_links']}</b> | فعال: <b>{summary['active_links']}</b>\n"
        f"کل ورود: <b>{summary['total_joins']:,}</b> | کاربران یکتا: <b>{summary['unique_joins']:,}</b>\n"
        f"اعضای منتسب فعال: <b>{summary['active_members']:,}</b> | خروج: <b>{summary['leaves']:,}</b>\n\n"
        "هر لینک نام مستقل دارد و نتیجه جذب آن جداگانه اندازه‌گیری می‌شود.",
        rows,
    )
    return ConversationHandler.END


async def growth_link_lab_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CHANNEL_ATTRIBUTION):
        return
    query = update.callback_query
    data = str(query.data or "")
    model = data.split(":", 1)[1] if data.startswith("growth_model:") else "last_touch"
    try:
        section_names = (
            "public_channel_links",
            "public_channel_link_events",
            "vip_orders",
            "marketing_campaigns",
        )
        section_values = await asyncio.gather(
            *(async_read_db_section(name) for name in section_names)
        )
        lab = growth_link_lab(
            dict(zip(section_names, section_values, strict=True)),
            attribution_model=model,
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    totals = lab["totals"]
    lines = [
        "📈 <b>Growth Link Lab</b>",
        "",
        f"مدل انتساب: <b>{'آخرین تماس' if model == 'last_touch' else 'اولین تماس'}</b>",
        f"لینک‌ها: <b>{int(totals.get('links', 0)):,}</b> | جذب یکتا: <b>{int(totals.get('unique_joins', 0)):,}</b>",
        f"خرید منتسب: <b>{int(totals.get('approved_orders', 0)):,}</b>",
        f"هزینه: <b>{int(totals.get('cost', 0)):,}</b> تومان",
        f"درآمد واقعی: <b>{int(totals.get('revenue', 0)):,}</b> تومان",
        f"ROAS: <b>{float(totals.get('roas', 0)):.2f}x</b> | ROI: <b>{float(totals.get('roi', 0)):.2f}٪</b>",
        f"CAC: <b>{float(totals.get('cac', 0)):,.0f}</b> | هزینه هر جذب: <b>{float(totals.get('cost_per_join', 0)):,.0f}</b>",
        "",
        "🏆 <b>بهترین لینک‌ها</b>",
    ]
    for index, row in enumerate(lab.get("links", [])[:5], start=1):
        lines.append(
            f"{index}. <b>{esc(row.get('name'))}</b> — "
            f"{int(row.get('unique_joins', 0)):,} جذب | "
            f"{int(row.get('approved_orders', 0)):,} خرید | "
            f"{int(row.get('revenue', 0)):,} تومان"
        )
    lines.extend(["", "📣 <b>تبلیغ‌کننده‌ها</b>"])
    for row in lab.get("advertisers", [])[:4]:
        lines.append(
            f"• {esc(row.get('name'))}: {int(row.get('unique_joins', 0)):,} جذب | "
            f"ROAS {float(row.get('roas', 0)):.2f}x"
        )
    lines.extend(["", "🧭 <b>منابع ورودی</b>"])
    for row in lab.get("sources", [])[:4]:
        lines.append(
            f"• {esc(row.get('name'))}: {int(row.get('approved_orders', 0)):,} خرید | "
            f"{int(row.get('revenue', 0)):,} تومان"
        )
    rows = [
        [
            InlineKeyboardButton(
                "✅ آخرین تماس" if model == "last_touch" else "آخرین تماس",
                callback_data="growth_model:last_touch",
            ),
            InlineKeyboardButton(
                "✅ اولین تماس" if model == "first_touch" else "اولین تماس",
                callback_data="growth_model:first_touch",
            ),
        ],
        [InlineKeyboardButton("🔄 تازه‌سازی", callback_data=f"growth_model:{model}")],
        back("a_channel_attribution")[0],
    ]
    await query.answer()
    await edit(query, "\n".join(lines)[:3900], rows)


async def channel_link_create_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CHANNEL_ATTRIBUTION):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "➕ <b>ساخت لینک جذب کانال</b>\n\n"
        "قالب حرفه‌ای:\n"
        "<code>نام | تبلیغ‌کننده | منبع | رسانه | خلاقه | هزینه | سقف عضو | اعتبار روز</code>\n\n"
        "مثال:\n<code>اینستاگرام مرداد | Agency A | instagram | story | video-01 | 5000000 | 0 | 30</code>\n\n"
        "قالب ساده قبلی نیز معتبر است:\n<code>نام لینک | سقف عضو | اعتبار روز</code>",
        back("a_channel_attribution"),
    )
    return CHANNEL_LINK_INPUT


async def channel_link_create_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CHANNEL_ATTRIBUTION):
        return ConversationHandler.END
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|")]
    if len(parts) not in {3, 8}:
        await reply(
            update,
            "❌ قالب صحیح: <code>نام | تبلیغ‌کننده | منبع | رسانه | خلاقه | هزینه | سقف عضو | اعتبار روز</code>",
        )
        return CHANNEL_LINK_INPUT
    name = " ".join(parts[0].split())
    advertiser = ""
    source = name
    medium = "telegram_invite"
    creative = ""
    cost = 0
    try:
        if len(parts) == 8:
            advertiser, source, medium, creative = parts[1:5]
            cost, member_limit, days = int(parts[5]), int(parts[6]), int(parts[7])
        else:
            member_limit, days = int(parts[1]), int(parts[2])
    except ValueError:
        await reply(update, "❌ هزینه، سقف عضو و اعتبار روز باید عدد صحیح باشند.")
        return CHANNEL_LINK_INPUT
    if (
        not 3 <= len(name) <= 80
        or not 0 <= cost <= 10**15
        or not 0 <= member_limit <= 99_999
        or not 0 <= days <= 3650
    ):
        await reply(update, "❌ نام ۳ تا ۸۰ نویسه، هزینه مثبت، سقف عضو ۰ تا ۹۹٬۹۹۹ و اعتبار ۰ تا ۳۶۵۰ روز باشد.")
        return CHANNEL_LINK_INPUT
    if not SETTINGS.public_channel_id:
        await reply(update, "❌ PUBLIC_CHANNEL_ID تنظیم نشده است.", back("a_channel_attribution"))
        return ConversationHandler.END
    kwargs: dict[str, Any] = {
        "chat_id": SETTINGS.public_channel_id,
        "name": name[:32],
    }
    expiry: datetime | None = None
    if member_limit:
        kwargs["member_limit"] = member_limit
    if days:
        expiry = utc_now() + timedelta(days=days)
        kwargs["expire_date"] = expiry
    try:
        invite = await context.bot.create_chat_invite_link(**kwargs)
        link = await async_with_db(
            lambda db: register_public_channel_link(
                db,
                name=name,
                invite_link=invite.invite_link,
                created_by=update.effective_user.id,
                channel_id=SETTINGS.public_channel_id,
                expires_at=expiry,
                member_limit=member_limit,
                advertiser=advertiser,
                source=source,
                medium=medium,
                creative=creative,
                cost=cost,
            )
        )
        await async_with_db(
            lambda db: audit(db, update.effective_user.id, "public_channel_link_created", str(link["id"]))
        )
    except TelegramError as exc:
        await reply(update, f"❌ ساخت لینک در تلگرام ناموفق بود: {esc(exc)}", back("a_channel_attribution"))
        return ConversationHandler.END
    await reply(
        update,
        f"✅ <b>لینک جذب ساخته شد</b>\n\n"
        f"نام: <b>{esc(link['name'])}</b>\n"
        f"تبلیغ‌کننده: <b>{esc(link.get('advertiser') or '—')}</b>\n"
        f"منبع/رسانه: <b>{esc(link.get('source') or '—')} / {esc(link.get('medium') or '—')}</b>\n"
        f"هزینه: <b>{int(link.get('cost', 0) or 0):,}</b> تومان\n"
        f"لینک: {esc(link['invite_link'])}",
        [[InlineKeyboardButton("📊 مشاهده گزارش", callback_data=f"channel_link_view:{link['id']}")], back("a_channel_attribution")[0]],
    )
    return ConversationHandler.END


async def channel_link_detail_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CHANNEL_ATTRIBUTION):
        return
    query = update.callback_query
    link_id = str(query.data).split(":", 1)[1]
    try:
        report = public_channel_link_report(await async_snapshot(), link_id)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    link = report["link"]
    await query.answer()
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton("🔄 تازه‌سازی گزارش", callback_data=f"channel_link_view:{link['id']}")]
    ]
    if link.get("status") == "active":
        rows.append([InlineKeyboardButton("⛔ لغو لینک", callback_data=f"channel_link_revoke:{link['id']}")])
    rows.append(back("a_channel_attribution")[0])
    await edit(
        query,
        f"🔗 <b>{esc(link.get('name'))}</b>\n\n"
        f"وضعیت: <b>{'فعال' if link.get('status') == 'active' else 'لغوشده'}</b>\n"
        f"لینک: {esc(link.get('invite_link'))}\n"
        f"کمپین: <code>{esc(link.get('campaign_id') or '—')}</code>\n\n"
        f"تبلیغ‌کننده: <b>{esc(link.get('advertiser') or '—')}</b>\n"
        f"منبع/رسانه: <b>{esc(link.get('source') or '—')} / {esc(link.get('medium') or '—')}</b>\n"
        f"خلاقه: <b>{esc(link.get('creative') or '—')}</b> | هزینه: <b>{int(link.get('cost', 0) or 0):,}</b> تومان\n\n"
        f"کل ورود: <b>{int(link.get('join_count', 0) or 0):,}</b>\n"
        f"کاربر یکتا: <b>{report['unique_users']:,}</b> | ورود مجدد: <b>{int(link.get('rejoin_count', 0) or 0):,}</b>\n"
        f"عضو منتسب فعال: <b>{int(link.get('active_members', 0) or 0):,}</b> | خروج: <b>{int(link.get('leave_count', 0) or 0):,}</b>\n"
        f"کاربر ثبت‌شده ربات: <b>{report['registered_users']:,}</b> ({report['registration_rate']:.2f}٪)\n"
        f"خرید تأییدشده: <b>{report['approved_orders']:,}</b> ({report['purchase_rate']:.2f}٪)\n"
        f"پنجره انتساب خرید: <b>{report['attribution_window_days']} روز</b>\n"
        f"درآمد منتسب: <b>{report['revenue']:,}</b> تومان",
        rows,
    )


async def channel_link_revoke_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CHANNEL_ATTRIBUTION):
        return
    query = update.callback_query
    link_id = str(query.data).split(":", 1)[1]
    link = channel_link_by_id(await async_snapshot(), link_id)
    if link is None:
        await query.answer("لینک پیدا نشد.", show_alert=True)
        return
    try:
        await context.bot.revoke_chat_invite_link(
            chat_id=int(link.get("channel_id") or SETTINGS.public_channel_id),
            invite_link=str(link["invite_link"]),
        )
        await async_with_db(
            lambda db: mark_public_channel_link_revoked(db, link_id, actor_id=query.from_user.id)
        )
    except TelegramError as exc:
        await query.answer(f"لغو لینک ناموفق بود: {exc}", show_alert=True)
        return
    await query.answer("لینک لغو شد.", show_alert=True)
    await edit(
        query,
        "⛔ <b>لینک لغو شد</b>\n\nاین لینک دیگر عضو جدید نمی‌پذیرد و آمار قبلی آن برای گزارش‌گیری حفظ شده است.",
        [[InlineKeyboardButton("📊 گزارش نهایی لینک", callback_data=f"channel_link_view:{link_id}")], back("a_channel_attribution")[0]],
    )


def _chat_member_is_active(member: Any) -> bool:
    status = str(getattr(member, "status", "") or "")
    if status in {"member", "administrator", "creator", "owner"}:
        return True
    return status == "restricted" and bool(getattr(member, "is_member", False))


async def public_channel_membership_update(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    membership = update.chat_member
    if membership is None or not SETTINGS.public_channel_id:
        return
    if int(membership.chat.id) != int(SETTINGS.public_channel_id):
        return
    old_active = _chat_member_is_active(membership.old_chat_member)
    new_active = _chat_member_is_active(membership.new_chat_member)
    if old_active == new_active:
        return
    user_id = membership.new_chat_member.user.id
    invite_link = ""
    if new_active and membership.invite_link:
        invite_link = str(membership.invite_link.invite_link or "")

    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        result = record_public_channel_membership(
            db,
            user_id=user_id,
            joined=new_active,
            invite_link=invite_link,
        )
        link = result.get("link")
        if result.get("recorded") and isinstance(link, dict) and link.get("campaign_id"):
            record_campaign_touch(
                db,
                str(link["campaign_id"]),
                user_id,
                "channel_join" if new_active else "channel_leave",
                metadata={"link_id": link.get("id")},
            )
        return result

    result = await async_with_db(mutate)
    if result.get("recorded"):
        metric_increment("public_channel_membership_attributed")


async def retention_center_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RETENTION):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    candidates = retention_candidates(db)
    summary = retention_summary(db)
    settings = retention_settings(db)
    reasons: dict[str, int] = {}
    for row in candidates:
        reasons[str(row.get("reason"))] = reasons.get(str(row.get("reason")), 0) + 1
    labels = {"vip_expiring": "VIP رو به پایان", "inactive_vip": "VIP غیرفعال", "abandoned_checkout": "خرید رهاشده"}
    details = "\n".join(f"• {labels.get(key, key)}: <b>{value}</b>" for key, value in reasons.items()) or "• مورد جدیدی شناسایی نشد"
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton("🔍 شناسایی و صف‌بندی", callback_data="retention_run")],
        [state_button("ارسال خودکار نگهداشت", bool(settings.get("auto_send")), callback_data="retention_toggle_auto")],
    ]
    for candidate in candidates[:12]:
        uid = str(candidate.get("user_id") or "")
        if not uid:
            continue
        user = db.get("users", {}).get(uid, {})
        name = str(user.get("first_name") or user.get("username") or uid)
        reason = labels.get(str(candidate.get("reason")), str(candidate.get("reason") or "پیگیری"))
        rows.append([InlineKeyboardButton(f"👤 {name} · {reason}"[:64], callback_data=f"crm_open:{uid}")])
    rows.append(back("admin_cat:sales")[0])
    await edit(
        query,
        "🎯 <b>مرکز نگهداشت مشتری</b>\n\n"
        f"کاندید فعلی: <b>{len(candidates)}</b>\n"
        f"رویداد در صف: <b>{summary['pending']}</b> | ارسال‌شده: <b>{summary['sent']}</b> | ناموفق: <b>{summary['failed']}</b>\n"
        f"تبدیل به خرید: <b>{summary['converted']}</b> ({summary['conversion_rate']:.1f}٪) | ارزش: <b>{summary['conversion_value']:,}</b>\n"
        f"ارسال خودکار: <b>{'فعال' if settings.get('auto_send') else 'غیرفعال'}</b>\n\n{details}\n\n"
        "هر کاربر را باز کنید تا سابقه، مرحله CRM، یادداشت، پیام مستقیم، پیگیری و کد تخفیف را بررسی کنید.",
        rows,
    )


async def retention_run(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RETENTION):
        return
    query = update.callback_query
    created = await async_with_db(queue_retention_events)
    await query.answer(f"{len(created)} رویداد جدید وارد صف شد.", show_alert=True)
    await retention_center_view(update, context)


async def retention_toggle_auto(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RETENTION):
        return
    query = update.callback_query

    def mutate(db: dict[str, Any]) -> bool:
        settings = retention_settings(db)
        settings["auto_send"] = not bool(settings.get("auto_send", False))
        set_control_value(
            db,
            "retention",
            "auto_send",
            settings["auto_send"],
            query.from_user.id,
        )
        audit(
            db,
            query.from_user.id,
            "retention_auto_send",
            str(settings["auto_send"]),
        )
        return bool(settings["auto_send"])

    enabled = await async_with_db(mutate)
    await query.answer("ارسال خودکار فعال شد." if enabled else "ارسال خودکار متوقف شد.", show_alert=True)
    await retention_center_view(update, context)


async def capability_matrix_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CAPABILITIES):
        return
    query = update.callback_query
    await query.answer()
    counts = capability_summary()
    lines = ["🧩 <b>ماتریس وضعیت قابلیت‌ها</b>", ""]
    for key, label in CAPABILITY_LABELS.items():
        lines.append(f"• {esc(label)}: <b>{int(counts.get(key, 0))}</b>")
    lines.extend(["", "در صفحه هر ماژول، قابلیت‌های نیازمند تنظیم یا آزمایشی با وضعیت مشخص نمایش داده می‌شوند؛ گزینه‌های برنامه‌ریزی‌شده نباید به‌عنوان قابلیت عملیاتی استفاده شوند."])
    await edit(query, "\n".join(lines), [[InlineKeyboardButton("🧭 مرکز کنترل", callback_data="a_control_center")], back("admin_cat:system")[0]])


async def signal_tracking_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    settings = (await async_snapshot()).get("settings", {}).get("signalTracking", {})
    enabled = bool(settings.get("enabled", True))
    auto_publish = bool(settings.get("auto_publish", False))
    supported = "XAUUSD، XAGUSD، EURUSD، GBPUSD، USDJPY، BTC/ETH، US100، GER40، US500"
    rows = [
        [state_button("ردیابی خودکار", enabled, callback_data="sig_tracking_toggle:enabled")],
        [state_button("انتشار خودکار", auto_publish, callback_data="sig_tracking_toggle:auto_publish")],
        [InlineKeyboardButton("🔍 بررسی همین حالا", callback_data="sig_tracking_run", style="primary")],
        back("a_signal_results")[0],
    ]
    await edit(
        query,
        "🤖 <b>ردیابی خودکار سیگنال</b>\n\n"
        f"ردیابی: <b>{'فعال' if enabled else 'غیرفعال'}</b>\n"
        f"انتشار خودکار نتیجه: <b>{'فعال' if auto_publish else 'نیازمند تأیید ادمین'}</b>\n"
        f"نمادهای پشتیبانی‌شده: <code>{supported}</code>\n\n"
        "برای جلوگیری از نتیجه اشتباه، حالت پیش‌فرض فقط پیشنهاد نتیجه به ادمین است.",
        rows,
    )


async def signal_tracking_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    key = query.data.split(":", 1)[1]

    def toggle(db: dict[str, Any]) -> bool:
        settings = db.setdefault("settings", {}).setdefault("signalTracking", {})
        settings[key] = not bool(settings.get(key, key == "enabled"))
        settings["updated_at"] = utc_iso()
        return bool(settings[key])

    value = await async_with_db(toggle)
    await query.answer("فعال شد" if value else "غیرفعال شد", show_alert=True)
    await signal_tracking_panel(update, context)


async def _run_signal_tracking(context: ContextTypes.DEFAULT_TYPE) -> int:
    expired_rows = await async_with_db(expire_due_signals)
    for expired_row in expired_rows:
        await run_blocking(project_signal_update, expired_row, "signal.expired", timeout=20)
        try:
            await _refresh_signal_channel_messages(context.bot, expired_row)
            await _publish_signal_update(context.bot, expired_row, _signal_result_message(expired_row))
        except TelegramError:
            logger.warning("Could not publish expired signal update for %s", expired_row.get("id"))
    db = await async_snapshot()
    settings = db.get("settings", {}).get("signalTracking", {})
    if not settings.get("enabled", True):
        return 0
    normalized_symbols: set[str] = set()
    for row in db.get("signals", []):
        if not isinstance(row, dict) or str(row.get("status") or "open") in FINAL_SIGNAL_STATUSES:
            continue
        raw_symbol = str(row.get("market_symbol") or row.get("symbol") or "")
        if not raw_symbol:
            continue
        try:
            normalized_symbols.add(normalize_tracking_symbol(raw_symbol))
        except ValueError:
            logger.warning("Unsupported signal tracking symbol: %s", raw_symbol)
    ranges = await fetch_ranges(normalized_symbols, concurrency=4)
    market_ranges = {symbol: value.as_dict() for symbol, value in ranges.items()}
    proposals = await async_with_db(lambda database: store_tracking_proposals(database, tracking_candidates(database, market_ranges)))
    auto_publish = bool(settings.get("auto_publish", False))
    for proposal in proposals:
        if auto_publish and proposal.get("auto_publish_safe", not proposal.get("ambiguous")):
            row = await async_with_db(
                lambda database, item=proposal: set_signal_lifecycle(
                    database,
                    item["signal_id"],
                    item["event"],
                    "auto",
                    price=item["price"],
                    source="price_tracker",
                )
            )
            await run_blocking(project_signal_update, row, "signal.tracker_updated", timeout=20)
            await _refresh_signal_channel_messages(context.bot, row)
            await _publish_signal_update(context.bot, row, _signal_result_message(row))
        else:
            keyboard = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "✅ ثبت نتیجه",
                            callback_data=f"sig_track_accept:{proposal['signal_id']}:{proposal['event']}",
                        ),
                        InlineKeyboardButton(
                            "❌ رد پیشنهاد",
                            callback_data=f"sig_track_reject:{proposal['signal_id']}:{proposal['event']}",
                        ),
                    ]
                ]
            )
            for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_SIGNAL_STATUS_MANAGE)):
                try:
                    await _telegram_request_with_button_fallback(
                        context.bot.send_message,
                        admin_id,
                        "🤖 <b>پیشنهاد ردیاب قیمت</b>\n"
                        f"سیگنال: <code>#{proposal.get('display_number', proposal['signal_id'])}</code> | {esc(proposal['symbol'])}\n"
                        f"بازه: <code>{proposal['low']} — {proposal['high']}</code> | بسته‌شدن: <code>{proposal['price']}</code>\n"
                        f"منبع: <code>{esc(proposal.get('source'))}</code>\n"
                        f"رویداد پیشنهادی: <b>{esc(signal_status_label(proposal['event']))}</b>"
                        + (
                            f"\n📦 ورودهای پرشده: <code>{esc('، '.join(proposal.get('filled_entries', [])))}</code> | <b>{float(proposal.get('filled_percent', 0) or 0):.0f}%</b>"
                            if proposal.get("filled_entries")
                            else ""
                        )
                        + ("\n⚠️ در یک کندل چند سطح لمس شده؛ تأیید دستی الزامی است." if proposal.get("ambiguous") else "")
                        + ("\n⚠️ داده فقط Snapshot/Fallback است؛ انتشار خودکار غیرفعال شد." if proposal.get("snapshot") else "")
                        + (
                            "\n⚠️ داده منبع قدیمی یا کم‌اعتماد است؛ نتیجه را دستی بررسی کنید."
                            if proposal.get("stale") and not proposal.get("snapshot")
                            else ""
                        ),
                        parse_mode=ParseMode.HTML,
                        reply_markup=keyboard,
                    )
                except TelegramError:
                    pass
    return len(proposals)


async def signal_tracking_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        await _run_signal_tracking(context)
    except Exception:
        logger.exception("Signal tracking cycle failed")


async def signal_tracking_run(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer("در حال بررسی…")
    count = await _run_signal_tracking(context)
    await query.answer(f"{count} رویداد جدید پیدا شد", show_alert=True)


async def signal_tracking_decision(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    action, signal_id_text, event = query.data.split(":", 2)
    if action.endswith("reject"):
        await async_with_db(
            lambda db: resolve_tracking_proposal(
                db,
                int(signal_id_text),
                event,
                status="rejected",
                admin_id=query.from_user.id,
            )
        )
        await mark_callback_message(query, "❌ پیشنهاد رد شد")
        return
    try:
        row = await async_with_db(
            lambda db: (
                resolve_tracking_proposal(
                    db,
                    int(signal_id_text),
                    event,
                    status="accepted",
                    admin_id=query.from_user.id,
                ),
                set_signal_lifecycle(db, int(signal_id_text), event, query.from_user.id, source="tracker_confirmed"),
            )[1]
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await _refresh_signal_channel_messages(context.bot, row)
    await run_blocking(project_signal_update, row, "signal.tracker_confirmed", timeout=20)
    await _publish_signal_update(context.bot, row, _signal_result_message(row))
    await mark_callback_message(query, "✅ نتیجه ثبت شد")


async def id_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await reply(update, f"👤 User ID: <code>{update.effective_user.id}</code>\n💬 Chat ID: <code>{update.effective_chat.id}</code>")


async def heartbeat_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    await run_blocking(
        write_heartbeat,
        SETTINGS.heartbeat_file,
        status="running",
        details={"bot_username": effective_bot_username()},
        timeout=5,
        acquire_timeout=1,
    )


async def operational_backup_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    if SETTINGS.database_url:
        path = await run_blocking(
            create_postgres_dump_backup,
            SETTINGS.database_url,
            SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
            key_version=SETTINGS.backup_key_version,
            timeout_seconds=300,
            timeout=330,
        )
        drill_path = path
        drill = await run_blocking(
            run_postgres_dump_restore_drill,
            drill_path,
            SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
            decryption_keys=SETTINGS.backup_previous_keys,
            timeout=150,
        )
    else:
        path = await run_blocking(
            create_operational_backup,
            SETTINGS.db_file,
            SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
            key_version=SETTINGS.backup_key_version,
            timeout=60,
        )
        drill_path = path
        if not (path.name.endswith(".json") or path.name.endswith(".json.enc")):
            snapshot_for_drill = await async_snapshot()
            drill_path = await run_blocking(
                create_payload_backup,
                snapshot_for_drill,
                SETTINGS.backup_dir,
                encryption_key=SETTINGS.backup_encryption_key,
                key_version=SETTINGS.backup_key_version,
                timeout=60,
            )
        drill = await run_blocking(
            run_payload_restore_drill,
            drill_path,
            SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
            decryption_keys=SETTINGS.backup_previous_keys,
            key_version=SETTINGS.backup_key_version,
            timeout=60,
        )
    uploaded = False
    if SETTINGS.external_backup_url:
        uploaded = await upload_external_backup(
            path,
            SETTINGS.external_backup_url,
            timeout_seconds=max(30, SETTINGS.request_timeout_seconds),
        )
    await run_blocking(prune_operational_backups, SETTINGS.backup_dir, keep=30, timeout=30)
    def record_backup(db: dict[str, Any]) -> None:
        created_at = utc_iso()
        db.setdefault("operations", {}).update(
            {
                "last_operational_backup_at": created_at,
                "last_operational_backup_file": path.name,
                "last_external_backup_uploaded": uploaded,
                "last_restore_drill_at": drill.get("tested_at"),
                "last_restore_drill_status": drill.get("restore_drill"),
                "last_restore_drill_file": drill_path.name,
            }
        )
        history = db.setdefault("backup_history", [])
        history.append(
            {
                "created_at": created_at,
                "file": path.name,
                "restore_drill": drill.get("restore_drill"),
                "external_uploaded": uploaded,
                "source": "operational_backup_job",
            }
        )
        db["backup_history"] = history[-100:]

    await async_with_db(record_backup)


async def observability_persist_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    persist_observability()


async def business_intelligence_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Refresh trust metrics and queue retention candidates without unsafe auto-send."""
    try:
        result = await async_with_db(
            lambda db: {
                "trust": refresh_trust_center(db),
                "retention_created": len(queue_retention_events(db)),
                "incidents": incident_summary(db),
            }
        )
        metric_gauge("retention_queue_created_last_run", int(result.get("retention_created", 0) or 0))
        metric_gauge("operational_incidents_open", int(result.get("incidents", {}).get("open", 0) or 0))
    except Exception as exc:
        logger.exception("Business intelligence job failed")
        error_kind = type(exc).__name__
        error_detail = repr(exc)
        try:
            await async_with_db(
                lambda db: record_incident(
                    db, source="business_intelligence_job", kind=error_kind, detail=error_detail, severity="warning"
                )
            )
        except Exception:
            logger.exception("Could not persist business intelligence incident")


async def incident_maintenance_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Escalate, notify and prune incidents instead of only storing them."""
    maintenance = await async_with_db(maintain_incidents)
    metric_gauge("incident_auto_resolved_last_run", maintenance.get("auto_resolved", 0))
    if not governance_notifications_enabled(await async_snapshot()):
        return
    claimed = await async_with_db(claim_critical_notifications)
    if not claimed:
        return
    recipients = set((await run_blocking(_admin_ids_for_permission, PERMISSION_INCIDENTS)))
    if SETTINGS.admin_ids:
        recipients.add(int(SETTINGS.admin_ids[0]))
    for row in claimed:
        delivered = False
        errors: list[str] = []
        text = (
            "🔴 <b>رخداد بحرانی SENTINEL</b>\n\n"
            f"شناسه: <code>{esc(row.get('correlation_id') or row.get('id'))}</code>\n"
            f"منبع: <b>{esc(row.get('source'))}</b>\n"
            f"نوع: <b>{esc(row.get('kind'))}</b>\n"
            f"تکرار: <b>{int(row.get('count', 1) or 1)}</b>\n"
            "جزئیات فنی با شناسهٔ رخداد در مرکز رخدادها و لاگ ثبت شده است.\n\n"
            f"راهنما: {esc(row.get('runbook'))}"
        )
        keyboard = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "👁 در حال بررسی",
                        callback_data=f"incident_ack:{row['id']}",
                    ),
                    InlineKeyboardButton(
                        "✅ حل شد",
                        callback_data=f"incident_resolve:{row['id']}",
                    ),
                ],
                [InlineKeyboardButton("🚨 مرکز رخدادها", callback_data="a_incidents")],
            ]
        )
        for admin_id in sorted(recipients):
            try:
                await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    admin_id,
                    text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=keyboard,
                )
                delivered = True
            except TelegramError as exc:
                errors.append(exc.__class__.__name__)
        await async_with_db(
            lambda db, incident_id=row["id"], ok=delivered, error=",".join(errors): mark_incident_notification(
                db,
                incident_id,
                success=ok,
                detail=error or "no_admin_recipient",
            )
        )


async def retention_delivery_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Deliver queued retention campaigns with quiet hours, retry and conversion tracking."""
    await async_with_db(queue_retention_events)
    events = await async_with_db(claim_due_retention_events)
    for event in events:
        uid = str(event.get("user_id") or "")
        if not uid.isdigit():
            await async_with_db(
                lambda db, event_id=event["id"]: mark_retention_delivery(
                    db,
                    event_id,
                    success=False,
                    error="invalid_user_id",
                )
            )
            continue
        allowed = await async_with_db(
            lambda db, user_id=uid: route_notification(
                db,
                user_id,
                "retention",
            )
        )
        if not allowed:
            await async_with_db(
                lambda db, event_id=event["id"]: mark_retention_delivery(
                    db,
                    event_id,
                    success=True,
                )
            )
            continue
        try:
            message = await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(uid),
                retention_message(event),
                reply_markup=InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("💎 مشاهده و تمدید VIP", callback_data="u_vip")],
                        [InlineKeyboardButton("👤 حساب من", callback_data="u_account")],
                    ]
                ),
            )
            await async_with_db(
                lambda db, event_id=event["id"], message_id=getattr(message, "message_id", None): mark_retention_delivery(
                    db,
                    event_id,
                    success=True,
                    message_id=message_id,
                )
            )
        except TelegramError as exc:
            await async_with_db(
                lambda db, event_id=event["id"], error=exc.__class__.__name__: (
                    mark_retention_delivery(
                        db,
                        event_id,
                        success=False,
                        error=error,
                    ),
                    record_incident(
                        db,
                        source="retention_delivery",
                        kind=error,
                        detail=f"event={event_id}",
                        severity="warning",
                    ),
                )
            )
    summary = await async_with_db(retention_summary)
    metric_gauge("retention_pending", int(summary.get("pending", 0) or 0))
    metric_gauge(
        "retention_conversion_rate",
        float(summary.get("conversion_rate", 0) or 0),
    )


async def user_notification_digest_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Deliver durable daily/weekly user digests with retry-safe claims."""
    claims = await async_with_db(lambda db: claim_due_user_digests(db, limit=100))
    for claim in claims:
        uid = str(claim["user_id"])
        kind = str(claim["kind"])
        period_key = str(claim["period_key"])
        try:
            db = await async_snapshot()
            payload = build_user_digest(db, uid, kind)
            text = render_user_digest(payload)
            language = str(payload.get("language") or "fa")
            markup = InlineKeyboardMarkup(
                [
                    [InlineKeyboardButton("🧭 Today" if language == "en" else "🧭 امروز من", callback_data="u_today")],
                    [InlineKeyboardButton("🔔 Notifications" if language == "en" else "🔔 مرکز اعلان‌ها", callback_data="account_notifications")],
                ]
            )
            await context.bot.send_message(
                chat_id=int(uid),
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
            )
        except Exception as exc:
            logger.warning("User digest delivery failed user=%s kind=%s: %s", uid, kind, exc)
            metric_increment("user_notification_digest_failed_total")
            await async_with_db(
                lambda db, uid=uid, kind=kind, period_key=period_key, exc=exc: mark_user_digest_delivery(
                    db, uid, kind, period_key, success=False, error=str(exc)
                )
            )
            continue
        await async_with_db(
            lambda db, uid=uid, kind=kind, period_key=period_key: mark_user_digest_delivery(
                db, uid, kind, period_key, success=True
            )
        )
        metric_increment("user_notification_digest_sent_total")


async def signal_approval_expiry_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    approvals = await async_with_db(claim_expired_signal_approvals)
    for row in approvals:
        requester = str(row.get("requested_by") or "")
        success = False
        error = "invalid_requester"
        if requester.isdigit():
            try:
                payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
                await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    int(requester),
                    "⌛️ <b>مهلت تأیید سیگنال تمام شد</b>\n\n"
                    f"درخواست: <code>#{row.get('id')}</code>\n"
                    f"نماد: <b>{esc(payload.get('symbol') or '—')}</b>\n"
                    "سیگنال منتشر نشد. در صورت نیاز، آن را دوباره بررسی و ارسال کنید.",
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("📡 ساخت سیگنال جدید", callback_data="a_signal")]]
                    ),
                )
                success = True
                error = ""
            except TelegramError as exc:
                error = exc.__class__.__name__
        await async_with_db(
            lambda db, approval_id=row["id"], ok=success, detail=error: mark_expired_signal_approval_notice(
                db,
                approval_id,
                success=ok,
                error=detail,
            )
        )


async def operations_intelligence_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    result = await async_with_db(lambda db: run_safe_self_healing(db))
    memory = dict(result.get("memory") or {})
    if memory.get("percent") is not None:
        metric_gauge("memory_guardian_percent", float(memory.get("percent") or 0))
    metric_gauge("memory_guardian_rss_mb", float(memory.get("rss_mb", 0) or 0))
    metric_gauge("self_healing_actions_last", len(result.get("actions") or []))


async def provider_health_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Probe concrete providers and keep the registry free of synthetic rows.

    ``fetch_market_quote`` already records every concrete API attempt. Older
    releases recorded the final consensus label as another provider, creating
    stale ``Consensus: ...`` and ``market-router`` rows that repeatedly turned
    the governance report red.
    """
    symbols = ("XAUUSD", "EURUSD", "BTCUSD")
    active_names = provider_names_for_symbols(symbols)
    await async_with_db(lambda db: sanitize_provider_health(db, active_providers=active_names))
    succeeded = failed = 0
    for symbol in symbols:
        try:
            quote = await fetch_market_quote(symbol, force=True)
            if quote.stale:
                failed += 1
                metric_increment("provider_probe_stale_total")
            else:
                succeeded += 1
        except Exception as exc:
            failed += 1
            metric_increment("provider_probe_failures_total")
            logger.warning("Provider health probe failed for %s: %s", symbol, exc.__class__.__name__)
    cleanup = await async_with_db(lambda db: sanitize_provider_health(db, active_providers=active_names))
    metric_gauge("provider_probe_successes_last_run", succeeded)
    metric_gauge("provider_probe_failures_last_run", failed)
    metric_gauge("provider_registry_active", cleanup.get("active", 0))
    metric_gauge("provider_registry_removed_last_run", cleanup.get("removed", 0))


async def payment_reconciliation_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Reconcile each order once; changed orders can be reviewed again manually."""
    def reconcile_new(db: dict[str, Any]) -> int:
        known = {
            str(row.get("order_id") or "")
            for row in db.get("payment_reconciliations", [])
            if isinstance(row, dict)
        }
        pending = [
            row
            for row in db.get("vip_orders", [])
            if isinstance(row, dict) and str(row.get("order_id") or "") not in known
        ]
        for row in pending[:500]:
            reconcile_order(db, row)
        return min(len(pending), 500)

    count = await async_with_db(reconcile_new)
    metric_gauge("payment_reconciliations_last_run", count)


async def post_shutdown(application: Application) -> None:
    set_readiness_state("bootstrap_complete", False)
    from core.runtime_watchdog import stop_runtime_watchdog
    stop_runtime_watchdog()
    from core.miniapp_server import drain_background_tasks, unregister_telegram_application
    await drain_background_tasks(timeout=5)
    unregister_telegram_application(application)
    # Stop and drain HTTP users of the pools before closing the databases.
    try:
        await run_blocking(stop_health_server, timeout=10)
    except Exception:
        logger.exception("Could not stop Mini App health server during shutdown")
    metric_gauge("telegram_initialized", 0)
    await close_http_client()
    await close_distributed_jobs()
    await close_shared_cache()
    try:
        from core.connection_limits import close_connection_limit_client
        await close_connection_limit_client()
    except Exception:
        logger.exception("Could not close connection-limit Redis client")
    try:
        from services.event_stream_service import close_event_stream_pool
        close_event_stream_pool()
    except Exception:
        logger.exception("Could not close event stream pool")
    try:
        from modules.gemini_ai import close_gemini_http_client
        await run_blocking(close_gemini_http_client, timeout=10)
    except Exception:
        logger.exception("Could not close Gemini HTTP client")
    try:
        from core.storage.engine import normalized_engine
        await run_blocking(normalized_engine().close, timeout=10)
    except Exception:
        logger.exception("Could not close normalized database pool")
    try:
        from core.db import close_database_store
        await run_blocking(close_database_store, timeout=10)
    except Exception:
        logger.exception("Could not close legacy database pool")
    try:
        persistence = getattr(application, "persistence", None)
        if persistence is not None and hasattr(persistence, "close"):
            await run_blocking(persistence.close, timeout=10)
    except Exception:
        logger.exception("Could not close Telegram persistence pool")
    if not SETTINGS.database_url:
        _secure_persistence_location(SETTINGS.persistence_file)
    try:
        await run_blocking(
            write_heartbeat,
            SETTINGS.heartbeat_file,
            status="stopped",
            details={"bot_username": effective_bot_username()},
            timeout=5,
            acquire_timeout=1,
        )
    except (OSError, TimeoutError):
        logger.exception("Could not write shutdown heartbeat")
    try:
        from modules.signal import shutdown_signal_executor

        shutdown_signal_executor()
    except Exception:
        logger.exception("Could not shut down signal image executor")
    try:
        from core.async_runtime import shutdown_blocking_executor

        if not shutdown_blocking_executor(wait_seconds=0.5):
            logger.warning("Blocking I/O daemon workers are still running; process exit will not wait for them")
    except Exception:
        logger.exception("Could not shut down blocking I/O executor")


async def check_order_notifications(context: ContextTypes.DEFAULT_TYPE) -> None:
    from services.vip_payment_orchestrator import reconcile_approved_orders
    await reconcile_approved_orders(context.bot)
    # Recover normalized approval leases first. A crash after invite creation
    # leaves the link in the order payload, allowing this worker to revoke it
    # before another administrator can claim the order.
    try:
        from repositories.v2.commerce import CommerceRepository
        from services.vip_order_projection import project_normalized_order_to_legacy
        normalized_repo = CommerceRepository()
        normalized_stale = await run_blocking(normalized_repo.recover_stale_approval_claims, timeout=20)
        for normalized_order in normalized_stale:
            order_id = normalized_order.get("id")
            stale_link = str(normalized_order.get("processing_invite_link") or "")
            recovery_completed = bool(normalized_order.get("recovery_completed"))
            if stale_link and not recovery_completed:
                revoked = False
                revoke_error = ""
                try:
                    await context.bot.revoke_chat_invite_link(
                        chat_id=SETTINGS.private_channel_id, invite_link=stale_link,
                    )
                    revoked = True
                except BadRequest:
                    # Already expired/revoked/not found is a successful safety outcome.
                    revoked = True
                except TelegramError as exc:
                    revoke_error = f"{exc.__class__.__name__}: {exc}"[:500]
                    logger.exception("Could not revoke normalized stale approval invite order=%s", order_id)
                recovered = await run_blocking(
                    normalized_repo.complete_stale_approval_recovery,
                    order_id,
                    invite_revoked=revoked,
                    error=revoke_error,
                    timeout=20,
                )
                recovery_completed = bool(recovered and recovered.get("status") == "pending")
            if recovery_completed:
                await run_blocking(project_normalized_order_to_legacy, order_id, timeout=20)
    except Exception:
        logger.exception("Normalized VIP approval lease recovery failed")

    # Recover abandoned legacy approval claims. Any one-use invite created before a
    # process crash is revoked best-effort before the order becomes pending.
    stale_rows = await async_with_db(stale_vip_order_claims)
    for order in stale_rows:
        revoke_error = ""
        invite_link = str(order.get("processing_invite_link") or "")
        if invite_link:
            try:
                await context.bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_link,
                )
            except BadRequest:
                # Already revoked/expired/not found is safe for recovery.
                pass
            except TelegramError as exc:
                revoke_error = f"invite revoke failed: {exc.__class__.__name__}"
                logger.warning("Could not revoke stale approval invite for %s", order.get("order_id"))
        stale_order_id = str(order.get("order_id"))
        await async_with_db(lambda db, oid=stale_order_id, err=revoke_error: recover_stale_order_claim(db, oid, err))

    def collect(db: dict) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        admin_rows = [
            dict(order)
            for order in db.get("vip_orders", [])
            if isinstance(order, dict)
            and order.get("status") == "pending"
            and not order.get("admin_notified_at")
            and _notification_due(order, "admin")
        ][-20:]
        user_rows = [
            dict(order)
            for order in db.get("vip_orders", [])
            if isinstance(order, dict)
            and order.get("status") in {"approved", "rejected"}
            and order.get("refund_status") != "full"
            and not order.get("user_notified_at")
            and _notification_due(order, "user")
        ][-50:]
        return admin_rows, user_rows

    admin_rows, user_rows = await async_with_db(collect)
    for order in admin_rows:
        success = await _notify_admins_about_order(context.bot, order)
        await async_with_db(
            lambda db, oid=order["order_id"], ok=success: (
                _mark_order_admin_notified(db, oid) if ok else _mark_order_admin_notify_failed(db, oid)
            )
        )
    for order in user_rows:
        success = await _notify_order_user(context.bot, order)
        await async_with_db(lambda db, oid=order["order_id"], ok=success: _mark_order_user_notification(db, oid, ok))


async def check_contest_deadlines(context: ContextTypes.DEFAULT_TYPE) -> None:
    candidates = await async_with_db(refresh_all_contests)
    if not candidates:
        return
    labels = {"price": "قیمت", "chart": "چارت", "candle": "کندل"}
    for item in candidates:
        text = (
            f"⏰ زمان مسابقه {labels.get(item.get('type'), item.get('type'))} پایان یافت.\n"
            f"شناسه: <code>{esc(item.get('id'))}</code>\n"
            "برای ثبت نتیجه وارد پنل مسابقات شوید."
        )
        delivered = False
        errors: list[str] = []
        for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_CONTESTS)):
            try:
                await _telegram_request_with_button_fallback(context.bot.send_message, admin_id, text, parse_mode=ParseMode.HTML)
                delivered = True
            except TelegramError as exc:
                errors.append(exc.__class__.__name__)
                logger.warning("Could not notify admin %s about contest deadline", admin_id)
        error_summary = ",".join(errors)
        await async_with_db(
            lambda db, row=item, ok=delivered, err=error_summary: mark_deadline_notification_result(
                db,
                str(row.get("type")),
                str(row.get("id")),
                success=ok,
                error=err,
            )
        )


def feature_job(module_key: str, job: Any) -> Any:
    """Stop background work when the same user-facing module is disabled."""

    async def run(context: ContextTypes.DEFAULT_TYPE) -> Any:
        if not is_module_enabled(await async_snapshot(), module_key):
            metric_increment(f"job_skipped_feature_disabled_{module_key}")
            return None
        return await job(context)

    run.__name__ = f"{getattr(job, '__name__', 'job')}_{module_key}_gated"
    return run


async def runtime_dependency_health_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Refresh readiness for shared infrastructure without crashing the process."""
    try:
        database_ok = bool(await run_blocking(database_healthcheck, timeout=5, acquire_timeout=2))
    except Exception:
        logger.exception("Database readiness probe failed")
        database_ok = False
    set_readiness_state("database", database_ok)
    metric_gauge("database_ready", 1 if database_ok else 0)

    try:
        cache = await shared_cache_healthcheck(require_redis=bool(SETTINGS.redis_url))
        redis_ok = bool(cache.get("healthy")) and (not SETTINGS.redis_url or cache.get("backend") == "redis")
    except Exception:
        logger.exception("Redis readiness probe failed")
        redis_ok = False
    set_readiness_state("redis", redis_ok)
    metric_gauge("redis_ready", 1 if redis_ok else 0)

    try:
        receipts = await run_blocking(receipt_storage_status, timeout=5)
        receipt_ok = bool(receipts.get("healthy")) and (
            not SETTINGS.webapp_api_enabled or bool(receipts.get("persistent"))
        )
    except Exception:
        logger.exception("Receipt storage readiness probe failed")
        receipt_ok = False
    set_readiness_state("receipt_storage", receipt_ok)
    metric_gauge("receipt_storage_ready", 1 if receipt_ok else 0)

    try:
        from core.storage.migration import migration_status
        migration = await run_blocking(migration_status, timeout=5)
        migration_ok = bool(migration.get("complete"))
    except Exception:
        logger.exception("Database migration readiness probe failed")
        migration_ok = False
    set_readiness_state("migration", migration_ok)
    metric_gauge("migration_ready", 1 if migration_ok else 0)

    telegram_delivery_ok = True
    telegram_queue_state: dict[str, int] = {"pending": 0, "dead": 0, "oldest_pending_age_seconds": 0}
    if SETTINGS.run_mode == "webhook":
        try:
            from core.telegram_update_store import backlog as telegram_update_backlog
            telegram_queue_state = await run_blocking(telegram_update_backlog, timeout=5)
            pending_limit = max(10, int(os.getenv("TELEGRAM_UPDATE_BACKLOG_READY_LIMIT", "5000") or 5000))
            dead_limit = max(0, int(os.getenv("TELEGRAM_UPDATE_DEAD_READY_LIMIT", "50") or 50))
            max_age = max(30, int(os.getenv("TELEGRAM_UPDATE_MAX_READY_AGE_SECONDS", "300") or 300))
            telegram_delivery_ok = (
                int(telegram_queue_state.get("pending") or 0) <= pending_limit
                and int(telegram_queue_state.get("dead") or 0) <= dead_limit
                and int(telegram_queue_state.get("oldest_pending_age_seconds") or 0) <= max_age
            )
        except Exception:
            logger.exception("Telegram durable queue readiness probe failed")
            telegram_delivery_ok = False
    set_readiness_state("telegram_delivery", telegram_delivery_ok)
    metric_gauge("telegram_delivery_ready", 1 if telegram_delivery_ok else 0)
    metric_gauge("telegram_update_backlog", int(telegram_queue_state.get("pending") or 0))
    metric_gauge("telegram_update_dead", int(telegram_queue_state.get("dead") or 0))
    metric_gauge("telegram_update_oldest_age_seconds", int(telegram_queue_state.get("oldest_pending_age_seconds") or 0))

    if not redis_ok and SETTINGS.redis_url:
        await async_with_db(
            lambda db: record_incident(
                db,
                source="redis",
                kind="dependency_unavailable",
                detail="Redis readiness probe failed. Distributed locks, shared limits, and streams are degraded.",
                severity="critical",
                metadata={"configured": True},
                dedupe_minutes=30,
            )
        )
    if not receipt_ok:
        await async_with_db(
            lambda db: record_incident(
                db,
                source="receipt_storage",
                kind="dependency_unavailable",
                detail="Receipt storage is unavailable, non-persistent, or below the minimum free-space threshold.",
                severity="critical",
                metadata={"configured": bool(SETTINGS.webapp_api_enabled)},
                dedupe_minutes=30,
            )
        )
    if not telegram_delivery_ok:
        await async_with_db(
            lambda db: record_incident(
                db,
                source="telegram_update",
                kind="delivery_backlog_unhealthy",
                detail="Telegram durable update queue is above its safe backlog, age, or dead-letter threshold.",
                severity="critical",
                metadata=telegram_queue_state,
                dedupe_minutes=15,
            )
        )
    if not migration_ok:
        await async_with_db(
            lambda db: record_incident(
                db,
                source="database",
                kind="migration_incomplete",
                detail="The normalized database migration marker is missing or unreadable.",
                severity="critical",
                metadata={"schema": "v8"},
                dedupe_minutes=30,
            )
        )


async def retention_cleanup_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Apply bounded audit, event, command, and rotated-log retention."""
    from core.retention import cleanup_normalized_records, cleanup_rotated_logs

    database_result = await run_blocking(cleanup_normalized_records, timeout=60)
    log_result = await run_blocking(cleanup_rotated_logs, timeout=30)
    for key, value in database_result.items():
        metric_gauge(f"retention_{key}_removed_last_run", int(value or 0))
    metric_gauge("retention_log_files_removed_last_run", int(log_result.get("removed", 0) or 0))
    await async_with_db(
        lambda db: audit(
            db,
            "system",
            "retention_cleanup",
            json.dumps({"database": database_result, "logs": log_result}, ensure_ascii=False, default=str)[:900],
        )
    )


async def ai_channel_operations_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    if context is None:
        return

    def claim(db):
        for row in db.setdefault("ai_channel_operations", []):
            if isinstance(row, dict) and row.get("status") in {"queued", "retry"}:
                row.update({"status": "processing", "updated_at": utc_iso(), "attempts": int(row.get("attempts", 0) or 0) + 1})
                return dict(row)
        return None

    row = await async_with_db(claim)
    if not row:
        return
    error = ""
    try:
        chat_id = int(row["chat_id"]); message_id = int(row["message_id"]); operation = str(row.get("operation") or "")
        if operation == "edit_text":
            await context.bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=str(row.get("text") or ""), parse_mode=ParseMode.HTML)
        elif operation == "edit_media":
            path = str(row.get("asset_path") or "")
            if not path or not os.path.isfile(path):
                raise ValueError("AI_CHANNEL_ASSET_NOT_FOUND")
            with open(path, "rb") as photo:
                await context.bot.edit_message_media(chat_id=chat_id, message_id=message_id, media=InputMediaPhoto(media=photo, caption=str(row.get("text") or "") or None, parse_mode=ParseMode.HTML))
        elif operation == "delete":
            await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
        elif operation == "pin":
            await context.bot.pin_chat_message(chat_id=chat_id, message_id=message_id, disable_notification=True)
        elif operation == "unpin":
            await context.bot.unpin_chat_message(chat_id=chat_id, message_id=message_id)
        else:
            raise ValueError("CHANNEL_OPERATION_INVALID")
    except Exception as exc:
        logger.exception("AI channel operation %s failed", row.get("id"))
        error = f"{exc.__class__.__name__}: {str(exc)[:500]}"

    def finish(db):
        target = next((item for item in db.setdefault("ai_channel_operations", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == int(row["id"])), None)
        if target:
            target.update({"status": "failed" if error else "completed", "last_error": error, "completed_at": utc_iso() if not error else "", "updated_at": utc_iso()})
        return dict(target or row)
    await async_with_db(finish)


async def ai_signal_refresh_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    if context is None:
        return

    def claim(db):
        for item in db.setdefault("ai_signal_refresh_queue", []):
            if isinstance(item, dict) and item.get("status") in {"queued", "retry"}:
                item.update({"status": "processing", "updated_at": utc_iso(), "attempts": int(item.get("attempts", 0) or 0) + 1})
                signal_id = str(item.get("signal_id") or "")
                signals = [row for row in db.get("signals", []) if isinstance(row, dict)]
                if signal_id.lower() in {"latest", "last"}:
                    signal = signals[-1] if signals else None
                else:
                    signal = next((row for row in signals if str(row.get("id")) == signal_id or str(row.get("display_number")) == signal_id), None)
                return dict(item), dict(signal) if signal else None
        return None, None

    task, signal = await async_with_db(claim)
    if not task:
        return
    error = ""
    errors_count = 0
    try:
        if not signal:
            raise ValueError("SIGNAL_NOT_FOUND")
        errors_count = await _refresh_signal_channel_messages(context.bot, signal, rebuild_media=True)
        if errors_count:
            raise RuntimeError(f"SIGNAL_CHANNEL_REFRESH_ERRORS:{errors_count}")
    except Exception as exc:
        logger.exception("AI signal refresh %s failed", task.get("id"))
        error = f"{exc.__class__.__name__}: {str(exc)[:500]}"

    def finish(db):
        target = next((item for item in db.setdefault("ai_signal_refresh_queue", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == int(task["id"])), None)
        if target:
            target.update({"status": "failed" if error else "completed", "last_error": error, "telegram_errors": errors_count, "completed_at": utc_iso() if not error else "", "updated_at": utc_iso()})
        return dict(target or task)
    await async_with_db(finish)


async def ai_primary_approval_notification_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    if context is None or not SETTINGS.primary_admin_id:
        return
    def claim(db):
        for row in db.setdefault("ai_admin_command_queue", []):
            if isinstance(row, dict) and str(row.get("status") or "") == "pending_primary_approval" and not row.get("notified_at"):
                row["notified_at"] = utc_iso(); row["updated_at"] = utc_iso(); return dict(row)
        return None
    row = await async_with_db(claim)
    if row:
        try:
            await context.bot.send_message(
                chat_id=int(SETTINGS.primary_admin_id),
                text=(
                    "🧠 <b>درخواست اجرای Gemini از ادمین دیگر</b>\n\n"
                    f"شناسه: <code>{row.get('id')}</code>\n"
                    f"درخواست‌کننده: <code>{esc(row.get('requested_by'))}</code>\n"
                    f"عملیات: <code>{esc(row.get('action'))}</code>\n"
                    f"دلیل: {esc(row.get('reason') or '—')}"
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ تأیید و اجرا", callback_data=f"ai_cmd_approve:{row.get('id')}", style="success"),
                    InlineKeyboardButton("❌ رد", callback_data=f"ai_cmd_reject:{row.get('id')}", style="danger"),
                ]]),
            )
        except Exception:
            logger.exception("Could not notify primary admin about AI command %s", row.get("id"))
        return

    def claim_admin(db):
        for uid, item in (db.get("delegated_admins") or {}).items():
            if not isinstance(item, dict):
                continue
            if str(item.get("approval_status") or "approved") != "pending" or item.get("approval_notified_at"):
                continue
            item["approval_notified_at"] = utc_iso(); item["updated_at"] = utc_iso()
            return {**dict(item), "user_id": str(uid)}
        return None
    pending_admin = await async_with_db(claim_admin)
    if not pending_admin:
        return
    try:
        await context.bot.send_message(
            chat_id=int(SETTINGS.primary_admin_id),
            text=(
                "🛡 <b>درخواست افزودن ادمین جدید</b>\n\n"
                f"آیدی عددی: <code>{esc(pending_admin.get('user_id'))}</code>\n"
                f"ثبت‌کننده: <code>{esc(pending_admin.get('created_by') or '—')}</code>\n"
                f"نقش: <b>{esc(pending_admin.get('role') or 'admin')}</b>\n"
                f"دسترسی‌ها: {esc('، '.join(pending_admin.get('permissions') or []) or 'بدون دسترسی')}"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ تأیید ادمین", callback_data=f"delegated_admin_approve:{pending_admin.get('user_id')}", style="success"),
                InlineKeyboardButton("❌ رد", callback_data=f"delegated_admin_reject:{pending_admin.get('user_id')}", style="danger"),
            ]]),
        )
    except Exception:
        logger.exception("Could not notify primary admin about delegated admin %s", pending_admin.get("user_id"))


async def ai_retention_cleanup_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Prune AI conversations, aliases, snapshots, quota reservations and reports."""
    from modules.gemini_ai import cleanup_ai_retention

    result = await run_blocking(cleanup_ai_retention, timeout=60)
    for key, value in result.items():
        metric_gauge(f"ai_retention_{key}_removed_last_run", int(value or 0))
    await async_with_db(
        lambda db: audit(
            db,
            "system",
            "ai_retention_cleanup",
            json.dumps(result, ensure_ascii=False, default=str)[:900],
        )
    )


async def receipt_cleanup_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Delete only unattached receipt blobs older than the configured retention window."""
    retention_days = max(1, min(int(os.getenv("RECEIPT_ORPHAN_RETENTION_DAYS", "7") or 7), 365))
    result = await async_with_db(
        lambda db: cleanup_orphan_receipts(db, older_than_days=retention_days, limit=500)
    )
    metric_gauge("receipt_cleanup_removed_last_run", int(result.get("removed", 0) or 0))
    metric_gauge("receipt_cleanup_failed_last_run", int(result.get("failed", 0) or 0))
    await async_with_db(
        lambda db: audit(
            db,
            "system",
            "receipt_retention_cleanup",
            json.dumps({
                "removed": int(result.get("removed", 0) or 0),
                "failed": int(result.get("failed", 0) or 0),
                "retention_days": retention_days,
            }, ensure_ascii=False),
        )
    )
    if int(result.get("failed", 0) or 0):
        await async_with_db(
            lambda db: record_incident(
                db,
                source="receipt_storage",
                kind="orphan_cleanup_failed",
                detail="One or more expired unattached receipt blobs could not be deleted.",
                severity="warning",
                metadata={"failed": int(result.get("failed", 0) or 0)},
                dedupe_minutes=1440,
            )
        )


async def refresh_channel_permission_health(context: ContextTypes.DEFAULT_TYPE) -> dict[str, int]:
    """Verify channel administration/posting rights without wasting Telegram API quota.

    Healthy channels are refreshed at most every ten minutes. Unhealthy or unknown
    channels are retried every two minutes so an administrator sees recovery quickly.
    The check uses only the bot's existing Telegram API access and introduces no paid
    dependency.
    """
    db = await async_snapshot()
    channel_ids: set[int] = {
        int(value) for value in (SETTINGS.public_channel_id, SETTINGS.private_channel_id) if int(value or 0)
    }
    for row in db.get("publisher_channels", []):
        if not isinstance(row, dict) or not row.get("enabled", True):
            continue
        try:
            channel_id = int(row.get("chat_id") or 0)
        except (TypeError, ValueError):
            continue
        if channel_id:
            channel_ids.add(channel_id)
    if not channel_ids:
        return {"checked": 0, "probed": 0, "cached": 0, "healthy": 0, "unhealthy": 0}

    previous = db.get("channel_permission_health", {})
    previous = previous if isinstance(previous, dict) else {}
    now = utc_now()
    rows: dict[str, dict[str, Any]] = {}
    due_ids: list[int] = []
    for chat_id in sorted(channel_ids):
        cached = previous.get(str(chat_id))
        if not isinstance(cached, dict):
            due_ids.append(chat_id)
            continue
        checked_at = parse_dt(str(cached.get("checked_at") or ""))
        age_seconds = (now - checked_at).total_seconds() if checked_at else float("inf")
        ttl_seconds = 600 if str(cached.get("status") or "") == "healthy" else 120
        if age_seconds < ttl_seconds:
            rows[str(chat_id)] = dict(cached)
        else:
            due_ids.append(chat_id)

    bot_id = int(getattr(context.bot, "id", 0) or 0)
    if due_ids and not bot_id:
        try:
            bot_id = int((await context.bot.get_me()).id)
        except TelegramError:
            logger.exception("Could not resolve bot identity for channel permission probe")
            for chat_id in due_ids:
                rows[str(chat_id)] = {
                    "chat_id": str(chat_id),
                    "status": "error",
                    "member_status": "",
                    "can_post_messages": False,
                    "detail": "bot_identity_unavailable",
                    "checked_at": utc_iso(now),
                }
            await async_with_db(lambda current: current.__setitem__("channel_permission_health", rows))
            healthy = sum(1 for row in rows.values() if row.get("status") == "healthy")
            return {
                "checked": len(rows),
                "probed": len(due_ids),
                "cached": len(rows) - len(due_ids),
                "healthy": healthy,
                "unhealthy": len(rows) - healthy,
            }

    for chat_id in due_ids:
        status = "unknown"
        detail = ""
        member_status = ""
        can_post = False
        try:
            member = await context.bot.get_chat_member(chat_id=chat_id, user_id=bot_id)
            member_status = str(getattr(member, "status", "") or "").lower()
            administrator = member_status in {"creator", "owner", "administrator"}
            can_post_attr = getattr(member, "can_post_messages", None)
            can_post = administrator and can_post_attr is not False
            if not administrator:
                status = "not_admin"
            elif not can_post:
                status = "cannot_post"
            else:
                status = "healthy"
        except Forbidden as exc:
            status, detail = "forbidden", str(exc)[:300]
        except BadRequest as exc:
            status, detail = "missing", str(exc)[:300]
        except TelegramError as exc:
            status, detail = "error", str(exc)[:300]
        rows[str(chat_id)] = {
            "chat_id": str(chat_id),
            "status": status,
            "member_status": member_status,
            "can_post_messages": bool(can_post),
            "detail": detail,
            "checked_at": utc_iso(now),
        }

    # Remove stale rows for channels that are no longer configured.
    rows = {str(chat_id): rows[str(chat_id)] for chat_id in sorted(channel_ids) if str(chat_id) in rows}
    await async_with_db(lambda current: current.__setitem__("channel_permission_health", rows))
    healthy = sum(1 for row in rows.values() if row.get("status") == "healthy")
    return {
        "checked": len(rows),
        "probed": len(due_ids),
        "cached": len(rows) - len(due_ids),
        "healthy": healthy,
        "unhealthy": len(rows) - healthy,
    }


async def operations_governance_watchdog_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Run free/self-hosted operational checks and notify authorized admins only on actionable changes."""
    if not governance_monitoring_enabled(await async_snapshot()):
        return
    await refresh_channel_permission_health(context)
    result = await async_with_db(run_automation_checks)
    digest = await async_with_db(claim_governance_digest)
    if not digest:
        return
    health = digest.get("health", {})
    text = (
        "🧠 <b>گزارش حاکمیت عملیات</b>\n\n"
        f"در انتظار تصمیم: <b>{int(digest.get('pending', 0) or 0)}</b>\n"
        f"سلامت خودکار: ✅ <b>{int(health.get('healthy', 0) or 0)}</b> | "
        f"⚠️ <b>{int(health.get('warning', 0) or 0)}</b> | "
        f"🔴 <b>{int(health.get('critical', 0) or 0)}</b> | "
        f"❔ <b>{int(health.get('unknown', 0) or 0)}</b>\n"
        f"Retry: <b>{int((result.get('retry') or {}).get('retried', 0) or 0)}</b>"
    )
    delivered = False
    errors: list[str] = []
    for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_OPERATIONS_GOVERNANCE)):
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                chat_id=admin_id,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🧠 بازکردن مرکز", callback_data="a_ops_governance")]]),
            )
            delivered = True
        except TelegramError as exc:
            errors.append(exc.__class__.__name__)
            logger.warning("Could not notify operations governance admin %s", admin_id)
    await async_with_db(lambda db: mark_governance_digest(db, success=delivered, error=",".join(errors)))


def _configure_governance_monitoring(application: Any, db: dict[str, Any]) -> None:
    """Keep manual mode unscheduled, including previously registered jobs."""
    queue = application.job_queue
    if queue is None:
        return
    for job in queue.get_jobs_by_name("operations-governance-watchdog"):
        job.schedule_removal()
    if not governance_monitoring_enabled(db):
        return
    interval = max(300, int(control_module_state(db, "governance").get("watchdog_interval_minutes", 10) or 10) * 60)
    queue.run_repeating(
        distributed_job(
            "operations_governance",
            observed_job("operations_governance", feature_job("governance", operations_governance_watchdog_job)),
            lease_seconds=min(max(180, interval - 30), 3600),
        ),
        interval=interval,
        first=75,
        name="operations-governance-watchdog",
    )


async def ai_signal_lab_shadow_scan_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Process queued shadow scans and notify the primary admin for human review.

    Candidates remain shadow-only. The notification button only moves a
    candidate into the existing Entry/SL/TP approval queue; it never publishes.
    """
    results = await process_pending_shadow_scans(limit=3)
    if context is None or not SETTINGS.primary_admin_id:
        return
    for result in results:
        for candidate in (result.get("candidates") or [])[:10]:
            candidate_id = int(candidate.get("id", 0) or 0)
            if candidate_id <= 0:
                continue
            targets = " / ".join(str(item) for item in (candidate.get("targets") or [])) or "—"
            text = (
                "🧪 <b>Signal Lab · کاندیدای سایه</b>\n\n"
                f"شناسه: <code>LAB-{candidate_id}</code>\n"
                f"نماد: <b>{esc(candidate.get('symbol') or '—')}</b> | "
                f"جهت: <b>{esc(candidate.get('side') or '—')}</b>\n"
                f"Entry پیشنهادی: <code>{esc(candidate.get('entry') or '—')}</code>\n"
                f"SL پیشنهادی: <code>{esc(candidate.get('stop') or '—')}</code>\n"
                f"TP پیشنهادی: <code>{esc(targets)}</code>\n"
                f"امتیاز اطمینان داده: <b>{float(candidate.get('confidence', 0) or 0) * 100:.1f}%</b>\n\n"
                "این خروجی فقط آزمایشی است و هیچ سیگنالی منتشر نشده است. "
                "با دکمه زیر، آن را وارد صف بررسی انسانی Entry، SL و TP کنید."
            )
            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("🛡 ارسال به صف بررسی", callback_data=f"ai_lab_review:{candidate_id}"),
            ]])
            try:
                await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    chat_id=int(SETTINGS.primary_admin_id),
                    text=text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=keyboard,
                )
            except TelegramError:
                logger.warning("Could not notify primary admin about Signal Lab candidate %s", candidate_id)


async def ai_signal_lab_candidate_review_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Human-only promotion of a shadow candidate to the signal approval queue."""
    query = update.callback_query
    if not _is_owner_admin(query.from_user.id):
        await query.answer("فقط ادمین اصلی می‌تواند این کاندیدا را بررسی کند.", show_alert=True)
        return
    await query.answer()
    try:
        candidate_id = int(str(query.data).split(":", 1)[1])
        result = await async_with_db(lambda db: promote_candidate_to_review(
            db, candidate_id=candidate_id, actor_id=query.from_user.id, target="public",
        ))
    except (ValueError, IndexError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    approval = result["approval"]
    payload = approval.get("payload") if isinstance(approval.get("payload"), dict) else {}
    targets = " / ".join(str(item) for item in (payload.get("targets") or [])) or "—"
    text = (
        "🛡 <b>کاندیدا وارد صف بررسی انسانی شد</b>\n\n"
        f"شناسه تأیید: <code>SA-{approval['id']}</code>\n"
        f"نماد: <b>{esc(payload.get('symbol') or '—')}</b> | "
        f"جهت: <b>{esc(payload.get('side') or '—')}</b>\n"
        f"Entry: <code>{esc(payload.get('entry') or '—')}</code>\n"
        f"SL: <code>{esc(payload.get('stop') or '—')}</code>\n"
        f"TP: <code>{esc(targets)}</code>\n\n"
        "تأیید زیر به‌معنای تأیید انسانی همین Entry، SL و TP و سپس انتشار است."
    )
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ تأیید و انتشار", callback_data=f"sig_approval:{approval['id']}:approve"),
        InlineKeyboardButton("❌ رد", callback_data=f"sig_approval:{approval['id']}:reject"),
    ]])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=keyboard)


async def gemini_health_probe_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    from modules.gemini_ai import gemini_live_health
    await run_blocking(gemini_live_health, force=True, generation_test=False, timeout=30)


async def gemini_daily_manager_report_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    from modules.gemini_ai import ai_runtime_settings, build_daily_manager_report
    settings = await run_blocking(ai_runtime_settings, timeout=10)
    if not bool(settings.get("daily_report_enabled")):
        return
    local_now = datetime.now(ZoneInfo(SETTINGS.timezone))
    if local_now.hour != int(settings.get("daily_report_hour", SETTINGS.gemini_daily_report_hour) or 0):
        return
    day = local_now.date().isoformat()
    db = await async_snapshot()
    runtime = db.get("ai_runtime_settings") if isinstance(db.get("ai_runtime_settings"), dict) else {}
    if str(runtime.get("last_daily_delivery_date") or "") == day:
        return
    delivered = False
    for admin_id in SETTINGS.admin_ids:
        try:
            report = await run_blocking(build_daily_manager_report, admin_id, language="fa", force=False, timeout=45)
            await context.bot.send_message(
                chat_id=admin_id,
                text="📋 <b>گزارش روزانه مدیر Sentinel</b>\n\n" + esc(str(report.get("answer") or "")[:3600]),
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🧠 مرکز هوش مصنوعی", callback_data="a_ai_command_center")]]),
            )
            delivered = True
        except TelegramError:
            logger.warning("Could not deliver Gemini daily report to admin %s", admin_id)
    if delivered:
        await async_with_db(lambda data: data.setdefault("ai_runtime_settings", {}).update({"last_daily_delivery_date": day, "last_daily_delivery_at": utc_iso()}))


_GOOGLE_SHEETS_JOB_LOCK: asyncio.Lock | None = None
_GOOGLE_SHEETS_JOB_LOCK_LOOP: asyncio.AbstractEventLoop | None = None


def _google_sheets_job_lock() -> asyncio.Lock:
    global _GOOGLE_SHEETS_JOB_LOCK, _GOOGLE_SHEETS_JOB_LOCK_LOOP
    loop = asyncio.get_running_loop()
    if _GOOGLE_SHEETS_JOB_LOCK is None or _GOOGLE_SHEETS_JOB_LOCK_LOOP is not loop:
        _GOOGLE_SHEETS_JOB_LOCK = asyncio.Lock()
        _GOOGLE_SHEETS_JOB_LOCK_LOOP = loop
    return _GOOGLE_SHEETS_JOB_LOCK


async def google_sheets_secondary_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Flush both Sentinel persistence layers to Google Sheets and reconcile core failover."""
    try:
        async with _google_sheets_job_lock():
            await _google_sheets_secondary_job_locked()
    except Exception:
        # A secondary outage must never stop the primary bot runtime. Failed
        # writes remain in the durable outboxes for the next pass.
        logger.exception("Google Sheets secondary database worker failed")
        metric_gauge("google_sheets_secondary_last_ok", 0)
    else:
        metric_gauge("google_sheets_secondary_last_ok", 1)


async def _google_sheets_secondary_job_locked() -> None:
    try:
        from core.db import (
            google_sheets_backup_status,
            google_sheets_failover_active,
            google_sheets_failover_reconcile,
            google_sheets_sync_now,
        )
        from core.google_sheets_backup import (
            flush_normalized_pending,
            normalized_pending_tables,
        )
        from core.google_sheets_backup import (
            is_configured as google_sheets_configured,
        )
        from core.storage.engine import normalized_engine

        if not google_sheets_configured():
            metric_gauge("google_sheets_secondary_configured", 0)
            return
        metric_gauge("google_sheets_secondary_configured", 1)
        if google_sheets_failover_active():
            result = await run_blocking(google_sheets_failover_reconcile, timeout=20)
            metric_gauge("google_sheets_core_failover_active", 1 if result.get("active") else 0)
        else:
            result = await run_blocking(google_sheets_sync_now, full=False, timeout=30)
            metric_gauge("google_sheets_core_pending", int(result.get("pending", 0) or 0))
        engine = normalized_engine()
        if bool(getattr(engine, "google_failover_active", False)):
            normalized_reconcile = await run_blocking(engine.reconcile_google_failover, timeout=30)
            metric_gauge(
                "google_sheets_v8_reconciled",
                1 if normalized_reconcile.get("status") == "reconciled" else 0,
            )
        normalized_result = await run_blocking(flush_normalized_pending, engine, sync_version=utc_iso(), timeout=30)
        metric_gauge("google_sheets_v8_pending", int(normalized_result.get("pending", 0) or 0))
        metric_gauge("google_sheets_v8_failover_active", 1 if bool(getattr(engine, "google_failover_active", False)) else 0)
        status = google_sheets_backup_status()
        metric_gauge("google_sheets_secondary_pending", len(status.get("pending_sections", [])) + len(normalized_pending_tables()))
    except Exception:
        raise


async def google_sheets_full_snapshot_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Hourly integrity snapshot for both database generations."""
    try:
        async with _google_sheets_job_lock():
            await _google_sheets_full_snapshot_job_locked()
    except Exception:
        logger.exception("Google Sheets full integrity snapshot failed")
        metric_gauge("google_sheets_full_snapshot_ok", 0)
    else:
        metric_gauge("google_sheets_full_snapshot_ok", 1)


async def _google_sheets_full_snapshot_job_locked() -> None:
    try:
        from core.db import google_sheets_failover_active
        from core.google_sheets_backup import (
            attest_backup_read_write,
            sync_full_normalized_snapshot,
            sync_full_snapshot,
        )
        from core.google_sheets_backup import (
            is_configured as google_sheets_configured,
        )
        from core.storage.engine import normalized_engine
        if not google_sheets_configured():
            return
        core_data = await async_snapshot()
        core_source = "google_failover" if google_sheets_failover_active() else "primary"
        await run_blocking(sync_full_snapshot, core_data, sync_version=utc_iso(), source=core_source, timeout=60)
        engine = normalized_engine()
        v8_source = "google_failover_v8" if bool(getattr(engine, "google_failover_active", False)) else "primary_v8"
        await run_blocking(sync_full_normalized_snapshot, engine, sync_version=utc_iso(), source=v8_source, timeout=60)
        await run_blocking(attest_backup_read_write, timeout=30)
        metric_gauge("google_sheets_backup_attested", 1)
    except Exception:
        metric_gauge("google_sheets_backup_attested", 0)
        raise


async def _bootstrap_google_sheets_secondary(startup_db: dict[str, Any]) -> None:
    """Create a complete first backup before the regular retry worker starts."""
    try:
        from core.google_sheets_backup import (
            attest_backup_read_write,
            bootstrap_needed,
            normalized_bootstrap_needed,
            sync_full_normalized_snapshot,
            sync_full_snapshot,
        )
        from core.google_sheets_backup import (
            is_configured as google_sheets_configured,
        )
        from core.storage.engine import normalized_engine

        if not google_sheets_configured():
            metric_gauge("google_sheets_secondary_configured", 0)
            return
        metric_gauge("google_sheets_secondary_configured", 1)
        if await run_blocking(bootstrap_needed, timeout=15):
            await run_blocking(sync_full_snapshot, startup_db, sync_version=utc_iso(), source="startup_primary", timeout=60)
        if await run_blocking(normalized_bootstrap_needed, timeout=15):
            engine = normalized_engine()
            await run_blocking(sync_full_normalized_snapshot, engine, sync_version=utc_iso(), source="startup_primary_v8", timeout=60)
        await run_blocking(attest_backup_read_write, timeout=30)
        metric_gauge("google_sheets_backup_attested", 1)
        metric_gauge("google_sheets_secondary_bootstrap_ok", 1)
    except Exception:
        # Service-account permissions may be completed after deployment. The
        # bot remains available and the recurring worker retries automatically.
        logger.exception("Google Sheets secondary database bootstrap failed")
        metric_gauge("google_sheets_backup_attested", 0)
        metric_gauge("google_sheets_secondary_bootstrap_ok", 0)


async def google_sheets_bootstrap_job(context: ContextTypes.DEFAULT_TYPE | None = None) -> None:
    """Run the first full secondary backup after the primary bot is already available."""
    startup_db = await async_snapshot()
    async with _google_sheets_job_lock():
        await _bootstrap_google_sheets_secondary(startup_db)


async def post_init(application: Application) -> None:
    install_smart_logging()
    from core.miniapp_server import register_telegram_application
    set_readiness_state("bootstrap_complete", False)
    register_telegram_application(application, asyncio.get_running_loop())
    # Application.initialize() has already called getMe at this point. Use the
    # authenticated username instead of trusting an optional Railway variable.
    _remember_runtime_bot_username(getattr(application.bot, "username", None))
    _secure_persistence_location(SETTINGS.persistence_file)
    startup_db = await async_snapshot()  # creates/migrates the database before accepting updates
    configure_observability(SETTINGS.metrics_file, SETTINGS.heartbeat_file, SETTINGS.heartbeat_max_age_seconds)
    storage = persistent_storage_status(database_url=SETTINGS.database_url, db_file=SETTINGS.db_file)
    metric_gauge("persistent_storage", 1 if bool(storage["persistent"]) else 0)
    if not bool(storage["persistent"]):
        await async_with_db(
            lambda db: record_incident(
                db,
                source="database",
                kind="ephemeral_storage",
                detail=(
                    "Railway is using temporary SQLite storage. The bot is operational, "
                    "but users, orders, points, signals, and settings can be lost after redeploy. "
                    "Attach PostgreSQL or mount a Railway Volume for durable data."
                ),
                severity="critical",
                metadata={
                    "backend": str(storage["backend"]),
                    "reason": str(storage["reason"]),
                    "requires_action": True,
                },
                dedupe_minutes=1440,
            )
        )
    set_readiness_state("database", False)
    await runtime_dependency_health_job()
    from modules.personal_notifications import initialize_personal_notifications
    await async_with_db(initialize_personal_notifications)
    register_readiness_check("telegram", lambda: bool(getattr(application.bot, "username", None)))
    register_readiness_check("telegram_application_running", lambda: bool(getattr(application, "running", False)))

    def telegram_transport_running() -> bool:
        if not bool(getattr(application, "running", False)):
            return False
        if SETTINGS.run_mode == "webhook":
            # Webhook registration has its own readiness state and the FastAPI
            # server thread is monitored by the independent runtime watchdog.
            return True
        updater = getattr(application, "updater", None)
        return bool(updater is not None and getattr(updater, "running", False))

    register_readiness_check("telegram_transport_running", telegram_transport_running)
    processor_healthy = getattr(application.update_processor, "is_healthy", lambda: True)
    register_readiness_check("telegram_update_processor", processor_healthy)
    register_readiness_check(
        "job_queue",
        lambda: bool(application.job_queue is not None and getattr(application.job_queue.scheduler, "running", True)),
    )
    metric_gauge("configured_concurrent_updates", SETTINGS.concurrent_updates)
    metric_gauge("http_circuits_open", sum(1 for row in circuit_snapshot().values() if row.get("open")))
    if application.job_queue is None:
        raise RuntimeError('JobQueue is unavailable. Install "python-telegram-bot[job-queue]".')
    await run_blocking(
        write_heartbeat,
        SETTINGS.heartbeat_file,
        status="running",
        details={"bot_username": effective_bot_username()},
        timeout=5,
        acquire_timeout=1,
    )
    application.job_queue.run_repeating(
        distributed_job("experience_reconciliation", observed_job("experience_reconciliation", experience_maintenance_job), lease_seconds=90),
        interval=60, first=30, name="experience-reconciliation",
    )
    application.job_queue.run_repeating(
        observed_job("runtime_dependencies", runtime_dependency_health_job),
        interval=60,
        first=60,
        name="runtime-dependency-health",
    )
    application.job_queue.run_once(
        distributed_job(
            "google_sheets_bootstrap",
            observed_job("google_sheets_bootstrap", google_sheets_bootstrap_job),
            lease_seconds=180,
        ),
        when=5,
        name="google-sheets-delayed-bootstrap",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "google_sheets_secondary",
            observed_job("google_sheets_secondary", google_sheets_secondary_job),
            lease_seconds=90,
        ),
        interval=15,
        first=15,
        name="google-sheets-secondary-sync",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "google_sheets_full_snapshot",
            observed_job("google_sheets_full_snapshot", google_sheets_full_snapshot_job),
            lease_seconds=900,
        ),
        interval=3600,
        first=300,
        name="google-sheets-full-integrity-snapshot",
    )
    _configure_governance_monitoring(application, startup_db)
    application.job_queue.run_repeating(
        observed_job("heartbeat", heartbeat_job),
        interval=SETTINGS.heartbeat_interval_seconds,
        first=SETTINGS.heartbeat_interval_seconds,
        name="application-heartbeat",
    )
    application.job_queue.run_repeating(
        observed_job("operations_intelligence", operations_intelligence_job),
        interval=60,
        first=30,
        name="operations-intelligence",
    )
    application.job_queue.run_repeating(
        distributed_job("vip_expiry", observed_job("vip_expiry", feature_job("subscriptions", check_expired_vips)), lease_seconds=3600),
        interval=SETTINGS.vip_check_interval_seconds,
        first=15,
        name="vip-expiry-check",
    )
    application.job_queue.run_repeating(
        distributed_job("contest_deadlines", observed_job("contest_deadlines", feature_job("contests", check_contest_deadlines)), lease_seconds=3600),
        interval=SETTINGS.contest_check_interval_seconds,
        first=30,
        name="contest-deadline-check",
    )
    application.job_queue.run_repeating(
        distributed_job("order_notifications", observed_job("order_notifications", feature_job("subscriptions", check_order_notifications)), lease_seconds=3600),
        interval=SETTINGS.order_notification_interval_seconds,
        first=45,
        name="order-notification-retry",
    )
    application.job_queue.run_repeating(
        distributed_job("broadcast_queue", observed_job("broadcast_queue", broadcast_queue_job), lease_seconds=3600),
        interval=SETTINGS.broadcast_job_interval_seconds,
        first=10,
        name="persistent-broadcast-queue",
    )
    application.job_queue.run_repeating(
        distributed_job("ai_channel_operations", observed_job("ai_channel_operations", ai_channel_operations_job), lease_seconds=120),
        interval=10, first=20, name="ai-channel-operations",
    )
    application.job_queue.run_repeating(
        distributed_job("ai_signal_refresh", observed_job("ai_signal_refresh", ai_signal_refresh_job), lease_seconds=120),
        interval=10, first=25, name="ai-signal-refresh",
    )
    application.job_queue.run_repeating(
        distributed_job("ai_primary_approval_notification", observed_job("ai_primary_approval_notification", ai_primary_approval_notification_job), lease_seconds=120),
        interval=20, first=30, name="ai-primary-approval-notification",
    )
    alert_interval = max(15, int(control_module_state((await async_snapshot()), "alerts").get("check_seconds", 60) or 60))
    application.job_queue.run_repeating(
        distributed_job("price_alerts", observed_job("price_alerts", feature_job("alerts", check_price_alerts_job)), lease_seconds=3600),
        interval=alert_interval,
        first=min(60, alert_interval),
        name="personal-price-alerts",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "automation_outbox",
            observed_job(
                "automation_outbox",
                feature_job("automation", automation_outbox_job),
            ),
            lease_seconds=12,
        ),
        interval=15,
        first=12,
        name="automation-outbox",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "automation_v2_runtime",
            observed_job(
                "automation_v2_runtime",
                feature_job("automation", automation_v2_runtime_job),
            ),
            lease_seconds=25,
        ),
        interval=30,
        first=18,
        name="automation-v2-runtime",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "campaign_scheduler",
            observed_job(
                "campaign_scheduler",
                feature_job("automation", campaign_scheduler_job),
            ),
            lease_seconds=25,
        ),
        interval=30,
        first=25,
        name="campaign-scheduler",
    )
    application.job_queue.run_repeating(
        distributed_job("automation", observed_job("automation", feature_job("automation", automation_job)), lease_seconds=3600),
        interval=3600,
        first=90,
        name="management-automation",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "economic_calendar_automation",
            observed_job("economic_calendar_automation", feature_job("calendar", economic_calendar_automation_job)),
            lease_seconds=900,
        ),
        interval=300,
        first=105,
        name="economic-calendar-automation",
    )
    application.job_queue.run_repeating(
        distributed_job("channel_snapshots", observed_job("channel_snapshots", feature_job("channels", channel_snapshot_job)), lease_seconds=900),
        interval=3600,
        first=120,
        name="channel-member-snapshots",
    )
    application.job_queue.run_repeating(
        distributed_job("privacy_cleanup", observed_job("privacy_cleanup", feature_job("privacy", privacy_cleanup_job)), lease_seconds=3600),
        interval=86400,
        first=180,
        name="privacy-retention-cleanup",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "retention_cleanup",
            observed_job("retention_cleanup", feature_job("privacy", retention_cleanup_job)),
            lease_seconds=3600,
        ),
        interval=86400,
        first=210,
        name="audit-log-retention-cleanup",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "user_notification_digest",
            observed_job("user_notification_digest", feature_job("notify", user_notification_digest_job)),
            lease_seconds=240,
        ),
        interval=300,
        first=150,
        name="user-notification-digest",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "ai_retention_cleanup",
            observed_job("ai_retention_cleanup", feature_job("privacy", ai_retention_cleanup_job)),
            lease_seconds=3600,
        ),
        interval=86400,
        first=225,
        name="ai-retention-cleanup",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "receipt_cleanup",
            observed_job("receipt_cleanup", feature_job("privacy", receipt_cleanup_job)),
            lease_seconds=3600,
        ),
        interval=86400,
        first=240,
        name="receipt-orphan-cleanup",
    )
    application.job_queue.run_repeating(
        distributed_job("signal_tracking", observed_job("signal_tracking", feature_job("tracker", signal_tracking_job)), lease_seconds=3600),
        interval=SETTINGS.signal_tracking_interval_seconds,
        first=120,
        name="signal-price-tracking",
    )
    application.job_queue.run_repeating(
        distributed_job("scheduled_signals", observed_job("scheduled_signals", feature_job("signals", scheduled_signal_job)), lease_seconds=3600),
        interval=60,
        first=20,
        name="scheduled-signal-publisher",
    )
    application.job_queue.run_repeating(
        distributed_job("ai_signal_lab_shadow", observed_job("ai_signal_lab_shadow", ai_signal_lab_shadow_scan_job), lease_seconds=600),
        interval=300,
        first=90,
        name="ai-signal-lab-shadow-scan",
    )
    application.job_queue.run_repeating(
        distributed_job("scenario_evaluation", observed_job("scenario_evaluation", feature_job("news", market_scenario_evaluation_job)), lease_seconds=3600),
        interval=14400,
        first=600,
        name="scenario-evaluation",
    )
    application.job_queue.run_repeating(
        distributed_job("market_morning", observed_job("market_morning", feature_job("news", market_morning_job)), lease_seconds=3600),
        interval=300,
        first=75,
        name="morning-market-briefing",
    )
    application.job_queue.run_repeating(
        distributed_job("operational_backup", observed_job("operational_backup", feature_job("backup", operational_backup_job)), lease_seconds=3600),
        interval=86400,
        first=60,
        name="encrypted-offsite-backup",
    )
    application.job_queue.run_repeating(
        observed_job("metrics_persist", observability_persist_job),
        interval=60,
        first=60,
        name="metrics-persist",
    )
    application.job_queue.run_repeating(
        distributed_job("business_intelligence", observed_job("business_intelligence", feature_job("trust", business_intelligence_job)), lease_seconds=7200),
        interval=21600,
        first=180,
        name="trust-retention-refresh",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "kpi_trader_reminders",
            observed_job("kpi_trader_reminders", kpi_due_reminder_job),
            lease_seconds=900,
        ),
        interval=1800,
        first=210,
        name="kpi-trader-deadline-reminders",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "incident_maintenance",
            observed_job(
                "incident_maintenance",
                feature_job("incidents", incident_maintenance_job),
            ),
            lease_seconds=300,
        ),
        interval=60,
        first=55,
        name="incident-notification-escalation",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "retention_delivery",
            observed_job(
                "retention_delivery",
                feature_job("retention", retention_delivery_job),
            ),
            lease_seconds=300,
        ),
        interval=120,
        first=110,
        name="retention-delivery",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "signal_approval_expiry",
            observed_job(
                "signal_approval_expiry",
                feature_job("signals", signal_approval_expiry_job),
            ),
            lease_seconds=180,
        ),
        interval=60,
        first=35,
        name="signal-approval-expiry",
    )
    application.job_queue.run_repeating(
        distributed_job("provider_health", observed_job("provider_health", feature_job("tracker", provider_health_job)), lease_seconds=900),
        interval=300,
        first=20,
        name="provider-health-probe",
    )
    application.job_queue.run_repeating(
        distributed_job("gemini_health", observed_job("gemini_health", gemini_health_probe_job), lease_seconds=240),
        interval=300,
        first=45,
        name="gemini-provider-health",
    )
    application.job_queue.run_repeating(
        distributed_job("gemini_daily_report", observed_job("gemini_daily_report", gemini_daily_manager_report_job), lease_seconds=1800),
        interval=1800,
        first=300,
        name="gemini-daily-manager-report",
    )
    application.job_queue.run_repeating(
        distributed_job(
            "payment_reconciliation",
            observed_job("payment_reconciliation", feature_job("subscriptions", payment_reconciliation_job)),
            lease_seconds=1800,
        ),
        interval=1800,
        first=165,
        name="payment-reconciliation",
    )
    from modules.education import publish_scheduled_lessons

    async def education_publication_job(context):
        count = await async_with_db(publish_scheduled_lessons)
        metric_gauge("education_scheduled_published_last_run", len(count))

    application.job_queue.run_repeating(
        distributed_job("education_publication", observed_job("education_publication", education_publication_job), lease_seconds=120),
        interval=60, first=60, name="education-publication",
    )
    # Re-apply durable operator pauses after every restart. Protected jobs are ignored.
    job_control_apply = apply_persisted_job_controls(application.job_queue, startup_db)
    metric_gauge("job_control_paused_applied", int(job_control_apply.get("applied", 0)))

    # Telegram command metadata is useful but non-critical. Keep the command
    # definitions here so release regressions can prove all user entry points
    # remain exposed, while each network call is bounded and best-effort.
    command_timeout = max(2.0, min(20.0, float(os.getenv("TELEGRAM_METADATA_TIMEOUT_SECONDS", "8") or 8)))
    fa_commands = [
        ("start", "شروع ربات و نمایش منوی اصلی"),
        ("menu", "بازکردن منوی اصلی"),
        ("vip", "خرید یا مدیریت اشتراک VIP"),
        ("prices", "مشاهده قیمت بازار"),
        ("calculator", "ماشین حساب ریسک و حجم"),
        ("referral", "لینک و آمار رفرال"),
        ("account", "حساب‌های من، امتیاز و جوایز"),
        ("trading", "مرکز معاملات، ژورنال و واچ لیست"),
        ("signals", "مشاهده سیگنال‌ها"),
        ("support", "پشتیبانی و تیکت‌ها"),
        ("language", "تغییر زبان فارسی یا انگلیسی"),
        ("id", "نمایش شناسه کاربر و چت"),
        ("cancel", "لغو عملیات جاری"),
    ]
    en_commands = [
        ("start", "Start the bot and show the main menu"),
        ("menu", "Open the main menu"),
        ("vip", "Buy or manage VIP subscription"),
        ("prices", "View live market prices"),
        ("calculator", "Risk and position-size calculator"),
        ("referral", "Referral link and performance"),
        ("account", "My account, points and rewards"),
        ("trading", "Trading center, journal and watchlist"),
        ("signals", "View trading signals"),
        ("support", "Support and tickets"),
        ("language", "Change Persian or English language"),
        ("id", "Show user and chat ID"),
        ("cancel", "Cancel the current action"),
    ]
    metadata_operations = (
        ("commands_fa", lambda: application.bot.set_my_commands(fa_commands)),
        ("commands_en", lambda: application.bot.set_my_commands(en_commands, language_code="en")),
        ("command_menu", lambda: application.bot.set_chat_menu_button(menu_button=MenuButtonCommands())),
    )
    for metadata_name, metadata_operation in metadata_operations:
        try:
            await asyncio.wait_for(metadata_operation(), timeout=command_timeout)
            metric_gauge(f"telegram_metadata_{metadata_name}_ok", 1)
        except Exception:
            metric_gauge(f"telegram_metadata_{metadata_name}_ok", 0)
            logger.warning(
                "Telegram metadata setup %s failed/timed out; startup continues",
                metadata_name,
                exc_info=True,
            )
    metric_gauge("telegram_initialized", 1)
    set_readiness_state("bootstrap_complete", True)
    from core.runtime_watchdog import start_runtime_watchdog
    def actual_delivery_probe() -> dict[str, Any]:
        probe = dict(getattr(application.update_processor, "delivery_probe", lambda: {})())
        probe["pending"] = max(application.update_queue.qsize(), int(probe.get("pending", 0) or 0))
        return probe

    start_runtime_watchdog(
        heartbeat_file=SETTINGS.heartbeat_file,
        heartbeat_max_age_seconds=SETTINGS.heartbeat_max_age_seconds,
        application_running=lambda: telegram_transport_running() and processor_healthy(),
        health_server_required=bool(SETTINGS.health_port),
        delivery_probe=actual_delivery_probe,
    )
    logger.info("SENTINEL bot initialized as @%s", getattr(application.bot, "username", "unknown"))


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    metric_increment("unhandled_update_errors_total")
    error_ref = uuid.uuid4().hex[:10].upper()
    error = context.error
    if error:
        record_observability_error("update", error)
    logger.exception("Unhandled update error ref=%s", error_ref, exc_info=error)
    update_id = getattr(update, "update_id", None)
    if update_id is not None:
        try:
            from core.telegram_update_outcome import record_update_failure
            record_update_failure(update_id, type(error).__name__ if error else "UnknownError")
        except Exception:
            logger.exception("Could not mark Telegram update failure ref=%s", error_ref)
    user_id = getattr(getattr(update, "effective_user", None), "id", None)
    chat_id = getattr(getattr(update, "effective_chat", None), "id", None)
    try:
        await async_with_db(
            lambda db: record_incident(
                db,
                source="telegram_update",
                kind=type(error).__name__ if error else "UnknownError",
                detail=f"ref={error_ref} | {error!r}",
                severity="critical",
                metadata={"error_ref": error_ref, "update_id": update_id, "user_id": user_id, "chat_id": chat_id},
                dedupe_minutes=5,
            )
        )
    except Exception:
        logger.exception("Could not persist incident ref=%s", error_ref)
    if isinstance(update, Update) and update.effective_message:
        try:
            language = (await run_blocking(_language_for_user, user_id)) if user_id else "fa"
            ai_state = context.user_data.get("sentinel_ai_chat") if isinstance(getattr(context, "user_data", None), dict) else None
            if not isinstance(ai_state, dict) and isinstance(getattr(context, "chat_data", None), dict):
                ai_state = context.chat_data.get("sentinel_ai_chat")
            if isinstance(ai_state, dict):
                text = (
                    "🧠 The Gemini chat is still active. This response was not completed; send the message again.\n"
                    f"Recovery ID: <code>{error_ref}</code>"
                    if language == "en"
                    else "🧠 گفت‌وگوی Gemini همچنان فعال است. پاسخ این پیام کامل نشد؛ پیام را دوباره ارسال کنید.\n"
                    f"شناسه بازیابی: <code>{error_ref}</code>"
                )
            else:
                text = (
                    "❌ An unexpected error occurred. The incident was recorded; please try again.\n"
                    f"Tracking ID: <code>{error_ref}</code>"
                    if language == "en"
                    else "❌ خطای پیش‌بینی‌نشده‌ای رخ داد. رخداد ثبت شد؛ دوباره تلاش کنید.\n"
                    f"شناسه پیگیری: <code>{error_ref}</code>"
                )
            await update.effective_message.reply_text(text, parse_mode=ParseMode.HTML)
        except Exception:
            logger.exception("Could not deliver error recovery message ref=%s", error_ref)



async def unknown_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Recover stale buttons by opening their nearest live menu instead of leaving them dead."""
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    data = str(query.data or "")
    context.user_data.clear()

    recovery_routes = (
        (("buy_", "vip_pay_method:"), u_vip),
        (("calc:", "risk:"), u_calc),
        (("contest_price", "contest_candle", "contest_news", "chart_answer:", "news_answer:"), u_contests),
        (("sig_result", "sig_stats", "a_signal_results"), a_signal_results),
        (("sig_",), a_signal),
        (("vip_field:", "vip_usdt_toggle"), a_vip_settings),
        (("disc_",), a_disc),
        (("price_alert", "pa_", "usdt_convert"), u_price),
        (("admin_user", "admin_private", "bcast_", "a_users", "a_broadcast"), admin_home),
        (("admin_add", "admin_manage:", "admin_perm:", "admin_perm_all:", "admin_remove:", "a_admins"), a_admins),
        (("reward_points:", "a_reward_points"), a_reward_points),
        (("lesson_",), a_edu),
        (("mission_",), a_missions),
        (("vip_extend", "vip_days:"), a_vip_ext),
        (("ticket_u",), u_support),
        (("ticket_a",), a_tickets),
        (("faq_add", "faq_delete:"), a_faq),
        (("faq:",), u_faq),
        (
            (
                "price_contest",
                "pc_",
                "chart_contest",
                "chart_duration:",
                "chart_final:",
                "candle_contest",
                "candle_duration:",
                "contest_rewards_set",
            ),
            a_contest,
        ),
        (("approve:", "reject:", "pending_detail:", "a_pending:"), a_pending),
        (("reward_done:",), a_reward_requests),
        (("redeem:",), u_rewards),
        (("edu_cat:", "lesson:"), u_edu),
        (("price:", "price_energy", "iran_prices", "crypto_", "stock_"), u_price),
        (("nav_user:",), home_callback),
        (("admin_cat:",), admin_home),
        (("u_signal_portal", "user_signal_"), user_signal_portal),
        (("user_watchlist", "watchlist_", "user_journal", "journal_"), user_signal_portal),
        (("a_portfolio", "portfolio_"), a_portfolio),
        (("owner_kpi_",), owner_kpi_center),
        (("a_signal_cycle",), admin_signal_cycle),
        (("mi_admin", "mi_news", "mi_scenario", "a_market_intel"), a_market_intel),
        (("mi_", "u_market_intel"), u_market_intel),
    )
    for prefixes, callback in recovery_routes:
        if any(data == prefix or data.startswith(prefix) for prefix in prefixes):
            await callback(update, context)
            return

    await query.answer(
        "This old menu was refreshed." if language == "en" else "منوی دکمه قدیمی تازه‌سازی شد.",
        show_alert=False,
    )
    await edit(query, (await run_blocking(user_home_text, query.from_user.id)), (await run_blocking(main_menu, query.from_user.id)))


async def portfolio_conversation_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("portfolio_note_uid", None)
    context.user_data.pop("portfolio_result", None)
    context.user_data.pop("journal_result_id", None)
    data = str(update.callback_query.data or "") if update.callback_query else ""
    if data == "a_portfolio":
        await a_portfolio(update, context)
    else:
        await user_journal(update, context)
    return ConversationHandler.END


async def internal_search_conversation_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    data = str(update.callback_query.data or "") if update.callback_query else ""
    if data == "nav_user:growth":
        await user_navigation(update, context)
    else:
        await home_callback(update, context)
    return ConversationHandler.END


async def sales_growth_conversation_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("vip_plan_draft", None)
    context.user_data.pop("vip_plan_edit", None)
    context.user_data.pop("public_discount_draft", None)
    data = str(update.callback_query.data or "") if update.callback_query else ""
    if data == "a_vip_plans":
        await a_vip_plans(update, context)
    elif data == "a_public_discounts":
        await a_public_discounts(update, context)
    else:
        await admin_navigation(update, context)
    return ConversationHandler.END


def _secure_persistence_location(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.parent.chmod(0o700)
    except OSError:
        logger.warning("Could not restrict persistence directory permissions: %s", path.parent)
    if not path.exists():
        return
    if path.is_symlink() or not path.is_file():
        raise RuntimeError("PERSISTENCE_FILE must be a regular file and must not be a symbolic link")
    try:
        path.chmod(0o600)
    except OSError as exc:
        raise RuntimeError(f"Could not secure PERSISTENCE_FILE permissions: {path}") from exc


def build_application() -> Application:
    from telegram.ext import TypeHandler

    from core.resilient_bot import make_bot
    if SETTINGS.database_url:
        persistence = SafePostgresPersistence(SETTINGS.database_url, update_interval=15)
    else:
        _secure_persistence_location(SETTINGS.persistence_file)
        persistence = SafeSQLitePersistence(
            filepath=SETTINGS.persistence_file,
            update_interval=15,
        )
    app = (
        Application.builder()
        .bot(make_bot(SETTINGS.bot_token))
        .persistence(persistence)
        .concurrent_updates(KeyedUpdateProcessor(SETTINGS.concurrent_updates))
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    ai_chat_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(
                u_ai_chat_start,
                pattern=r"^(?:u_ai_chat_start|u_ai_hub(?::(?:home|u_price|u_calc|trade|markets|tools|learning|account|club|support|challenges))?)$",
            ),
            CallbackQueryHandler(a_ai_chat_start, pattern=r"^a_ai_chat_start$"),
            CallbackQueryHandler(a_admin_search_start, pattern=r"^a_admin_search$"),
            CommandHandler("asearch", admin_search_command),
            CommandHandler("copilot", copilot_command),
        ],
        states={
            "AI_CHAT_SCOPE": [
                CallbackQueryHandler(a_ai_chat_scope, pattern=r"^a_ai_chat_scope:(?:management|crm|user_behavior|channel|tickets|signals|risk|system|knowledge)$"),
                CallbackQueryHandler(ai_chat_home, pattern=r"^ai_chat_home:(?:user|admin)$"),
                CallbackQueryHandler(ai_chat_stop, pattern=r"^ai_chat_stop:(?:user|admin)$"),
            ],
            "AI_CHAT_INPUT": [
                CallbackQueryHandler(user_ai_preset_handler, pattern=r"^u_ai_preset:[a-z_]+$"),
                CallbackQueryHandler(ai_chat_home, pattern=r"^ai_chat_home:(?:user|admin)$"),
                CallbackQueryHandler(ai_voice_transcript_action, pattern=r"^ai_voice_(?:confirm|cancel):[a-f0-9]{16}$"),
                MessageHandler(filters.ChatType.PRIVATE & filters.VOICE, ai_chat_voice_router),
                MessageHandler(filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND, ai_chat_message_router),
                CallbackQueryHandler(ai_chat_stop, pattern=r"^ai_chat_stop:(?:user|admin)$"),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
        ],
        allow_reentry=True,
        per_message=False,
        name="ai_chat_conversation",
        persistent=True,
    )

    buy_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(vip_payment_method_select, pattern=r"^vip_pay_method:(?:card|usdt)$"),
            CallbackQueryHandler(buy_has_coupon, pattern=r"^buy_has_coupon$"),
            CallbackQueryHandler(buy_no_coupon, pattern=r"^buy_no_coupon$"),
        ],
        states={
            BUY_COUPON: [MessageHandler(filters.TEXT & ~filters.COMMAND, buy_coupon_text)],
            BUY_TXID: [MessageHandler(filters.TEXT & ~filters.COMMAND, buy_txid_text)],
            BUY_RECEIPT: [
                MessageHandler(filters.PHOTO, buy_receipt),
                MessageHandler(~filters.PHOTO & ~filters.COMMAND, buy_receipt_invalid),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(u_vip, pattern=r"^u_vip$"),
            CallbackQueryHandler(vip_plan_select, pattern=r"^vip_plan:\d+$"),
            CallbackQueryHandler(vip_payment_method_select, pattern=r"^vip_pay_method:(?:card|usdt)$"),
            CallbackQueryHandler(home_callback, pattern=r"^home$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="buy_conversation",
        persistent=True,
    )

    calc_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(u_calc, pattern=r"^u_calc$"), CallbackQueryHandler(signal_calc_start, pattern=r"^signal_calc:\d+$"), CallbackQueryHandler(calc_profile_start, pattern=r"^calc_profile:")],
        states={
            CALC_MARKET: [CallbackQueryHandler(calc_market_handler, pattern=r"^calc_market:"), CallbackQueryHandler(calc_profile_start, pattern=r"^calc_profile:")],
            CALC_PROFILE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, calc_profile_input)],
            CALC_BALANCE_CHOICE: [CallbackQueryHandler(calc_balance_choice, pattern=r"^calc_balance_choice:")],
            CALC_SYMBOL: [CallbackQueryHandler(calc_symbol, pattern=r"^calc_symbol:"), MessageHandler(filters.TEXT & ~filters.COMMAND, calc_symbol_text)],
            CALC_BALANCE: [MessageHandler(filters.TEXT & ~filters.COMMAND, calc_balance)],
            CALC_RISK: [CallbackQueryHandler(calc_risk_button, pattern=r"^risk:"), MessageHandler(filters.TEXT & ~filters.COMMAND, calc_risk_text)],
            CALC_ENTRY: [MessageHandler(filters.TEXT & ~filters.COMMAND, calc_entry)],
            CALC_SL: [MessageHandler(filters.TEXT & ~filters.COMMAND, calc_stop)],
            CALC_LEVERAGE: [CallbackQueryHandler(calc_leverage_button, pattern=r"^calc_leverage:"), MessageHandler(filters.TEXT & ~filters.COMMAND, calc_leverage_text)],
            CALC_FEE: [CallbackQueryHandler(calc_fee_button, pattern=r"^calc_fee:"), MessageHandler(filters.TEXT & ~filters.COMMAND, calc_fee_text)],
            CALC_CROSS: [MessageHandler(filters.TEXT & ~filters.COMMAND, calc_cross_text)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(u_calc, pattern=r"^u_calc$"),
            CallbackQueryHandler(home_callback, pattern=r"^home$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="calc_conversation",
        persistent=True,
    )

    user_contest_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(contest_price_join, pattern=r"^contest_price$"),
            CallbackQueryHandler(contest_candle_join, pattern=r"^contest_candle$"),
        ],
        states={
            PRICE_GUESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, contest_price_guess)],
            CANDLE_GUESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, candle_guess)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(u_contests, pattern=r"^u_contests$")],
        allow_reentry=True,
        per_message=False,
        name="user_contest_conversation",
        persistent=True,
    )

    signal_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(a_signal, pattern=r"^a_signal$"), CallbackQueryHandler(signal_channel_id_start, pattern=r"^sig_channel_id_start$"), CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:"), CallbackQueryHandler(navigation_back, pattern=r"^nb:sig_back:")],
        states={
            SIG_MARKET: [
                CallbackQueryHandler(signal_market_handler, pattern=r"^sig_market:"),
                CallbackQueryHandler(signal_channel_id_start, pattern=r"^sig_channel_id_start$"),
                CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:"),
            ],
            SIG_SYMBOL: [
                CallbackQueryHandler(signal_symbol, pattern=r"^sig_symbol:"),
                CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, signal_symbol_text),
            ],
            SIG_TYPE: [CallbackQueryHandler(signal_side, pattern=r"^sig_side:"), CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:")],
            SIG_ENTRY: [MessageHandler(filters.TEXT & ~filters.COMMAND, signal_entry), CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:")],
            SIG_TP: [MessageHandler(filters.TEXT & ~filters.COMMAND, signal_targets), CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:")],
            SIG_SL: [MessageHandler(filters.TEXT & ~filters.COMMAND, signal_stop), CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:")],
            SIG_RISK: [
                CallbackQueryHandler(signal_risk_button, pattern=r"^sig_risk:"),
                CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, signal_risk_text),
            ],
            SIG_CHART_IMAGE: [
                MessageHandler(filters.PHOTO, signal_chart_image),
                CallbackQueryHandler(signal_chart_skip, pattern=r"^sig_chart_skip$"),
                CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:"),
            ],
            SIG_TARGET: [
                CallbackQueryHandler(signal_target, pattern=r"^sig_target:(?:public|private|both)$"),
                CallbackQueryHandler(signal_preview_target, pattern=r"^sig_preview_target$"),
                CallbackQueryHandler(signal_chart_change, pattern=r"^sig_chart_change$"),
                CallbackQueryHandler(signal_publish_now, pattern=r"^sig_publish_now$"),
                CallbackQueryHandler(signal_schedule_start, pattern=r"^sig_schedule_start$"),
                CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:"),
            ],
            SIG_SCHEDULE_TIME: [MessageHandler(filters.TEXT & ~filters.COMMAND, signal_schedule_input), CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:")],
            SIGNAL_CHANNEL_ID_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, signal_channel_id_input),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(signal_wizard_back, pattern=r"^sig_back:"),
            CallbackQueryHandler(a_signal, pattern=r"^a_signal$"),
            CallbackQueryHandler(admin_home, pattern=r"^admin_home$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="signal_conversation",
        persistent=True,
    )

    signal_template_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(signal_template_upload_start, pattern=r"^sig_tpl_upload:(?:buy|sell)$"),
                      CallbackQueryHandler(signal_color_custom_start, pattern=r"^sig_color_custom:(?:buy|sell):(?:symbol|entry|stop|tp1|tp2|tp3|risk)$")],
        states={
            SIGNAL_TEMPLATE_COLOR_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, signal_color_custom_input)],
            SIGNAL_TEMPLATE_UPLOAD_INPUT: [
                MessageHandler((filters.PHOTO | filters.Document.ALL) & ~filters.COMMAND, signal_template_upload_input),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(signal_template_upload_cancel, pattern=r"^sig_tpl_side:(?:buy|sell)$"),
            CallbackQueryHandler(signal_template_home, pattern=r"^sig_tpl_home$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="signal_template_conversation",
        persistent=True,
    )

    announcement_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(announcement_start, pattern=r"^announce_new$")],
        states={
            ANNOUNCE_DEST: [CallbackQueryHandler(announcement_destination, pattern=r"^announce_dest:(?:public|private|both)$")],
            ANNOUNCE_TOPIC: [CallbackQueryHandler(announcement_topic, pattern=r"^announce_topic:[a-z_]+$")],
            ANNOUNCE_CUSTOM_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, announcement_custom_title)],
            ANNOUNCE_CONTENT: [MessageHandler(~filters.COMMAND, announcement_content)],
            ANNOUNCE_CONFIRM: [CallbackQueryHandler(announcement_publish, pattern=r"^announce_publish$")],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_announcement, pattern=r"^a_announcement$"), CallbackQueryHandler(admin_home, pattern=r"^admin_home$")],
        allow_reentry=True,
        per_message=False,
        name="announcement_conversation",
        persistent=True,
    )

    vip_settings_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(a_vip_settings, pattern=r"^a_vip_settings$")],
        states={
            VIP_FIELD_VALUE: [
                CallbackQueryHandler(vip_usdt_toggle_handler, pattern=r"^vip_usdt_toggle$"),
                CallbackQueryHandler(vip_field_select, pattern=r"^vip_field:"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, vip_field_value),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(a_vip_settings, pattern=r"^a_vip_settings$"),
            CallbackQueryHandler(admin_home, pattern=r"^admin_home$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="vip_settings_conversation",
        persistent=True,
    )

    discount_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(disc_create_start, pattern=r"^disc_create$"),
            CallbackQueryHandler(disc_send_start, pattern=r"^disc_send$"),
            CallbackQueryHandler(disc_random_start, pattern=r"^disc_random$"),
        ],
        states={
            DISC_PERCENT: [
                CallbackQueryHandler(disc_percent_select, pattern=r"^disc_percent:"),
                CallbackQueryHandler(disc_refill_do, pattern=r"^disc_refill_do:"),
            ],
            DISC_SEND_UID: [MessageHandler(filters.TEXT & ~filters.COMMAND, disc_send_uid)],
            DISC_SEND_PERCENT: [CallbackQueryHandler(disc_send_percent, pattern=r"^disc_send_percent:")],
            DISC_RANDOM_PERCENT: [CallbackQueryHandler(disc_random_percent, pattern=r"^disc_random_percent:")],
            DISC_RANDOM_COUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, disc_random_count)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_disc, pattern=r"^a_disc$")],
        allow_reentry=True,
        per_message=False,
        name="discount_conversation",
        persistent=True,
    )

    price_alert_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(price_alert_new, pattern=r"^price_alert_new$"),
            CallbackQueryHandler(signal_alert_start, pattern=r"^signal_alert:\d+$"),
            CallbackQueryHandler(usdt_convert_start, pattern=r"^usdt_convert$"),
        ],
        states={
            PRICE_ALERT_ASSET: [
                CallbackQueryHandler(price_alert_asset, pattern=r"^pa_asset:"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, price_alert_asset_text),
            ],
            PRICE_ALERT_CONDITION: [CallbackQueryHandler(price_alert_condition, pattern=r"^pa_cond:")],
            PRICE_ALERT_VALUE: [MessageHandler(filters.TEXT & ~filters.COMMAND, price_alert_value)],
            USDT_CONVERT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, usdt_convert_amount)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(u_price, pattern=r"^u_price$")],
        allow_reentry=True,
        per_message=False,
        name="price_alert_conversation",
        persistent=True,
    )

    crypto_search_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(crypto_search_start, pattern=r"^crypto_search$")],
        states={
            CRYPTO_SEARCH_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, crypto_search_input),
                CallbackQueryHandler(crypto_search_pick, pattern=r"^crypto_pick:[a-z0-9-]+$"),
                CallbackQueryHandler(crypto_search_page, pattern=r"^crypto_page:(?:\d+|noop)$"),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(crypto_search_start, pattern=r"^crypto_search$"),
            CallbackQueryHandler(crypto_menu, pattern=r"^crypto_menu$"),
            CallbackQueryHandler(u_price, pattern=r"^u_price$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="crypto_search_conversation",
        persistent=True,
    )

    stock_search_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(stock_search_start, pattern=r"^stock_search$")],
        states={
            STOCK_SEARCH_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, stock_search_input),
                CallbackQueryHandler(stock_search_pick, pattern=r"^stock_pick:[A-Z0-9.\-]+$"),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(stock_search_start, pattern=r"^stock_search$"),
            CallbackQueryHandler(stock_menu, pattern=r"^stock_menu$"),
            CallbackQueryHandler(u_price, pattern=r"^u_price$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="stock_search_conversation",
        persistent=True,
    )

    market_search_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(market_search_start, pattern=r"^market_search$")],
        states={
            MARKET_SEARCH_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, market_search_input)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(market_search_start, pattern=r"^market_search$"),
            CallbackQueryHandler(u_price, pattern=r"^u_price$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="market_search_conversation",
        persistent=True,
    )

    admin_user_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(a_users, pattern=r"^a_users$"),
            CallbackQueryHandler(a_crm, pattern=r"^a_crm$"),
            CallbackQueryHandler(admin_user_points_start, pattern=r"^admin_user_points:"),
            CallbackQueryHandler(admin_user_ban_start, pattern=r"^admin_user_ban:"),
            CallbackQueryHandler(admin_private_add_start, pattern=r"^admin_private_add$"),
        ],
        states={
            ADMIN_USER_SEARCH: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_user_search)],
            ADMIN_USER_POINTS: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_user_points_input)],
            ADMIN_USER_BAN_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_user_ban_reason)],
            ADMIN_PRIVATE_CHANNEL_DAYS: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_private_add_days)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(admin_home, pattern=r"^admin_home$")],
        allow_reentry=True,
        per_message=False,
        name="admin_user_conversation",
        persistent=True,
    )

    admin_access_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_add_start, pattern=r"^admin_add$")],
        states={ADMIN_ADD_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_add_id_input)]},
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(a_admins, pattern=r"^a_admins$"),
            CallbackQueryHandler(admin_home, pattern=r"^admin_home$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="admin_access_conversation",
        persistent=True,
    )

    broadcast_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(a_broadcast, pattern=r"^a_broadcast$")],
        states={
            BROADCAST_SEGMENT: [CallbackQueryHandler(broadcast_segment, pattern=r"^bcast_segment:")],
            BROADCAST_MESSAGE: [MessageHandler(filters.ALL & ~filters.COMMAND, broadcast_message)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(a_announcement, pattern=r"^a_announcement$"),
            CallbackQueryHandler(admin_home, pattern=r"^admin_home$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="broadcast_conversation",
        persistent=True,
    )

    reward_points_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(reward_points_select, pattern=r"^(?:reward_points:|reward_referral:)")],
        states={REWARD_POINTS_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, reward_points_input)]},
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_reward_points, pattern=r"^a_reward_points$")],
        allow_reentry=True,
        per_message=False,
        name="reward_points_conversation",
        persistent=True,
    )

    lesson_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(lesson_add_start, pattern=r"^lesson_add$"),
            CallbackQueryHandler(lesson_edit_start, pattern=r"^lesson_edit:\d+$"),
            CallbackQueryHandler(lesson_media_add_start, pattern=r"^lesson_media_add:\d+$"),
        ],
        states={
            LESSON_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, lesson_add_input)],
            LESSON_EDIT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, lesson_edit_input)],
            LESSON_MEDIA_INPUT: [
                CallbackQueryHandler(lesson_media_done, pattern=r"^lesson_media_done:\d+$"),
                MessageHandler(filters.ALL & ~filters.COMMAND, lesson_media_input),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_edu, pattern=r"^a_edu$")],
        allow_reentry=True,
        per_message=False,
        name="lesson_conversation",
        persistent=True,
    )

    mission_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(mission_add_start, pattern=r"^mission_add$"),
            CallbackQueryHandler(mission_manual_start, pattern=r"^mission_manual$"),
            CallbackQueryHandler(mission_edit_start, pattern=r"^mission_edit:\d+$"),
        ],
        states={
            MISSION_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, mission_add_input)],
            MISSION_EDIT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, mission_edit_input)],
            MISSION_MANUAL_UID: [MessageHandler(filters.TEXT & ~filters.COMMAND, mission_manual_uid)],
            MISSION_MANUAL_ID: [CallbackQueryHandler(mission_manual_complete, pattern=r"^mission_manual_id:")],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_missions, pattern=r"^a_missions$")],
        allow_reentry=True,
        per_message=False,
        name="mission_conversation",
        persistent=True,
    )

    vip_extension_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(vip_extend_one_start, pattern=r"^vip_extend_one$"),
            CallbackQueryHandler(vip_extend_all_start, pattern=r"^vip_extend_all$"),
        ],
        states={
            VIP_EXT_UID: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_extend_uid)],
            VIP_EXT_DAYS: [CallbackQueryHandler(vip_extend_days, pattern=r"^vip_days:")],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_vip_ext, pattern=r"^a_vip_ext$")],
        allow_reentry=True,
        per_message=False,
        name="vip_extension_conversation",
        persistent=True,
    )

    ticket_media_filter = (
        filters.TEXT | filters.PHOTO | filters.Document.ALL | filters.VIDEO | filters.VOICE | filters.AUDIO
    ) & ~filters.COMMAND
    ticket_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(ticket_new_start, pattern=r"^ticket_new$"),
            CallbackQueryHandler(ticket_context_start, pattern=r"^ticket_from:[a-z_]+:[a-zA-Z0-9_-]+$"),
            CallbackQueryHandler(ticket_user_reply_start, pattern=r"^ticket_u_reply:\d+$"),
            CallbackQueryHandler(ticket_admin_reply_start, pattern=r"^ticket_a_reply:\d+$"),
            CallbackQueryHandler(ticket_note_start, pattern=r"^ticket_note:\d+$"),
            CallbackQueryHandler(ticket_canned_add_start, pattern=r"^ticket_canned_add$"),
        ],
        states={
            TICKET_NEW_MESSAGE: [
                CallbackQueryHandler(ticket_new_category, pattern=r"^ticket_cat:(?:general|account|payment|signal|education|technical)$"),
                MessageHandler(ticket_media_filter, ticket_new_message),
            ],
            TICKET_USER_REPLY: [MessageHandler(ticket_media_filter, ticket_user_reply_message)],
            TICKET_ADMIN_REPLY: [MessageHandler(ticket_media_filter, ticket_admin_reply_message)],
            TICKET_INTERNAL_NOTE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, ticket_note_input)],
            TICKET_CANNED_REPLY_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, ticket_canned_add_input)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(u_support, pattern=r"^u_support$"),
            CallbackQueryHandler(a_tickets, pattern=r"^a_tickets$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="ticket_conversation",
        persistent=True,
    )

    faq_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(faq_add_start, pattern=r"^faq_add$"),
            CallbackQueryHandler(faq_edit_start, pattern=r"^faq_edit:\d+$"),
            CallbackQueryHandler(faq_search_start, pattern=r"^faq_search$"),
        ],
        states={
            FAQ_ADD_QUESTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, faq_add_question)],
            FAQ_ADD_ANSWER: [MessageHandler(filters.TEXT & ~filters.COMMAND, faq_add_answer)],
            FAQ_EDIT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, faq_edit_input)],
            FAQ_SEARCH_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, faq_search_input)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_faq, pattern=r"^a_faq$")],
        allow_reentry=True,
        per_message=False,
        name="faq_conversation",
        persistent=True,
    )

    contest_reward_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(contest_rewards_start, pattern=r"^contest_rewards_set$")],
        states={CONTEST_REWARD_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, contest_rewards_input)]},
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_contest, pattern=r"^a_contest$")],
        allow_reentry=True,
        per_message=False,
        name="contest_reward_conversation",
        persistent=True,
    )

    admin_contest_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(price_contest_start, pattern=r"^price_contest_start$"),
            CallbackQueryHandler(price_contest_end, pattern=r"^price_contest_end$"),
            CallbackQueryHandler(chart_contest_start, pattern=r"^chart_contest_start$"),
            CallbackQueryHandler(chart_contest_end, pattern=r"^chart_contest_end$"),
            CallbackQueryHandler(candle_contest_start, pattern=r"^candle_contest_start$"),
            CallbackQueryHandler(candle_contest_end, pattern=r"^candle_contest_end$"),
            CallbackQueryHandler(news_contest_start, pattern=r"^news_contest_start$"),
            CallbackQueryHandler(news_contest_end, pattern=r"^news_contest_end$"),
        ],
        states={
            PRICE_CONTEST_SYMBOL: [CallbackQueryHandler(price_contest_symbol, pattern=r"^pc_symbol:")],
            PRICE_CONTEST_MEDIA: [
                CallbackQueryHandler(price_contest_media_skip, pattern=r"^pc_media_skip$"),
                MessageHandler((filters.PHOTO | filters.TEXT) & ~filters.COMMAND, price_contest_media),
            ],
            PRICE_CONTEST_DURATION: [CallbackQueryHandler(price_contest_duration, pattern=r"^pc_duration:")],
            PRICE_CONTEST_FINAL: [MessageHandler(filters.TEXT & ~filters.COMMAND, price_contest_final)],
            CHART_CONTEST_INPUT: [MessageHandler((filters.PHOTO | filters.TEXT) & ~filters.COMMAND, chart_contest_input)],
            CHART_CONTEST_DURATION: [CallbackQueryHandler(chart_contest_duration, pattern=r"^chart_duration:")],
            CHART_CONTEST_FINAL: [CallbackQueryHandler(chart_contest_final, pattern=r"^chart_final:")],
            CANDLE_CONTEST_QUESTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, candle_contest_question)],
            CANDLE_CONTEST_DURATION: [CallbackQueryHandler(candle_contest_duration, pattern=r"^candle_duration:")],
            CANDLE_CONTEST_FINAL: [MessageHandler(filters.TEXT & ~filters.COMMAND, candle_contest_final)],
            NEWS_CONTEST_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, news_contest_name)],
            NEWS_CONTEST_RESULT: [CallbackQueryHandler(news_contest_final, pattern=r"^news_final:")],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(a_contest, pattern=r"^a_contest$")],
        allow_reentry=True,
        per_message=False,
        name="admin_contest_conversation",
        persistent=True,
    )

    management_suite_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(crm_note_start, pattern=r"^crm_note(?::\d+)?$"),
            CallbackQueryHandler(crm_message_start, pattern=r"^crm_message:\d+$"),
            CallbackQueryHandler(crm_tag_start, pattern=r"^crm_tag(?::\d+)?$"),
            CallbackQueryHandler(crm_followup_start, pattern=r"^crm_followup(?::\d+)?$"),
            CallbackQueryHandler(crm_custom_field_start, pattern=r"^crm_field:\d+:[a-z_]+$"),
            CallbackQueryHandler(automation_setting_start, pattern=r"^auto_set:[a-z_]+$"),
            CallbackQueryHandler(shift_set_start, pattern=r"^shift_set:\d+$"),
            CallbackQueryHandler(signal_edit_start, pattern=r"^sig_edit:\d+:(?:stop|entry|add_target|note|target_\d+)$"),
            CallbackQueryHandler(signal_metrics_start, pattern=r"^sig_metrics:\d+$"),
            CallbackQueryHandler(signal_result_media_start, pattern=r"^sig_result_media:\d+$"),
            CallbackQueryHandler(signal_result_media_start, pattern=r"^sig_lifecycle:\d+:(?:manual_close|stop|tp\d+)$"),
            CallbackQueryHandler(signal_result_media_start, pattern=r"^sig_result_set:\d+:(?:target|stop)$"),
            CallbackQueryHandler(force_join_link_start, pattern=r"^force_join_link_start$"),
            CallbackQueryHandler(control_edit_start, pattern=r"^ecc_edit:[a-z0-9_]+:[a-z0-9_]+$"),
            CallbackQueryHandler(education_buy_start, pattern=r"^edu_buy:\d+$"),
        ],
        states={
            CRM_NOTE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, crm_note_input)],
            CRM_MESSAGE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, crm_message_input)],
            CRM_TAG_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, crm_tag_input)],
            CRM_FOLLOWUP_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, crm_followup_input)],
            CRM_CUSTOM_FIELD_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, crm_custom_field_input)],
            AUTOMATION_SETTING_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, automation_setting_input)],
            ADMIN_SHIFT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, shift_set_input)],
            SIGNAL_EDIT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, signal_edit_input)],
            SIGNAL_METRICS_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, signal_metrics_input)],
            SIGNAL_RESULT_MEDIA_INPUT: [
                CallbackQueryHandler(signal_result_media_cancel, pattern=r"^sig_result_media_cancel:\d+$"),
                MessageHandler(filters.PHOTO, signal_result_media_input),
                MessageHandler(~filters.PHOTO & ~filters.COMMAND, signal_result_media_invalid),
            ],
            FORCE_JOIN_LINK_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, force_join_link_input)],
            ENTERPRISE_CONTROL_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, control_edit_input)],
            EDUCATION_RECEIPT: [
                MessageHandler(filters.PHOTO, education_receipt),
                MessageHandler(~filters.PHOTO & ~filters.COMMAND, education_receipt_invalid),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),CommandHandler("cancel", cancel_command), CallbackQueryHandler(admin_home, pattern=r"^admin_home$")],
        allow_reentry=True,
        per_message=False,
        name="management_suite_conversation",
        persistent=True,
    )

    internal_search_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(internal_search_start, pattern=r"^u_search$")],
        states={
            INTERNAL_SEARCH_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, internal_search_input)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(internal_search_conversation_cancel, pattern=r"^(?:nav_user:growth|home)$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="internal_search_conversation",
        persistent=True,
    )

    sales_growth_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(vip_plan_add_start, pattern=r"^vip_plan_add$"),
            CallbackQueryHandler(vip_plan_quick_start, pattern=r"^vip_plan_quick$"),
            CallbackQueryHandler(vip_plan_wizard_start, pattern=r"^vip_plan_wizard$"),
            CallbackQueryHandler(
                vip_plan_edit_start,
                pattern=r"^vip_plan_edit:\d+:(?:name|description|price|original_price|duration_days|sales_limit|features|window)$",
            ),
            CallbackQueryHandler(public_discount_add_start, pattern=r"^public_discount_add$"),
            CallbackQueryHandler(public_discount_quick_start, pattern=r"^public_discount_quick$"),
            CallbackQueryHandler(public_discount_wizard_start, pattern=r"^public_discount_wizard$"),
            CallbackQueryHandler(public_discount_edit_start, pattern=r"^public_discount_edit:[A-Z0-9_-]+$"),
            CallbackQueryHandler(public_discount_batch_start, pattern=r"^public_discount_batch:[A-Z0-9_-]+$"),
            CallbackQueryHandler(public_discount_affiliate_start, pattern=r"^public_discount_affiliate:[A-Z0-9_-]+$"),
        ],
        states={
            VIP_PLAN_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_add_input)],
            VIP_PLAN_NAME_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_name)],
            VIP_PLAN_PRICE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_price)],
            VIP_PLAN_DAYS_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_days)],
            VIP_PLAN_AUDIENCE_INPUT: [CallbackQueryHandler(vip_plan_wizard_audience, pattern=r"^vip_plan_audience:(?:all|new|renewal)$")],
            VIP_PLAN_ORIGINAL_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_original)],
            VIP_PLAN_LIMIT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_limit)],
            VIP_PLAN_HIGHLIGHT_INPUT: [CallbackQueryHandler(vip_plan_wizard_highlight, pattern=r"^vip_plan_featured:(?:yes|no)$")],
            VIP_PLAN_FEATURES_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_features)],
            VIP_PLAN_DESCRIPTION_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_description)],
            VIP_PLAN_WINDOW_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_wizard_window)],
            VIP_PLAN_EDIT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_plan_edit_input)],
            PUBLIC_DISCOUNT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_add_input)],
            PUBLIC_CODE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_wizard_code)],
            PUBLIC_PERCENT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_wizard_percent)],
            PUBLIC_WINDOW_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_wizard_window)],
            PUBLIC_MAX_USES_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_wizard_max_uses)],
            PUBLIC_USER_LIMIT_INPUT: [CallbackQueryHandler(public_discount_wizard_user_limit, pattern=r"^public_user_limit:(?:yes|no)$")],
            PUBLIC_CAMPAIGN_EDIT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_edit_input)],
            PUBLIC_BATCH_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_batch_input)],
            PUBLIC_AFFILIATE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, public_discount_affiliate_input)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(vip_plan_edit_cancel, pattern=r"^vip_plan_edit_menu:\d+$"),
            CallbackQueryHandler(sales_growth_conversation_cancel, pattern=r"^(?:a_vip_plans|a_public_discounts|admin_cat:sales)$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="sales_growth_conversation",
        persistent=True,
    )

    portfolio_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(portfolio_user_search_start, pattern=r"^portfolio_user_search$"),
            CallbackQueryHandler(portfolio_note_start, pattern=r"^portfolio_note:\d+$"),
            CallbackQueryHandler(portfolio_result_start, pattern=r"^portfolio_result:\d+:\d+$"),
            CallbackQueryHandler(journal_result_start, pattern=r"^journal_result:\d+$"),
            CallbackQueryHandler(journal_new_start, pattern=r"^journal_new:(?:forex|crypto)$"),
        ],
        states={
            PORTFOLIO_USER_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, portfolio_user_search_input)],
            JOURNAL_ADMIN_NOTE_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, portfolio_note_input)],
            PORTFOLIO_RESULT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, portfolio_result_input)],
            JOURNAL_RESULT_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, journal_result_input)],
            JOURNAL_NEW_INPUT: [
                CallbackQueryHandler(journal_new_reason, pattern=r"^journal_reason:(?:forex|crypto):(?:channel_signal|personal_analysis|other)$"),
                CallbackQueryHandler(journal_new_start, pattern=r"^journal_new:(?:forex|crypto)$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, journal_new_input),
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(portfolio_conversation_cancel, pattern=r"^(?:a_portfolio|user_journal(?::(?:forex|crypto))?)$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="portfolio_conversation",
        persistent=True,
    )

    signal_cycle_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(admin_signal_cycle_name_start, pattern=r"^a_signal_cycle_name$"),
            CallbackQueryHandler(admin_signal_cycle_rename_start, pattern=r"^a_signal_cycle_rename$"),
        ],
        states={
            SIGNAL_CYCLE_NAME_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_signal_cycle_name_input)],
            SIGNAL_CYCLE_RENAME_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_signal_cycle_rename_input)],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(signal_cycle_conversation_cancel, pattern=r"^a_signal_cycle$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="signal_cycle_conversation",
        persistent=True,
    )

    rules_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(rules_edit_start, pattern=r"^rules_edit:(?:fa|en)$")],
        states={
            RULES_INPUT: [
                MessageHandler(
                    (filters.TEXT | filters.Document.ALL) & ~filters.COMMAND,
                    rules_input,
                )
            ]
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(rules_admin_view, pattern=r"^a_rules$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="rules_conversation",
        persistent=True,
    )

    campaign_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(campaign_new_start, pattern=r"^campaign_new$"),
            CallbackQueryHandler(campaign_schedule_start, pattern=r"^campaign_schedule:CMP-\d{6}$"),
        ],
        states={
            CAMPAIGN_NAME_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, campaign_name_input)],
            CAMPAIGN_CATEGORY_INPUT: [
                CallbackQueryHandler(campaign_category_input, pattern=r"^campaign_cat:[a-z_]+$")
            ],
            CAMPAIGN_AUDIENCE_INPUT: [
                CallbackQueryHandler(campaign_audience_input, pattern=r"^campaign_audience:[a-z_]+$")
            ],
            CAMPAIGN_DISCOUNT_INPUT: [
                CallbackQueryHandler(campaign_discount_none, pattern=r"^campaign_discount:none$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, campaign_discount_input),
            ],
            CAMPAIGN_MESSAGE_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, campaign_message_input)
            ],
            CAMPAIGN_TRACKING_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, campaign_tracking_input)
            ],
            CAMPAIGN_DELIVERY_INPUT: [
                CallbackQueryHandler(
                    campaign_delivery_input,
                    pattern=r"^campaign_delivery:(?:draft|link_bot|link_channel|link_both)$",
                )
            ],
            CAMPAIGN_SCHEDULE_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, campaign_schedule_input)
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(campaign_studio_view, pattern=r"^a_campaigns$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="campaign_conversation",
        persistent=True,
    )

    channel_link_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(channel_link_create_start, pattern=r"^channel_link_new$")],
        states={
            CHANNEL_LINK_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, channel_link_create_input)
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(channel_attribution_view, pattern=r"^a_channel_attribution$"),
        ],
        allow_reentry=True,
        per_message=False,
        name="channel_link_conversation",
        persistent=True,
    )

    kpi_trader_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(kpi_task_new_start, pattern=r"^kpi_task_new$"),
            CallbackQueryHandler(
                owner_kpi_assign_start, pattern=r"^owner_kpi_assign:\d+$"
            ),
            CallbackQueryHandler(
                owner_kpi_score_start, pattern=r"^owner_kpi_score:\d+$"
            ),
            CallbackQueryHandler(
                owner_kpi_limits_start, pattern=r"^owner_kpi_limits$"
            ),
            CallbackQueryHandler(
                kpi_business_outcome_start, pattern=r"^kpi_business:KPI-\d{6}$"
            ),
            CallbackQueryHandler(
                kpi_submission_start, pattern=r"^kpi_task_submit:KPI-\d{6}$"
            ),
            CallbackQueryHandler(
                kpi_review_reject_start,
                pattern=r"^kpi_review_reject:KPS-\d{6}$",
            ),
        ],
        states={
            KPI_TASK_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, kpi_task_new_input)
            ],
            KPI_SUBMISSION_INPUT: [
                MessageHandler(
                    (
                        filters.TEXT
                        | filters.PHOTO
                        | filters.Document.ALL
                        | filters.VIDEO
                        | filters.VOICE
                        | filters.AUDIO
                    )
                    & ~filters.COMMAND,
                    kpi_submission_input,
                )
            ],
            KPI_REJECTION_INPUT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, kpi_review_reject_input
                )
            ],
            OWNER_KPI_SCORE_INPUT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, owner_kpi_score_input
                )
            ],
            OWNER_KPI_LIMITS_INPUT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, owner_kpi_limits_input
                )
            ],
            KPI_BUSINESS_OUTCOME_INPUT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, kpi_business_outcome_input
                )
            ],
        },
        fallbacks=[
            MessageHandler(QUICK_MENU_FILTER, quick_menu_button),
            CommandHandler("cancel", cancel_command),
            CallbackQueryHandler(
                kpi_conversation_navigation,
                pattern=(
                    r"^(?:kpi_trader_home|a_kpi_trader|owner_kpi_center|"
                    r"owner_kpi_admin:\d+|kpi_trader_task:KPI-\d{6}|"
                    r"kpi_review_view:KPS-\d{6}|kpi_admin_task:KPI-\d{6})$"
                ),
            ),
        ],
        allow_reentry=True,
        per_message=False,
        name="kpi_trader_conversation",
        persistent=True,
    )

    # Capture the exact current screen before any callback mutates it. This runs
    # in an earlier handler group and never blocks the actual callback handler.
    from core.conversation_reset import reset_conversations_on_exit
    app.add_handler(TypeHandler(Update, reset_conversations_on_exit), group=-9)
    app.add_handler(CallbackQueryHandler(capture_navigation_screen), group=-8)
    register_guard_plan(
        app, CallbackQueryHandler, MessageHandler, filters.ALL, globals(), GUARD_STACK
    )
    # Remove any Reply Keyboard cached by older releases on the user's first
    # private message. Other groups continue processing the same update.
    app.add_handler(
        MessageHandler(filters.ChatType.PRIVATE, command_menu_keyboard_guard),
        group=-7,
    )
    app.add_handler(
        MessageHandler(
            filters.ChatType.CHANNEL & filters.REPLY & (filters.TEXT | filters.CAPTION),
            signal_reply_status_handler,
        ),
        group=1,
    )
    app.add_handler(
        ChatMemberHandler(
            public_channel_membership_update,
            chat_member_types=ChatMemberHandler.CHAT_MEMBER,
        ),
        group=1,
    )
    register_command_plan(app, CommandHandler, globals(), COMMAND_ROUTES)
    experience_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(milestone_config_callback,pattern=r"^ms:choice:\d+:[a-z_]+:[a-z_0-9]+$"),CallbackQueryHandler(experience_input_start, pattern=r"^(?:milestone_new|milestone_field:\d+:[a-z_]+|gift_direct:\d+:[a-f0-9]{12}|gift_redeem_start|palette_start|norm_ticket_reply:[A-Za-z0-9_-]+|handoff_start:\d+)$")],
        states={EXPERIENCE_INPUT: [CallbackQueryHandler(milestone_config_callback,pattern=r"^ms:choice:\d+:[a-z_]+:[a-z_0-9]+$"),CallbackQueryHandler(handoff_target_handler, pattern=r"^handoff_target:\d+$"), MessageHandler(filters.TEXT & ~filters.COMMAND, experience_input_message)]},
        fallbacks=[CommandHandler("cancel", cancel_command)],
        name="experience_conversation", persistent=True, allow_reentry=True, per_message=False,
    )
    creation_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(creation_callback, pattern=r"^(?:a_create|cw:.+)$")],
        states={"CREATION_INPUT": [CallbackQueryHandler(creation_callback, pattern=r"^(?:a_create|cw:.+)$"), MessageHandler(filters.ALL & ~filters.COMMAND, creation_message)]},
        fallbacks=[CommandHandler("cancel", cancel_command)], name="creation_conversation", persistent=True, allow_reentry=True, per_message=False,
    )
    automation_ui_conversation = ConversationHandler(
        entry_points=[CallbackQueryHandler(automation_ui_callback,pattern=r"^au:[A-Za-z0-9_:-]+$")],
        states={AUTOMATION_UI_INPUT:[CallbackQueryHandler(automation_ui_callback,pattern=r"^au:[A-Za-z0-9_:-]+$"),
                                    MessageHandler(filters.TEXT & ~filters.COMMAND,automation_ui_input)]},
        fallbacks=[CommandHandler("cancel",cancel_command)],name="automation_ui_conversation",
        persistent=True,allow_reentry=True,per_message=False,
    )
    conversations = [automation_ui_conversation, creation_conversation, experience_conversation, *resolve_named(locals(), CONVERSATION_HANDLER_NAMES)]
    # Active conversations normally consume every text message. Put the quick
    # menu escape first in every state so the persistent keyboard always exits
    # the current flow instead of being mistaken for a coupon, symbol or note.
    for conversation in conversations:
        for state_handlers in conversation.states.values():
            # These escape controls must win over every free-text or callback form.
            # Inline controls are inserted here too, otherwise an active
            # ConversationHandler can swallow the callback before the global
            # callback router sees it.
            state_handlers.insert(0, CallbackQueryHandler(restart_bot_callback, pattern=r"^restart_bot$"))
            state_handlers.insert(0, CallbackQueryHandler(navigation_back, pattern=r"^(?:nav_back|nb:.+)$"))
            state_handlers.insert(0, CallbackQueryHandler(cancel_current_callback, pattern=r"^cancel_current$"))
            state_handlers.insert(0, MessageHandler(RESTART_BOT_FILTER, restart_command))
            state_handlers.insert(0, MessageHandler(CANCEL_OPERATION_FILTER, cancel_command))
            state_handlers.insert(0, MessageHandler(KEYBOARD_SHORTCUT_FILTER, keyboard_shortcut_button))
            state_handlers.insert(0, MessageHandler(QUICK_MENU_FILTER, quick_menu_button))
    register_handlers(app, conversations)
    # AI asset capture runs after normal conversations, so it cannot steal ticket,
    # signal-template or other feature uploads. It only acts after /aiasset.
    app.add_handler(MessageHandler((filters.PHOTO | filters.Document.ALL) & ~filters.COMMAND, ai_asset_capture), group=2)
    # When no conversation is active, keep the same controls globally available.
    app.add_handler(MessageHandler(KEYBOARD_SHORTCUT_FILTER, keyboard_shortcut_button))
    app.add_handler(MessageHandler(QUICK_MENU_FILTER, quick_menu_button))
    app.add_handler(MessageHandler(CANCEL_OPERATION_FILTER, cancel_command))
    app.add_handler(MessageHandler(RESTART_BOT_FILTER, restart_command))

    register_callback_routes(app, CallbackQueryHandler, callback_routes(globals()))

    app.add_handler(CallbackQueryHandler(unknown_callback))
    app.add_error_handler(error_handler)
    return app


async def _durable_telegram_update_pump(application: Application, stop_event: asyncio.Event, worker_id: str) -> None:
    """Move durably stored Telegram updates into PTB with bounded backpressure."""
    from core.observability import gauge, increment
    from core.telegram_update_store import backlog, claim_pending, mark_failed, release_worker, worker_inflight

    queue_limit = max(10, min(10000, int(os.getenv("WEBHOOK_QUEUE_MAXSIZE", "1000") or 1000)))
    batch_size = max(1, min(100, int(os.getenv("WEBHOOK_QUEUE_BATCH_SIZE", "50") or 50)))
    processor = application.update_processor
    concurrency = max(1, processor.max_concurrent_updates)
    lease_seconds = max(120.0, getattr(processor, 'processing_timeout', 90) + getattr(processor, 'lock_timeout', 5) + 60)
    try:
        while not stop_event.is_set():
            leased = await run_blocking(worker_inflight, worker_id, stale_seconds=lease_seconds, timeout=10)
            depth = int(application.update_queue.qsize())
            gauge("telegram_ptb_queue_depth", depth)
            if depth >= queue_limit or leased >= concurrency:
                increment("telegram_queue_backpressure_total")
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=0.25)
                except TimeoutError:
                    continue
                continue
            capacity = max(1, min(batch_size, queue_limit - depth, concurrency - leased))
            rows = await run_blocking(claim_pending, worker_id, limit=capacity, stale_seconds=lease_seconds, timeout=10)
            set_readiness_state("telegram_update_pump", True)
            if not rows:
                state = await run_blocking(backlog, timeout=10)
                gauge("telegram_update_backlog", int(state.get("pending") or 0))
                gauge("telegram_update_dead", int(state.get("dead") or 0))
                gauge("telegram_update_oldest_age_seconds", int(state.get("oldest_pending_age_seconds") or 0))
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=0.5)
                except TimeoutError:
                    continue
                continue
            for row in rows:
                try:
                    update = Update.de_json(row["payload"], application.bot)
                    await asyncio.wait_for(application.update_queue.put(update), timeout=2.0)
                    increment("telegram_updates_enqueued_total")
                except Exception as exc:
                    status = await run_blocking(mark_failed, row["update_id"], exc.__class__.__name__, timeout=10)
                    increment(f"telegram_updates_{status}_total")
    finally:
        set_readiness_state("telegram_update_pump", False)
        try:
            if stop_event.is_set():
                await run_blocking(release_worker, worker_id, timeout=10)
        except Exception:
            logger.exception("Update pump lease release failed; SQL lease expiry will recover it")


async def _run_unified_webhook(application: Application) -> None:
    """Run Telegram webhook delivery through the already-running FastAPI server."""
    import signal

    from core.miniapp_server import register_telegram_application, unregister_telegram_application
    from core.telegram_bootstrap import initialize_with_retry, supervise_update_pump, telegram_startup_call

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()
    installed_signals: list[signal.Signals] = []

    def request_stop() -> None:
        stop_event.set()

    for signum in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signum, request_stop)
            installed_signals.append(signum)
        except (NotImplementedError, RuntimeError):
            pass

    initialized = False
    started = False
    set_readiness_state("telegram_webhook_registered", False)
    pump_task: asyncio.Task[None] | None = None
    worker_id = f"{os.getenv('RAILWAY_REPLICA_ID') or os.getenv('HOSTNAME') or 'local'}:{os.getpid()}"
    try:
        if not await initialize_with_retry(application, stop_event):
            return
        initialized = True
        if application.post_init is not None:
            await application.post_init(application)
        await application.start()
        started = True
        register_telegram_application(application, loop)
        pump_task = asyncio.create_task(
            supervise_update_pump(application, stop_event, lambda: _durable_telegram_update_pump(application, stop_event, worker_id)),
            name="sentinel-telegram-update-pump",
        )

        webhook_url = f"{SETTINGS.webhook_url.rstrip('/')}/{SETTINGS.webhook_path.strip('/')}"
        async def register_webhook():
            await application.bot.set_webhook(
                url=webhook_url, allowed_updates=Update.ALL_TYPES,
                drop_pending_updates=False, secret_token=SETTINGS.webhook_secret_token,
                max_connections=SETTINGS.webhook_max_connections,
            )

        if await telegram_startup_call(register_webhook, stop_event, name="setWebhook"):
            set_readiness_state("telegram_webhook_registered", True)
            metric_gauge("telegram_webhook_registered", 1)
            logger.info("Unified Telegram webhook registered")
        stop_task = asyncio.create_task(stop_event.wait())
        try:
            await asyncio.wait({stop_task, pump_task}, return_when=asyncio.FIRST_COMPLETED)
            if pump_task.done():
                await pump_task  # propagate fatal delivery failure to process supervisor
        finally:
            stop_task.cancel()
            await asyncio.gather(stop_task, return_exceptions=True)
    finally:
        set_readiness_state("telegram_webhook_registered", False)
        metric_gauge("telegram_webhook_registered", 0)
        stop_event.set()
        if pump_task is not None:
            try:
                await asyncio.wait_for(pump_task, timeout=10)
            except (TimeoutError, asyncio.CancelledError):
                pump_task.cancel()
                await asyncio.gather(pump_task, return_exceptions=True)
            except Exception:
                logger.exception("Update pump stopped after terminal failure")
        unregister_telegram_application(application)
        for signum in installed_signals:
            try:
                loop.remove_signal_handler(signum)
            except (NotImplementedError, RuntimeError):
                pass
        if started and application.running:
            await application.stop()
        if started and application.post_stop is not None:
            await application.post_stop(application)
        if initialized:
            await application.shutdown()
        if initialized and application.post_shutdown is not None:
            await application.post_shutdown(application)


def main() -> None:
    configure_logging()
    SETTINGS.validate()
    configure_telemetry()
    locked = acquire_single_instance(SETTINGS.db_file.parent / ".sentinel-bot.lock", wait_seconds=5)
    if not locked:
        logger.info("Process lock disabled for Railway rolling deployment")
    if not SETTINGS.public_channel_id or not SETTINGS.private_channel_id:
        logger.warning("One or more channel IDs are not configured; channel-only features will remain unavailable")
    with_db(ensure_discount_system)
    configure_observability(SETTINGS.metrics_file, SETTINGS.heartbeat_file, SETTINGS.heartbeat_max_age_seconds)
    set_readiness_state("bootstrap_complete", False)
    # Liveness must be available before Telegram getMe/setWebhook so Railway does
    # not restart a healthy process during a temporary Telegram outage.
    start_health_server(SETTINGS.health_host, SETTINGS.health_port)
    application = build_application()
    if SETTINGS.run_mode == "webhook":
        logger.info(
            "Starting unified webhook mode on FastAPI %s:%s path=/%s",
            SETTINGS.health_host,
            SETTINGS.health_port,
            SETTINGS.webhook_path,
        )
        asyncio.run(_run_unified_webhook(application))
    else:
        from core.telegram_bootstrap import bootstrap_attempts
        logger.info("Starting polling with a finite Telegram bootstrap retry budget")
        application.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=False,
            bootstrap_retries=bootstrap_attempts(),
        )



__feature_exports__ = ('kpi_admin_home', 'kpi_task_new_start', '_parse_kpi_due', 'kpi_task_new_input', 'kpi_admin_tasks', 'kpi_admin_task_view', 'kpi_task_status_handler', 'kpi_business_outcome_start', 'kpi_business_outcome_input', 'kpi_review_queue', 'kpi_review_view', '_kpi_quality_gate_text', 'kpi_quality_gate_view', 'kpi_quality_toggle_handler', '_notify_kpi_review_result', 'kpi_review_action', 'kpi_review_reject_start', 'kpi_review_reject_input', 'kpi_leaderboard', 'kpi_due_reminder_job', 'signal_analysts', 'signal_analyst_detail', 'incident_center_view', 'incident_status_handler', 'trust_center_view', '_campaign_category_rows', '_campaign_audience_rows', '_campaign_detail_text', 'campaign_studio_view', 'campaign_new_start', 'campaign_name_input', 'campaign_category_input', 'campaign_audience_input', 'campaign_discount_none', 'campaign_discount_input', 'campaign_message_input', 'campaign_tracking_input', '_dispatch_marketing_campaign', 'campaign_delivery_input', 'campaign_schedule_start', 'campaign_schedule_input', 'campaign_detail_view', 'campaign_preview_handler', 'campaign_dispatch_handler', 'campaign_set_delivery_handler', 'campaign_status_handler', 'campaign_report_view', 'campaign_tracking_link_create', 'channel_attribution_view', 'growth_link_lab_view', 'channel_link_create_start', 'channel_link_create_input', 'channel_link_detail_view', 'channel_link_revoke_handler', '_chat_member_is_active', 'public_channel_membership_update', 'ai_retention_cleanup_job', 'retention_center_view', 'retention_run', 'retention_toggle_auto', 'capability_matrix_view', 'signal_tracking_panel', 'signal_tracking_toggle', '_run_signal_tracking', 'signal_tracking_job', 'signal_tracking_run', 'signal_tracking_decision', 'id_command', 'heartbeat_job', 'operational_backup_job', 'observability_persist_job', 'business_intelligence_job', 'incident_maintenance_job', 'retention_delivery_job', 'signal_approval_expiry_job', 'ai_signal_lab_candidate_review_callback', 'operations_intelligence_job', 'provider_health_job', 'payment_reconciliation_job', 'post_shutdown', 'check_order_notifications', 'check_contest_deadlines', 'feature_job', 'refresh_channel_permission_health', 'operations_governance_watchdog_job', 'post_init', 'error_handler', 'unknown_callback', 'portfolio_conversation_cancel', 'internal_search_conversation_cancel', 'sales_growth_conversation_cancel', '_secure_persistence_location', 'build_application', 'main')
