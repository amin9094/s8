import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=new URL('../',import.meta.url),hub=fs.readFileSync(new URL('webapp/src/user-hub.js',root),'utf8');
const html=fs.readFileSync(new URL('webapp/index.html',root),'utf8');
const results=[];
function setup(lang='fa'){
 const listeners=[],badge={hidden:true,textContent:'',setAttribute(){}},page={innerHTML:'',children:[],querySelectorAll:()=>[],querySelector:()=>null,prepend(el){this.children.unshift(el);}};
 const element=()=>({dataset:{},innerHTML:'',querySelector:()=>({append(){}}),after(){}});
 const c=vm.createContext({console,Set,Number,String,Math,Promise,I18N:{fa:{},en:{}},state:{lang,resources:{overview:{bot_username:'Sentinel_bot',account:{unread_rewards:2}},hub:{unread_rewards:2,points:{balance:10},available:[],wallet:[{title:'First',seen_key:'one',unread:true},{title:'Second',seen_key:'two',unread:true}]}}},
  document:{addEventListener:(_name,fn)=>listeners.push(fn),createElement:element},navigator:{},tg:{openTelegramLink:url=>c.lastLink=url},window:{open:url=>c.lastLink=url},
  $:sel=>sel==='#rewardNavBadge'?badge:page,$$:()=>[],
  renderChrome(){},renderMore:async()=>{},openMore:async()=>{},localizeUiTree(){},t:v=>v,esc:v=>String(v??'').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;'),num:v=>String(v??0),icon:v=>`<svg><use href="#i-${v}"/></svg>`,date:()=>'',pageHead:()=>'',skeleton:()=>'',metric:()=>'',empty:()=>'',errorPanel:()=>'',sentinelService:()=>'',toast:()=>{},closeModal(){},openModal(){},invalidate(){},
  action:async()=>({unread_rewards:0}),loadResource:async()=>c.state.resources.hub,navigate:async target=>{c.lastPage=target;},toggleLanguage:async()=>{c.state.lang=c.state.lang==='fa'?'en':'fa';}});
 vm.runInContext(hub,c);
 const click=async dataset=>listeners[0]({target:{closest:()=>({dataset})},preventDefault(){},stopImmediatePropagation(){}});
 return {c,badge,page,click};
}
async function test(name,fn){try{await fn();results.push({name,status:'PASS'});}catch(e){results.push({name,status:'FAIL',reason:e.stack});}}
await test('Same priority order and full-width subscription in both languages',()=>{
 for(const language of ['fa','en']){const {c}=setup(language);const items=vm.runInContext('userMenuItems()',c);assert.deepEqual(Array.from(items.slice(0,9),x=>x.id),['vip','education','calculator','market','account','contests','missions','signals','trading']);assert.equal(items[0].wide,true);assert.equal(items[0].tone,'success');assert.match(vm.runInContext('userMenuHtml()',c),/menu-wide/);}
});
await test('Every catalog button has an existing target and a real SVG icon',()=>{
 const {c}=setup('en'),items=vm.runInContext('userMenuItems()',c);assert.equal(new Set(items.map(x=>x.id)).size,items.length);
 const pages=new Set(['rewards','risk','journal','trading','signals']),opens=new Set(['vip','education','calculator','market','settings','contests','missions','referral','rankings','calendar','tradeCenter','support','search','orders','notifications','ai','rewards']);
 for(const item of items){assert.ok(html.includes(`id="i-${item.ic}"`),item.ic);if(item.kind==='page')assert.ok(pages.has(item.target));if(item.kind==='open')assert.ok(opens.has(item.target));if(item.kind==='bridge')assert.equal(vm.runInContext(`BOT_DESTINATIONS.has(${JSON.stringify(item.target)})`,c),true);}
 const compact=vm.runInContext('userMenuHtml(true)',c);assert.equal((compact.match(/data-menu-id=/g)||[]).length,13);
});
await test('Unread rewards remain neutral with an accessible count',()=>{
 const {c}=setup();const menu=vm.runInContext('userMenuHtml()',c);assert.equal((menu.match(/class="menu-unread"/g)||[]).length,1);assert.match(menu,/aria-label="2 جایزه جدید"/);const item=vm.runInContext("userMenuItems().find(x=>x.id==='rewards')",c);assert.equal(item.tone,'');
});
await test('My rewards shortcut opens the actual Mine tab, not the catalog',async()=>{
 const {c,click}=setup();await click({rewardOpen:'mine'});assert.equal(c.lastPage,'rewards');assert.equal(vm.runInContext('rewardTab',c),'mine');await click({menuLanguage:'toggle'});assert.equal(c.state.lang,'en');
});
await test('Viewing own awards acknowledges only their keys and clears badges',async()=>{
 const {c,badge,click}=setup();let payload;c.action=async(name,value)=>{assert.equal(name,'reward_seen');payload=value;return {unread_rewards:0};};await click({rewardOpen:'mine'});await vm.runInContext('renderRewardsWorkspace()',c);assert.deepEqual(Array.from(payload.keys),['one','two']);assert.equal(c.state.resources.overview.account.unread_rewards,0);assert.equal(badge.hidden,true);
 c.state.resources.overview.account.unread_rewards=1;vm.runInContext('renderChrome()',c);assert.equal(badge.hidden,false);assert.equal(badge.textContent,'1');
});
await test('An acknowledgement failure preserves the unread marker',async()=>{
 const {c,click}=setup();c.console={...console,warn(){}};c.action=async()=>{throw new Error('offline');};await click({rewardOpen:'mine'});await vm.runInContext('renderRewardsWorkspace()',c);assert.equal(c.state.resources.overview.account.unread_rewards,2);
});
await test('Rules bridge and rejection of forged destinations',async()=>{
 const {c,click}=setup();await click({botBridge:'web_rules'});assert.equal(c.lastLink,'https://t.me/Sentinel_bot?start=web_rules');c.lastLink='';await click({botBridge:'https://evil.invalid'});assert.equal(c.lastLink,'');
});
await test('Reordering retains all supplemental and authorized admin services',async()=>{
 const {c,page}=setup();let removed=0;const buttons=[{dataset:{open:'market'}},{dataset:{open:'feed'}},{dataset:{open:'track'}},{dataset:{open:'revisions'}}];const section={querySelectorAll:()=>buttons,remove(){removed++;}};
 page.querySelectorAll=()=>[section];const moved=[];c.document.createElement=()=>({innerHTML:'',querySelector:()=>({append(...nodes){moved.push(...nodes)}}),after(){}});
 await vm.runInContext('renderMore()',c);assert.equal(removed,1);assert.deepEqual(moved.map(x=>x.dataset.open),['feed','track','revisions']);assert.match(page.children[0].innerHTML,/data-menu-id="vip"/);
});
const failed=results.filter(x=>x.status==='FAIL');
if(process.argv.includes('--preview')){
 const {c}=setup();const menu=vm.runInContext('userMenuHtml()',c);const sprite=html.slice(html.indexOf('<svg class="svg-sprite"'),html.indexOf('  </svg>')+8);
 fs.writeFileSync(new URL('quality-artifacts/menu_preview_FA.html',root),`<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SENTINEL — نمونه منو</title><style>${fs.readFileSync(new URL('webapp/src/styles.css',root),'utf8')}body{padding:18px}.preview-shell{max-width:430px;margin:auto}.svg-sprite{display:none}</style><body>${sprite}<main class="preview-shell"><h1>SENTINEL</h1><p>نمونه چیدمان؛ دادهٔ نمایشی و دکمه‌های غیرفعال.</p>${menu}</main></body></html>`);
 fs.writeFileSync(new URL('quality-artifacts/menu_behavior_838.json',root),JSON.stringify({passed:results.length-failed.length,failed:failed.length,mode:'real source executed in Node; simulated DOM and server responses',results},null,2));
}
console.log(JSON.stringify({passed:results.length-failed.length,failed:failed.length,results}));
process.exitCode=failed.length?1:0;
