from __future__ import annotations

import hashlib
from typing import Any

from core.utils import utc_iso
from modules.i18n import normalize_language

MAX_RULES_LENGTH = 32_000
MAX_RULES_HISTORY = 50
MAX_ACCEPTANCE_HISTORY = 250_000


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def rules_settings(db: dict[str, Any]) -> dict[str, Any]:
    raw = db.setdefault("rules_settings", {})
    if not isinstance(raw, dict):
        raw = {}
        db["rules_settings"] = raw
    raw.setdefault("enabled", True)
    raw.setdefault("version", 0)
    raw.setdefault("text", "")
    raw.setdefault("content_hash", "")
    raw.setdefault("updated_at", None)
    raw.setdefault("updated_by", None)
    raw.setdefault("history", [])
    if not isinstance(raw.get("history"), list):
        raw["history"] = []
    locales = raw.setdefault("locales", {})
    if not isinstance(locales, dict):
        locales = {}
        raw["locales"] = locales
    # Lossless migration from the original single-language schema.
    if "fa" not in locales:
        locales["fa"] = {
            "version": int(raw.get("version", 0) or 0),
            "text": str(raw.get("text") or ""),
            "content_hash": str(raw.get("content_hash") or ""),
            "updated_at": raw.get("updated_at"),
            "updated_by": raw.get("updated_by"),
            "history": list(raw.get("history") or []),
        }
    locales.setdefault(
        "en",
        {
            "version": 0,
            "text": "",
            "content_hash": "",
            "updated_at": None,
            "updated_by": None,
            "history": [],
        },
    )
    for language in ("fa", "en"):
        locale = locales.setdefault(language, {})
        locale.setdefault("version", 0)
        locale.setdefault("text", "")
        locale.setdefault("content_hash", "")
        locale.setdefault("updated_at", None)
        locale.setdefault("updated_by", None)
        locale.setdefault("history", [])
        if not isinstance(locale.get("history"), list):
            locale["history"] = []
    db.setdefault("rules_acceptances", {})
    if not isinstance(db.get("rules_acceptances"), dict):
        db["rules_acceptances"] = {}
    db.setdefault("rules_acceptance_history", [])
    if not isinstance(db.get("rules_acceptance_history"), list):
        db["rules_acceptance_history"] = []
    return raw


def normalize_rules_text(value: Any) -> str:
    text = str(value or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        raise ValueError("متن قوانین نمی‌تواند خالی باشد.")
    if len(text) > MAX_RULES_LENGTH:
        raise ValueError(f"متن قوانین حداکثر می‌تواند {MAX_RULES_LENGTH:,} نویسه باشد.")
    return text


def publish_rules(
    db: dict[str, Any],
    text: Any,
    actor_id: int | str,
    language: str = "fa",
) -> dict[str, Any]:
    state = rules_settings(db)
    language = normalize_language(language)
    locale = state["locales"][language]
    normalized = normalize_rules_text(text)
    digest = _hash_text(normalized)
    if normalized == locale.get("text") and digest == locale.get("content_hash"):
        return current_rules(db, language)
    now = utc_iso()
    previous_text = str(locale.get("text") or "")
    previous_version = int(locale.get("version", 0) or 0)
    if previous_version > 0 and previous_text:
        locale["history"].append(
            {
                "version": previous_version,
                "text": previous_text,
                "content_hash": str(locale.get("content_hash") or _hash_text(previous_text)),
                "updated_at": locale.get("updated_at"),
                "updated_by": locale.get("updated_by"),
                "archived_at": now,
                "language": language,
            }
        )
        locale["history"] = locale["history"][-MAX_RULES_HISTORY:]
    locale.update(
        {
            "enabled": True,
            "version": previous_version + 1,
            "text": normalized,
            "content_hash": digest,
            "updated_at": now,
            "updated_by": str(actor_id),
        }
    )
    # Keep legacy Persian fields synchronized for old exports and integrations.
    if language == "fa":
        for key in ("version", "text", "content_hash", "updated_at", "updated_by", "history"):
            state[key] = locale[key]
    return current_rules(db, language)


def set_rules_enabled(db: dict[str, Any], enabled: bool, actor_id: int | str) -> dict[str, Any]:
    state = rules_settings(db)
    state["enabled"] = bool(enabled)
    state["updated_at"] = utc_iso()
    state["updated_by"] = str(actor_id)
    return state


def current_rules(db: dict[str, Any], language: str = "fa") -> dict[str, Any]:
    state = rules_settings(db)
    language = normalize_language(language)
    locale = state["locales"][language]
    return {
        "enabled": bool(state.get("enabled", True)),
        "language": language,
        "version": int(locale.get("version", 0) or 0),
        "text": str(locale.get("text") or ""),
        "content_hash": str(locale.get("content_hash") or ""),
        "updated_at": locale.get("updated_at"),
        "updated_by": locale.get("updated_by"),
    }


def user_has_accepted_rules(
    db: dict[str, Any],
    user_id: int | str,
    language: str = "fa",
) -> bool:
    state = current_rules(db, language)
    if not bool(state.get("enabled", True)) or int(state.get("version", 0) or 0) <= 0 or not state.get("text"):
        return True
    language = normalize_language(language)
    from modules.shared_preferences import migrate_shared_preference
    migrate_shared_preference(db, user_id, "rules_acceptances")
    row = db.setdefault("rules_acceptances", {}).get(str(int(user_id)))
    if isinstance(row, dict) and "version" not in row:
        row = row.get(language)
    return bool(
        isinstance(row, dict)
        and int(row.get("version", 0) or 0) == int(state["version"])
        and str(row.get("content_hash") or "") == str(state.get("content_hash") or "")
    )


def accept_current_rules(
    db: dict[str, Any],
    user_id: int | str,
    language: str = "fa",
) -> dict[str, Any]:
    language = normalize_language(language)
    state = current_rules(db, language)
    if int(state.get("version", 0) or 0) <= 0 or not state.get("text"):
        raise ValueError("هنوز متن قوانینی منتشر نشده است.")
    uid = str(int(user_id))
    row = {
        "user_id": uid,
        "version": int(state["version"]),
        "content_hash": str(state.get("content_hash") or ""),
        "accepted_at": utc_iso(),
        "language": language,
    }
    from modules.shared_preferences import migrate_shared_preference
    migrate_shared_preference(db, user_id, "rules_acceptances")
    acceptances = db.setdefault("rules_acceptances", {})
    existing = acceptances.get(uid)
    # Migrate a legacy Persian acceptance to the new per-language container.
    if isinstance(existing, dict) and "version" in existing:
        existing = {"fa": dict(existing)}
    if not isinstance(existing, dict):
        existing = {}
    existing[language] = row
    acceptances[uid] = existing
    history = db.setdefault("rules_acceptance_history", [])
    duplicate = next(
        (
            item
            for item in reversed(history[-1000:])
            if isinstance(item, dict)
            and str(item.get("user_id")) == uid
            and int(item.get("version", 0) or 0) == int(row["version"])
            and str(item.get("content_hash") or "") == str(row["content_hash"])
            and normalize_language(item.get("language") or "fa") == language
        ),
        None,
    )
    if duplicate is None:
        history.append(dict(row))
        db["rules_acceptance_history"] = history[-MAX_ACCEPTANCE_HISTORY:]
    return row


def rules_acceptance_history(
    db: dict[str, Any],
    user_id: int | str,
    *,
    limit: int = 50,
    language: str | None = None,
) -> list[dict[str, Any]]:
    uid = str(int(user_id))
    normalized = normalize_language(language) if language else None
    rows = [
        dict(row)
        for row in db.setdefault("rules_acceptance_history", [])
        if isinstance(row, dict) and str(row.get("user_id")) == uid
        and (normalized is None or normalize_language(row.get("language") or "fa") == normalized)
    ]
    return list(reversed(rows[-max(1, min(int(limit), 500)) :]))


def rules_acceptance_summary(db: dict[str, Any], language: str = "fa") -> dict[str, int]:
    language = normalize_language(language)
    state = current_rules(db, language)
    version = int(state.get("version", 0) or 0)
    digest = str(state.get("content_hash") or "")
    accepted = sum(
        1
        for container in db.setdefault("rules_acceptances", {}).values()
        for row in [
            (
                container
                if isinstance(container, dict) and "version" in container and language == "fa"
                else container.get(language)
                if isinstance(container, dict)
                else None
            )
        ]
        if isinstance(row, dict)
        and int(row.get("version", 0) or 0) == version
        and str(row.get("content_hash") or "") == digest
    )
    users = len(db.get("users", {})) if isinstance(db.get("users"), dict) else 0
    return {"accepted": accepted, "pending": max(0, users - accepted), "users": users, "version": version}
