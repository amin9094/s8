from __future__ import annotations

import re
from typing import Any

_PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_TARGET_PATTERN = re.compile(r"^(?:tp|target|t|تارگت|هدف)\s*[-_:#]?\s*(10|[1-9])(?:\s*(?:شد|خورد|ثبت|رسید))?$", re.IGNORECASE)

_STATUS_ALIASES: dict[str, str] = {
    "entry": "entry_hit",
    "entry hit": "entry_hit",
    "entry_hit": "entry_hit",
    "ورود": "entry_hit",
    "ورود شد": "entry_hit",
    "ورود انجام شد": "entry_hit",
    "ریسک فری": "breakeven",
    "ریسک‌فری": "breakeven",
    "ریسکفری": "breakeven",
    "risk free": "breakeven",
    "risk-free": "breakeven",
    "breakeven": "breakeven",
    "break even": "breakeven",
    "be": "breakeven",
    "بستن بخشی": "partial_close",
    "خروج بخشی": "partial_close",
    "partial": "partial_close",
    "partial close": "partial_close",
    "بستن دستی": "manual_close",
    "خروج دستی": "manual_close",
    "manual close": "manual_close",
    "close": "manual_close",
    "استاپ": "stop",
    "استاپ خورد": "stop",
    "حد ضرر": "stop",
    "stop": "stop",
    "sl": "stop",
    "ورود نداد": "no_entry",
    "فعال نشد": "no_entry",
    "no entry": "no_entry",
    "no_entry": "no_entry",
    "لغو": "cancelled",
    "لغو شد": "cancelled",
    "cancel": "cancelled",
    "cancelled": "cancelled",
}


def signal_reference(signal_id: int | str) -> str:
    """Return the stable, user-facing signal identifier."""
    return f"#{int(signal_id)}"


def _normalize_reply_text(text: str) -> str:
    value = str(text or "").translate(_PERSIAN_DIGITS).replace("\u200c", " ").strip().lower()
    value = re.sub(r"[✅☑️🎯🛑📍🟦✂️✋🚫❌]+", "", value).strip()
    value = re.sub(r"^[!/]+", "", value)
    value = re.sub(r"^(?:وضعیت|نتیجه)\s*[:：-]?\s*", "", value)
    return re.sub(r"\s+", " ", value).strip(" .،,:؛-_")


def parse_signal_reply_status(text: str, *, target_count: int = 10) -> str | None:
    """Parse a short admin reply such as TP2, استاپ or ریسک فری.

    Only concise, explicit status replies are accepted so ordinary channel
    discussion cannot accidentally change a signal result.
    """
    value = _normalize_reply_text(text)
    if not value:
        return None
    target_match = _TARGET_PATTERN.fullmatch(value)
    if target_match:
        target = int(target_match.group(1))
        if 1 <= target <= max(0, int(target_count)):
            return f"tp{target}"
        return None
    return _STATUS_ALIASES.get(value)


def find_signal_by_delivery(db: dict[str, Any], chat_id: int | str, message_id: int | str) -> dict[str, Any] | None:
    """Find the signal whose original Telegram message is being replied to."""
    try:
        wanted_chat = int(chat_id)
        wanted_message = int(message_id)
    except (TypeError, ValueError):
        return None
    for row in reversed(db.get("signals", [])):
        if not isinstance(row, dict):
            continue
        for delivery in row.get("deliveries", []):
            if not isinstance(delivery, dict):
                continue
            try:
                if int(delivery.get("chat_id")) == wanted_chat and int(delivery.get("message_id")) == wanted_message:
                    return row
            except (TypeError, ValueError):
                continue
    return None
