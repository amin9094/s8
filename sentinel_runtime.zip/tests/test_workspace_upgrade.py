from __future__ import annotations
import copy
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from types import SimpleNamespace
import pytest
from tests.test_master_upgrade import state, canonical_store, OWNER  # noqa: F401
from modules import admin_creation as creation
from modules.prize_delivery import deliver_prize, validate_prize


def test_idle_watchdog_and_delivery_stall():
    from core.runtime_watchdog import DeliveryProgressWatch
    watch=DeliveryProgressWatch(60)
    assert watch.check({'pending':0,'completed':0},0) is None
    assert watch.check({'pending':0,'completed':0},1000) is None
    assert watch.check({'pending':2,'completed':0},1001) is None
    assert watch.check({'pending':2,'completed':0},1062)=='telegram-delivery-no-progress:2'
    assert watch.check({'pending':2,'completed':1},1063) is None
    assert watch.check({'pending':0,'completed':1},5000) is None
    assert watch.check({'pending':1,'processor_healthy':False},5001)=='telegram-update-processor-stalled'


@pytest.mark.parametrize('kind',['mission','contest','reward'])
@pytest.mark.parametrize('reward_type',['points','vip_days','discount_coupon','combined'])
def test_wizard_publishes_only_reviewed_prize(state,kind,reward_type):
    draft=creation.create_draft(state,OWNER,kind,mode='quick')
    values=draft['values'];values.update(reward_type=reward_type,value=10,prize_points=25,prize_vip=7,prize_coupon=20,event='complete_lesson',claim='assign',users=['1'])
    state['admin_creation_drafts'][draft['id']]['values']=values
    with pytest.raises(ValueError):creation.publish(state,OWNER,draft['id'],draft['revision'])
    assert creation.review(state,OWNER,draft['id'])
    result=creation.publish(state,OWNER,draft['id'],draft['revision'])
    assert creation.publish(state,OWNER,draft['id'],draft['revision'])==result
    if kind=='mission':assert result['prize']['vip_days']==(7 if reward_type=='combined' else 10 if reward_type=='vip_days' else 0)
    if kind=='contest':assert result['prize_by_rank']['1']['coupon_percent']==(20 if reward_type=='combined' else 10 if reward_type=='discount_coupon' else 0)
    if kind=='reward':assert state['user_rewards']


def test_parallel_combined_delivery_is_one_grant(state,canonical_store):
    from core.db import with_db,load_db
    prize={'points':25,'vip_days':7,'coupon_percent':20}
    def issue(_):return with_db(lambda db:deliver_prize(db,1,prize,source_event='test:combined',title='test'))
    with ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(issue,range(20)))
    db=load_db()
    assert db['user_points']['1']==25 and len(db['user_rewards'])==3
    assert len([c for c in db['discount_codes'].values() if c.get('assigned_to')=='1'])==1
    assert len([e for e in db['economic_events'].values() if e['kind']!='vip_grant'])==3
    assert len([e for e in db['economic_events'].values() if e['kind']=='vip_grant'])==1


def test_combined_failure_rolls_back_every_component(state,canonical_store,monkeypatch):
    import core.domain as domain
    from core.db import with_db,load_db
    monkeypatch.setattr(domain,'assign_discount_from_pool',lambda *a,**k:(_ for _ in ()).throw(ValueError('stock failed')))
    with pytest.raises(ValueError,match='stock failed'):
        with_db(lambda db:deliver_prize(db,1,{'points':25,'vip_days':7,'coupon_percent':20},source_event='rollback',title='test'))
    db=load_db()
    assert not db.get('economic_events') and not db['user_rewards'] and not db['vip_users']
    assert not db['user_points'].get('1',0)


def test_mission_prize_once_and_global_cap(state):
    from core.domain import complete_mission
    from modules.missions import create_mission
    m=create_mission(state,title='lesson',reward=25,event='complete_lesson')
    m.update(prize={'points':25,'vip_days':7,'coupon_percent':20},max_completions=1,completions_count=0)
    assert complete_mission(state,1,m)
    assert not complete_mission(state,1,m) and not complete_mission(state,2,m)
    assert state['user_points']['1']==25 and m['completions_count']==1
    assert len(state['user_rewards'])==3


def test_vip_only_contest_history_and_idempotent_settlement(state):
    from modules.contest import start_price_contest,add_price_guess,end_price_contest
    from services.miniapp_read_service_v2 import _contest_history_row
    from core.utils import utc_iso,utc_now
    c=start_price_contest(state,'XAUUSD',60,reward_points=0)
    c.update(prize_by_rank={'1':{'points':0,'vip_days':7,'coupon_percent':0}},reward_by_rank={'1':0},tie_handling='earliest')
    assert add_price_guess(state,1,100)=='OK' and add_price_guess(state,2,90)=='OK'
    c['ends_at']=utc_iso(utc_now()-timedelta(seconds=1))
    closed,rows=end_price_contest(state,100)
    assert rows[0]['prize']['vip_days']==7
    assert _contest_history_row(closed,1)['won'] is True
    assert not _contest_history_row(closed,2)['won']
    assert end_price_contest(state,100)==(None,[]) and len(state['user_rewards'])==1


def test_hub_private_ownership_and_pagination(state,monkeypatch):
    from core.domain import add_points,create_discount,ensure_referral
    from modules.advanced_features import record_user_reward
    from services import miniapp_read_service_v2 as service
    create_discount(state,20,assigned_to=1,code='OWNED')
    create_discount(state,30,assigned_to=2,code='PRIVATE')
    record_user_reward(state,2,'private',reward_type='vip_days')
    for n in range(25):add_points(state,1,1,'test',source_event=f'point:{n}')
    ensure_referral(state,1)
    monkeypatch.setattr(service,'read_db_sections',lambda _:copy.deepcopy(state))
    d=service.user_hub(SimpleNamespace(user_id=1),limit=20)
    assert len(d['points']['history'])==20 and d['points']['next_cursor']==20
    assert d['points']['total']==25 and [x['code'] for x in d['wallet']]==['OWNED']
    d2=service.user_hub(SimpleNamespace(user_id=1),cursor=20,limit=20)
    assert len(d2['points']['history'])==5 and d2['points']['next_cursor'] is None


@pytest.mark.parametrize('prize',[{'vip_days':3651},{'coupon_percent':99},{'points':-1},{}])
def test_forged_prize_fails_closed(prize):
    with pytest.raises(ValueError):validate_prize(prize)


def test_prior_user_actions_preserved_with_priority(monkeypatch):
    from bot_runtime import navigation as nav
    monkeypatch.setattr(nav,'load_db',lambda:{})
    monkeypatch.setattr(nav,'_language_for_user',lambda uid:'fa')
    monkeypatch.setattr(nav,'_is_any_admin',lambda uid:False)
    monkeypatch.setattr(nav,'_has_any_admin_permission',lambda *a:False)
    monkeypatch.setattr(nav,'with_webapp',lambda rows:rows)
    rows=nav.main_menu(1);flat=[b.callback_data for row in rows for b in row]
    assert {'u_vip','u_edu','u_price','u_calc','u_contests','u_missions','u_account','nav_user:trade','u_calendar:today','u_support','language_menu','u_rewards','u_referral','u_signal_portal','u_settings','u_today','home'}<=set(flat)
    assert flat[:7]==['u_vip','u_edu','u_calc','u_price','u_account','u_contests','u_missions']
    assert len(flat)==len(set(flat)) and all(len(row)<=2 for row in rows)


def test_palette_text_contrast():
    import re
    from pathlib import Path
    css=(Path(__file__).resolve().parents[1]/'webapp/src/styles.css').read_text()
    palette={}
    for block in re.findall(r':root\s*\{([^}]+)',css):
        palette.update(re.findall(r'--([a-z0-9-]+)\s*:\s*(#[0-9a-fA-F]{6})\b',block))
    def lum(color):
        values=[int(color[i:i+2],16)/255 for i in (1,3,5)]
        return sum(w*(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4) for v,w in zip(values,(.2126,.7152,.0722)))
    for foreground in ('text','muted','subtle','blue','cyan','gold','green','red','amber'):
        for background in ('bg','panel','panel2'):
            assert (lum(palette[foreground])+.05)/(lum(palette[background])+.05)>=4.5,(foreground,background)


def test_real_frontend_recovery_flow():
    import os
    import shutil
    import subprocess
    from pathlib import Path
    node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
    assert node, 'Node is required for the Mini App recovery gate'
    root=Path(__file__).resolve().parents[1]
    result=subprocess.run([node,str(root/'tests/miniapp_recovery.mjs')],capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr
    assert '7 scenarios passed' in result.stdout
