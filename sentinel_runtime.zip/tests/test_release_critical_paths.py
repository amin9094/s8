from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest
from PIL import Image

from modules.automation_event_bus import derive_automation_events
from modules.automation_v2 import create_automation_rule, process_automation_event

OWNER = 354678485


def _triggers(events):
    return {name for name, _ in events}


def test_event_bus_derives_all_operational_domains() -> None:
    before = {
        "users": {},
        "vip_orders": {
            "old-approved": {"id": "old-approved", "user_id": "1", "status": "pending"},
            "old-rejected": {"id": "old-rejected", "user_id": "2", "status": "pending"},
        },
        "tickets": {
            "2": {"id": "2", "user_id": "2", "status": "open", "waiting_for": "user"},
            "3": {"id": "3", "user_id": "3", "status": "open", "waiting_for": "user"},
        },
        "signals": {
            "pub": {"id": "pub", "status": "draft"},
            "tp": {"id": "tp", "status": "active"},
            "sl": {"id": "sl", "status": "active"},
            "close": {"id": "close", "status": "active"},
            "ignore": {"id": "ignore", "status": "active"},
        },
        "marketing_campaigns": {"CMP-2": {"id": "CMP-2", "status": "draft"}},
        "contests": {"2": {"id": "2", "status": "active"}},
        "user_missions": {"2": {"id": "2", "user_id": "2", "completed": False}},
        "provider_health": {"gemini": {"id": "gemini", "status": "up"}},
    }
    after = {
        **before,
        "users": {"10": {"id": "10", "user_id": "10", "created_at": "2026-08-03T00:00:00+00:00"}},
        "vip_orders": {
            **before["vip_orders"],
            "new": {"id": "new", "user_id": "10", "status": "pending"},
            "old-approved": {"id": "old-approved", "user_id": "1", "status": "approved"},
            "old-rejected": {"id": "old-rejected", "user_id": "2", "status": "rejected"},
        },
        "tickets": {
            **before["tickets"],
            "1": {"id": "1", "user_id": "1", "status": "open", "waiting_for": "admin"},
            "2": {"id": "2", "user_id": "2", "status": "closed", "waiting_for": "user"},
            "3": {"id": "3", "user_id": "3", "status": "open", "waiting_for": "admin"},
        },
        # Compatibility mirror must not duplicate ticket_created.
        "support_tickets": [{"id": "1", "user_id": "1", "status": "open", "waiting_for": "admin"}],
        "signals": {
            **before["signals"],
            "new": {"id": "new", "status": "draft"},
            "pub": {"id": "pub", "status": "published"},
            "tp": {"id": "tp", "status": "tp1"},
            "sl": {"id": "sl", "status": "stop_loss"},
            "close": {"id": "close", "status": "closed"},
            "ignore": {"id": "ignore", "status": "unknown"},
        },
        "marketing_campaigns": {
            **before["marketing_campaigns"],
            "CMP-1": {"id": "CMP-1", "status": "draft"},
            "CMP-2": {"id": "CMP-2", "status": "published"},
        },
        "public_channel_link_events": {"L1": {"id": "L1", "type": "click", "user_id": "9", "link_id": "A"}},
        "contests": {
            **before["contests"],
            "1": {"id": "1", "status": "active"},
            "2": {"id": "2", "status": "completed"},
        },
        "user_missions": {"2": {"id": "2", "user_id": "2", "completed": True}},
        "incidents": {"I1": {"id": "I1", "status": "open"}},
        "provider_health": {"gemini": {"id": "gemini", "status": "down"}},
        "mt5_risk_alerts": {"M1": {"id": "M1", "user_id": "7", "severity": "high"}},
    }
    events = derive_automation_events(before, after)
    assert _triggers(events) >= {
        "user_registered", "payment_created", "payment_approved", "payment_rejected",
        "ticket_created", "ticket_closed", "ticket_waiting", "signal_created", "signal_published",
        "signal_tp", "signal_sl", "signal_closed", "campaign_created", "campaign_published",
        "link_clicked", "contest_started", "contest_ended", "mission_completed", "system_error",
        "provider_down", "mt5_risk",
    }
    assert sum(1 for trigger, payload in events if trigger == "ticket_created" and payload["ticket_id"] == "1") == 1


def test_event_bus_trigger_filter_avoids_unrelated_domains() -> None:
    before = {"users": {}, "vip_orders": [{"id": "1", "status": "pending"}]}
    after = {"users": {"2": {"id": "2"}}, "vip_orders": [{"id": "1", "status": "approved"}]}
    events = derive_automation_events(before, after, active_triggers={"user_registered"})
    assert [name for name, _ in events] == ["user_registered"]


def test_dispatcher_claim_retry_dead_letter_and_success(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import automation_v2_dispatcher as dispatcher

    now = datetime.now(UTC)
    db = {
        "automation_v2_jobs": {
            "pending": {"id": "pending", "kind": "webhook", "status": "pending", "next_attempt_at": (now - timedelta(seconds=1)).isoformat(), "attempts": 0},
            "future": {"id": "future", "kind": "webhook", "status": "pending", "next_attempt_at": (now + timedelta(hours=1)).isoformat()},
            "busy": {"id": "busy", "kind": "webhook", "status": "processing", "claimed_at": now.isoformat()},
            "stale": {"id": "stale", "kind": "webhook", "status": "processing", "claimed_at": (now - timedelta(minutes=10)).isoformat()},
            "other": {"id": "other", "kind": "message", "status": "pending"},
        }
    }
    claimed = dispatcher.claim_due_automation_v2_jobs(db, limit=10)
    assert {row["id"] for row in claimed} == {"pending", "stale"}
    assert all(row["status"] == "processing" for row in claimed)

    retry = dispatcher.mark_automation_v2_job_result(db, "pending", success=False, detail="temporary")
    assert retry["status"] == "retry" and retry["next_attempt_at"]
    db["automation_v2_jobs"]["pending"]["attempts"] = 4
    dead = dispatcher.mark_automation_v2_job_result(db, "pending", success=False, detail="permanent")
    assert dead["status"] == "dead_letter"
    assert db["automation_v2_dead_letter"][-1]["id"] == "pending"
    complete = dispatcher.mark_automation_v2_job_result(db, "stale", success=True, status_code=204)
    assert complete["status"] == "completed" and complete["last_status_code"] == 204
    with pytest.raises(ValueError, match="AUTOMATION_JOB_NOT_FOUND"):
        dispatcher.mark_automation_v2_job_result(db, "missing", success=True)


def test_dispatcher_dns_and_webhook_delivery(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import automation_v2_dispatcher as dispatcher

    monkeypatch.setattr(dispatcher.socket, "getaddrinfo", lambda *_a, **_k: [(None, None, None, None, ("8.8.8.8", 443))])
    assert dispatcher._resolve_public_addresses("example.com") == ["8.8.8.8"]
    monkeypatch.setattr(dispatcher.socket, "getaddrinfo", lambda *_a, **_k: [(None, None, None, None, ("127.0.0.1", 443))])
    with pytest.raises(ValueError, match="PRIVATE_ADDRESS"):
        dispatcher._resolve_public_addresses("example.com")
    monkeypatch.setattr(dispatcher.socket, "getaddrinfo", lambda *_a, **_k: [])
    with pytest.raises(ValueError, match="DNS_EMPTY"):
        dispatcher._resolve_public_addresses("example.com")

    monkeypatch.setenv("AUTOMATION_WEBHOOK_ALLOWED_HOSTS", "example.com")
    monkeypatch.setattr(dispatcher, "_resolve_public_addresses", lambda _host: ["8.8.8.8"])

    class Response:
        status_code = 500
        async def aiter_bytes(self):
            yield b"x" * 9000

    class StreamContext:
        async def __aenter__(self): return Response()
        async def __aexit__(self, *_args): return False

    class Client:
        def stream(self, *args, **kwargs):
            assert kwargs["headers"].get("Host") is None
            return StreamContext()

    ok, code, detail = asyncio.run(dispatcher._deliver_webhook({
        "payload": {"url": "https://example.com/hook", "headers": {"Host": "evil", "X-Test": "1"}, "body": {"a": 1}}
    }, Client()))
    assert not ok and code == 500 and detail.startswith("HTTP_500:")

    class ErrorClient:
        def stream(self, *_a, **_k):
            raise httpx.ConnectError("offline")

    ok, code, detail = asyncio.run(dispatcher._deliver_webhook({"payload": {"url": "https://example.com/hook"}}, ErrorClient()))
    assert not ok and code == 0 and "ConnectError" in detail


def test_dispatcher_scheduled_cycle_cleanup_and_runtime(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from services import automation_v2_dispatcher as dispatcher

    assert dispatcher.run_scheduled_automation_cycle({"automation_rules_v2": {}})["events"] == 0
    db = {"automation_rules_v2": {"1": {"enabled": True, "trigger": "scheduled"}}}
    monkeypatch.setattr(dispatcher, "collect_scheduled_automation_events", lambda *_a, **_k: [("vip_expiring", {"event_id": "1"})])
    monkeypatch.setattr(dispatcher, "process_automation_event", lambda _db, trigger, _payload, **_kw: {"count": 2 if trigger == "scheduled" else 1})
    cycle = dispatcher.run_scheduled_automation_cycle(db)
    assert cycle["events"] == 2 and cycle["matched_rules"] == 3

    from modules import gemini_ads
    monkeypatch.setattr(gemini_ads, "cleanup_generated_ad_assets", lambda _db, now=None: {"removed": 2, "freed_bytes": 100, "remaining_bytes": 0})
    cleanup_db: dict = {}
    first = dispatcher.run_ai_ad_asset_cleanup_cycle(cleanup_db)
    second = dispatcher.run_ai_ad_asset_cleanup_cycle(cleanup_db)
    assert first["removed"] == 2 and second["skipped"] is True

    calls: list[str] = []
    async def fake_async_with_db(fn):
        calls.append(fn.__name__)
        return fn({"automation_rules_v2": {}})
    async def fake_deliver(*, limit=20):
        calls.append(f"deliver:{limit}")
        return {"completed": 0, "failed": 0}
    monkeypatch.setattr(dispatcher, "async_with_db", fake_async_with_db)
    monkeypatch.setattr(dispatcher, "deliver_automation_v2_jobs", fake_deliver)
    asyncio.run(dispatcher.automation_v2_runtime_job())
    assert "run_scheduled_automation_cycle" in calls and "deliver:20" in calls and "run_ai_ad_asset_cleanup_cycle" in calls


def test_automation_actions_conditions_guards_and_webhook(monkeypatch: pytest.MonkeyPatch) -> None:
    from modules import automation_v2

    monkeypatch.setenv("AUTOMATION_WEBHOOK_ALLOWED_HOSTS", "example.com")
    db = {
        "marketing_campaigns": {"CMP-1": {"id": "CMP-1", "status": "draft"}},
        "tickets": [{"id": "T-1", "status": "open", "user_id": "12"}],
    }
    actions = [
        {"type": "send_message", "payload": {"user_id": "{{user_id}}", "text": "hello {{user_id}}"}},
        {"type": "notify_admin", "payload": {"admin_id": str(OWNER), "text": "new event"}},
        {"type": "add_tag", "payload": {"user_id": "{{user_id}}", "tag": "vip"}},
        {"type": "remove_tag", "payload": {"user_id": "{{user_id}}", "tag": "missing"}},
        {"type": "create_task", "payload": {"title": "Call {{user_id}}", "description": "follow up"}},
        {"type": "create_ticket", "payload": {"user_id": "{{user_id}}", "subject": "Automation", "message": "Review"}},
        {"type": "queue_campaign", "payload": {"campaign_id": "CMP-1"}},
        {"type": "ai_draft", "payload": {"prompt": "Write a useful draft"}},
        {"type": "stop_feature", "payload": {"feature": "campaigns.enabled"}},
        {"type": "webhook", "payload": {"url": "https://example.com/hook", "method": "POST", "body": {"user": "{{user_id}}"}}},
        {"type": "assign_admin", "payload": {"admin_id": str(OWNER), "target_type": "ticket", "target_id": "T-1"}},
        {"type": "write_log", "payload": {"message": "done {{user_id}}"}},
    ]
    rule = create_automation_rule(
        db, name="all actions", trigger="custom",
        conditions={"all": [
            {"field": "amount", "operator": "gte", "value": 10},
            {"field": "status", "operator": "in", "value": ["ready", "approved"]},
            {"any": [
                {"field": "name", "operator": "contains", "value": "amir"},
                {"field": "missing", "operator": "exists"},
            ]},
        ]},
        actions=actions, guards={"max_runs_per_day": 5, "cooldown_seconds": 1}, actor_id=OWNER, enabled=True,
    )
    result = process_automation_event(db, "custom", {
        "event_id": "evt-all", "entity_id": "12", "user_id": "12", "amount": 15, "status": "ready", "name": "Amir Hesabi",
    }, actor_id=OWNER)
    assert result["matched"][0]["status"] == "completed"
    assert len(db["automation_outbox"]) == 2
    assert db["crm_profiles"]["12"]["tags"] == ["vip"]
    assert db["marketing_campaigns"]["CMP-1"]["status"] == "queued"
    assert db["feature_flags"]["campaigns.enabled"] is False
    assert db["automation_v2_jobs"]
    assert db["tickets"][0]["assigned_admin"] == str(OWNER)
    assert db["automation_rules_v2"][rule["id"]]["success_count"] == 1
    guarded = process_automation_event(db, "custom", {
        "event_id": "evt-guard", "entity_id": "12", "user_id": "12", "amount": 15, "status": "ready", "name": "Amir",
    }, actor_id=OWNER)
    assert guarded["matched"][0]["status"] == "guarded"


def _png(size=(512, 512), color="black") -> bytes:
    out = BytesIO(); Image.new("RGB", size, color).save(out, "PNG"); return out.getvalue()


def test_gemini_ads_qa_schedule_cleanup_and_storage(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from modules import gemini_ads

    settings = SimpleNamespace(gemini_generated_ads_dir=str(tmp_path), run_mode="development")
    monkeypatch.setattr(gemini_ads, "SETTINGS", settings)
    monkeypatch.setattr(gemini_ads, "gemini_generate_ad_copy", lambda *_a, **_k: {
        "variants": ["تبلیغ حرفه‌ای Sentinel برای مدیریت ریسک"] * 3,
        "selected": "تبلیغ حرفه‌ای Sentinel برای مدیریت ریسک",
        "rationale": "test", "model": "copy",
    })
    monkeypatch.setattr(gemini_ads, "gemini_generate_admin_image", lambda *_a, **_k: {
        "image_bytes": _png(), "mime_type": "image/png", "model": "image",
    })
    db: dict = {}
    campaign = gemini_ads.create_ai_ad_campaign(db, actor_id=OWNER, name="risk ad", product="risk", objective="sale", delivery="public")
    generated = gemini_ads.generate_ai_ad_image(db, campaign["id"], actor_id=OWNER)
    approved = gemini_ads.approve_ai_ad(db, campaign["id"], actor_id=OWNER)
    scheduled = gemini_ads.schedule_ai_ad(db, campaign["id"], scheduled_for=(datetime.now(UTC) + timedelta(hours=2)).isoformat(), actor_id=OWNER)
    assert generated["qa"]["passed"] and approved["ai_ad_status"] == "APPROVED" and scheduled["ai_ad_status"] == "SCHEDULED"
    summary = gemini_ads.ai_ad_summary(db, campaign["id"])
    assert summary["assets"] and summary["qa"]["passed"]

    # Old inactive references are purged and metadata is updated.
    asset = db["marketing_campaigns"][campaign["id"]]["ai_assets"][0]
    db["marketing_campaigns"][campaign["id"]].update({
        "status": "completed", "ai_ad_status": "EXPIRED", "updated_at": (datetime.now(UTC) - timedelta(days=60)).isoformat(),
    })
    old = datetime.now().timestamp() - 60 * 86400
    os.utime(asset["path"], (old, old))
    cleanup = gemini_ads.cleanup_generated_ad_assets(db, now=datetime.now(UTC))
    assert cleanup["removed"] == 1 and asset["storage_state"] == "purged" and asset["path"] == ""

    # Production storage must live under the configured volume.
    prod = SimpleNamespace(gemini_generated_ads_dir=str(tmp_path / "outside"), run_mode="production")
    monkeypatch.setattr(gemini_ads, "SETTINGS", prod)
    monkeypatch.setenv("PERSISTENT_DATA_DIR", str(tmp_path / "volume"))
    monkeypatch.delenv("ALLOW_EPHEMERAL_STORAGE", raising=False)
    with pytest.raises(RuntimeError, match="NOT_ON_PERSISTENT_VOLUME"):
        gemini_ads._safe_dir()


def test_gemini_ad_qa_rejects_copy_and_invalid_assets(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from modules import gemini_ads

    monkeypatch.setattr(gemini_ads, "SETTINGS", SimpleNamespace(gemini_generated_ads_dir=str(tmp_path), run_mode="development"))
    db = {"marketing_campaigns": {"CMP-1": {
        "id": "CMP-1", "message": "سود تضمینی", "ai_copy_selected": "سود تضمینی",
        "ai_ad_status": "AI_DRAFT", "ai_assets": [{"id": "A", "path": str(tmp_path / "missing.png"), "sha256": "bad", "mime_type": "text/plain", "width": 1, "height": 1}],
    }}, "campaign_events": []}
    qa = gemini_ads.run_ai_ad_qa(db, "CMP-1", actor_id=OWNER)
    assert not qa["passed"]
    assert {"COPY_TOO_SHORT", "PROHIBITED_CLAIM"}.issubset(set(qa["errors"]))
    assert any(error.startswith("ASSET_") for error in qa["errors"])
    with pytest.raises(ValueError, match="AI_AD_QA_FAILED"):
        gemini_ads.approve_ai_ad(db, "CMP-1", actor_id=OWNER)
