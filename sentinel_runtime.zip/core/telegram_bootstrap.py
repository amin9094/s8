"""Bounded Telegram bootstrap and supervised durable delivery."""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import timedelta
from typing import Any

from telegram.error import NetworkError, RetryAfter

from core.observability import increment, record_error, set_readiness_state

logger = logging.getLogger(__name__)


def bootstrap_attempts() -> int:
    """Finite startup budget shared by polling and webhook delivery."""
    return max(1, min(20, int(os.getenv("TELEGRAM_BOOTSTRAP_ATTEMPTS", "6") or 6)))


async def _pause(stop_event: asyncio.Event, seconds: float) -> None:
    try:
        await asyncio.wait_for(stop_event.wait(), timeout=seconds)
    except TimeoutError:
        pass


async def telegram_startup_call(operation, stop_event: asyncio.Event, *, name: str) -> bool:
    attempts = bootstrap_attempts()
    timeout = max(1, min(120, float(os.getenv("TELEGRAM_BOOTSTRAP_TIMEOUT_SECONDS", "30"))))
    for attempt in range(attempts):
        if stop_event.is_set():
            return False
        try:
            async with asyncio.timeout(timeout):
                await operation()
            return True
        except (NetworkError, RetryAfter, TimeoutError) as exc:
            if attempt + 1 == attempts:
                logger.exception("Telegram %s exhausted bootstrap attempts", name)
                raise
            delay = min(30.0, 2.0 ** attempt)
            if isinstance(exc, RetryAfter):
                value = exc.retry_after
                seconds = value.total_seconds() if isinstance(value, timedelta) else float(value)
                # Do not send another request before Telegram's requested delay.
                # Excessively long flood waits are handed to the supervisor.
                if seconds > 120:
                    raise
                delay = max(delay, seconds)
            logger.warning("Telegram %s unavailable (%s), attempt %s/%s", name, type(exc).__name__, attempt + 1, attempts)
            await _pause(stop_event, delay)
    return False


async def initialize_with_retry(application: Any, stop_event: asyncio.Event) -> bool:
    return await telegram_startup_call(application.initialize, stop_event, name="initialize")


async def supervise_update_pump(application, stop_event: asyncio.Event, worker) -> None:
    """Restart a failed pump with a finite budget; propagate exhaustion to main.

    The queue stays durable in SQL. A dead delivery worker must not leave a
    healthy HTTP-only process behind. The platform handles terminal recovery.
    """
    attempts = max(1, min(20, int(os.getenv("TELEGRAM_PUMP_RESTART_ATTEMPTS", "5"))))
    for attempt in range(attempts):
        if stop_event.is_set():
            return
        try:
            await worker()
            if not stop_event.is_set():
                raise RuntimeError("Telegram update pump exited unexpectedly")
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            set_readiness_state("telegram_update_pump", False)
            increment("telegram_pump_failures_total")
            record_error("telegram_update_pump", exc)
            logger.exception("Telegram update pump failed (%s/%s)", attempt + 1, attempts)
            try:
                async with asyncio.timeout(10):
                    await application.process_error(update=None, error=exc)
            except Exception:
                logger.exception("Could not report update pump incident")
            if attempt + 1 == attempts:
                raise RuntimeError("Telegram delivery recovery budget exhausted") from exc
            await _pause(stop_event, min(30.0, 2.0 ** attempt))
