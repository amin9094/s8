from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from config import SETTINGS, persistent_storage_status
from core.db import database_catalog
from repositories.miniapp_read_repository import miniapp_reads
from core.domain import is_vip
from core.rate_limit import backend_status as rate_limit_backend_status
from core.utils import parse_dt, utc_iso
from core.webapp_auth import TelegramWebAppIdentity
from modules.admin_access import (
    PERMISSION_ADMIN_SHIFTS,
    PERMISSION_AUDIT_LOGS,
    PERMISSION_CAMPAIGNS,
    PERMISSION_SYSTEM_HEALTH_VIEW,
    PERMISSION_INTEGRATION_HEALTH_VIEW,
    has_permission,
    is_any_admin,
)
from modules.economic_calendar import cached_calendar_events, user_calendar_preferences
from modules.experiment_lab import experiment_lab_snapshot, experiment_report
from modules.i18n import user_language
from modules.admin_control_center import notification_preferences
from modules.market_intelligence import latest_snapshot
from modules.market_scope import MARKET_CRYPTO, MARKET_FOREX, signal_market_category
from modules.miniapp_product import order_detail, orders_for_user, vip_catalog
from modules.operations_handoff import daily_operations_brief, handoffs_for_admin
from modules.outcome_engine import FINAL_SIGNAL_STATUSES
from modules.portfolio import journal_entries, journal_stats, watchlist_for_user
from modules.product_intelligence import (
    market_regime_dashboard,
    onboarding_snapshot,
    signal_replay,
    signal_share_card,
)
from modules.rules import current_rules, user_has_accepted_rules
from modules.receipt_storage import receipt_storage_status
from modules.signal_portal import get_user_signal_choice
from modules.signal_safety import entry_display
from modules.support import find_ticket
from modules.trading_os import (
    account_exposure,
    accounts_for_user,
    behavioral_review,
    correlation_snapshot,
    late_entry_snapshot,
    portfolio_exposure,
    positions_for_user,
    pretrade_safety_gate,
    prop_account_snapshot,
    revision_inbox,
    track_record_explorer,
    trust_passport,
    what_if_snapshot,
)
from services.access_policy import enabled_feature_payload




# Bounded section sets keep high-volume GET endpoints away from unrelated
# business domains. Helpers may initialize missing optional keys in this
# defensive snapshot, but no read callback can persist those mutations.
_READ_SECTIONS = {
    "overview": (
        "users", "user_profiles", "user_points", "vip_users", "vip_orders", "vip_plans", "vip_settings",
        "discounts", "tickets", "signals", "user_signal_choices", "market_intelligence",
        "trading_accounts", "user_positions", "position_pnl_events", "position_audit",
        "personal_risk_profiles", "signal_revisions", "signal_revision_acknowledgements",
        "miniapp_onboarding", "trade_journal", "behavioral_insights", "user_notification_preferences",
        "enterprise_control", "rules_settings", "rules_acceptances", "delegated_admins",
    ),
    "global_search": (
        "signals", "vip_users", "user_signal_choices", "market_intelligence", "trade_journal",
        "vip_orders", "tickets",
    ),
    "admin_operations": (
        "delegated_admins", "admin_shifts", "shift_handoffs", "operations_daily_briefs",
        "vip_orders", "tickets", "incidents", "scheduled_signals", "kpi_trader_tasks",
        "marketing_campaigns",
    ),
    "signals": ("signals", "vip_users", "user_signal_choices", "market_intelligence"),
    "signal_detail": (
        "signals", "vip_users", "user_signal_choices", "market_intelligence", "economic_calendar",
        "economic_calendar_preferences", "trading_accounts", "user_positions", "position_pnl_events",
        "position_audit", "personal_risk_profiles", "signal_revisions", "signal_revision_acknowledgements",
        "signal_outcome_events", "signal_archive", "trust_center",
    ),
    "signal_replay": (
        "signals", "vip_users", "signal_replays", "signal_share_cards", "signal_archive",
        "signal_outcome_events", "signal_revisions", "trust_center",
    ),
    "risk": ("trading_accounts", "user_positions", "position_pnl_events", "position_audit", "personal_risk_profiles"),
    "journal": ("trade_journal", "user_positions", "position_pnl_events", "behavioral_insights", "trading_accounts", "personal_risk_profiles"),
    "market": ("market_intelligence", "user_watchlists", "market_regime_history", "signals", "signal_archive", "signal_outcome_events"),
    "calendar": ("economic_calendar", "economic_calendar_preferences"),
    "orders": ("vip_orders",),
    "tickets": ("tickets",),
    "track_record": ("signals", "signal_archive", "signal_outcome_events", "signal_revisions", "signal_versions", "trust_center"),
    "revisions": ("signals", "signal_revisions", "signal_revision_acknowledgements", "user_positions"),
    "admin_audit": ("admin_logs", "delegated_admins"),
    "experiments": ("growth_experiments", "experiment_assignments", "experiment_events", "delegated_admins"),
}

def _read_bounded(name: str, callback):
    return miniapp_reads.bounded(_READ_SECTIONS[name], callback)


def _page(values: list[Any], *, cursor: int = 0, limit: int = 20) -> dict[str, Any]:
    start = max(0, int(cursor or 0))
    size = max(1, min(int(limit or 20), 100))
    items = values[start : start + size]
    next_cursor = start + len(items) if start + len(items) < len(values) else None
    return {"items": items, "cursor": start, "next_cursor": next_cursor, "total": len(values), "limit": size}


def _visible_signal(db: dict[str, Any], item: dict[str, Any], vip_active: bool) -> bool:
    delivered = {str(value) for value in item.get("delivered_channels", [])}
    requested = {str(value) for value in item.get("requested_channels", [])}
    target = str(item.get("target") or "")
    public_visible = "public" in delivered or (not delivered and ("public" in requested or target in {"public", "both"}))
    private_visible = "private" in delivered or (not delivered and ("private" in requested or target in {"private", "both"}))
    return public_visible or (vip_active and private_visible)


def _visible_signals(db: dict[str, Any], user_id: int | str) -> list[dict[str, Any]]:
    vip_active = is_vip(db, user_id)
    rows = [row for row in db.get("signals", []) if isinstance(row, dict) and _visible_signal(db, row, vip_active)]
    rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    return rows


def _entry_text(signal: dict[str, Any]) -> str:
    try:
        return entry_display(signal.get("entries") or [signal.get("entry")])
    except (TypeError, ValueError):
        return str(signal.get("entry") or "—")


def _quote_map(snapshot: dict[str, Any]) -> dict[str, dict[str, Any]]:
    raw = snapshot.get("quotes", {}) if isinstance(snapshot.get("quotes"), dict) else {}
    output: dict[str, dict[str, Any]] = {}
    for symbol, value in raw.items():
        if isinstance(value, dict):
            price = value.get("price", value.get("close", value.get("value")))
            updated = value.get("updated_at", value.get("datetime", snapshot.get("generated_at")))
            spread = value.get("spread")
            bid = value.get("bid")
            ask = value.get("ask")
            provider = value.get("provider", snapshot.get("source", "market_snapshot"))
            confidence = value.get("confidence", snapshot.get("confidence"))
            providers = value.get("providers", value.get("provider_count", snapshot.get("provider_count")))
        else:
            price, updated, spread, provider = value, snapshot.get("generated_at"), None, snapshot.get("source", "market_snapshot")
        try:
            numeric = float(price)
        except (TypeError, ValueError):
            continue
        try:
            bid_value = float(bid) if bid is not None else None
        except (TypeError, ValueError):
            bid_value = None
        try:
            ask_value = float(ask) if ask is not None else None
        except (TypeError, ValueError):
            ask_value = None
        if spread is None and bid_value is not None and ask_value is not None:
            spread = ask_value - bid_value
        parsed_updated = parse_dt(str(updated or ""))
        age_seconds = max(0, int((datetime.now(UTC) - parsed_updated).total_seconds())) if parsed_updated else None
        output[str(symbol).upper().replace("/", "")] = {
            "symbol": str(symbol).upper(), "price": numeric, "mid": numeric, "bid": bid_value, "ask": ask_value,
            "updated_at": updated, "age_seconds": age_seconds, "stale": age_seconds is None or age_seconds > 120,
            "spread": spread, "provider": provider, "providers": providers, "confidence": confidence,
        }
    return output


def _quote_for_signal(db: dict[str, Any], signal: dict[str, Any]) -> dict[str, Any]:
    snapshot = latest_snapshot(db)
    quotes = _quote_map(snapshot)
    symbol = str(signal.get("symbol") or "").upper().replace("/", "")
    aliases = {symbol, symbol.replace("USDT", "USD"), symbol.replace("USD", "USDT")}
    return next((quotes[key] for key in aliases if key in quotes), {"symbol": symbol, "price": None, "updated_at": snapshot.get("generated_at"), "provider": "unavailable"})


def _signal_core(db: dict[str, Any], uid: str, signal: dict[str, Any]) -> dict[str, Any]:
    from modules.signal_engine import signal_rr_snapshot
    rr_metrics = signal_rr_snapshot(signal)
    targets = [str(value) for value in signal.get("targets", []) if str(value).strip()]
    entries = [str(value) for value in signal.get("entries", []) if str(value).strip()]
    if not entries and signal.get("entry") not in {None, ""}:
        entries = [str(signal.get("entry"))]
    quote = _quote_for_signal(db, signal)
    current_price = quote.get("price")
    late = late_entry_snapshot(signal, current_price if isinstance(current_price, (int, float)) else None)
    return {
        "id": int(signal.get("id", 0) or 0),
        "display_number": int(signal.get("display_number", signal.get("id", 0)) or 0),
        "cycle_id": int(signal.get("cycle_id", 1) or 1),
        "market_category": signal_market_category(signal),
        "symbol": str(signal.get("symbol") or ""),
        "side": str(signal.get("side") or "").lower(),
        "entries": entries,
        "entry": _entry_text(signal),
        "stop": str(signal.get("stop") or ""),
        "targets": targets,
        "risk": str(signal.get("risk") or ""),
        "risk_reward": str(rr_metrics["risk_reward"]) if rr_metrics["risk_reward"] is not None else "",
        "target_rr": rr_metrics["target_rr"],
        "status": str(signal.get("status") or "open"),
        "session": str(signal.get("market_session_label") or signal.get("market_session") or ""),
        "revision": int(signal.get("revision", 1) or 1),
        "created_at": signal.get("created_at"),
        "updated_at": signal.get("updated_at"),
        "expires_at": signal.get("expires_at"),
        "highest_target_hit": int(signal.get("highest_target_hit", 0) or 0),
        "profit_percent": float(signal.get("profit_percent", 0) or 0),
        "remaining_risk_percent": float(signal.get("remaining_risk_percent", signal.get("risk", 0)) or 0),
        "choice": dict(get_user_signal_choice(db, uid, signal.get("id", 0)) or {}),
        "quote": quote,
        "entry_state": {**late, **rr_metrics},
    }


def _nearby_news(db: dict[str, Any], uid: str, signal: dict[str, Any]) -> list[dict[str, Any]]:
    now = datetime.now(UTC)
    rows = cached_calendar_events(db, uid, period="week")
    symbol = str(signal.get("symbol") or "").upper()
    currencies = {symbol[:3], symbol[3:6] if len(symbol) >= 6 else ""} - {""}
    output: list[dict[str, Any]] = []
    for event in rows:
        if not isinstance(event, dict):
            continue
        event_dt = parse_dt(str(event.get("datetime") or event.get("date") or event.get("time") or ""))
        if not event_dt or abs((event_dt - now).total_seconds()) > 6 * 3600:
            continue
        currency = str(event.get("currency") or event.get("country") or "").upper()
        if currencies and currency and currency not in currencies:
            continue
        output.append({
            "title": str(event.get("title") or event.get("event") or ""),
            "currency": currency,
            "importance": str(event.get("importance") or event.get("impact") or ""),
            "datetime": event_dt.isoformat(),
            "minutes_from_now": round((event_dt - now).total_seconds() / 60),
        })
    return output[:10]


def overview(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        language = user_language(db, uid) or "fa"
        users = db.get("users", {})
        user = users.get(uid, {}) if isinstance(users, dict) else {}
        vip_active = is_vip(db, uid)
        visible = _visible_signals(db, uid)
        active = [row for row in visible if str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES]
        tickets = [row for row in db.get("tickets", []) if isinstance(row, dict) and str(row.get("user_id")) == uid]
        orders = orders_for_user(db, uid)
        accounts = accounts_for_user(db, uid)
        default_account = next((row for row in accounts if row.get("is_default")), accounts[0])
        exposure = account_exposure(db, uid, default_account["id"])
        prop = prop_account_snapshot(db, uid, default_account["id"])
        revisions_pending = len(revision_inbox(db, uid))
        onboarding = onboarding_snapshot(db, uid)
        today_actions: list[dict[str, Any]] = []
        if not onboarding.get("completed"):
            today_actions.append({"type": "onboarding", "priority": "high", "target": "onboarding"})
        if revisions_pending:
            today_actions.append({"type": "revision", "priority": "high", "count": revisions_pending, "target": "revisions"})
        if exposure.get("risk_exhausted"):
            today_actions.append({"type": "risk_exhausted", "priority": "critical", "target": "risk"})
        elif float(exposure.get("remaining_daily_risk_percent", 0) or 0) <= 0.5:
            today_actions.append({"type": "risk_low", "priority": "high", "target": "risk", "remaining": exposure.get("remaining_daily_risk_percent")})
        if prop.get("breaches"):
            today_actions.append({"type": "prop_breach", "priority": "critical", "target": "risk", "breaches": prop.get("breaches")})
        pending_orders = sum(1 for row in orders if row.get("status") in {"pending", "approving"})
        if pending_orders:
            today_actions.append({"type": "pending_order", "priority": "normal", "count": pending_orders, "target": "orders"})
        open_tickets = sum(1 for row in tickets if row.get("status") == "open")
        if open_tickets:
            today_actions.append({"type": "open_ticket", "priority": "normal", "count": open_tickets, "target": "support"})
        return {
            "user": {
                "id": identity.user_id,
                "username": identity.username or str(user.get("username") or ""),
                "first_name": identity.first_name or str(user.get("first_name") or ""),
                "last_name": identity.last_name or str(user.get("last_name") or ""),
                "language": language,
            },
            "account": {
                "points": max(0, int(db.get("user_points", {}).get(uid, 0) or 0)),
                "vip_active": vip_active,
                "vip_expires_at": db.get("vip_users", {}).get(uid, {}).get("expires_at"),
                "orders_total": len(orders),
                "pending_orders": pending_orders,
                "open_tickets": open_tickets,
                "active_signals": len(active),
                "active_forex_signals": sum(1 for row in active if signal_market_category(row) == MARKET_FOREX),
                "active_crypto_signals": sum(1 for row in active if signal_market_category(row) == MARKET_CRYPTO),
            },
            "risk": {
                "accounts": accounts,
                "default_account": default_account,
                "portfolio_exposure": portfolio_exposure(db, uid),
                "account_exposure": exposure,
                "prop": prop,
                "what_if": what_if_snapshot(db, uid, default_account["id"]),
                "correlation": correlation_snapshot(db, uid),
            },
            "recent_signals": [_signal_core(db, uid, row) for row in visible[:6]],
            "journal_stats": journal_stats(db, uid),
            "revision_count": revisions_pending,
            "today_actions": today_actions,
            "notifications": notification_preferences(db, uid),
            "onboarding": onboarding,
            "bot_username": SETTINGS.bot_username,
            "features": enabled_feature_payload(db),
            "commerce": vip_catalog(db, uid, vip_active=vip_active),
            "rules": {**current_rules(db, language), "language": language, "accepted": user_has_accepted_rules(db, uid, language)},
            "admin_available": is_any_admin(db, uid),
            "generated_at": utc_iso(),
        }
    return _read_bounded("overview", read)


def signals(identity: TelegramWebAppIdentity, *, cursor: int = 0, limit: int = 20, status: str = "", market: str = "", query: str = "") -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        rows = _visible_signals(db, uid)
        clean_query = str(query or "").upper().strip()
        if status:
            rows = [row for row in rows if str(row.get("status") or "open").lower() == status.lower()]
        if market:
            rows = [row for row in rows if signal_market_category(row) == market]
        if clean_query:
            rows = [row for row in rows if clean_query in str(row.get("symbol") or "").upper() or clean_query in str(row.get("display_number") or "")]
        page = _page(rows, cursor=cursor, limit=limit)
        page["items"] = [_signal_core(db, uid, row) for row in page["items"]]
        return page
    return _read_bounded("signals", read)


def signal_detail(identity: TelegramWebAppIdentity, signal_id: int | str, *, account_id: int | str | None = None) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        signal = next((row for row in _visible_signals(db, uid) if int(row.get("id", 0) or 0) == int(signal_id)), None)
        if not signal:
            raise ValueError("SIGNAL_NOT_FOUND")
        core = _signal_core(db, uid, signal)
        quote = core["quote"]
        price = quote.get("price") if isinstance(quote.get("price"), (int, float)) else None
        try:
            gate = pretrade_safety_gate(
                db,
                uid,
                signal,
                account_id=account_id,
                current_price=price,
            )
        except (ValueError, TypeError) as exc:
            gate = {"status": "unavailable", "can_execute": False, "reasons": [str(exc)]}
        return {
            **core,
            "note": str(signal.get("note") or signal.get("analysis") or "")[:8000],
            "nearby_news": _nearby_news(db, uid, signal),
            "correlation": correlation_snapshot(db, uid, candidate_symbol=str(signal.get("symbol") or "")),
            "pretrade_gate": gate,
            "trust_passport": trust_passport(db, signal),
            "positions": [row for row in positions_for_user(db, uid, include_voided=True) if int(row.get("signal_id", 0) or 0) == int(signal_id)],
        }
    return _read_bounded("signal_detail", read)


def signal_replay_detail(identity: TelegramWebAppIdentity, signal_id: int | str) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        visible_ids = {int(row.get("id", 0) or 0) for row in _visible_signals(db, uid)}
        if int(signal_id) not in visible_ids:
            raise ValueError("SIGNAL_NOT_FOUND")
        return signal_replay(db, signal_id)
    return _read_bounded("signal_replay", read)


def signal_share_card_detail(identity: TelegramWebAppIdentity, signal_id: int | str) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        visible_ids = {int(row.get("id", 0) or 0) for row in _visible_signals(db, uid)}
        if int(signal_id) not in visible_ids:
            raise ValueError("SIGNAL_NOT_FOUND")
        return signal_share_card(db, signal_id)
    return _read_bounded("signal_replay", read)


def risk(identity: TelegramWebAppIdentity, *, account_id: int | str | None = None) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        accounts = accounts_for_user(db, uid)
        account = next((row for row in accounts if str(row.get("id")) == str(account_id)), None) if account_id else next((row for row in accounts if row.get("is_default")), accounts[0])
        return {
            "accounts": accounts,
            "selected_account": account,
            "exposure": account_exposure(db, uid, account["id"]),
            "portfolio_exposure": portfolio_exposure(db, uid),
            "prop": prop_account_snapshot(db, uid, account["id"]),
            "what_if": what_if_snapshot(db, uid, account["id"]),
            "correlation": correlation_snapshot(db, uid),
            "positions": positions_for_user(db, uid, account_id=account["id"]),
        }
    return _read_bounded("risk", read)


def journal(
    identity: TelegramWebAppIdentity,
    *,
    cursor: int = 0,
    limit: int = 30,
    status: str = "",
    symbol: str = "",
    query: str = "",
) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        rows = journal_entries(db, uid, limit=5000)
        clean_status = str(status or "").strip().lower()
        clean_symbol = str(symbol or "").strip().upper()
        needle = str(query or "").strip().casefold()
        if clean_status:
            rows = [row for row in rows if str(row.get("status") or "").lower() == clean_status]
        if clean_symbol:
            rows = [row for row in rows if clean_symbol in str(row.get("symbol") or "").upper()]
        if needle:
            rows = [
                row for row in rows
                if needle in f"{row.get('symbol', '')} {row.get('setup', '')} {row.get('note', '')} "
                f"{' '.join(row.get('tags', []) if isinstance(row.get('tags'), list) else [])}".casefold()
            ]
        page = _page(rows, cursor=cursor, limit=limit)
        page["stats"] = journal_stats(db, uid)
        page["behavioral_review"] = behavioral_review(db, uid)
        return page
    return _read_bounded("journal", read)


def market(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        snapshot = latest_snapshot(db)
        return {
            "quotes": list(_quote_map(snapshot).values()),
            "snapshot": snapshot,
            "watchlist": watchlist_for_user(db, uid),
            "regime": market_regime_dashboard(db),
            "generated_at": snapshot.get("generated_at"),
        }
    return _read_bounded("market", read)


def calendar(
    identity: TelegramWebAppIdentity,
    *,
    cursor: int = 0,
    limit: int = 40,
    currency: str = "",
    impact: str = "",
    query: str = "",
) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        rows = cached_calendar_events(db, uid, period="week")
        clean_currency = str(currency or "").strip().upper()
        clean_impact = str(impact or "").strip().lower()
        needle = str(query or "").strip().casefold()
        if clean_currency:
            rows = [row for row in rows if str(row.get("currency") or row.get("country") or "").upper() == clean_currency]
        if clean_impact:
            rows = [row for row in rows if str(row.get("impact") or row.get("importance") or "").lower() == clean_impact]
        if needle:
            rows = [row for row in rows if needle in f"{row.get('title', '')} {row.get('event', '')} {row.get('currency', '')}".casefold()]
        page = _page(rows, cursor=cursor, limit=limit)
        page["preferences"] = user_calendar_preferences(db, uid)
        return page
    return _read_bounded("calendar", read)


def orders(
    identity: TelegramWebAppIdentity,
    *,
    cursor: int = 0,
    limit: int = 20,
    status: str = "",
    query: str = "",
) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        rows = orders_for_user(db, identity.user_id)
        clean_status = str(status or "").strip().lower()
        needle = str(query or "").strip().casefold()
        if clean_status:
            rows = [row for row in rows if str(row.get("status") or "").lower() == clean_status]
        if needle:
            rows = [row for row in rows if needle in f"{row.get('order_id', '')} {row.get('plan_name', '')} {row.get('status', '')}".casefold()]
        return _page(rows, cursor=cursor, limit=limit)
    return _read_bounded("orders", read)


def order(identity: TelegramWebAppIdentity, order_id: str) -> dict[str, Any]:
    return _read_bounded("orders", lambda db: order_detail(db, identity.user_id, order_id))


def tickets(
    identity: TelegramWebAppIdentity,
    *,
    cursor: int = 0,
    limit: int = 20,
    status: str = "",
    query: str = "",
) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        rows = [row for row in db.get("tickets", []) if isinstance(row, dict) and str(row.get("user_id")) == uid]
        clean_status = str(status or "").strip().lower()
        needle = str(query or "").strip().casefold()
        if clean_status:
            rows = [row for row in rows if str(row.get("status") or "").lower() == clean_status]
        if needle:
            rows = [row for row in rows if needle in f"{row.get('id', '')} {row.get('subject', '')} {row.get('category', '')}".casefold()]
        rows.sort(key=lambda row: str(row.get("updated_at") or row.get("created_at") or ""), reverse=True)
        return _page(rows, cursor=cursor, limit=limit)
    return _read_bounded("tickets", read)


def ticket(identity: TelegramWebAppIdentity, ticket_id: int | str) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        row = find_ticket(db, ticket_id)
        if not row or str(row.get("user_id")) != str(identity.user_id):
            raise ValueError("TICKET_NOT_FOUND")
        return dict(row)
    return _read_bounded("tickets", read)


def track_record(identity: TelegramWebAppIdentity, *, symbol: str = "", market_filter: str = "", cursor: int = 0, limit: int = 20) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        result = track_record_explorer(db, symbol=symbol, market=market_filter, limit=500)
        page = _page(result["ledger"], cursor=cursor, limit=limit)
        page["summary"] = result["summary"]
        return page
    return _read_bounded("track_record", read)


def revisions(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    return _read_bounded("revisions", lambda db: {"items": revision_inbox(db, identity.user_id)})


def global_search(identity: TelegramWebAppIdentity, query: str, *, limit: int = 30) -> dict[str, Any]:
    clean = str(query or "").strip()
    if len(clean) < 2:
        return {"items": [], "query": clean, "total": 0}
    needle = clean.casefold()

    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        output: list[dict[str, Any]] = []
        for signal in _visible_signals(db, uid):
            haystack = f"{signal.get('symbol', '')} {signal.get('display_number', '')} {signal.get('note', '')}".casefold()
            if needle in haystack:
                output.append({"type": "signal", "id": signal.get("id"), "title": f"{signal.get('symbol')} · #{signal.get('display_number', signal.get('id'))}", "subtitle": signal.get("status"), "target": f"signal:{signal.get('id')}"})
        for row in journal_entries(db, uid, limit=5000):
            haystack = f"{row.get('symbol', '')} {row.get('setup', '')} {row.get('note', '')} {' '.join(row.get('tags', []) if isinstance(row.get('tags'), list) else [])}".casefold()
            if needle in haystack:
                output.append({"type": "journal", "id": row.get("id"), "title": f"{row.get('symbol')} · {row.get('side')}", "subtitle": row.get("status"), "target": "journal"})
        for row in orders_for_user(db, uid):
            haystack = f"{row.get('order_id', '')} {row.get('plan_name', '')} {row.get('status', '')}".casefold()
            if needle in haystack:
                output.append({"type": "order", "id": row.get("order_id"), "title": str(row.get("plan_name") or "VIP"), "subtitle": row.get("status"), "target": "orders"})
        for row in db.get("tickets", []):
            if not isinstance(row, dict) or str(row.get("user_id")) != uid:
                continue
            haystack = f"{row.get('id', '')} {row.get('subject', '')} {row.get('category', '')}".casefold()
            if needle in haystack:
                output.append({"type": "ticket", "id": row.get("id"), "title": str(row.get("subject") or "Support"), "subtitle": row.get("status"), "target": f"ticket:{row.get('id')}"})
        return {"items": output[: max(1, min(int(limit), 100))], "query": clean, "total": len(output)}

    return _read_bounded("global_search", read)


def admin_operations(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        can_operations = has_permission(db, uid, PERMISSION_ADMIN_SHIFTS)
        can_health = has_permission(db, uid, PERMISSION_SYSTEM_HEALTH_VIEW) or has_permission(
            db, uid, PERMISSION_INTEGRATION_HEALTH_VIEW
        )
        if not can_operations and not can_health:
            raise PermissionError("FORBIDDEN")
        configured_admins = [uid]
        delegated = db.get("delegated_admins", {})
        if isinstance(delegated, dict):
            configured_admins.extend(str(key) for key, row in delegated.items() if isinstance(row, dict) and row.get("active", True))
        catalog = database_catalog()
        storage = persistent_storage_status(database_url=SETTINGS.database_url, db_file=SETTINGS.db_file)
        return {
            "brief": daily_operations_brief(db, admin_ids=tuple(dict.fromkeys(configured_admins)), persist=False) if can_operations else {},
            "handoffs": handoffs_for_admin(db, uid, limit=100) if can_operations else [],
            "system_health": ({
                "database": {
                    "persistent": bool(storage.get("persistent")),
                    "reason": str(storage.get("reason") or ""),
                    "version": catalog.get("version"),
                    "sections": len(catalog.get("sections", [])),
                    "users": catalog.get("users", {}),
                },
                "rate_limit": rate_limit_backend_status(),
                "receipt_storage": receipt_storage_status(),
                "migration": __import__("core.storage.migration", fromlist=["migration_status"]).migration_status(),
                "release": {
                    "version": SETTINGS.release_version,
                    "build_number": SETTINGS.release_build_number,
                    "commit_sha": SETTINGS.release_commit_sha,
                    "image_digest": SETTINGS.release_image_digest,
                },
            } if can_health else {}),
            "generated_at": utc_iso(),
        }
    return _read_bounded("admin_operations", read)


def admin_experiments(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        if not has_permission(db, uid, PERMISSION_CAMPAIGNS):
            raise PermissionError("FORBIDDEN")
        return experiment_lab_snapshot(db)
    return _read_bounded("experiments", read)


def admin_experiment_detail(identity: TelegramWebAppIdentity, experiment_id: int | str) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        if not has_permission(db, uid, PERMISSION_CAMPAIGNS):
            raise PermissionError("FORBIDDEN")
        return experiment_report(db, experiment_id)
    return _read_bounded("experiments", read)


def admin_audit_logs(
    identity: TelegramWebAppIdentity,
    *,
    cursor: int = 0,
    limit: int = 50,
    query: str = "",
    action: str = "",
) -> dict[str, Any]:
    def read(db: dict[str, Any]) -> dict[str, Any]:
        uid = str(identity.user_id)
        if not has_permission(db, uid, PERMISSION_AUDIT_LOGS):
            raise PermissionError("FORBIDDEN")
        rows = [dict(row) for row in db.get("admin_logs", []) if isinstance(row, dict)]
        rows.reverse()
        needle = str(query or "").strip().casefold()
        clean_action = str(action or "").strip().casefold()
        if clean_action:
            rows = [row for row in rows if clean_action in str(row.get("action") or "").casefold()]
        if needle:
            rows = [row for row in rows if needle in f"{row.get('admin_id', '')} {row.get('action', '')} {row.get('details', '')}".casefold()]
        return _page(rows, cursor=cursor, limit=limit)
    return _read_bounded("admin_audit", read)
