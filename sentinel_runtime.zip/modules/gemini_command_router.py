from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable

from modules.ai_action_firewall import action_family

_PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_NUMBER_WORDS = {
    "صفر": 0, "یک": 1, "یه": 1, "دو": 2, "سه": 3, "چهار": 4, "پنج": 5,
    "شش": 6, "هفت": 7, "هشت": 8, "نه": 9, "ده": 10, "یازده": 11,
    "دوازده": 12, "سیزده": 13, "چهارده": 14, "پانزده": 15, "شانزده": 16,
    "هفده": 17, "هجده": 18, "نوزده": 19, "بیست": 20, "سی": 30, "چهل": 40,
    "پنجاه": 50, "شصت": 60, "هفتاد": 70, "هشتاد": 80, "نود": 90, "صد": 100,
}

_SCOPE_TERMS: dict[str, tuple[str, ...]] = {
    "tickets": ("تیکت", "پشتیبانی", "درخواست پشتیبانی", "ticket", "support case"),
    "signals": ("سیگنال", "قالب", "تارگت", "حد ضرر", "استاپ", "signal", "template", "entry", "stop loss"),
    "channel": ("کانال", "پست", "پیام کانال", "اعلان", "انتشار", "channel", "announcement", "publish"),
    "crm": (
        "crm", "مشتری", "سرنخ", "کاربر", "کمپین", "کد تخفیف", "تخفیف", "کوپن",
        "پرداخت", "رسید", "سفارش", "اشتراک", "وی آی پی", "vip", "پلن", "campaign",
        "customer", "lead", "discount", "coupon", "payment", "receipt", "order", "subscription",
    ),
    "user_behavior": ("رفتار کاربر", "رفتار کاربران", "مسیر کاربر", "ریزش", "user behavior", "journey", "dropoff"),
    "risk": ("ریسک", "پراپ", "دراودان", "حد زیان", "risk", "prop", "drawdown"),
    "system": (
        "سلامت سیستم", "خطای سرور", "رخداد", "ران تایم", "ران‌تایم", "مینی اپ", "مینی‌اپ",
        "ماژول", "تنظیمات ربات", "system health", "incident", "runtime", "miniapp", "module",
    ),
    "knowledge": (
        "آموزش", "درس", "فایل آموزشی", "دانش", "ماموریت", "مأموریت", "مسابقه", "ایده",
        "education", "lesson", "knowledge", "mission", "contest", "idea",
    ),
}

_SCOPE_FAMILIES: dict[str, frozenset[str]] = {
    "management": frozenset({"report", "runtime", "admin", "crm", "commerce", "ticket", "signal", "channel", "education", "idea", "user"}),
    "crm": frozenset({"crm", "commerce", "user", "idea"}),
    "user_behavior": frozenset({"user", "crm", "report"}),
    "channel": frozenset({"channel", "crm"}),
    "tickets": frozenset({"ticket"}),
    "signals": frozenset({"signal", "risk"}),
    "risk": frozenset({"risk", "signal", "report"}),
    "system": frozenset({"runtime", "report", "admin"}),
    "knowledge": frozenset({"education", "idea", "report"}),
}

_ACTION_HINTS: dict[str, tuple[str, ...]] = {
    "public_discount_create": ("کد تخفیف", "تخفیف عمومی", "کوپن", "discount code", "coupon"),
    "campaign_create": ("کمپین بساز", "کارزار بساز", "campaign create"),
    "payment_approve": ("پرداخت را تایید", "پرداخت را تأیید", "رسید را تایید", "سفارش را تایید", "approve payment"),
    "payment_reject": ("پرداخت را رد", "رسید را رد", "سفارش را رد", "reject payment"),
    "admin_vip_plan_create": ("پلن بساز", "اشتراک بساز", "پلن vip", "create vip plan"),
    "admin_vip_plan_update": ("پلن را تغییر", "پلن را ویرایش", "update plan"),
    "admin_vip_plan_toggle": ("پلن را فعال", "پلن را غیرفعال", "آرشیو پلن", "toggle plan"),
    "admin_vip_plan_delete": ("پلن را حذف", "delete plan"),
    "ticket_admin_reply": ("به تیکت پاسخ", "پاسخ تیکت", "reply ticket"),
    "ticket_admin_status_update": ("وضعیت تیکت", "تیکت را ببند", "تیکت را باز", "ticket status"),
    "ticket_admin_assign": ("تیکت را واگذار", "تخصیص تیکت", "assign ticket"),
    "ticket_admin_priority_update": ("اولویت تیکت", "ticket priority"),
    "ticket_admin_internal_note": ("یادداشت تیکت", "یادداشت داخلی", "ticket note"),
    "ai_signal_template_apply_asset": ("عکس قالب", "فایل قالب", "قالب buy", "قالب sell", "template asset"),
    "ai_signal_template_layout_update": ("چیدمان قالب", "جای متن قالب", "اندازه فونت قالب", "مختصات قالب", "template layout"),
    "ai_signal_template_reset": ("ریست قالب", "بازنشانی قالب", "قالب پیش فرض", "reset template"),
    "ai_signal_refresh_channel": ("بازسازی سیگنال", "رفرش سیگنال کانال", "refresh signal"),
    "signal_edit": ("سیگنال را ویرایش", "سیگنال را تغییر", "edit signal"),
    "signal_result_set": ("نتیجه سیگنال", "تی پی خورد", "استاپ خورد", "بریک ایون", "signal result"),
    "signal_result_reset": ("نتیجه سیگنال را پاک", "سیگنال را دوباره باز", "reset signal result"),
    "signal_delete": ("سیگنال را حذف", "delete signal"),
    "miniapp_signal_publish": ("سیگنال را منتشر", "ارسال سیگنال", "publish signal"),
    "ai_signal_draft_create": ("پیش نویس سیگنال", "پیش‌نویس سیگنال", "signal draft"),
    "admin_user_ban": ("کاربر را بن", "کاربر را مسدود", "ban user"),
    "admin_user_unban": ("رفع بن", "کاربر را آزاد", "unban user"),
    "delegated_admin_upsert": ("ادمین اضافه", "مدیر اضافه", "add admin"),
    "delegated_admin_permissions_set": ("مجوز ادمین", "دسترسی مدیر", "admin permission"),
    "delegated_admin_remove": ("ادمین را حذف", "مدیر را حذف", "remove admin"),
    "ai_lesson_create": ("آموزش بساز", "درس بساز", "آموزش جدید", "create lesson"),
    "ai_lesson_update": ("آموزش را ویرایش", "درس را تغییر", "update lesson"),
    "ai_lesson_status": ("آموزش را منتشر", "درس را آرشیو", "publish lesson"),
    "ai_lesson_delete": ("آموزش را حذف", "درس را حذف", "delete lesson"),
    "ai_mission_create": ("ماموریت بساز", "مأموریت بساز", "create mission"),
    "ai_mission_update": ("ماموریت را ویرایش", "مأموریت را تغییر", "update mission"),
    "ai_mission_toggle": ("ماموریت را فعال", "ماموریت را غیرفعال", "toggle mission"),
    "ai_mission_delete": ("ماموریت را حذف", "مأموریت را حذف", "delete mission"),
    "ai_contest_start": ("مسابقه بساز", "مسابقه شروع", "start contest"),
    "ai_contest_end": ("مسابقه را تمام", "مسابقه را پایان", "end contest"),
    "miniapp_announcement_publish": ("اعلان منتشر", "خبر منتشر", "announcement publish"),
    "publication_enqueue": ("در کانال منتشر", "در صف انتشار", "queue publication"),
    "ai_channel_message_operation": ("پیام کانال را ویرایش", "پیام کانال را حذف", "پین کن", "unpin"),
    "miniapp_runtime_toggle": ("مینی اپ را فعال", "مینی اپ را غیرفعال", "miniapp toggle"),
    "runtime_mode_update": ("حالت تعمیر", "حالت نگهداری", "حالت فقط خواندنی", "runtime mode"),
    "control_change": ("تنظیم ماژول", "تنظیمات را تغییر", "change module"),
    "ai_idea_create": ("ایده ثبت", "ایده بساز", "ایده جدید", "save idea"),
    "admin_command_center_snapshot": ("مرکز فرماندهی", "کارهای امروز", "command center"),
    "admin_global_search": ("جستجوی سراسری", "پیدا کن", "global search"),
    "automation_v2_rule_list": ("اتوماسیون ها را نشان بده", "لیست اتوماسیون", "list automations"),
    "automation_v2_rule_create": ("اتوماسیون بساز", "قانون خودکار بساز", "create automation"),
    "automation_v2_rule_update": ("اتوماسیون را ویرایش کن", "update automation"),
    "automation_v2_rule_test": ("اتوماسیون را تست کن", "dry run automation"),
    "ai_ad_campaign_create": ("تبلیغ بساز", "تبلیغ جمنای", "create ai ad"),
    "ai_ad_image_generate": ("عکس تبلیغ بساز", "تصویر تبلیغ تولید کن", "generate ad image"),
    "ai_ad_summary": ("وضعیت تبلیغ", "خلاصه تبلیغ", "ad summary"),
    "ai_ad_approve": ("تبلیغ را تایید کن", "approve ad"),
    "ai_ad_schedule": ("تبلیغ را زمان بندی کن", "schedule ad"),
}


# Every registered operational action has at least one natural-language alias.
# This keeps the correct action inside the small FunctionDeclaration set even
# when the administrator writes Persian and the backend description is English.
_ACTION_HINTS.update({
    "control_change": ("تنظیم ماژول را تغییر بده", "مقدار تنظیمات را عوض کن", "change setting"),
    "control_reset": ("تنظیمات ماژول را ریست کن", "ماژول را به پیش فرض برگردان", "reset module"),
    "control_preset": ("پریست را اعمال کن", "تنظیم آماده را اعمال کن", "apply preset"),
    "runtime_mode_update": ("حالت ربات را تغییر بده", "حالت نگهداری را فعال کن", "runtime mode"),
    "miniapp_runtime_toggle": ("مینی اپ را روشن کن", "مینی اپ را خاموش کن", "toggle miniapp"),
    "integration_reconcile": ("ارتباط ربات و مینی اپ را همگام کن", "یکپارچه سازی را بازسازی کن", "reconcile integration"),
    "incident_status_update": ("وضعیت رخداد را تغییر بده", "رخداد را حل شده کن", "update incident"),
    "automation_retry": ("اتوماسیون را دوباره اجرا کن", "پیام ناموفق را تلاش مجدد کن", "retry automation"),
    "campaign_create": ("کمپین بساز", "کارزار جدید ایجاد کن", "create campaign"),
    "public_discount_create": ("کد تخفیف بساز", "تخفیف عمومی ایجاد کن", "create discount code"),
    "ai_idea_create": ("ایده جدید ثبت کن", "ایده بساز", "create idea"),
    "campaign_status_update": ("وضعیت کمپین را تغییر بده", "کمپین را فعال کن", "update campaign status"),
    "campaign_delivery_update": ("روش ارسال کمپین را تغییر بده", "تحویل کمپین را عوض کن", "campaign delivery"),
    "campaign_schedule": ("کمپین را زمان بندی کن", "زمان کمپین را تنظیم کن", "schedule campaign"),
    "experiment_create": ("آزمایش محتوا بساز", "تست ای بی ایجاد کن", "create experiment"),
    "experiment_status_update": ("وضعیت آزمایش را تغییر بده", "آزمایش را متوقف کن", "update experiment"),
    "miniapp_announcement_publish": ("اعلان مینی اپ منتشر کن", "خبر را در مینی اپ بفرست", "publish announcement"),
    "publisher_channel_upsert": ("کانال را ثبت کن", "کانال مدیریت شده را تغییر بده", "register channel"),
    "publication_enqueue": ("محتوا را در صف انتشار بگذار", "در کانال منتشر کن", "queue publication"),
    "publication_status_update": ("وضعیت انتشار را تغییر بده", "انتشار را لغو کن", "update publication"),
    "content_render": ("محتوا را رندر کن", "کارت محتوا بساز", "render content"),
    "public_performance_snapshot": ("گزارش عملکرد عمومی بساز", "اسنپ شات عملکرد بگیر", "performance snapshot"),
    "business_inbox_admin_classify": ("پیام مشتری را طبقه بندی کن", "اینباکس کسب و کار را دسته بندی کن", "classify inbox"),
    "workspace_create": ("فضای کاری بساز", "ورک اسپیس ایجاد کن", "create workspace"),
    "payment_approve": ("پرداخت را تایید کن", "رسید را تایید کن", "approve payment"),
    "payment_reject": ("پرداخت را رد کن", "رسید را رد کن", "reject payment"),
    "admin_vip_plan_create": ("پلن اشتراک بساز", "پلن وی آی پی ایجاد کن", "create vip plan"),
    "admin_vip_plan_update": ("پلن اشتراک را ویرایش کن", "مشخصات پلن را تغییر بده", "update vip plan"),
    "admin_vip_plan_toggle": ("پلن را فعال کن", "پلن را غیرفعال کن", "toggle vip plan"),
    "admin_vip_plan_delete": ("پلن را حذف کن", "delete vip plan"),
    "admin_user_ban": ("کاربر را مسدود کن", "کاربر را بن کن", "ban user"),
    "admin_user_unban": ("مسدودی کاربر را بردار", "رفع بن کاربر", "unban user"),
    "delegated_admin_upsert": ("ادمین فرعی اضافه کن", "مدیر جدید ثبت کن", "add delegated admin"),
    "delegated_admin_permissions_set": ("مجوز ادمین را تغییر بده", "دسترسی مدیر را تنظیم کن", "set admin permissions"),
    "delegated_admin_remove": ("ادمین فرعی را حذف کن", "مدیر را بردار", "remove delegated admin"),
    "signal_edit": ("سیگنال را ویرایش کن", "فیلد سیگنال را تغییر بده", "edit signal"),
    "signal_result_set": ("نتیجه سیگنال را ثبت کن", "تی پی سیگنال را ثبت کن", "set signal result"),
    "signal_result_reset": ("نتیجه سیگنال را پاک کن", "سیگنال را دوباره باز کن", "reset signal result"),
    "signal_delete": ("سیگنال را حذف کن", "delete signal"),
    "miniapp_signal_publish": ("سیگنال را منتشر کن", "سیگنال را در ربات و مینی اپ بفرست", "publish signal"),
    "ai_signal_draft_create": ("پیش نویس سیگنال بساز", "پیشنویس سیگنال ایجاد کن", "create signal draft"),
    "signal_job_retry": ("صف سیگنال را دوباره اجرا کن", "کار سیگنال را تلاش مجدد کن", "retry signal job"),
    "signal_job_cancel": ("کار زمان بندی سیگنال را لغو کن", "صف سیگنال را کنسل کن", "cancel signal job"),
    "signal_job_update": ("کار زمان بندی سیگنال را تغییر بده", "زمان ارسال سیگنال را عوض کن", "update signal job"),
    "signal_cycle_rollover": ("دوره سیگنال را رول اور کن", "دوره فعال را به دوره جدید منتقل کن", "rollover signal cycle"),
    "signal_cycle_close": ("دوره سیگنال را ببند", "close signal cycle"),
    "signal_cycle_start": ("دوره سیگنال جدید شروع کن", "start signal cycle"),
    "signal_cycle_rename": ("نام دوره سیگنال را تغییر بده", "rename signal cycle"),
    "ai_signal_template_apply_asset": ("عکس قالب سیگنال را عوض کن", "تصویر قالب بای را قرار بده", "apply signal template asset"),
    "ai_signal_template_layout_update": ("چیدمان قالب سیگنال را تغییر بده", "جای متن قالب را عوض کن", "update signal template layout"),
    "ai_signal_template_reset": ("قالب سیگنال را ریست کن", "قالب اصلی را برگردان", "reset signal template"),
    "ai_signal_refresh_channel": ("پیام سیگنال کانال را بازسازی کن", "سیگنال کانال را رفرش کن", "refresh channel signal"),
    "ai_channel_message_operation": ("پیام کانال را ویرایش کن", "پیام کانال را پین کن", "channel message operation"),
    "ticket_admin_reply": ("به تیکت پاسخ بده", "پاسخ تیکت را ارسال کن", "reply ticket"),
    "ticket_admin_status_update": ("وضعیت تیکت را تغییر بده", "تیکت را ببند", "update ticket status"),
    "ticket_admin_assign": ("تیکت را به ادمین واگذار کن", "تیکت را تخصیص بده", "assign ticket"),
    "ticket_admin_priority_update": ("اولویت تیکت را تغییر بده", "update ticket priority"),
    "ticket_admin_internal_note": ("یادداشت داخلی تیکت ثبت کن", "add ticket note"),
    "shift_handoff_create": ("تحویل شیفت بساز", "شیفت را به مدیر بعدی تحویل بده", "create shift handoff"),
    "shift_handoff_status_update": ("وضعیت تحویل شیفت را تغییر بده", "update shift handoff"),
    "prop_template_create": ("قالب قوانین پراپ بساز", "الگوی حساب پراپ ایجاد کن", "create prop template"),
    "ai_lesson_create": ("آموزش جدید بساز", "درس ایجاد کن", "create lesson"),
    "ai_lesson_update": ("آموزش را ویرایش کن", "درس را تغییر بده", "update lesson"),
    "ai_lesson_status": ("آموزش را منتشر کن", "درس را آرشیو کن", "change lesson status"),
    "ai_lesson_delete": ("آموزش را حذف کن", "delete lesson"),
    "ai_mission_create": ("ماموریت جدید بساز", "مأموریت ایجاد کن", "create mission"),
    "ai_mission_update": ("ماموریت را ویرایش کن", "مأموریت را تغییر بده", "update mission"),
    "ai_mission_toggle": ("ماموریت را فعال کن", "مأموریت را غیرفعال کن", "toggle mission"),
    "ai_mission_delete": ("ماموریت را حذف کن", "delete mission"),
    "ai_contest_start": ("مسابقه جدید شروع کن", "مسابقه بساز", "start contest"),
    "ai_contest_end": ("مسابقه را پایان بده", "مسابقه را تمام کن", "end contest"),
    "governance_request_retry": ("درخواست حاکمیتی را دوباره اجرا کن", "retry governance request"),
    "signal_team_rules_update": ("قوانین تیم سیگنال را تغییر بده", "محدودیت سیگنال روزانه را تنظیم کن", "update signal team rules"),
    "ai_signal_lab_strategy_create": ("استراتژی آزمایشگاه سیگنال بساز", "استراتژی شدو ایجاد کن", "create signal lab strategy"),
    "ai_signal_lab_scan_queue": ("اسکن آزمایشگاه سیگنال اجرا کن", "اسکن شدو را در صف بگذار", "queue signal lab scan"),
    "admin_ai_user_access_toggle": ("دسترسی جمنای کاربران را تغییر بده", "جمنای را برای همه کاربران فعال کن", "toggle user ai access"),
    "admin_ai_health_test": ("سلامت جمنای را تست کن", "تست اتصال جمنای اجرا کن", "test gemini health"),
    "admin_ai_daily_report": ("گزارش روزانه مدیر بساز", "daily manager report"),
    "admin_ai_execution_toggle": ("اجرای جمنای را فعال کن", "اجرای جمنای را متوقف کن", "toggle gemini execution"),
    "mission_control_refresh": ("مرکز ماموریت را تازه سازی کن", "شاخص های فوری را رفرش کن", "refresh mission control"),
    "action_inbox_refresh": ("صندوق اقدامات را تازه سازی کن", "موارد نیازمند تصمیم را نشان بده", "refresh action inbox"),
    "platform_dashboard_refresh": ("داشبورد پلتفرم را تازه سازی کن", "وضعیت سرویس و هزینه را نشان بده", "refresh platform dashboard"),
    "partner_create": ("همکار فروش ثبت کن", "پارتنر تبلیغاتی بساز", "create partner"),
    "partner_dashboard_refresh": ("داشبورد همکاران را تازه سازی کن", "عملکرد پارتنرها را نشان بده", "refresh partner dashboard"),
    "webhook_register": ("وب هوک ثبت کن", "endpoint رویدادها را اضافه کن", "register webhook"),
})

_WORD_RE = re.compile(r"[\w\u0600-\u06ff]+", re.UNICODE)


def normalize_command(value: Any) -> str:
    text = str(value or "").translate(_PERSIAN_DIGITS).casefold().replace("‌", " ")
    text = re.sub(r"[يى]", "ی", text)
    text = re.sub(r"ك", "ک", text)
    return " ".join(text.split())


def infer_admin_scope(command: str, *, default: str = "management") -> str:
    normalized = normalize_command(command)
    scores: dict[str, int] = {scope: 0 for scope in _SCOPE_TERMS}
    for scope, terms in _SCOPE_TERMS.items():
        for term in terms:
            token = normalize_command(term)
            if token and token in normalized:
                scores[scope] += 4 + min(5, len(token) // 4)
    # Explicit operational phrases resolve ambiguous generic words.
    if "قالب" in normalized:
        scores["signals"] += 15
    if any(term in normalized for term in ("کد تخفیف", "پرداخت", "رسید", "پلن", "اشتراک")):
        scores["crm"] += 15
    if any(term in normalized for term in ("مشتری", "سرنخ", "کاربران غیرفعال")):
        scores["crm"] += 12
    best, score = max(scores.items(), key=lambda item: item[1])
    return best if score > 0 else (default if default in _SCOPE_FAMILIES else "management")


def _terms(value: str) -> set[str]:
    return {item for item in _WORD_RE.findall(normalize_command(value)) if len(item) > 1}


def select_operational_tools(
    command: str,
    catalog: Iterable[dict[str, Any]],
    *,
    scope: str,
    limit: int = 18,
) -> list[dict[str, Any]]:
    normalized = normalize_command(command)
    command_terms = _terms(normalized)
    allowed_families = _SCOPE_FAMILIES.get(scope, _SCOPE_FAMILIES["management"])
    scored: list[tuple[int, str, dict[str, Any]]] = []
    for row in catalog:
        if not isinstance(row, dict):
            continue
        action = str(row.get("action") or "")
        if not action:
            continue
        family = action_family(action)
        score = 8 if family in allowed_families else 0
        if action.casefold() in normalized or action.replace("_", " ").casefold() in normalized:
            score += 120
        hints = _ACTION_HINTS.get(action, ())
        for hint in hints:
            if normalize_command(hint) in normalized:
                score += 40
        action_terms = set(action.replace("_", " ").split())
        description_terms = _terms(str(row.get("description") or ""))
        score += 3 * len(command_terms & action_terms)
        score += len(command_terms & description_terms)
        # Family-level relevance gives every registered module a path without
        # flooding Gemini with all ~80 deep schemas in a single request.
        family_terms = {
            "commerce": {"تخفیف", "پرداخت", "رسید", "سفارش", "پلن", "اشتراک", "vip"},
            "ticket": {"تیکت", "پشتیبانی"},
            "signal": {"سیگنال", "قالب", "تارگت", "استاپ"},
            "channel": {"کانال", "پست", "انتشار", "اعلان"},
            "crm": {"مشتری", "کمپین", "crm", "سرنخ"},
            "education": {"آموزش", "درس", "ماموریت", "مأموریت", "مسابقه"},
            "runtime": {"سیستم", "ماژول", "مینی", "تنظیمات", "ران"},
            "user": {"کاربر", "بن", "مسدود"},
            "admin": {"ادمین", "مدیر", "مجوز"},
            "idea": {"ایده", "پیشنهاد"},
            "report": {"گزارش", "بررسی", "سلامت"},
        }.get(family, set())
        score += 5 * len(command_terms & family_terms)
        scored.append((score, action, row))
    scored.sort(key=lambda item: (-item[0], item[1]))
    positive = [row for score, _action, row in scored if score > 0]
    if not positive:
        positive = [row for _score, _action, row in scored if action_family(str(row.get("action") or "")) in allowed_families]
    return positive[: max(1, min(int(limit or 18), 24))]


def _number_token(value: str) -> int | None:
    token = normalize_command(value).strip(" -_")
    if token.isdigit():
        return int(token)
    if token in _NUMBER_WORDS:
        return _NUMBER_WORDS[token]
    if " و " in token:
        total = 0
        for part in token.split(" و "):
            number = _NUMBER_WORDS.get(part)
            if number is None:
                return None
            total += number
        return total
    return None


def _extract_number_before(normalized: str, marker: str) -> int | None:
    match = re.search(rf"([\w\u0600-\u06ff]+)\s*{re.escape(marker)}", normalized)
    return _number_token(match.group(1)) if match else None


def _extract_id(normalized: str, *labels: str) -> int | None:
    for label in labels:
        match = re.search(rf"{re.escape(label)}\s*(?:شماره|#|آیدی|id)?\s*[:：]?\s*(\d+)", normalized)
        if match:
            return int(match.group(1))
    numbers = [int(item) for item in re.findall(r"\b\d+\b", normalized)]
    return numbers[0] if len(numbers) == 1 else None


@dataclass(frozen=True)
class LocalPlan:
    calls: list[dict[str, Any]]
    missing_fields: list[str]
    matched_action: str = ""


def deterministic_local_plan(command: str) -> LocalPlan:
    """High-confidence offline planner for critical common admin commands.

    It is a provider fallback, not a replacement for Gemini. Only commands with
    explicit operation family and enough values are emitted; ambiguous commands
    return the exact missing fields instead of choosing an unrelated tool.
    """
    normalized = normalize_command(command)
    calls: list[dict[str, Any]] = []

    if "تخفیف" in normalized and any(term in normalized for term in ("بساز", "ایجاد کن", "اضافه کن", "درست کن", "آماده کن", "بزن", "انجام بده")):
        code_match = re.search(r"(?:با\s+کد|کد\s*[:：])\s*([a-z0-9_-]{4,24})", normalized, re.I)
        if not code_match:
            candidates = re.findall(r"\b[a-z][a-z0-9_-]{3,23}\b", normalized, re.I)
            code = candidates[-1].upper() if candidates else ""
        else:
            code = code_match.group(1).upper()
        percent = _extract_number_before(normalized, "درصد")
        day_match = re.search(r"(?:مدت\s*)?([\w\u0600-\u06ff]+)\s*روز", normalized)
        days = _number_token(day_match.group(1)) if day_match else None
        missing = [name for name, value in (("code", code), ("percent", percent), ("days", days)) if value in (None, "")]
        if missing:
            return LocalPlan([], missing, "public_discount_create")
        max_uses = _extract_number_before(normalized, "بار") or 0
        return LocalPlan([{
            "action": "public_discount_create",
            "payload": {"code": code, "percent": percent, "days": days, "max_uses": max_uses, "one_per_user": True},
            "reason": "فرمان صریح ادمین برای ساخت کد تخفیف عمومی",
        }], [], "public_discount_create")

    if any(term in normalized for term in ("پرداخت", "رسید", "سفارش")):
        order_id = _extract_id(normalized, "سفارش", "پرداخت", "رسید")
        if any(term in normalized for term in ("تایید کن", "تأیید کن", "قبول کن")):
            return LocalPlan(
                [{"action": "payment_approve", "payload": {"order_id": order_id}, "reason": "تأیید صریح سفارش توسط ادمین"}] if order_id else [],
                [] if order_id else ["order_id"], "payment_approve",
            )
        if "رد کن" in normalized:
            reason_match = re.search(r"(?:به دلیل|دلیل)\s+(.+?)(?:\s+رد کن|$)", normalized)
            reason = (reason_match.group(1).strip() if reason_match else "رد توسط مدیر")
            missing = [] if order_id else ["order_id"]
            return LocalPlan(
                [{"action": "payment_reject", "payload": {"order_id": order_id, "reason": reason}, "reason": "رد صریح سفارش توسط ادمین"}] if not missing else [],
                missing, "payment_reject",
            )

    if "تیکت" in normalized:
        ticket_id = _extract_id(normalized, "تیکت")
        if "پاسخ" in normalized and any(term in normalized for term in ("بده", "ارسال کن", "ثبت کن")):
            text_match = re.search(r"(?:متن|پاسخ)\s*[:：]\s*(.+)$", normalized)
            text = text_match.group(1).strip() if text_match else ""
            missing = [name for name, value in (("ticket_id", ticket_id), ("text", text)) if not value]
            return LocalPlan(
                [{"action": "ticket_admin_reply", "payload": {"ticket_id": ticket_id, "text": text}, "reason": "پاسخ صریح به تیکت"}] if not missing else [],
                missing, "ticket_admin_reply",
            )
        status = None
        if "ببند" in normalized:
            status = "closed"
        elif "باز کن" in normalized or "دوباره باز" in normalized:
            status = "open"
        if status:
            return LocalPlan(
                [{"action": "ticket_admin_status_update", "payload": {"ticket_id": ticket_id, "status": status}, "reason": "تغییر صریح وضعیت تیکت"}] if ticket_id else [],
                [] if ticket_id else ["ticket_id"], "ticket_admin_status_update",
            )

    if "قالب" in normalized and "سیگنال" in normalized:
        side = "BUY" if any(term in normalized for term in ("buy", "خرید")) else "SELL" if any(term in normalized for term in ("sell", "فروش")) else ""
        if any(term in normalized for term in ("ریست", "بازنشانی", "پیش فرض", "پیش‌فرض")):
            return LocalPlan(
                [{"action": "ai_signal_template_reset", "payload": {"side": side, "background": True, "layout": True}, "reason": "بازنشانی صریح قالب سیگنال"}] if side else [],
                [] if side else ["side"], "ai_signal_template_reset",
            )
        if any(term in normalized for term in ("عکس", "فایل", "asset", "پس زمینه", "پس‌زمینه")):
            asset_match = re.search(r"(?:asset|فایل|عکس)\s*(?:شماره|#|id)?\s*[:：]?\s*(\d+|latest|آخرین)", normalized)
            asset_id: Any = "latest" if "آخرین" in normalized else (asset_match.group(1) if asset_match else "")
            missing = [name for name, value in (("side", side), ("asset_id", asset_id)) if not value]
            return LocalPlan(
                [{"action": "ai_signal_template_apply_asset", "payload": {"side": side, "asset_id": asset_id, "autodetect": True}, "reason": "اعمال فایل صریح روی قالب سیگنال"}] if not missing else [],
                missing, "ai_signal_template_apply_asset",
            )

    if "کاربر" in normalized:
        user_id = _extract_id(normalized, "کاربر")
        if any(term in normalized for term in ("رفع بن", "آزاد کن", "unban")):
            return LocalPlan(
                [{"action": "admin_user_unban", "payload": {"user_id": user_id}, "reason": "رفع مسدودی صریح کاربر"}] if user_id else [],
                [] if user_id else ["user_id"], "admin_user_unban",
            )
        if any(term in normalized for term in ("بن کن", "مسدود کن", "ban")):
            days = _extract_number_before(normalized, "روز") or 0
            reason_match = re.search(r"(?:به دلیل|دلیل)\s+(.+?)(?:\s+(?:بن|مسدود)\s*کن|$)", normalized)
            reason = reason_match.group(1).strip() if reason_match else "دستور مدیر"
            return LocalPlan(
                [{"action": "admin_user_ban", "payload": {"user_id": user_id, "days": days, "reason": reason}, "reason": "مسدودی صریح کاربر"}] if user_id else [],
                [] if user_id else ["user_id"], "admin_user_ban",
            )

    if "مینی اپ" in normalized or "مینی‌اپ" in normalized or "miniapp" in normalized:
        if any(term in normalized for term in ("فعال کن", "روشن کن", "غیرفعال کن", "خاموش کن")):
            enabled = not any(term in normalized for term in ("غیرفعال", "خاموش"))
            return LocalPlan([{
                "action": "miniapp_runtime_toggle",
                "payload": {"enabled": enabled, "reason": "فرمان مستقیم ادمین اصلی"},
                "reason": "تغییر صریح وضعیت مینی‌اپ",
            }], [], "miniapp_runtime_toggle")

    if "ایده" in normalized and any(term in normalized for term in ("ثبت کن", "بساز", "ایجاد کن", "اضافه کن", "درست کن", "آماده کن", "انجام بده")):
        description = re.sub(r"^(?:یک\s+)?ایده(?:\s+جدید)?\s*(?:با عنوان)?", "", normalized).strip()
        if description:
            title = description[:100]
            return LocalPlan([{
                "action": "ai_idea_create",
                "payload": {"title": title, "description": description, "category": "product", "priority": 3, "status": "backlog"},
                "reason": "ثبت صریح ایده در Backlog ادمین",
            }], [], "ai_idea_create")
        return LocalPlan([], ["title", "description"], "ai_idea_create")

    return LocalPlan([], [], "")


# R28 executive-admin aliases are intentionally explicit so every new registered
# action remains selectable from a small Gemini FunctionDeclaration set.
_ACTION_HINTS.update({
    "admin_command_center_snapshot": ("مرکز فرماندهی را نشان بده", "کارهای فوری امروز", "show command center"),
    "admin_global_search": ("در کل سنتینل جستجو کن", "پیدا کن", "global search"),
    "automation_v2_rule_list": ("قوانین اتوماسیون را نشان بده", "list automation rules"),
    "automation_v2_rule_create": ("اتوماسیون جدید بساز", "create automation rule"),
    "automation_v2_rule_update": ("قانون اتوماسیون را ویرایش کن", "update automation rule"),
    "automation_v2_rule_test": ("اتوماسیون را آزمایشی اجرا کن", "test automation rule"),
    "ai_ad_campaign_create": ("تبلیغ هوشمند بساز", "create gemini advertisement"),
    "ai_ad_image_generate": ("تصویر تبلیغ تولید کن", "generate advertisement image"),
    "ai_ad_summary": ("خلاصه تبلیغ را نشان بده", "advertisement summary"),
    "ai_ad_approve": ("تبلیغ را تایید کن", "approve advertisement"),
    "ai_ad_schedule": ("تبلیغ را زمان بندی کن", "schedule advertisement"),
})
