function openModal(eyebrow, title, body, actions = []) { state.modalGeneration=(state.modalGeneration||0)+1; saveVisibleDrafts(); trapModal(false); state.modalDraftContext = `${eyebrow}:${title}`; state.modalReturn = document.activeElement; $('#modalEyebrow').textContent = translateUiText(eyebrow); $('#modalTitle').textContent = translateUiText(title); $('#modalBody').innerHTML = body; restoreFormDrafts(); setModalFooter(actions); localizeUiTree($('#modal')); $('#modalLayer').hidden = false; document.body.style.overflow = 'hidden'; $('#main')?.setAttribute('inert', ''); $('#modal').focus(); installTelegramNavigation(); syncTelegramNavigation(); trapModal(true); }
function setModalFooter(actions = []) { const foot = $('#modalFooter'); foot.innerHTML = actions.map((a, i) => `<button class="button ${a.kind === 'secondary' ? 'secondary' : a.kind === 'danger' ? 'danger' : ''}" data-modal-action="${i}">${esc(a.label)}</button>`).join(''); foot.hidden = !actions.length; state.modalActions = actions; if (state.mainButtonHandler)
    tg?.MainButton?.offClick?.(state.mainButtonHandler); state.mainButtonHandler = null; const primaryIndex = actions.findIndex(a => a.kind === 'primary'); if (primaryIndex >= 0 && tg?.MainButton) {
    state.mainButtonHandler = () => actions[primaryIndex]?.action?.();
    tg.MainButton.setParams?.({ text: String(actions[primaryIndex].label || t('submit')), is_visible: true, is_active: true });
    tg.MainButton.onClick?.(state.mainButtonHandler);
}
else
    tg?.MainButton?.hide?.(); }
function closeModal() { state.modalGeneration=(state.modalGeneration||0)+1; if ($('#modalLayer').hidden)
    return; saveVisibleDrafts(); $('#modalLayer').hidden = true; document.body.style.overflow = ''; $('#main')?.removeAttribute('inert'); if (state.mainButtonHandler)
    tg?.MainButton?.offClick?.(state.mainButtonHandler); state.mainButtonHandler = null; setModalFooter([]); tg?.MainButton?.hide?.(); syncTelegramNavigation(); trapModal(false); state.modalReturn?.focus?.(); state.modalReturn = null; }
function trapModal(active) { if (active) {
    state.trapHandler = e => { if (e.key === 'Escape') {
        closeModal();
        return;
    } if (e.key !== 'Tab')
        return; const focusable = $$('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])', $('#modal')); if (!focusable.length)
        return; const first = focusable[0], last = focusable.at(-1); if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
    }
    else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
    } };
    document.addEventListener('keydown', state.trapHandler);
}
else if (state.trapHandler) {
    document.removeEventListener('keydown', state.trapHandler);
    state.trapHandler = null;
} }
function errorPanel(err, key) { return `<div class="panel"><div class="empty">${icon('alert')}<h2>${esc(t('error'))}</h2><p>${esc(err.message)}</p><button class="button" data-retry="${key}">${esc(t('retry'))}</button></div></div>`; }
function invalidate(...keys) { state.resourceEpochs ??= new Map(); keys.forEach(k => { state.loaded.delete(k); state.resourceEpochs.set(k,(state.resourceEpochs.get(k)||0)+1); }); }
async function navigate(page, scroll = true) { if (!['home','signals','risk','journal','more','trading','rewards'].includes(page)) page='home'; if(scroll && page!==state.page) {state.pageHistory.push(state.page);if(state.pageHistory.length>20)state.pageHistory.shift();} if(page==='home')state.pageHistory=[]; state.page = page; syncTelegramNavigation(); try { const routeNav=$('#pageNavigation');if(routeNav)routeNav.hidden=page==='home'; $$('.page').forEach(el => el.classList.toggle('active', el.dataset.page === page)); $$('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.pageTarget === page)); if (scroll)
    window.scrollTo({ top: 0, behavior: 'smooth' }); if (page === 'home')
    renderHome(); if (page === 'signals')
    await renderSignals(); if (page === 'risk')
    await renderRisk(); if (page === 'journal')
    await renderJournal(); if (page === 'more')
    await renderMore(); if (page === 'trading') renderTradingWorkspace(); if (page === 'rewards') await renderRewardsWorkspace(); if (state.lang === 'en') localizeUiTree(document); } finally { syncTelegramNavigation(); } }
function applyLanguage() { document.documentElement.lang = state.lang; document.documentElement.dir = state.lang === 'fa' ? 'rtl' : 'ltr'; document.title = state.lang === 'fa' ? 'SENTINEL | سیستم مدیریت معامله' : 'SENTINEL | Trading Risk OS'; const description = document.querySelector('meta[name="description"]'); if (description) description.content = state.lang === 'fa' ? 'SENTINEL — سیستم‌عامل مستقل مدیریت سیگنال، ریسک، ژورنال و شفافیت عملکرد' : 'SENTINEL — independent signal, risk, journal and verified-performance operating system'; renderChrome(); localizeUiTree(document); ensureUiLocalizationObserver(); }
async function toggleLanguage() { const previous = state.lang; state.lang = state.lang === 'fa' ? 'en' : 'fa'; localStorage.setItem('sentinelLanguage', state.lang); if (state.resources.overview?.user) state.resources.overview.user.language = state.lang; closeModal(); applyLanguage(); await navigate(state.page, false); localizeUiTree(document); if (!state.preview) { try { await action('language_update', { language: state.lang }, false); } catch (err) { state.lang = previous; localStorage.setItem('sentinelLanguage', previous); applyLanguage(); await navigate(state.page, false); toast(translateUiText(err.message || t('error')), 'error'); } } }
function copySignal(id) { const all = [...(state.resources.signals?.items || []), ...(state.resources.overview?.recent_signals || [])], s = all.find(x => Number(x.id) === Number(id)) || state.resources[`signal:${id}`]; if (!s)
    return; const text = [`${s.symbol} ${String(s.side).toUpperCase()}`, `Entry: ${s.entry}`, ...(s.targets || []).map((x, i) => `TP${i + 1}: ${x}`), `SL: ${s.stop}`, `Risk: ${s.risk}%`].join('\n'); navigator.clipboard.writeText(text).then(() => toast(t('copyDone'))); }
function exportJournal() { const rows = state.resources.journal?.items || [], fields = ['id', 'signal_id', 'source', 'entry_reason_type', 'entry_reason', 'symbol', 'side', 'entry_price', 'actual_stop', 'exit_price', 'volume', 'result_r', 'pnl_percent', 'pnl_amount', 'fees', 'commission', 'swap', 'status', 'note', 'created_at', 'closed_at']; const csv = [fields.join(','), ...rows.map(r => fields.map(k => `"${String(r[k] ?? '').replaceAll('"', '""')}"`).join(','))].join('\n'); const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'sentinel-journal.csv'; a.click(); URL.revokeObjectURL(a.href); }
async function downloadJournalPdf() { setBusy(true); try {
    const response = await fetch(`./api/v1/journal/export.pdf?lang=${encodeURIComponent(state.lang)}`, { credentials: 'include', headers: { 'Accept': 'application/pdf' } });
    if (!response.ok) {
        let message = 'PDF_EXPORT_FAILED';
        try {
            const body = await response.json();
            message = body?.error?.message || body?.detail || message;
        }
        catch { }
        throw new Error(message);
    }
    const blob = await response.blob();
    if (!blob.size)
        throw new Error('PDF_EXPORT_EMPTY');
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url;
    a.download = `sentinel-journal-${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    toast(state.lang === 'fa' ? 'گزارش PDF ژورنال آماده شد.' : 'Journal PDF downloaded.');
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function importJournal() { openModal('JOURNAL', t('importCsv'), `<div class="field"><label for="journalCsvFile">${esc(t('file'))}</label><input id="journalCsvFile" type="file" accept=".csv,text/csv" required></div>`, [{ label: t('importCsv'), kind: 'primary', action: async () => { const file = $('#journalCsvFile').files?.[0]; if (!file)
            return; setBusy(true); try {
            const content = await file.text();
            const result = await action('journal_import_csv', { content }, false);
            toast(`${t('success')}: ${num(result.imported, 0)}`);
            closeModal();
            invalidate('journal');
            await loadResource('journal', true);
            renderJournal();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function importBroker() { const accounts = state.resources.overview?.risk?.accounts || []; openModal('BROKER IMPORT', t('brokerImport'), `<form id="brokerImportForm"><div class="form-grid"><div class="field"><label for="brokerName">Broker / Platform</label><select id="brokerName"><option>MT5</option><option>MT4</option><option>cTrader</option><option>Generic CSV</option></select></div><div class="field"><label for="brokerAccount">${esc(t('account'))}</label><select id="brokerAccount">${accounts.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select></div></div><div class="field"><label for="brokerFile">${esc(t('file'))}</label><input id="brokerFile" type="file" accept=".csv,.html,.htm,text/csv,text/html" required aria-describedby="brokerHint"><small id="brokerHint" class="field-help">${state.lang === 'fa' ? 'گزارش معاملات MT4/MT5 یا CSV بروکر؛ رکورد تکراری با Ticket دوباره وارد نمی‌شود.' : 'MT4/MT5 statement or broker CSV; duplicate ticket IDs are skipped.'}</small></div></form>`, [{ label: t('brokerImport'), kind: 'primary', action: async () => { const f = $('#brokerImportForm'), file = $('#brokerFile').files?.[0]; if (!f.reportValidity() || !file)
            return; setBusy(true); try {
            const result = await action('broker_import', { content: await file.text(), filename: file.name, broker: $('#brokerName').value, account_id: $('#brokerAccount').value }, false);
            toast(`${t('success')}: ${num(result.imported, 0)} / ${num(result.parsed, 0)}`);
            closeModal();
            invalidate('journal');
            await loadResource('journal', true);
            renderJournal();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function adminWorkspace() {
    setBusy(true);
    try {
        const overview = state.resources.overview || await loadOverview(), admin = overview.admin || {}, perms = new Set(admin.permissions || []), owner = admin.role === 'owner', can = p => owner || perms.has(p), canAny = (...names) => owner || names.some(name => perms.has(name)),
            canPayment = canAny('payments','payment_dashboard_view','payment_transactions_view','payment_receipts_view','payment_receipt_approve','payment_receipt_reject','payment_manual_review'),
            canAi = can('ai_command_center'),
            canVipPlan = canAny('vip_settings','vip_plan_view','vip_plan_create','vip_plan_edit','vip_plan_activate','vip_plan_archive','vip_plan_delete'),
            canTickets = canAny('tickets','tickets_view','tickets_reply','tickets_assign','tickets_status_manage','tickets_priority_manage','ticket_attachments_view','ticket_internal_notes'),
            canTicketReply = canAny('tickets','tickets_reply'),
            canSignals = canAny('signals','signals_view','signal_edit','signal_results','signal_status_manage','signal_metrics_edit','signal_delete','signal_schedule','signal_board_manage','signal_publish_now'),
            canSignalQueue = canAny('signals','signal_schedule'),
            canSignalCycles = canAny('signals','signal_board_manage'),
            canUsers = canAny('users','users_view','user_ban_manage','user_vip_assign','user_sensitive_data_view'),
            canIntegrationView = canAny('system_control','integration_health_view'),
            canIntegrationManage = can('system_control'),
            canRuntime = canAny('runtime_safety','maintenance_mode_manage'),
            canSystemHealth = canAny('system_control','system_health_view','integration_health_view'),
            canAudit = canAny('audit_logs','system_health_view'),
            safe = async (key, allowed = true) => { if (!allowed)
            return null; try {
            return await loadResource(key, true);
        }
        catch (err) {
            state.adminLoadErrors = state.adminLoadErrors || {};
            state.adminLoadErrors[key] = err.message;
            return null;
        } };
        const [ops, experiments, orders, tickets, templates, integration, signalJobs, signalCycles, capabilities, aiCenter, vipPlans] = await Promise.all([
            safe('adminOps', true), safe('adminExperiments', can('campaigns')), safe('adminOrders', canPayment), safe('adminTickets', canTickets), safe('adminTemplates', can('signal_templates')), safe('adminIntegration', canIntegrationView), safe('adminSignalJobs', canSignalQueue), safe('adminSignalCycles', canSignalCycles), safe('adminCapabilities', true), safe('adminAI', canAi), safe('adminVipPlans', canVipPlan)
        ]);
        const brief = ops?.brief || {}, counts = brief.counts || {}, health = ops?.system_health || {}, intel = ops?.operations_intelligence || {}, runtime = overview.miniapp_runtime || { enabled: true }, orderRows = orders?.items || [], ticketRows = tickets?.items || [], signalRows = signalJobs?.items || [], cycleRows = signalCycles?.items || [], currentCycle = signalCycles?.current || cycleRows[0] || {}, handoffs = ops?.handoffs || [], experimentRows = experiments?.experiments || [];
        const fa = state.lang === 'fa', role = owner ? (fa ? 'مالک' : 'Owner') : (admin.role || 'admin'), pendingOrders = orderRows.filter(x => ['pending','approving'].includes(String(x.status))).length, waitingTickets = ticketRows.filter(x => x.status !== 'closed' && x.waiting_for === 'admin').length;
        const summary = `<section class="panel"><div class="panel-head"><div><small class="eyebrow">SENTINEL ADMIN</small><h3>${fa ? 'مرکز مدیریت ساده و عملیاتی' : 'Simple operations center'}</h3></div><span class="status-badge good">${esc(role)}</span></div><div class="panel-body"><div class="metric-grid">${metric(fa ? 'پرداخت منتظر' : 'Pending payments', num(pendingOrders, 0), '', 'warn')}${metric(fa ? 'تیکت نیازمند پاسخ' : 'Tickets waiting', num(waitingTickets, 0), '', 'warn')}${metric(fa ? 'سیگنال در صف' : 'Signal jobs', num(signalRows.length, 0), '', 'info')}${metric(fa ? 'دسترسی فعال' : 'Permissions', owner ? 'ALL' : num(perms.size, 0), '', 'good')}</div><p class="field-help">${fa ? 'کارهای روزمره در همین صفحه قرار دارند. تمام دسترسی‌های تخصصی بدون حذف، داخل «همه ابزارهای ادمین» باقی مانده‌اند.' : 'Daily actions stay on this page. Every advanced permission remains available in “All admin tools”.'}</p><div class="card-actions"><button class="button primary wide" data-admin-command-center>${fa ? 'همه ابزارهای ادمین' : 'All admin tools'}</button>${canPayment ? `<button class="button primary" data-admin-payments>${fa ? 'مدیریت رسیدها و پرداخت‌ها' : 'Receipts & payments'}</button>` : ''}${canSignals ? `<button class="button secondary" data-admin-signals>${fa ? 'مدیریت سیگنال‌ها' : 'Manage signals'}</button>` : ''}${canSignalQueue ? `<button class="button secondary" data-open="admin-signal-jobs">${fa ? 'صف ارسال سیگنال' : 'Signal delivery queue'}</button>` : ''}${canUsers ? `<button class="button secondary" data-admin-users>${fa ? 'کنترل کاربران' : 'User control'}</button>` : ''}${can('admin_management') ? `<button class="button secondary" data-admin-admins>${fa ? 'مدیریت ادمین‌ها' : 'Admin access'}</button>` : ''}${canAi ? `<button class="button secondary" data-admin-ai-center>${fa ? 'مرکز هوش مصنوعی' : 'AI Command Center'}</button>` : ''}${canVipPlan ? `<button class="button secondary" data-admin-vip-plans>${fa ? 'پلن‌ها و تنظیمات پرداخت VIP' : 'VIP plans & payment settings'}</button>` : ''}${canAudit ? `<button class="button secondary" data-admin-audit>${fa ? 'گزارش ممیزی' : 'Audit log'}</button>` : ''}</div></div></section>`;
        const runtimeSection = canRuntime ? `<section class="panel compact-panel"><div class="panel-head"><div><small class="eyebrow">MINI APP</small><h3>${fa ? 'دسترسی کاربران' : 'User availability'}</h3></div><span class="status-badge ${runtime.enabled !== false ? 'good' : 'bad'}">${runtime.enabled !== false ? 'ON' : 'OFF'}</span></div><div class="panel-body"><p>${runtime.enabled !== false ? (fa ? 'مینی‌اپ برای کاربران روشن است.' : 'Mini App is available to users.') : (fa ? 'مینی‌اپ برای کاربران خاموش است؛ دسترسی ادمین حفظ شده.' : 'Mini App is hidden from users; admin access remains.')}</p><button class="button ${runtime.enabled !== false ? 'danger' : 'primary'}" data-miniapp-toggle="${runtime.enabled !== false ? 'off' : 'on'}">${runtime.enabled !== false ? (fa ? 'خاموش‌کردن' : 'Disable') : (fa ? 'روشن‌کردن' : 'Enable')}</button></div></section>` : '';
        const integrationSection = canIntegrationView ? `<section class="panel compact-panel"><div class="panel-head"><div><small class="eyebrow">BOT ↔ MINI APP</small><h3>${fa ? 'همگام‌سازی اطلاعات' : 'Data synchronization'}</h3></div><span class="status-badge ${integration?.status === 'connected' ? 'good' : 'warn'}">${integration?.status === 'connected' ? 'CONNECTED' : 'CHECK'}</span></div><div class="panel-body"><p class="field-help">${fa ? 'سیگنال، اشتراک، واچ‌لیست و دسترسی‌ها بین ربات و مینی‌اپ تطبیق داده می‌شوند.' : 'Signals, subscriptions, watchlists and permissions are reconciled across both clients.'}</p>${canIntegrationManage ? `<button class="button primary" data-integration-reconcile>${icon('refresh')}${fa ? 'تطبیق دوباره' : 'Reconcile now'}</button>` : `<div class="notice info"><strong>${fa ? 'دسترسی فقط‌خواندنی' : 'Read-only access'}</strong><p>${fa ? 'وضعیت اتصال قابل مشاهده است؛ اجرای تطبیق نیازمند کنترل کامل سیستم است.' : 'Integration health is visible; reconciliation requires full system control.'}</p></div>`}</div></section>` : '';
        const cycleStats = currentCycle?.stats || {};
        const cycleSection = canSignalCycles ? `<section class="panel"><div class="panel-head"><div><small class="eyebrow">SIGNAL PERIODS</small><h3>${fa ? 'دوره‌های نام‌دار سیگنال' : 'Named signal periods'}</h3></div><span class="status-badge ${currentCycle?.status === 'closed' ? 'warn' : 'good'}">${currentCycle?.status === 'closed' ? (fa ? 'بسته' : 'CLOSED') : (fa ? 'فعال' : 'ACTIVE')}</span></div><div class="panel-body"><div class="row-between"><div><strong>#${num(currentCycle?.id || 1, 0)} · ${esc(currentCycle?.name || (fa ? 'دوره فعلی' : 'Current period'))}</strong><p class="field-help">${fa ? 'با بستن دوره، تاریخچه و سیگنال‌ها حذف نمی‌شوند.' : 'Closing preserves every signal and report.'}</p></div></div><div class="metric-grid">${metric(fa ? 'کل سیگنال' : 'Signals', num(cycleStats.total || 0, 0), '', 'info')}${metric(fa ? 'برد' : 'Wins', num(cycleStats.wins || 0, 0), '', 'good')}${metric(fa ? 'باخت' : 'Losses', num(cycleStats.losses || 0, 0), '', 'warn')}${metric(fa ? 'نرخ برد' : 'Win rate', `${num(cycleStats.win_rate || 0, 1)}%`, '', 'info')}</div><div class="card-actions"><button class="button primary" data-admin-signal-cycles>${fa ? 'آرشیو و گزارش دوره‌ها' : 'Period archive & reports'}</button>${currentCycle?.status === 'closed' ? `<button class="button" data-signal-cycle-name="start">${fa ? 'شروع دوره جدید' : 'Start new period'}</button>` : `<button class="button" data-signal-cycle-name="rollover">${fa ? 'بستن و شروع دوره جدید' : 'Close & start new'}</button><button class="button danger" data-signal-cycle-close>${fa ? 'فقط بستن دوره' : 'Close only'}</button>`}</div></div></section>` : '';
        const ordersSection = canPayment ? `<section class="panel"><div class="panel-head"><div><h3>${fa ? 'رسیدهای منتظر بررسی' : 'Receipts awaiting review'}</h3><small>${fa ? 'همگام با ربات و خرید Mini App' : 'Synced with Bot and Mini App checkout'}</small></div><span class="status-badge warn">${num(pendingOrders, 0)}</span></div><div class="panel-body journal-list">${orderRows.filter(x => ['pending','approving'].includes(String(x.status))).slice(0, 8).map(x => `<article class="journal-card"><div class="row-between"><strong>${esc(x.plan_name || x.plan_id || x.id)}</strong><span class="status-badge ${x.status === 'approving' ? 'info' : 'warn'}">${esc(x.status)}</span></div><p>${fa ? 'کاربر' : 'User'} ${esc(x.user_id)} · ${money(x.amount_toman || 0, 'T')}</p><div class="row-between"><small>${x.receipt_attached ? (fa ? '✅ رسید پیوست شده' : '✅ Receipt attached') : (fa ? '⚠️ بدون رسید' : '⚠️ No receipt')}</small><small>${date(x.updated_at || x.created_at)}</small></div><div class="card-actions"><button class="button primary small" data-admin-order="${esc(x.id)}">${fa ? 'مشاهده و بررسی' : 'Open & review'}</button></div></article>`).join('') || empty()}<div class="card-actions"><button class="button secondary wide" data-admin-payments>${fa ? 'مشاهده همه پرداخت‌ها' : 'View all payments'}</button></div></div></section>` : '';
        const ticketsSection = canTickets ? `<section class="panel"><div class="panel-head"><h3>${fa ? 'تیکت‌های نیازمند پاسخ' : 'Tickets needing reply'}</h3><span class="status-badge warn">${num(waitingTickets, 0)}</span></div><div class="panel-body journal-list">${ticketRows.filter(x => x.status !== 'closed' && x.waiting_for === 'admin').slice(0, 6).map(x => `<article class="journal-card"><div class="row-between"><strong>#${num(x.id, 0)} · ${esc(x.subject || 'Support')}</strong><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${fa ? 'کاربر' : 'User'} ${esc(x.user_id)} · ${esc(x.priority || 'normal')}</p><div class="card-actions"><button class="button primary small" data-admin-ticket="${x.id}">${canTicketReply ? (fa ? 'بازکردن و پاسخ' : 'Open & reply') : (fa ? 'مشاهده تیکت' : 'View ticket')}</button></div></article>`).join('') || empty()}</div></section>` : '';
        const advanced = `<details class="details-block"><summary>${fa ? 'ابزارها و جزئیات پیشرفته' : 'Advanced tools and details'}</summary><div class="admin-workspace">${canSystemHealth ? `<section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'سلامت سیستم' : 'System health'}</h3><span class="status-badge ${health.database?.persistent ? 'good' : 'warn'}">${esc(health.release || APP_VERSION)}</span></div><div class="panel-body"><div class="health-grid"><div class="health-card"><strong>Database</strong><span class="status-badge ${health.database?.persistent ? 'good' : 'bad'}">${health.database?.persistent ? 'Persistent' : 'Check'}</span><small>${esc(health.database?.reason || '')}</small></div><div class="health-card"><strong>Receipts</strong><span class="status-badge ${health.receipt_storage?.persistent && health.receipt_storage?.healthy ? 'good' : 'bad'}">${esc(health.receipt_storage?.backend || 'unknown')}</span><small>${esc(health.receipt_storage?.detail || '')}</small></div><div class="health-card"><strong>Memory</strong><span class="status-badge ${intel.memory?.state === 'healthy' ? 'good' : intel.memory?.state === 'critical' ? 'bad' : 'warn'}">${intel.memory?.percent == null ? 'unknown' : `${num(intel.memory.percent, 1)}%`}</span><small>${num(intel.memory?.rss_mb || 0, 1)} MB</small></div><div class="health-card"><strong>Self-healing</strong><span class="status-badge ${intel.self_healing?.enabled ? 'good' : 'warn'}">${intel.self_healing?.enabled ? 'ON' : 'OFF'}</span><small>${esc(intel.self_healing?.last_status || 'never')}</small></div></div></div></section>` : ''}${can('signal_templates') ? `<section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'قالب سیگنال' : 'Signal templates'}</h3></div><div class="panel-body">${['buy', 'sell'].map(side => { const row = templates?.[side]?.background || {}; return `<div class="account-card"><div class="row-between"><strong>${side.toUpperCase()}</strong><span class="status-badge ${row.custom ? 'good' : 'info'}">${row.custom ? 'CUSTOM' : 'DEFAULT'}</span></div><div class="field"><input id="adminTemplate${side}" type="file" accept="image/jpeg,image/png,image/webp"></div><div class="card-actions"><button class="button small" data-template-upload="${side}">${fa ? 'بارگذاری' : 'Upload'}</button>${row.custom ? `<button class="button danger small" data-template-reset="${side}">${fa ? 'قالب اصلی' : 'Default'}</button>` : ''}</div></div>`; }).join('')}</div></section>` : ''}${handoffs.length ? `<section class="panel compact-panel"><div class="panel-head"><h3>${esc(t('shiftHandoff'))}</h3><button class="button small" data-admin-handoff-new>${icon('plus')}${esc(t('newHandoff'))}</button></div><div class="panel-body journal-list">${handoffs.slice(0, 5).map(x => `<article class="journal-card"><strong>#${num(x.id, 0)} · ${esc(x.from_admin_id)} → ${esc(x.to_admin_id)}</strong><p>${esc(x.summary)}</p></article>`).join('')}</div></section>` : ''}${can('campaigns') ? `<section class="panel compact-panel"><div class="panel-head"><h3>${esc(t('experimentLab'))}</h3><button class="button small" data-experiment-new>${icon('plus')}${esc(t('newExperiment'))}</button></div><div class="panel-body journal-list">${experimentRows.slice(0, 5).map(x => `<article class="journal-card"><strong>${esc(x.name)}</strong><p>${esc(x.primary_metric || '')}</p></article>`).join('') || empty()}</div></section>` : ''}</div></details>`;
        openModal('ADMIN', t('adminConsole'), `<div class="admin-workspace">${summary}<div class="form-grid">${runtimeSection}${integrationSection}</div>${cycleSection}${ordersSection}${ticketsSection}${advanced}</div>`, []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function signalCycleStatusLabel(status) { const closed = String(status || 'active') === 'closed'; return state.lang === 'fa' ? (closed ? 'بسته' : 'فعال') : (closed ? 'Closed' : 'Active'); }
function signalCycleCard(row) { const stats = row?.stats || {}, closed = String(row?.status || 'active') === 'closed'; return `<article class="journal-card"><div class="row-between"><div><strong>#${num(row?.id || 0, 0)} · ${esc(row?.name || '—')}</strong><p>${esc(signalCycleStatusLabel(row?.status))} · ${num(stats.total || row?.signal_count || 0, 0)} ${state.lang === 'fa' ? 'سیگنال' : 'signals'}</p></div><span class="status-badge ${closed ? 'info' : 'good'}">${esc(signalCycleStatusLabel(row?.status))}</span></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'برد' : 'Wins', num(stats.wins || 0, 0), '', 'good')}${metric(state.lang === 'fa' ? 'باخت' : 'Losses', num(stats.losses || 0, 0), '', 'warn')}${metric(state.lang === 'fa' ? 'نرخ برد' : 'Win rate', `${num(stats.win_rate || 0, 1)}%`, '', 'info')}${metric(state.lang === 'fa' ? 'سود/زیان' : 'P/L', `${Number(stats.profit_percent_sum || 0) >= 0 ? '+' : ''}${num(stats.profit_percent_sum || 0, 2)}%`, '', Number(stats.profit_percent_sum || 0) >= 0 ? 'good' : 'warn')}</div><div class="card-actions"><button class="button primary small" data-signal-cycle-detail="${esc(row?.id)}">${state.lang === 'fa' ? 'مشاهده سیگنال‌ها' : 'View signals'}</button><button class="button small" data-signal-cycle-pdf="${esc(row?.id)}">PDF</button><button class="button secondary small" data-signal-cycle-rename="${esc(row?.id)}">${state.lang === 'fa' ? 'تغییر نام' : 'Rename'}</button></div></article>`; }
async function adminSignalCyclesModal() { setBusy(true); try {
    const d = await loadResource('adminSignalCycles', true), rows = d?.items || [], current = d?.current || rows[0] || {}, closed = String(current?.status || 'active') === 'closed';
    state.resources.adminSignalCycles = d;
    openModal('SIGNAL PERIODS', state.lang === 'fa' ? 'دوره‌های سیگنال و گزارش عملکرد' : 'Signal periods and performance', `<div class="notice info"><strong>${state.lang === 'fa' ? 'تاریخچه دائمی دوره‌ها' : 'Permanent period history'}</strong><p>${state.lang === 'fa' ? 'بستن دوره فقط آن را آرشیو می‌کند؛ سیگنال‌ها، نتایج و PDF آن باقی می‌مانند.' : 'Closing archives the period; signals, results and PDF remain available.'}</p></div><div class="card-actions"><button class="button primary" data-signal-cycle-name="${closed ? 'start' : 'rollover'}">${closed ? (state.lang === 'fa' ? 'شروع دوره جدید' : 'Start new period') : (state.lang === 'fa' ? 'بستن و شروع دوره جدید' : 'Close & start new')}</button>${!closed ? `<button class="button danger" data-signal-cycle-close>${state.lang === 'fa' ? 'فقط بستن دوره فعلی' : 'Close current only'}</button>` : ''}</div><div class="journal-list">${rows.map(signalCycleCard).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
function signalCycleNameModal(mode = 'rollover', cycleId = '') { const d = state.resources.adminSignalCycles || {}, current = d.current || {}, rename = mode === 'rename', start = mode === 'start', title = rename ? (state.lang === 'fa' ? 'تغییر نام دوره' : 'Rename period') : (start ? (state.lang === 'fa' ? 'شروع دوره جدید' : 'Start new period') : (state.lang === 'fa' ? 'بستن دوره فعلی و شروع دوره جدید' : 'Close current and start new')); const existing = rename ? (d.items || []).find(x => String(x.id) === String(cycleId))?.name || '' : ''; openModal('SIGNAL PERIOD', title, `<form id="signalCycleNameForm"><div class="notice ${mode === 'rollover' ? 'warning' : 'info'}"><p>${mode === 'rollover' ? (state.lang === 'fa' ? 'دوره فعلی بدون حذف تاریخچه بسته می‌شود و دوره جدید با شماره‌گذاری #1 آغاز خواهد شد.' : 'Current period will be preserved and a new #1 sequence starts.') : (rename ? (state.lang === 'fa' ? 'فقط نام دوره تغییر می‌کند و سیگنال‌ها دست‌نخورده می‌مانند.' : 'Only the name changes; signals remain untouched.') : (state.lang === 'fa' ? 'نام دوره جدید را مشخص کنید.' : 'Choose a name for the new period.'))}</p></div><div class="field"><label for="signalCycleName">${state.lang === 'fa' ? 'نام دوره' : 'Period name'}</label><input id="signalCycleName" required minlength="2" maxlength="120" value="${esc(existing)}" placeholder="${state.lang === 'fa' ? 'کمپین تبدیل ۱۰۰ به ۱۰۰۰' : '100 to 1000 campaign'}"></div></form>`, [{ label: rename ? (state.lang === 'fa' ? 'ذخیره نام' : 'Save name') : (state.lang === 'fa' ? 'ثبت و اجرا' : 'Confirm'), kind: 'primary', action: async () => { const form = $('#signalCycleNameForm'), name = $('#signalCycleName')?.value.trim(); if (!form?.reportValidity() || !name)
            return; if (mode === 'rollover' && !confirm(state.lang === 'fa' ? 'دوره فعلی بسته و دوره جدید آغاز شود؟' : 'Close current period and start a new one?'))
            return; setBusy(true); try {
            const actionName = rename ? 'signal_cycle_rename' : start ? 'signal_cycle_start' : 'signal_cycle_rollover', payload = rename ? { cycle_id: Number(cycleId), name } : { name };
            await action(actionName, payload, false);
            invalidate('adminSignalCycles', 'signals', 'overview', 'adminSignalJobs');
            await loadResource('adminSignalCycles', true);
            closeModal();
            await adminSignalCyclesModal();
            toast(state.lang === 'fa' ? 'دوره با موفقیت به‌روزرسانی شد.' : 'Period updated successfully.');
        }
        catch (err) {
            toast(err?.message || String(err), 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function closeSignalCycleFromMiniApp() { if (!confirm(state.lang === 'fa' ? 'دوره فعلی بسته شود؟ هیچ سیگنالی حذف نخواهد شد.' : 'Close current period? No signal will be deleted.'))
    return; setBusy(true); try {
    await action('signal_cycle_close', {}, false);
    invalidate('adminSignalCycles', 'signals', 'overview', 'adminSignalJobs');
    await loadResource('adminSignalCycles', true);
    closeModal();
    await adminSignalCyclesModal();
    toast(state.lang === 'fa' ? 'دوره بسته و در آرشیو نگهداری شد.' : 'Period closed and preserved.');
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
async function adminSignalCycleDetail(id) { setBusy(true); try {
    const d = await request(`./api/v1/admin/signal-cycles/${encodeURIComponent(id)}?limit=500`), row = d?.cycle || {}, items = d?.items || [], stats = row?.stats || {};
    openModal('SIGNAL PERIOD', `#${num(row.id || id, 0)} · ${row.name || '—'}`, `<div class="metric-grid">${metric(state.lang === 'fa' ? 'کل سیگنال' : 'Signals', num(stats.total || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'برد' : 'Wins', num(stats.wins || 0, 0), '', 'good')}${metric(state.lang === 'fa' ? 'باخت' : 'Losses', num(stats.losses || 0, 0), '', 'warn')}${metric(state.lang === 'fa' ? 'نرخ برد' : 'Win rate', `${num(stats.win_rate || 0, 1)}%`, '', 'info')}${metric(state.lang === 'fa' ? 'سود/زیان تجمعی' : 'Cumulative P/L', `${Number(stats.profit_percent_sum || 0) >= 0 ? '+' : ''}${num(stats.profit_percent_sum || 0, 2)}%`, '', Number(stats.profit_percent_sum || 0) >= 0 ? 'good' : 'warn')}</div><div class="card-actions"><button class="button primary" data-signal-cycle-pdf="${esc(id)}">${state.lang === 'fa' ? 'دریافت PDF کامل' : 'Download full PDF'}</button><button class="button secondary" data-signal-cycle-rename="${esc(id)}">${state.lang === 'fa' ? 'تغییر نام دوره' : 'Rename period'}</button><button class="button" data-admin-signal-cycles>${state.lang === 'fa' ? 'بازگشت به دوره‌ها' : 'Back to periods'}</button></div><div class="journal-list">${items.map(x => `<article class="journal-card"><div class="row-between"><strong>#${num(x.display_number || x.id || 0, 0)} · ${esc(x.symbol || '—')}</strong><span class="status-badge ${String(x.status || 'open').includes('stop') ? 'bad' : 'info'}">${esc(x.status || 'open')}</span></div><p>${esc(String(x.side || '').toUpperCase())} · ${state.lang === 'fa' ? 'سود/زیان' : 'P/L'} ${Number(x.profit_percent || 0) >= 0 ? '+' : ''}${num(x.profit_percent || 0, 2)}%</p></article>`).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
async function downloadSignalCyclePdf(id) { setBusy(true); try {
    const response = await fetch(`./api/v1/admin/signal-cycles/${encodeURIComponent(id)}/export.pdf?lang=${encodeURIComponent(state.lang)}`, { credentials: 'include', headers: { Accept: 'application/pdf' } });
    if (!response.ok) {
        let message = 'SIGNAL_PERIOD_PDF_FAILED';
        try {
            const body = await response.json();
            message = body?.error?.message || body?.detail || message;
        }
        catch { }
        throw new Error(message);
    }
    const blob = await response.blob();
    if (!blob.size)
        throw new Error('SIGNAL_PERIOD_PDF_EMPTY');
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url;
    a.download = `sentinel-signal-period-${id}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    toast(state.lang === 'fa' ? 'گزارش PDF دوره آماده شد.' : 'Period PDF downloaded.');
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
function adminPaymentTone(status) { return status === 'approved' ? 'good' : status === 'rejected' || status === 'cancelled' ? 'bad' : status === 'approving' ? 'info' : 'warn'; }
function adminPaymentLabel(status) { const fa = state.lang === 'fa', labels = fa ? { pending:'منتظر بررسی', approving:'در حال تأیید', approved:'تأییدشده', rejected:'ردشده', cancelled:'لغوشده', expired:'منقضی' } : { pending:'Pending review', approving:'Approving', approved:'Approved', rejected:'Rejected', cancelled:'Cancelled', expired:'Expired' }; return labels[String(status)] || String(status || 'unknown'); }
async function adminPaymentsModal(force = true) { setBusy(true); try {
    const data = await loadResource('adminOrders', force), rows = data?.items || [], filter = state.adminPaymentFilter || 'pending', visible = filter === 'all' ? rows : filter === 'pending' ? rows.filter(row => ['pending','approving'].includes(String(row.status))) : rows.filter(row => String(row.status) === filter), counts = rows.reduce((out,row) => (out[row.status] = (out[row.status] || 0) + 1, out), {});
    openModal('PAYMENT REVIEW', state.lang === 'fa' ? 'رسیدها و پرداخت‌های VIP' : 'VIP receipts and payments', `<div class="notice info"><strong>${state.lang === 'fa' ? 'ارتباط مستقیم ربات و Mini App' : 'Direct Bot ↔ Mini App sync'}</strong><p>${state.lang === 'fa' ? 'رسید ارسالی کاربر در همین صفحه دیده می‌شود؛ تأیید یا رد، همان سفارش را در ربات و Mini App به‌روزرسانی می‌کند.' : 'User receipts are reviewed here; approve/reject updates the same order in Bot and Mini App.'}</p></div><div class="filters">${['pending','approved','rejected','all'].map(key => `<button class="filter-chip ${filter === key ? 'active' : ''}" data-admin-payment-filter="${key}">${esc(key === 'all' ? (state.lang === 'fa' ? 'همه' : 'All') : adminPaymentLabel(key))}${key !== 'all' ? ` · ${num(key === 'pending' ? Number(counts.pending || 0) + Number(counts.approving || 0) : counts[key] || 0, 0)}` : ` · ${num(rows.length,0)}`}</button>`).join('')}</div><div class="journal-list" style="margin-top:12px">${visible.map(row => `<article class="journal-card"><div class="row-between"><div><strong>${esc(row.plan_name || row.plan_id || row.id)}</strong><p>#${esc(row.id)} · ${state.lang === 'fa' ? 'کاربر' : 'User'} ${esc(row.user_id)}</p></div><span class="status-badge ${adminPaymentTone(row.status)}">${esc(adminPaymentLabel(row.status))}</span></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'مبلغ' : 'Amount', money(row.amount_toman || 0, 'T'), '', 'warn')}${metric(state.lang === 'fa' ? 'رسید' : 'Receipt', row.receipt_attached ? (state.lang === 'fa' ? 'پیوست‌شده' : 'Attached') : (state.lang === 'fa' ? 'ندارد' : 'Missing'), '', row.receipt_attached ? 'good' : 'bad')}</div><small>${date(row.updated_at || row.created_at)}</small><div class="card-actions"><button class="button primary small" data-admin-order="${esc(row.id)}">${state.lang === 'fa' ? 'بازکردن رسید و بررسی' : 'Open receipt & review'}</button></div></article>`).join('') || empty()}</div>`, []);
} catch (err) { toast(err.message, 'error'); } finally { setBusy(false); } }

async function adminOrderDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/admin/orders/${encodeURIComponent(id)}`), receipt = x.receipt ? `<div class="receipt-preview"><img src="${esc(x.receipt.view_url)}" alt="Payment receipt" loading="lazy"></div>` : `<div class="notice warning">${state.lang === 'fa' ? 'رسیدی متصل نیست.' : 'No receipt attached.'}</div>`;
    openModal('VIP PAYMENT', `${x.plan_name || x.plan_id || x.id}`, `<div class="metric-grid">${metric(t('status'), esc(x.status), '', 'info')}${metric(state.lang === 'fa' ? 'کاربر' : 'User', esc(x.user_id), '', '')}${metric(t('payable'), money(x.amount_toman || 0, 'T'), '', 'warn')}${metric(t('paymentMethod'), esc(x.payment_method || '—'), '', '')}</div>${receipt}${x.transaction_hash ? `<div class="notice mono ltr">${esc(x.transaction_hash)}</div>` : ''}${x.rejection_reason ? `<div class="notice danger">${esc(x.rejection_reason)}</div>` : ''}<div class="notice ${x.receipt ? 'good' : 'danger'}"><strong>${x.receipt ? (state.lang === 'fa' ? 'رسید آماده بررسی است' : 'Receipt ready for review') : (state.lang === 'fa' ? 'رسیدی برای این سفارش ثبت نشده است' : 'No receipt is attached')}</strong>${x.receipt ? `<small>${date(x.receipt.created_at)} · ${num(x.receipt.size_bytes || 0,0)} bytes</small>` : ''}</div><div class="card-actions">${x.status === 'pending' && x.permissions?.approve ? `<button class="button primary" data-admin-order-approve="${esc(x.id)}">${state.lang === 'fa' ? 'تأیید دستی و ارسال لینک' : 'Manual approve & send link'}</button>` : ''}${x.status === 'pending' && x.permissions?.reject ? `<button class="button danger" data-admin-order-reject="${esc(x.id)}">${state.lang === 'fa' ? 'رد پرداخت' : 'Reject payment'}</button>` : ''}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function adminOrderRejectModal(id) { openModal('VIP PAYMENT', state.lang === 'fa' ? 'دلیل رد پرداخت' : 'Rejection reason', `<form id="adminRejectForm"><div class="field"><label for="adminRejectReason">${esc(t('reason'))}</label><textarea id="adminRejectReason" required minlength="3"></textarea></div></form>`, [{ label: state.lang === 'fa' ? 'رد پرداخت' : 'Reject', kind: 'danger', action: async () => { const f = $('#adminRejectForm'); if (!f.reportValidity())
            return; await action('payment_reject', { order_id: id, reason: $('#adminRejectReason').value }, false); invalidate('adminOrders', 'orders', 'overview'); closeModal(); await adminPaymentsModal(true); toast(t('success')); } }]); }
async function adminTicketDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/admin/tickets/${encodeURIComponent(id)}`), closed = x.status === 'closed', canReply = adminCan('tickets') || adminCan('tickets_reply'), canStatus = adminCan('tickets') || adminCan('tickets_status_manage');
    const replyForm = !closed && canReply ? `<form id="adminTicketReplyForm"><div class="field"><label for="adminTicketReply">${esc(t('message'))}</label><textarea id="adminTicketReply" required minlength="1" maxlength="4000"></textarea></div></form>` : '';
    const controls = `${!closed && canReply ? `<button class="button primary" data-admin-ticket-reply="${x.id}">${state.lang === 'fa' ? 'ارسال پاسخ' : 'Send reply'}</button>` : ''}${canStatus ? (!closed ? `<button class="button secondary" data-admin-ticket-status="${x.id}" data-status="pending">${state.lang === 'fa' ? 'در انتظار بررسی' : 'Mark pending'}</button><button class="button secondary" data-admin-ticket-status="${x.id}" data-status="answered">${state.lang === 'fa' ? 'پاسخ داده شد' : 'Mark answered'}</button><button class="button danger" data-admin-ticket-status="${x.id}" data-status="closed">${esc(t('close'))}</button>` : `<button class="button secondary" data-admin-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button>`) : ''}`;
    openModal('SUPPORT ADMIN', `#${x.id} · ${x.subject || 'Support'}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric('User', esc(x.user_id), '', 'info')}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'منتظر پاسخ' : 'Waiting for', esc(x.waiting_for || 'admin'), '', 'warn')}</div><div class="timeline">${(x.messages || []).map(m => `<div class="timeline-item ${m.sender === 'admin' ? 'admin-message' : 'user-message'}"><strong>${m.sender === 'admin' ? (state.lang === 'fa' ? 'ادمین SENTINEL' : 'SENTINEL Admin') : (state.lang === 'fa' ? 'کاربر' : 'User')}</strong><p>${esc(m.text)}</p><small>${date(m.created_at)}</small></div>`).join('') || empty()}</div>${replyForm}${controls ? `<div class="card-actions">${controls}</div>` : `<div class="notice info"><strong>${state.lang === 'fa' ? 'دسترسی فقط‌خواندنی' : 'Read-only access'}</strong></div>`}`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function uploadSignalTemplate(side) { const file = $(`#adminTemplate${side}`)?.files?.[0]; if (!file) {
    toast(state.lang === 'fa' ? 'ابتدا تصویر را انتخاب کنید.' : 'Choose an image first.', 'error');
    return;
} setBusy(true); try {
    const fd = new FormData();
    fd.append('file', file);
    await request(`./api/v1/admin/signal-templates/background?side=${encodeURIComponent(side)}`, { method: 'POST', csrf: true, body: fd }, 50000);
    invalidate('adminTemplates');
    closeModal();
    await adminWorkspace();
    toast(t('success'));
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function resetSignalTemplate(side) { setBusy(true); try {
    await request(`./api/v1/admin/signal-templates/background?side=${encodeURIComponent(side)}`, { method: 'DELETE', csrf: true }, 30000);
    invalidate('adminTemplates');
    closeModal();
    await adminWorkspace();
    toast(t('success'));
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function adminAuditModal() { setBusy(true); try {
    const d = await loadResource('adminAudit', true);
    openModal('AUDIT LOG', state.lang === 'fa' ? 'گزارش ممیزی قابل جست‌وجو' : 'Searchable audit log', `<div class="search-box">${icon('search')}<label class="sr-only" for="auditSearch">Search</label><input id="auditSearch" placeholder="action / admin / detail"></div><div id="auditRows" class="timeline" style="margin-top:12px">${(d.items || []).map(x => `<div class="timeline-item"><strong>${esc(x.action || 'event')}</strong><p>${esc(x.details || '')}</p><small>${esc(x.admin_id || '')} · ${date(x.created_at)}</small></div>`).join('') || empty()}</div>`, []);
    const input = $('#auditSearch');
    input?.addEventListener('input', () => { const q = input.value.trim().toLowerCase(); $$('.timeline-item', $('#auditRows')).forEach(row => row.hidden = q && !row.textContent.toLowerCase().includes(q)); });
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function handoffCreateModal() { openModal('SHIFT HANDOFF', t('newHandoff'), `<form id="handoffForm"><div class="field"><label for="handoffTo">${state.lang === 'fa' ? 'آیدی ادمین تحویل‌گیرنده' : 'Receiving admin ID'}</label><input id="handoffTo" inputmode="numeric" required></div><div class="field"><label for="handoffSummary">${state.lang === 'fa' ? 'خلاصه وضعیت' : 'Status summary'}</label><textarea id="handoffSummary" rows="4" required minlength="5"></textarea></div><div class="field"><label for="handoffPending">${state.lang === 'fa' ? 'موارد باز؛ هر خط یک مورد' : 'Pending items; one per line'}</label><textarea id="handoffPending" rows="4"></textarea></div><div class="field"><label for="handoffRisks">${state.lang === 'fa' ? 'ریسک‌ها؛ هر خط یک مورد' : 'Risks; one per line'}</label><textarea id="handoffRisks" rows="3"></textarea></div></form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#handoffForm'); if (!f.reportValidity())
            return; const list = id => $(id).value.split(/\n+/).map(x => x.trim()).filter(Boolean); setBusy(true); try {
            await action('shift_handoff_create', { to_admin_id: $('#handoffTo').value, summary: $('#handoffSummary').value, pending_items: list('#handoffPending'), risks: list('#handoffRisks') }, false);
            closeModal();
            invalidate('adminOps');
            toast(t('success'));
            await adminWorkspace();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function propTemplateCreateModal() { openModal('PROP RULE ENGINE', state.lang === 'fa' ? 'ساخت قالب قوانین پراپ' : 'Create prop rule template', `<form id="propTemplateForm"><div class="form-grid"><div class="field"><label for="propProvider">${state.lang === 'fa' ? 'شرکت پراپ' : 'Provider'}</label><input id="propProvider" required minlength="2" maxlength="80" placeholder="FTMO / FundedNext / Custom"></div><div class="field"><label for="propName">${esc(t('name'))}</label><input id="propName" required minlength="3" maxlength="120"></div><div class="field"><label for="propVersion">Version</label><input id="propVersion" type="number" min="1" value="1" required></div><div class="field"><label for="propTimezone">${esc(t('timezone'))}</label><input id="propTimezone" value="UTC" required></div><div class="field"><label for="propResetHour">${state.lang === 'fa' ? 'ساعت ریست روزانه' : 'Daily reset hour'}</label><input id="propResetHour" type="number" min="0" max="23" value="0" required></div><div class="field"><label for="propDailyLoss">${esc(t('dailyLoss'))} %</label><input id="propDailyLoss" inputmode="decimal" type="number" min="0.1" max="100" step="0.1" value="5" required></div><div class="field"><label for="propTotalLoss">${esc(t('totalLoss'))} %</label><input id="propTotalLoss" inputmode="decimal" type="number" min="0.1" max="100" step="0.1" value="10" required></div><div class="field"><label for="propDrawdownMode">${state.lang === 'fa' ? 'نوع افت سرمایه' : 'Drawdown mode'}</label><select id="propDrawdownMode"><option value="static">Static</option><option value="trailing">Trailing</option></select></div><div class="field"><label for="propDailyBasis">${state.lang === 'fa' ? 'مبنای ضرر روزانه' : 'Daily loss basis'}</label><select id="propDailyBasis"><option value="balance">Balance</option><option value="equity">Equity</option></select></div><div class="field"><label for="propOpenRisk">${esc(t('maxOpenRisk'))} %</label><input id="propOpenRisk" type="number" min="0.1" max="100" step="0.1" value="5" required></div><div class="field"><label for="propOpenTrades">${state.lang === 'fa' ? 'حداکثر معاملات باز' : 'Max open trades'}</label><input id="propOpenTrades" type="number" min="1" max="100" value="5" required></div><div class="field"><label for="propMinDays">${state.lang === 'fa' ? 'حداقل روز معاملاتی' : 'Minimum trading days'}</label><input id="propMinDays" type="number" min="0" max="365" value="0" required></div><div class="field"><label for="propNewsFreeze">${state.lang === 'fa' ? 'محدودیت خبر (دقیقه)' : 'News freeze (minutes)'}</label><input id="propNewsFreeze" type="number" min="0" max="240" value="0" required></div></div><label class="check-row"><input id="propFloating" type="checkbox" checked> <span>${state.lang === 'fa' ? 'زیان شناور در حد روزانه محاسبه شود' : 'Include floating loss in daily limit'}</span></label><label class="check-row"><input id="propWeekend" type="checkbox"> <span>${state.lang === 'fa' ? 'نگهداری آخر هفته مجاز باشد' : 'Allow weekend holding'}</span></label></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const f = $('#propTemplateForm'); if (!f.reportValidity())
            return; const rules = { daily_loss_percent: Number($('#propDailyLoss').value), total_loss_percent: Number($('#propTotalLoss').value), total_drawdown_mode: $('#propDrawdownMode').value, daily_loss_basis: $('#propDailyBasis').value, daily_reset_timezone: $('#propTimezone').value.trim(), daily_reset_hour: Number($('#propResetHour').value), include_floating_in_daily_loss: $('#propFloating').checked, max_open_risk_percent: Number($('#propOpenRisk').value), max_open_trades: Number($('#propOpenTrades').value), min_trading_days: Number($('#propMinDays').value), news_freeze_minutes: Number($('#propNewsFreeze').value), allow_weekend_holding: $('#propWeekend').checked }; setBusy(true); try {
            await action('prop_template_create', { provider: $('#propProvider').value.trim(), name: $('#propName').value.trim(), version: Number($('#propVersion').value), rules }, false);
            closeModal();
            invalidate('risk');
            toast(t('success'));
            await adminWorkspace();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function experimentCreateModal() { openModal('EXPERIMENT LAB', t('newExperiment'), `<form id="experimentForm"><div class="field"><label for="expName">${esc(t('name'))}</label><input id="expName" required minlength="3"></div><div class="field"><label for="expHypothesis">${esc(t('hypothesis'))}</label><textarea id="expHypothesis" rows="3" required minlength="5"></textarea></div><div class="form-grid"><div class="field"><label for="expMetric">${esc(t('primaryMetric'))}</label><select id="expMetric"><option value="purchase">Purchase</option><option value="checkout_started">Checkout started</option><option value="renewal">Renewal</option></select></div><div class="field"><label for="expSample">${esc(t('minimumSample'))}</label><input id="expSample" inputmode="numeric" value="100" min="10"></div><div class="field"><label for="expHoldout">Holdout %</label><input id="expHoldout" inputmode="decimal" value="10" min="0" max="50"></div><div class="field"><label for="expStop">Stop-loss %</label><input id="expStop" inputmode="decimal" value="25" min="0" max="100"></div></div><div class="field"><label for="expControl">Control label</label><input id="expControl" value="Control" required></div><div class="field"><label for="expVariant">Variant label</label><input id="expVariant" value="Variant A" required></div></form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#experimentForm'); if (!f.reportValidity())
            return; setBusy(true); try {
            await action('experiment_create', { name: $('#expName').value, hypothesis: $('#expHypothesis').value, primary_metric: $('#expMetric').value, min_sample_per_variant: Number($('#expSample').value), holdout_percent: Number($('#expHoldout').value), stop_loss_percent: Number($('#expStop').value), variants: [{ key: 'control', label: $('#expControl').value, weight: 1, is_control: true }, { key: 'variant_a', label: $('#expVariant').value, weight: 1, is_control: false }] }, false);
            closeModal();
            invalidate('adminExperiments');
            toast(t('success'));
            await adminWorkspace();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function syncActiveView() { if (document.hidden || state.preview) return; if (state.page === 'home') { await Promise.all([loadOverview(true), refreshFeed(true)]); renderChrome(); renderHome(); return; } if (['signals', 'risk', 'journal'].includes(state.page)) await Promise.all([loadOverview(true), loadResource(state.page, true)]); else await loadOverview(true); if(state.page==='rewards' || !$('#modalLayer')?.hidden && ['REWARDS','REFERRAL','MISSIONS'].includes($('#modalEyebrow')?.textContent)) await loadResource('hub',true); renderChrome(); if (state.page === 'signals') await renderSignals(); else if (state.page === 'risk') await renderRisk(); else if (state.page === 'journal') await renderJournal(); else await navigate(state.page, false); }
function connectEvents() { if (state.preview || !window.EventSource)
    return; clearTimeout(state.eventReconnectTimer); state.eventSource?.close(); const suffix = state.lastEventId ? `?last_id=${state.lastEventId}` : '', es = new EventSource(`./api/v1/events${suffix}`, { withCredentials: true }); state.eventSource = es; const accept = async (event, keys, refresh) => { const id = Number(event.lastEventId || 0), resync = event.type === 'stream.resync_required'; if (!resync && id && id <= state.lastEventId)
    return; if (id && id > state.lastEventId) {
    state.lastEventId = id;
    sessionStorage.setItem('sentinelLastEventId', String(id));
} invalidate(...keys); try {
    if (refresh === 'feed') {
        await refreshFeed(true);
        await loadOverview(true);
        renderChrome();
        if (state.page === 'home')
            renderHome();
        return;
    }
    if (resync) {
        await Promise.all([loadOverview(true), refreshFeed(false)]);
        renderChrome();
        if (state.page !== 'home')
            await loadResource(state.page, true);
        await navigate(state.page, false);
        return;
    }
    if (state.page === 'home') {
        await loadOverview(true);
        renderChrome();
        renderHome();
        return;
    }
    if (refresh === 'signals' && state.page === 'signals') {
        await loadResource('signals', true);
        await renderSignals();
    }
    else if (refresh === 'risk' && state.page === 'risk') {
        await loadResource('risk', true);
        await renderRisk();
    }
    else if (refresh === 'journal' && state.page === 'journal') {
        await loadResource('journal', true);
        await renderJournal();
    }
    else if (refresh === 'rewards') {
        await loadResource('hub',true);
        if(state.page==='rewards')await renderRewardsWorkspace();
    }
    else if (refresh === 'orders') {
        if (state.page === 'more' && state.resources.orders) await loadResource('orders', true);
        const paymentReviewOpen = !$('#modalLayer')?.hidden && $('#modalEyebrow')?.textContent === 'PAYMENT REVIEW';
        if (paymentReviewOpen) await adminPaymentsModal(true);
    }
    else if (refresh === 'tickets' && state.page === 'more' && state.resources.tickets) {
        await loadResource('tickets', true);
    }
}
catch { } }; const bind = (names, keys, refresh) => names.forEach(name => es.addEventListener(name, event => accept(event, keys, refresh))); bind(['signal.created', 'channel.announcement', 'channel.news', 'channel.publication'], ['feed', 'signals', 'overview', 'adminSignalJobs'], 'feed'); bind(['signal.updated', 'signal.revised', 'signal.closed', 'signal.choice_updated', 'signal.lifecycle_updated', 'signal.result_updated', 'signal.result_reset', 'signal.partial_closed', 'signal.metrics_updated', 'signal.edited'], ['signals', 'revisions', 'overview', 'adminSignals'], 'signals'); bind(['signal.deleted'], ['signals', 'revisions', 'overview', 'adminSignals'], 'signals'); bind(['admin.user_updated'], ['adminUsers', 'overview'], 'home'); bind(['admin.access_updated'], ['adminAdmins', 'adminCapabilities', 'overview'], 'home'); bind(['admin.control_updated', 'admin.governance_updated'], ['adminPlatform', 'adminCapabilities', 'overview'], 'home'); bind(['signal.cycle_changed'], ['adminSignalCycles', 'signals', 'overview', 'adminSignalJobs'], 'signals'); bind(['position.opened', 'position.closed', 'position.risk_changed', 'position.voided', 'account.updated', 'account.archived'], ['risk', 'overview', 'expansion'], 'risk'); bind(['journal.updated'], ['journal', 'overview', 'expansion'], 'journal'); bind(['order.status_changed', 'miniapp.vip_order_submit', 'miniapp.vip_order_cancel', 'miniapp.vip_order_resubmit'], ['orders', 'adminOrders', 'overview'], 'orders'); bind(['ticket.message_added', 'ticket.status_changed', 'miniapp.ticket_create', 'miniapp.ticket_reply', 'miniapp.ticket_status_update'], ['tickets', 'adminTickets', 'overview'], 'tickets'); bind(['rewards.updated','missions.updated','referral.updated','miniapp.reward_claim'], ['hub','overview'], 'rewards'); bind(['preferences.updated'], ['overview'], 'home'); bind(['stream.resync_required'], ['overview', 'signals', 'risk', 'journal', 'orders', 'tickets', 'revisions', 'feed', 'expansion', 'adminSignals', 'adminUsers', 'adminAdmins', 'adminCapabilities'], 'home'); es.onopen = () => { state.eventFailureCount = 0; clearInterval(state.pollTimer); }; const reconnect = (renew = false) => {
    if (state.eventSource !== es) return;
    es.close(); state.eventSource = null;
    state.eventFailureCount = renew ? Math.max(2, state.eventFailureCount + 1) : state.eventFailureCount + 1;
    startPolling(); clearTimeout(state.eventReconnectTimer);
    const delay = Math.min(30000, 2000 * 2 ** Math.min(4, state.eventFailureCount - 1));
    state.eventReconnectTimer = setTimeout(async () => {
        if (state.eventFailureCount >= 2) {
            try { await renewAuthenticatedSession(); state.eventFailureCount = 0; }
            catch { /* Existing polling and bounded reconnect delay retain recovery. */ }
        }
        connectEvents();
    }, delay);
};
es.addEventListener('stream.auth_required', () => reconnect(true));
es.addEventListener('stream.rotate', () => {
    if (state.eventSource !== es) return;
    es.close(); state.eventSource = null;
    clearTimeout(state.eventReconnectTimer);
    state.eventReconnectTimer = setTimeout(connectEvents, 250);
});
es.onerror = () => reconnect(); }

function startPolling() { clearInterval(state.pollTimer); const tick = async () => { if (document.hidden || state.preview) return; try { await syncActiveView(); } catch { } }; tick(); state.pollTimer = setInterval(tick, 8000); }
function startLivePricePolling() { clearInterval(state.livePriceTimer); const tick = async () => { if (document.hidden || state.preview || !state.online || state.busy)
    return; try {
    await refreshVisibleHub();
    if (state.page === 'signals' && $('#page-signals')?.classList.contains('active')) {
        const data = await loadResource('signals', true);
        refreshSignalCardsDom(data);
    }
    if ($('[data-market-refresh]')) {
        const data = await loadResource('market', true);
        refreshMarketDom(data);
    }
    if ($('#adminSignalForm'))
        await refreshAdminSignalQuote(true);
}
catch { } }; state.livePriceTimer = setInterval(tick, 15000); setTimeout(tick, 5000); }
// Legacy contract marker: LIVE MODULE REGISTRY (replaced by the localized dynamic operations center).

// Legacy source-contract marker retained for release tests: x.status==='pending'?`<button
