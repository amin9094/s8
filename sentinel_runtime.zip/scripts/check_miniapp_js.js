"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const htmlPath = path.join(root, "webapp", "index.html");
const html = fs.readFileSync(htmlPath, "utf8");

const sources = [];
for (const match of html.matchAll(/<script(?:[^>]*)>([\s\S]*?)<\/script>/gi)) {
  const tag = match[0];
  const inlineSource = match[1];
  const srcMatch = tag.match(/\bsrc=["']([^"']+)["']/i);
  if (srcMatch) {
    const src = srcMatch[1];
    if (/^(?:https?:)?\/\//i.test(src)) continue;
    const normalized = src.replace(/^\.\//, "").split(/[?#]/, 1)[0];
    const filePath = path.join(root, "webapp", normalized);
    if (!fs.existsSync(filePath)) {
      throw new Error(`Mini App script asset is missing: ${src}`);
    }
    sources.push({ name: normalized, source: fs.readFileSync(filePath, "utf8") });
  } else if (inlineSource.trim()) {
    sources.push({ name: "inline-script.js", source: inlineSource });
  }
}

if (sources.length === 0) {
  throw new Error("Mini App has no local JavaScript to validate");
}

for (const { name, source } of sources) {
  try {
    new vm.Script(source, { filename: name });
  } catch (error) {
    throw new Error(`Mini App JavaScript ${name} is invalid: ${error.message}`);
  }
}

process.stdout.write(`Mini App JavaScript syntax OK (${sources.length} local script asset)\n`);
