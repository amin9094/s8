from __future__ import annotations

from html import escape
from typing import Any

from ui.button_factory import InlineKeyboardButton

from modules.campaign_studio import (
    CAMPAIGN_AUDIENCES,
    CAMPAIGN_CATEGORIES,
    audience_members,
)


def campaign_category_rows(
    back_rows: list[list[InlineKeyboardButton]],
) -> list[list[InlineKeyboardButton]]:
    buttons = [
        InlineKeyboardButton(label, callback_data=f"campaign_cat:{key}")
        for key, (label, _) in CAMPAIGN_CATEGORIES.items()
    ]
    return [buttons[index : index + 2] for index in range(0, len(buttons), 2)] + back_rows


def campaign_audience_rows(
    back_rows: list[list[InlineKeyboardButton]],
) -> list[list[InlineKeyboardButton]]:
    buttons = [
        InlineKeyboardButton(label, callback_data=f"campaign_audience:{key}")
        for key, label in CAMPAIGN_AUDIENCES.items()
    ]
    return [buttons[index : index + 2] for index in range(0, len(buttons), 2)] + back_rows


def campaign_detail_text(db: dict[str, Any], campaign: dict[str, Any]) -> str:
    category = CAMPAIGN_CATEGORIES.get(str(campaign.get("category")), ("نامشخص", ""))[0]
    audience = CAMPAIGN_AUDIENCES.get(str(campaign.get("audience")), "نامشخص")
    status_labels = {
        "draft": "پیش‌نویس",
        "scheduled": "زمان‌بندی‌شده",
        "active": "فعال",
        "paused": "متوقف",
        "completed": "تکمیل‌شده",
        "cancelled": "لغوشده",
        "archived": "بایگانی",
    }
    discount = str(campaign.get("discount_code") or "—")
    tracking = campaign.get("tracking", {}) if isinstance(campaign.get("tracking"), dict) else {}
    recipient_count = len(audience_members(db, str(campaign.get("audience") or "all")))
    schedule_text = ""
    if campaign.get("scheduled_for"):
        schedule_text = (
            f"زمان انتشار: <b>{escape(str(campaign.get('scheduled_for')))}</b>\n"
            f"وضعیت زمان‌بندی: <b>{escape(str(campaign.get('schedule_status') or 'waiting'))}</b> | "
            f"تلاش: <b>{int(campaign.get('schedule_attempts', 0) or 0)}/{int(campaign.get('schedule_max_attempts', 5) or 5)}</b>\n"
        )
    return (
        f"🚀 <b>{escape(str(campaign.get('name') or ''))}</b>\n\n"
        f"شناسه: <code>{escape(str(campaign.get('id') or ''))}</code>\n"
        f"دسته: <b>{escape(category)}</b>\n"
        f"مخاطب: <b>{escape(audience)}</b> ({recipient_count:,} کاربر)\n"
        f"مسیر انتشار: <b>{escape(str(campaign.get('delivery') or ''))}</b>\n"
        f"وضعیت: <b>{escape(str(status_labels.get(str(campaign.get('status')), campaign.get('status'))))}</b>\n"
        f"کد تخفیف: <code>{escape(discount)}</code>\n"
        f"نسخه: <b>{int(campaign.get('version', 1) or 1)}</b>\n\n"
        f"<b>انتساب لینک</b>\n"
        f"Source: <code>{escape(str(tracking.get('source') or 'direct'))}</code> | "
        f"Medium: <code>{escape(str(tracking.get('medium') or 'telegram'))}</code>\n"
        f"Creative: <code>{escape(str(tracking.get('creative') or 'default'))}</code> | "
        f"Budget: <b>{int(tracking.get('budget', 0) or 0):,}</b>\n"
        + (
            f"🤖 <code>{escape(str(campaign.get('bot_tracking_link')))}</code>\n"
            if campaign.get("bot_tracking_link")
            else ""
        )
        + (
            f"📢 <code>{escape(str(campaign.get('channel_tracking_link')))}</code>\n"
            if campaign.get("channel_tracking_link")
            else ""
        )
        + "\n"
        f"{schedule_text}"
        f"<b>پیام کمپین</b>\n{escape(str(campaign.get('message') or '')[:1200])}"
    )
