from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def _present(env: Mapping[str, str], *names: str) -> bool:
    return any(str(env.get(name) or '').strip() for name in names)


def _truthy(env: Mapping[str, str], name: str, default: bool = False) -> bool:
    raw = str(env.get(name) or ('true' if default else 'false')).strip().lower()
    return raw in {'1', 'true', 'yes', 'on'}


def config_wizard_snapshot(env: Mapping[str, str]) -> dict[str, Any]:
    """Return a secret-safe configuration readiness summary.

    Values are never returned; only presence and grouped readiness are exposed.
    This makes the same summary safe for Telegram admin UI and CLI diagnostics.
    """
    google_enabled = _truthy(env, 'GOOGLE_SHEETS_BACKUP_ENABLED', False)
    gemini_enabled = _truthy(env, 'GEMINI_ENABLED', False)
    webapp_enabled = _truthy(env, 'WEBAPP_API_ENABLED', True)
    run_mode = str(env.get('RUN_MODE') or ('webhook' if _present(env, 'WEBHOOK_URL') else 'polling')).strip().lower()

    groups: list[dict[str, Any]] = []

    def add_group(key: str, title: str, checks: list[tuple[str, bool, str]]) -> None:
        required = [row for row in checks if row[2] == 'required']
        recommended = [row for row in checks if row[2] == 'recommended']
        missing_required = [label for label, ok, _ in required if not ok]
        missing_recommended = [label for label, ok, _ in recommended if not ok]
        groups.append({
            'key': key,
            'title': title,
            'required_total': len(required),
            'required_ready': len(required) - len(missing_required),
            'recommended_total': len(recommended),
            'recommended_ready': len(recommended) - len(missing_recommended),
            'missing_required': missing_required,
            'missing_recommended': missing_recommended,
            'ready': not missing_required,
        })

    add_group('telegram', 'Telegram', [
        ('BOT_TOKEN', _present(env, 'BOT_TOKEN', 'TELEGRAM_BOT_TOKEN', 'TOKEN'), 'required'),
        ('ADMIN_IDS / PRIMARY_ADMIN_ID', _present(env, 'ADMIN_IDS', 'TELEGRAM_ADMIN_IDS', 'ADMIN_ID', 'PRIMARY_ADMIN_ID', 'BOT_OWNER_ID', 'OWNER_ID'), 'required'),
        ('PUBLIC_CHANNEL_ID', _present(env, 'PUBLIC_CHANNEL_ID', 'PUBLIC_CHANNEL', 'CHANNEL_ID'), 'recommended'),
        ('PRIVATE_CHANNEL_ID', _present(env, 'PRIVATE_CHANNEL_ID', 'VIP_CHANNEL_ID', 'PRIVATE_CHANNEL'), 'recommended'),
    ])
    add_group('storage', 'Database & Storage', [
        ('DATABASE_URL', _present(env, 'DATABASE_URL', 'POSTGRES_URL'), 'required'),
        ('REDIS_URL', _present(env, 'REDIS_URL'), 'recommended'),
        ('PERSISTENT_DATA_DIR', _present(env, 'PERSISTENT_DATA_DIR', 'RAILWAY_VOLUME_MOUNT_PATH', 'VOLUME_MOUNT_PATH'), 'recommended'),
        ('BACKUP_ENCRYPTION_KEY', _present(env, 'BACKUP_ENCRYPTION_KEY'), 'recommended'),
    ])
    add_group('security', 'Security', [
        ('SENSITIVE_DATA_KEY', _present(env, 'SENSITIVE_DATA_KEY'), 'required'),
        ('WEBAPP_SESSION_SECRET', (not webapp_enabled) or _present(env, 'WEBAPP_SESSION_SECRET'), 'required'),
        ('WEBHOOK_SECRET_TOKEN', run_mode != 'webhook' or _present(env, 'WEBHOOK_SECRET_TOKEN'), 'required'),
        ('METRICS_TOKEN', _present(env, 'METRICS_TOKEN'), 'recommended'),
    ])
    add_group('google', 'Google Sheets', [
        ('GOOGLE_SHEETS_SPREADSHEET_ID', (not google_enabled) or _present(env, 'GOOGLE_SHEETS_SPREADSHEET_ID'), 'required'),
        ('Google service account', (not google_enabled) or _present(env, 'GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON', 'GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON_B64'), 'required'),
    ])
    add_group('webapp', 'Web App & Webhook', [
        ('WEBAPP_URL', (not webapp_enabled) or _present(env, 'WEBAPP_URL'), 'recommended'),
        ('WEBHOOK_URL', run_mode != 'webhook' or _present(env, 'WEBHOOK_URL'), 'required'),
    ])
    add_group('ai', 'Gemini AI', [
        ('GEMINI_API_KEY', (not gemini_enabled) or _present(env, 'GEMINI_API_KEY'), 'required'),
    ])
    add_group('monitoring', 'Monitoring', [
        ('SENTRY_DSN', _present(env, 'SENTRY_DSN'), 'recommended'),
        ('RELEASE_COMMIT_SHA', _present(env, 'RELEASE_COMMIT_SHA', 'GITHUB_SHA', 'RAILWAY_GIT_COMMIT_SHA'), 'recommended'),
        ('RELEASE_IMAGE_DIGEST', _present(env, 'RELEASE_IMAGE_DIGEST'), 'recommended'),
    ])

    required_total = sum(row['required_total'] for row in groups)
    required_ready = sum(row['required_ready'] for row in groups)
    recommended_total = sum(row['recommended_total'] for row in groups)
    recommended_ready = sum(row['recommended_ready'] for row in groups)
    required_score = round(required_ready * 100 / required_total) if required_total else 100
    completeness_denominator = required_total + recommended_total
    completeness_ready = required_ready + recommended_ready
    completeness_score = round(completeness_ready * 100 / completeness_denominator) if completeness_denominator else 100
    return {
        'ready': required_ready == required_total,
        'required_score': required_score,
        'completeness_score': completeness_score,
        'groups': groups,
        'features': {
            'google_sheets': google_enabled,
            'gemini': gemini_enabled,
            'webapp': webapp_enabled,
            'run_mode': run_mode,
        },
        'missing_required': [f"{group['title']}: {name}" for group in groups for name in group['missing_required']],
        'missing_recommended': [f"{group['title']}: {name}" for group in groups for name in group['missing_recommended']],
    }
