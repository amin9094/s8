from __future__ import annotations

import copy
import hashlib
import ipaddress
import json
import os
import re
from datetime import UTC, datetime, timedelta
from typing import Any, Iterable
from urllib.parse import urlparse

from config import SETTINGS, is_primary_admin
from core.db import next_id
from core.utils import parse_dt, utc_iso
from modules.admin_access import has_permission
from modules.automation_outbox import enqueue_automation_message
from modules.sales_growth import create_public_discount

ALLOWED_TRIGGERS = {
    "user_registered", "user_inactive", "vip_expiring", "vip_expired", "payment_created", "payment_approved", "payment_rejected",
    "ticket_created", "ticket_closed", "ticket_waiting", "signal_created", "signal_published", "signal_tp", "signal_sl", "signal_closed",
    "campaign_created", "campaign_published", "link_clicked", "contest_started", "contest_ended", "mission_completed",
    "system_error", "provider_down", "scheduled", "gemini_command", "mt5_risk", "custom",
}
ALLOWED_ACTIONS = {
    "send_message", "notify_admin", "add_tag", "remove_tag", "create_task", "create_ticket", "queue_campaign",
    "ai_draft", "stop_feature", "webhook", "create_coupon", "assign_admin", "write_log",
}
_ALLOWED_OPERATORS = {"exists", "not_exists", "eq", "ne", "contains", "in", "not_in", "gt", "gte", "lt", "lte"}
_MAX_CONDITION_DEPTH = 6
_IDEMPOTENCY_LEASE_SECONDS = 300
_MAX_ACTIONS_PER_RULE = 20
_WEBHOOK_HOST_RE = re.compile(r"^[A-Za-z0-9.-]{1,253}$")
_FEATURE_RE = re.compile(r"^[a-z][a-z0-9_.-]{1,63}$")

# Sections that one automation rule may mutate. Snapshotting only these keeps
# rollback cheap even when the main database contains a large user history.
_TRANSACTION_SECTIONS = {
    "automation_outbox", "automation_outbox_index", "automation_v2_jobs", "automation_v2_dead_letter",
    "automation_tasks", "automation_ai_drafts", "automation_custom_log", "crm_profiles", "tickets", "support_tickets",
    "feature_flags", "discount_codes", "marketing_campaigns", "campaign_events", "admin_assignments", "next_ids",
}


def _now() -> datetime:
    return datetime.now(UTC)


def _rule_id(db: dict[str, Any]) -> str:
    return f"AR2-{next_id(db, 'automation_rule_v2'):06d}"


def _run_id(db: dict[str, Any]) -> str:
    return f"AV2-{next_id(db, 'automation_run_v2'):09d}"


def _job_id(db: dict[str, Any]) -> str:
    return f"AJ2-{next_id(db, 'automation_job_v2'):09d}"


def _task_id(db: dict[str, Any]) -> str:
    return f"AT2-{next_id(db, 'automation_task_v2'):09d}"


def _as_int(value: Any, *, field: str, minimum: int = 0, maximum: int = 10_000_000) -> int:
    try:
        parsed = int(value or 0)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"AUTOMATION_{field.upper()}_INVALID") from exc
    if parsed < minimum or parsed > maximum:
        raise ValueError(f"AUTOMATION_{field.upper()}_INVALID")
    return parsed


def _require_text(payload: dict[str, Any], key: str, *, minimum: int = 1, maximum: int = 4096) -> str:
    value = str(payload.get(key) or "").strip()
    if not minimum <= len(value) <= maximum:
        raise ValueError(f"AUTOMATION_{key.upper()}_INVALID")
    return value


def _validate_recipient(value: Any, *, field: str = "recipient_id") -> str:
    text = str(value or "").strip()
    if not text.lstrip("-").isdigit() or int(text) == 0:
        raise ValueError(f"AUTOMATION_{field.upper()}_INVALID")
    return text


def _validate_webhook_url(value: Any) -> str:
    raw = str(value or "").strip()
    parsed = urlparse(raw)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("AUTOMATION_WEBHOOK_URL_INVALID")
    host = parsed.hostname.casefold().rstrip(".")
    if not _WEBHOOK_HOST_RE.fullmatch(host):
        raise ValueError("AUTOMATION_WEBHOOK_HOST_INVALID")
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".local", ".internal", ".localhost")):
        raise ValueError("AUTOMATION_WEBHOOK_PRIVATE_HOST_BLOCKED")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address and (address.is_private or address.is_loopback or address.is_link_local or address.is_reserved or address.is_multicast):
        raise ValueError("AUTOMATION_WEBHOOK_PRIVATE_HOST_BLOCKED")
    allowlist = {
        item.strip().casefold().rstrip(".")
        for item in os.getenv("AUTOMATION_WEBHOOK_ALLOWED_HOSTS", "").split(",")
        if item.strip()
    }
    if getattr(SETTINGS, "run_mode", "development") == "production" and not allowlist:
        raise ValueError("AUTOMATION_WEBHOOK_ALLOWLIST_REQUIRED")
    if allowlist and host not in allowlist and not any(host.endswith("." + item) for item in allowlist):
        raise ValueError("AUTOMATION_WEBHOOK_HOST_NOT_ALLOWED")
    if parsed.port not in {None, 443}:
        raise ValueError("AUTOMATION_WEBHOOK_PORT_BLOCKED")
    return raw[:2048]


def _clean_action(action: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(action, dict):
        raise ValueError("AUTOMATION_ACTION_INVALID")
    kind = str(action.get("type") or "").strip().lower()
    if kind not in ALLOWED_ACTIONS:
        raise ValueError("AUTOMATION_ACTION_INVALID")
    payload = copy.deepcopy(action.get("payload") if isinstance(action.get("payload"), dict) else {})

    # Validate static values now. Template placeholders are permitted and are
    # validated again after rendering immediately before execution.
    templated = lambda value: isinstance(value, str) and "{{" in value and "}}" in value
    if kind == "send_message":
        recipient = payload.get("recipient_id", payload.get("user_id"))
        if not templated(recipient):
            _validate_recipient(recipient)
        if not templated(payload.get("text")):
            _require_text(payload, "text", maximum=4096)
    elif kind == "notify_admin":
        recipient = payload.get("recipient_id", payload.get("admin_id", SETTINGS.primary_admin_id))
        if not templated(recipient):
            _validate_recipient(recipient, field="admin_id")
        if not templated(payload.get("text")):
            _require_text(payload, "text", maximum=4096)
    elif kind in {"add_tag", "remove_tag"}:
        if not templated(payload.get("user_id")):
            _validate_recipient(payload.get("user_id"), field="user_id")
        if not templated(payload.get("tag")):
            _require_text(payload, "tag", maximum=64)
    elif kind == "create_task":
        if not templated(payload.get("title")):
            _require_text(payload, "title", maximum=200)
    elif kind == "create_ticket":
        if not templated(payload.get("user_id")):
            _validate_recipient(payload.get("user_id"), field="user_id")
        if not templated(payload.get("subject")):
            _require_text(payload, "subject", maximum=200)
        if not templated(payload.get("message")):
            _require_text(payload, "message", maximum=4000)
    elif kind == "queue_campaign":
        if not templated(payload.get("campaign_id")):
            _require_text(payload, "campaign_id", maximum=80)
    elif kind == "ai_draft":
        if not templated(payload.get("prompt")):
            _require_text(payload, "prompt", minimum=3, maximum=12000)
    elif kind == "stop_feature":
        feature = str(payload.get("feature") or "").strip().lower()
        if not templated(feature) and not _FEATURE_RE.fullmatch(feature):
            raise ValueError("AUTOMATION_FEATURE_INVALID")
        payload["feature"] = feature
    elif kind == "webhook":
        if not templated(payload.get("url")):
            payload["url"] = _validate_webhook_url(payload.get("url"))
        method = str(payload.get("method") or "POST").upper()
        if method not in {"POST", "PUT", "PATCH"}:
            raise ValueError("AUTOMATION_WEBHOOK_METHOD_INVALID")
        headers = payload.get("headers") if isinstance(payload.get("headers"), dict) else {}
        if len(headers) > 20 or any(len(str(key)) > 80 or len(str(value)) > 1000 for key, value in headers.items()):
            raise ValueError("AUTOMATION_WEBHOOK_HEADERS_INVALID")
        body = payload.get("body", {})
        try:
            encoded_body = json.dumps(body, ensure_ascii=False, default=str, separators=(",", ":")).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise ValueError("AUTOMATION_WEBHOOK_BODY_INVALID") from exc
        if len(encoded_body) > 65_536:
            raise ValueError("AUTOMATION_WEBHOOK_BODY_TOO_LARGE")
        payload["headers"] = {str(key): str(value) for key, value in headers.items()}
        payload["body"] = body
        payload["method"] = method
    elif kind == "create_coupon":
        if not templated(payload.get("code")):
            code = re.sub(r"[^A-Za-z0-9_-]", "", str(payload.get("code") or "").upper())
            if not 4 <= len(code) <= 24:
                raise ValueError("AUTOMATION_COUPON_CODE_INVALID")
            payload["code"] = code
        if not templated(payload.get("percent")):
            _as_int(payload.get("percent"), field="coupon_percent", minimum=1, maximum=100)
        if not templated(payload.get("days", 7)):
            _as_int(payload.get("days", 7), field="coupon_days", minimum=1, maximum=365)
    elif kind == "assign_admin":
        if not templated(payload.get("admin_id")):
            _validate_recipient(payload.get("admin_id"), field="admin_id")
        if not templated(payload.get("target_id")):
            _require_text(payload, "target_id", maximum=100)
        target_type = str(payload.get("target_type") or "ticket").strip().lower()
        if target_type not in {"ticket", "task", "campaign"}:
            raise ValueError("AUTOMATION_ASSIGN_TARGET_INVALID")
        payload["target_type"] = target_type
    elif kind == "write_log":
        if not templated(payload.get("message")):
            _require_text(payload, "message", maximum=2000)
    return {"type": kind, "payload": payload}


def _validate_condition(value: Any, *, depth: int = 0) -> dict[str, Any]:
    if depth > _MAX_CONDITION_DEPTH or not isinstance(value, dict):
        raise ValueError("AUTOMATION_CONDITION_INVALID")
    if "all" in value or "any" in value:
        key = "all" if "all" in value else "any"
        items = value.get(key)
        if not isinstance(items, list) or not items or len(items) > 50:
            raise ValueError("AUTOMATION_CONDITION_INVALID")
        return {key: [_validate_condition(item, depth=depth + 1) for item in items]}
    field = str(value.get("field") or "").strip()
    operator = str(value.get("operator") or "eq").strip().lower()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,120}", field) or operator not in _ALLOWED_OPERATORS:
        raise ValueError("AUTOMATION_CONDITION_INVALID")
    return {"field": field, "operator": operator, "value": copy.deepcopy(value.get("value"))}


def _validate_conditions(value: Any) -> list[dict[str, Any]] | dict[str, Any]:
    if value in (None, [], {}):
        return []
    if isinstance(value, list):
        if len(value) > 50:
            raise ValueError("AUTOMATION_CONDITION_INVALID")
        return [_validate_condition(item) for item in value]
    return _validate_condition(value)


def _validate_guards(value: Any) -> dict[str, Any]:
    defaults = {
        "max_runs_per_day": 0, "max_runs_per_entity": 0, "cooldown_seconds": 0,
        "disable_after_failures": 0, "max_retries": 3, "retry_delay_seconds": 30,
        "dry_run": False, "cooldown_scope": "entity",
    }
    if value in (None, {}):
        return defaults
    if not isinstance(value, dict):
        raise ValueError("AUTOMATION_GUARDS_INVALID")
    allowed = {
        "max_runs_per_day", "max_runs_per_entity", "cooldown_seconds", "cooldown_scope",
        "disable_after_failures", "dry_run", "max_retries", "retry_delay_seconds",
    }
    unknown = set(value) - allowed
    if unknown:
        raise ValueError("AUTOMATION_GUARDS_INVALID")
    clean = {
        "max_runs_per_day": _as_int(value.get("max_runs_per_day"), field="max_runs_per_day", maximum=1_000_000),
        "max_runs_per_entity": _as_int(value.get("max_runs_per_entity"), field="max_runs_per_entity", maximum=1_000_000),
        "cooldown_seconds": _as_int(value.get("cooldown_seconds"), field="cooldown_seconds", maximum=31_536_000),
        "disable_after_failures": _as_int(value.get("disable_after_failures"), field="disable_after_failures", maximum=1000),
        "max_retries": _as_int(value.get("max_retries", 3), field="max_retries", maximum=20),
        "retry_delay_seconds": _as_int(value.get("retry_delay_seconds", 30), field="retry_delay_seconds", maximum=86_400),
        "dry_run": bool(value.get("dry_run", False)),
        "cooldown_scope": str(value.get("cooldown_scope") or "entity").strip().lower(),
    }
    if clean["cooldown_scope"] not in {"entity", "global"}:
        raise ValueError("AUTOMATION_COOLDOWN_SCOPE_INVALID")
    return clean


def _canonical_rule_payload(*, name: Any, trigger: Any, conditions: Any, actions: Any, guards: Any, enabled: Any) -> dict[str, Any]:
    clean_trigger = str(trigger or "").strip().lower()
    if clean_trigger not in ALLOWED_TRIGGERS:
        raise ValueError("AUTOMATION_TRIGGER_INVALID")
    clean_name = str(name or "").strip()
    if not clean_name:
        raise ValueError("AUTOMATION_NAME_REQUIRED")
    if not isinstance(actions, list) or not actions or len(actions) > _MAX_ACTIONS_PER_RULE:
        raise ValueError("AUTOMATION_ACTION_REQUIRED")
    return {
        "name": clean_name[:160],
        "trigger": clean_trigger,
        "conditions": _validate_conditions(conditions),
        "actions": [_clean_action(item) for item in actions],
        "guards": _validate_guards(guards),
        "enabled": bool(enabled),
    }


def create_automation_rule(
    db: dict[str, Any], *, name: str, trigger: str,
    conditions: list[dict[str, Any]] | dict[str, Any] | None,
    actions: list[dict[str, Any]], guards: dict[str, Any] | None,
    actor_id: int | str, enabled: bool = False,
) -> dict[str, Any]:
    canonical = _canonical_rule_payload(
        name=name, trigger=trigger, conditions=conditions, actions=actions, guards=guards, enabled=enabled,
    )
    row = {
        "id": _rule_id(db), **canonical,
        "status": "active" if canonical["enabled"] else "draft",
        "created_by": str(actor_id), "created_at": utc_iso(), "updated_at": utc_iso(),
        "success_count": 0, "failure_count": 0, "consecutive_failure_count": 0,
        "last_run_at": "", "last_error": "", "version": 1,
    }
    db.setdefault("automation_rules_v2", {})[row["id"]] = row
    db.setdefault("automation_v2_audit", []).append({
        "action": "rule_created", "rule_id": row["id"], "actor_id": str(actor_id), "created_at": utc_iso(),
    })
    return copy.deepcopy(row)


def update_automation_rule(db: dict[str, Any], rule_id: str, changes: dict[str, Any], *, actor_id: int | str) -> dict[str, Any]:
    row = db.setdefault("automation_rules_v2", {}).get(str(rule_id))
    if not isinstance(row, dict) or row.get("deleted_at"):
        raise ValueError("AUTOMATION_RULE_NOT_FOUND")
    allowed = {"name", "trigger", "conditions", "actions", "guards", "enabled"}
    merged = {key: copy.deepcopy(row.get(key)) for key in allowed}
    for key, value in dict(changes or {}).items():
        if key in allowed:
            merged[key] = copy.deepcopy(value)
    canonical = _canonical_rule_payload(**merged)
    row.update(canonical)
    row["status"] = "active" if row.get("enabled") else "draft"
    row["updated_at"] = utc_iso()
    row["updated_by"] = str(actor_id)
    row["version"] = int(row.get("version", 1) or 1) + 1
    db.setdefault("automation_v2_audit", []).append({
        "action": "rule_updated", "rule_id": row["id"], "actor_id": str(actor_id), "created_at": utc_iso(),
    })
    return copy.deepcopy(row)


def list_automation_rules(db: dict[str, Any], *, enabled: bool | None = None) -> list[dict[str, Any]]:
    rows = [copy.deepcopy(row) for row in db.get("automation_rules_v2", {}).values() if isinstance(row, dict) and not row.get("deleted_at")]
    if enabled is not None:
        rows = [row for row in rows if bool(row.get("enabled")) is bool(enabled)]
    return sorted(rows, key=lambda row: str(row.get("created_at") or ""), reverse=True)


def _get(event: dict[str, Any], field: str) -> Any:
    value: Any = event
    for part in str(field or "").split("."):
        if not isinstance(value, dict):
            return None
        value = value.get(part)
    return value


def _strict_equal(actual: Any, expected: Any) -> bool:
    if actual is None or expected is None:
        return actual is expected
    if isinstance(actual, bool) or isinstance(expected, bool):
        return isinstance(actual, bool) and isinstance(expected, bool) and actual is expected
    if isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
        return float(actual) == float(expected)
    if isinstance(actual, str) and isinstance(expected, str):
        return actual.casefold() == expected.casefold()
    return actual == expected


def _condition(condition: dict[str, Any], event: dict[str, Any]) -> bool:
    if "all" in condition:
        return all(_condition(item, event) for item in condition.get("all") or [])
    if "any" in condition:
        return any(_condition(item, event) for item in condition.get("any") or [])
    field = str(condition.get("field") or "")
    operator = str(condition.get("operator") or "eq").lower()
    actual = _get(event, field)
    expected = condition.get("value")
    if operator == "exists":
        return actual not in (None, "", [], {})
    if operator == "not_exists":
        return actual in (None, "", [], {})
    if operator == "eq":
        return _strict_equal(actual, expected)
    if operator == "ne":
        return not _strict_equal(actual, expected)
    if operator == "contains":
        return str(expected).casefold() in str(actual if actual is not None else "").casefold()
    if operator == "in":
        values = expected if isinstance(expected, (list, tuple, set)) else [expected]
        return any(_strict_equal(actual, item) for item in values)
    if operator == "not_in":
        values = expected if isinstance(expected, (list, tuple, set)) else [expected]
        return not any(_strict_equal(actual, item) for item in values)
    try:
        left, right = float(actual), float(expected)
    except (TypeError, ValueError):
        return False
    return {"gt": left > right, "gte": left >= right, "lt": left < right, "lte": left <= right}.get(operator, False)


def _matches(conditions: Any, event: dict[str, Any]) -> bool:
    if not conditions:
        return True
    if isinstance(conditions, list):
        return all(_condition(item, event) for item in conditions)
    return _condition(conditions, event) if isinstance(conditions, dict) else False


def _render(value: Any, event: dict[str, Any]) -> Any:
    if isinstance(value, dict):
        return {key: _render(item, event) for key, item in value.items()}
    if isinstance(value, list):
        return [_render(item, event) for item in value]
    if not isinstance(value, str):
        return value

    def replace(match: re.Match[str]) -> str:
        resolved = _get(event, match.group(1))
        return "" if resolved is None else str(resolved)

    return re.sub(r"{{\s*([\w.]+)\s*}}", replace, value)


def _event_key(trigger: str, event: dict[str, Any]) -> str:
    explicit = str(event.get("event_id") or event.get("idempotency_key") or "").strip()
    if explicit:
        return explicit[:200]
    payload = json.dumps(event, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(f"{trigger}:{payload}".encode()).hexdigest()[:40]


def _entity_id(event: dict[str, Any]) -> str:
    return str(event.get("user_id") or event.get("entity_id") or event.get("order_id") or event.get("ticket_id") or "")


def _guard_allows(db: dict[str, Any], rule: dict[str, Any], event: dict[str, Any]) -> tuple[bool, str]:
    guards = _validate_guards(rule.get("guards"))
    history = [row for row in db.setdefault("automation_v2_runs", []) if isinstance(row, dict)]
    now = _now()
    rule_id = str(rule.get("id"))
    entity = _entity_id(event)
    today = now.date().isoformat()
    max_daily = guards["max_runs_per_day"]
    if max_daily and sum(
        1 for row in history
        if row.get("rule_id") == rule_id and str(row.get("created_at") or "").startswith(today) and row.get("status") == "completed" and not row.get("dry_run")
    ) >= max_daily:
        return False, "daily_cap"
    max_entity = guards["max_runs_per_entity"]
    if max_entity and entity and sum(
        1 for row in history
        if row.get("rule_id") == rule_id and row.get("entity_id") == entity and row.get("status") == "completed" and not row.get("dry_run")
    ) >= max_entity:
        return False, "entity_cap"
    cooldown = guards["cooldown_seconds"]
    if cooldown:
        scope = guards["cooldown_scope"]
        latest = next((
            row for row in reversed(history)
            if row.get("rule_id") == rule_id and row.get("status") == "completed" and not row.get("dry_run")
            and (scope == "global" or not entity or row.get("entity_id") == entity)
        ), None)
        if latest:
            dt = parse_dt(latest.get("completed_at") or latest.get("created_at"))
            if dt and (now - dt).total_seconds() < cooldown:
                return False, "cooldown"
    return True, ""


def _validate_rendered_action(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    # Re-run the same schema after template expansion. This closes the gap where
    # a syntactically valid placeholder resolves to an empty/unsafe value.
    return _clean_action({"type": kind, "payload": payload})["payload"]


def _queue_general_job(db: dict[str, Any], *, kind: str, payload: dict[str, Any], rule: dict[str, Any], run_id: str, action_index: int) -> dict[str, Any]:
    row_id = _job_id(db)
    guards = _validate_guards(rule.get("guards"))
    row = {
        "id": row_id, "kind": kind, "payload": copy.deepcopy(payload), "rule_id": str(rule.get("id") or ""),
        "run_id": run_id, "action_index": action_index, "status": "pending", "attempts": 0,
        "max_attempts": max(1, guards.get("max_retries", 3) + 1), "next_attempt_at": utc_iso(),
        "created_at": utc_iso(), "updated_at": utc_iso(), "last_error": "",
    }
    db.setdefault("automation_v2_jobs", {})[row_id] = row
    return row


def _assign_admin(db: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    admin_id = _validate_recipient(payload.get("admin_id"), field="admin_id")
    target_id = _require_text(payload, "target_id", maximum=100)
    target_type = str(payload.get("target_type") or "ticket").lower()
    if target_type == "ticket":
        for section in ("tickets", "support_tickets"):
            rows = db.get(section)
            iterable: Iterable[dict[str, Any]] = rows.values() if isinstance(rows, dict) else rows if isinstance(rows, list) else []
            for row in iterable:
                if isinstance(row, dict) and str(row.get("id") or row.get("ticket_id") or "") == target_id:
                    row["assigned_admin"] = admin_id
                    row["updated_at"] = utc_iso()
                    return row
        raise ValueError("AUTOMATION_ASSIGN_TARGET_NOT_FOUND")
    if target_type == "campaign":
        row = db.setdefault("marketing_campaigns", {}).get(target_id)
        if not isinstance(row, dict):
            raise ValueError("AUTOMATION_ASSIGN_TARGET_NOT_FOUND")
        row["assigned_admin"] = admin_id
        row["updated_at"] = utc_iso()
        return row
    for row in db.setdefault("automation_tasks", []):
        if isinstance(row, dict) and str(row.get("id") or "") == target_id:
            row["assigned_admin"] = admin_id
            row["updated_at"] = utc_iso()
            return row
    raise ValueError("AUTOMATION_ASSIGN_TARGET_NOT_FOUND")


def _execute_action(
    db: dict[str, Any], rule: dict[str, Any], action: dict[str, Any], event: dict[str, Any],
    *, dry_run: bool, run_id: str, action_index: int,
) -> dict[str, Any]:
    kind = str(action.get("type") or "")
    payload = _validate_rendered_action(kind, _render(action.get("payload") or {}, event))
    result: dict[str, Any] = {"type": kind, "payload": copy.deepcopy(payload), "dry_run": dry_run}
    if dry_run:
        return result

    if kind in {"send_message", "notify_admin"}:
        if kind == "send_message":
            recipient = payload.get("recipient_id", payload.get("user_id"))
            scope = "user"
        else:
            recipient = payload.get("recipient_id", payload.get("admin_id", SETTINGS.primary_admin_id))
            scope = "admin"
        row = enqueue_automation_message(
            db,
            dedupe_key=f"av2:{rule.get('id')}:{run_id}:{action_index}",
            kind=kind,
            recipient_id=_validate_recipient(recipient),
            recipient_scope=scope,
            payload={
                "text": str(payload.get("text") or "")[:4096],
                "parse_mode": str(payload.get("parse_mode") or "HTML"),
                "disable_web_page_preview": bool(payload.get("disable_web_page_preview", True)),
                "buttons": copy.deepcopy(payload.get("buttons") or []),
                **({"attachment": copy.deepcopy(payload["attachment"])} if isinstance(payload.get("attachment"), dict) else {}),
            },
            max_attempts=max(1, _validate_guards(rule.get("guards"))["max_retries"] + 1),
            priority=_as_int(payload.get("priority", 3), field="priority", minimum=1, maximum=5),
        )
        result["outbox_id"] = row["id"]
    elif kind in {"add_tag", "remove_tag"}:
        user_id = _validate_recipient(payload.get("user_id") or event.get("user_id"), field="user_id")
        tag = _require_text(payload, "tag", maximum=64)
        profile = db.setdefault("crm_profiles", {}).setdefault(user_id, {"user_id": user_id, "tags": []})
        tags = {str(item) for item in profile.get("tags") or [] if str(item).strip()}
        tags.add(tag) if kind == "add_tag" else tags.discard(tag)
        profile["tags"] = sorted(tags)
        profile["updated_at"] = utc_iso()
    elif kind == "create_task":
        row = {"id": _task_id(db), "kind": "task", **payload, "status": str(payload.get("status") or "open"), "created_at": utc_iso(), "updated_at": utc_iso()}
        db.setdefault("automation_tasks", []).append(row)
        result["task_id"] = row["id"]
    elif kind == "create_ticket":
        row = {
            "id": _task_id(db), "kind": "ticket", "user_id": _validate_recipient(payload.get("user_id"), field="user_id"),
            "subject": _require_text(payload, "subject", maximum=200), "message": _require_text(payload, "message", maximum=4000),
            "status": "open", "waiting_for": "admin", "source": "automation_v2", "created_at": utc_iso(), "updated_at": utc_iso(),
        }
        db.setdefault("tickets", []).append(row)
        result["ticket_id"] = row["id"]
    elif kind == "queue_campaign":
        campaign_id = _require_text(payload, "campaign_id", maximum=80)
        campaign = db.setdefault("marketing_campaigns", {}).get(campaign_id)
        if not isinstance(campaign, dict):
            raise ValueError("AUTOMATION_CAMPAIGN_NOT_FOUND")
        campaign["status"] = "queued"
        campaign["schedule_status"] = "pending"
        campaign["updated_at"] = utc_iso()
        result["campaign_id"] = campaign_id
    elif kind == "ai_draft":
        row = {"id": _job_id(db), **payload, "status": "pending", "created_at": utc_iso(), "updated_at": utc_iso(), "rule_id": rule.get("id")}
        db.setdefault("automation_ai_drafts", []).append(row)
        result["draft_id"] = row["id"]
    elif kind == "stop_feature":
        feature = str(payload.get("feature") or "").strip().lower()
        if not _FEATURE_RE.fullmatch(feature):
            raise ValueError("AUTOMATION_FEATURE_INVALID")
        db.setdefault("feature_flags", {})[feature] = False
        result["feature"] = feature
    elif kind == "webhook":
        payload["url"] = _validate_webhook_url(payload.get("url"))
        row = _queue_general_job(db, kind="webhook", payload=payload, rule=rule, run_id=run_id, action_index=action_index)
        result["job_id"] = row["id"]
    elif kind == "create_coupon":
        days = _as_int(payload.get("days", 7), field="coupon_days", minimum=1, maximum=365)
        row = create_public_discount(
            db,
            code=str(payload.get("code") or ""),
            percent=_as_int(payload.get("percent"), field="coupon_percent", minimum=1, maximum=100),
            starts_at=utc_iso(),
            ends_at=utc_iso(_now() + timedelta(days=days)),
            max_uses=_as_int(payload.get("max_uses", 0), field="coupon_max_uses", maximum=1_000_000),
            one_per_user=bool(payload.get("one_per_user", True)),
            created_by=str(rule.get("created_by") or "automation_v2"),
        )
        result["coupon_code"] = row["code"]
    elif kind == "assign_admin":
        assigned = _assign_admin(db, payload)
        result["assigned_target"] = str(assigned.get("id") or assigned.get("ticket_id") or "")
    elif kind == "write_log":
        row = {"id": _job_id(db), **payload, "created_at": utc_iso(), "rule_id": rule.get("id"), "run_id": run_id}
        db.setdefault("automation_custom_log", []).append(row)
        result["log_id"] = row["id"]
    else:
        raise ValueError("AUTOMATION_ACTION_INVALID")
    return result


def _snapshot_sections(db: dict[str, Any]) -> dict[str, Any]:
    return {key: copy.deepcopy(db[key]) if key in db else None for key in _TRANSACTION_SECTIONS}


def _restore_sections(db: dict[str, Any], snapshot: dict[str, Any]) -> None:
    for key, value in snapshot.items():
        if value is None:
            db.pop(key, None)
        else:
            db[key] = value


def _actor_allowed(db: dict[str, Any], actor_id: int | str) -> bool:
    text = str(actor_id or "")
    if text in {"system", "scheduler", "event_bus", "automation_v2"}:
        return True
    return bool(is_primary_admin(actor_id) or has_permission(db, actor_id, "automations"))


def _idempotency_entry_active(entry: Any) -> bool:
    if not isinstance(entry, dict):
        return False
    status = str(entry.get("status") or "")
    if status == "completed":
        return True
    if status != "running":
        return False
    reserved = parse_dt(entry.get("reserved_at"))
    return bool(reserved and (_now() - reserved).total_seconds() < _IDEMPOTENCY_LEASE_SECONDS)


def process_automation_event(
    db: dict[str, Any], trigger: str, event: dict[str, Any], *, actor_id: int | str = "system", test_rule_id: str = "",
) -> dict[str, Any]:
    clean_trigger = str(trigger or "").strip().lower()
    if clean_trigger not in ALLOWED_TRIGGERS:
        raise ValueError("AUTOMATION_TRIGGER_INVALID")
    if not isinstance(event, dict):
        raise ValueError("AUTOMATION_EVENT_INVALID")
    if not _actor_allowed(db, actor_id):
        raise PermissionError("AUTOMATION_PERMISSION_REQUIRED")

    from modules.management_suite import automation_settings
    if not automation_settings(db).get("enabled",True):
        return {"trigger":clean_trigger,"matched":[],"count":0,"paused":True,"generated_at":utc_iso()}
    event_key = _event_key(clean_trigger, event)
    matched: list[dict[str, Any]] = []
    idempotency = db.setdefault("automation_v2_idempotency", {})
    # Operate on canonical rows, not deep-copied list output, so counters,
    # pause state and diagnostic errors persist in the same transaction.
    rules = [
        row for row in db.setdefault("automation_rules_v2", {}).values()
        if isinstance(row, dict) and bool(row.get("enabled")) and not row.get("deleted_at")
    ]
    rules.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    if test_rule_id:
        rules = [row for row in rules if str(row.get("id")) == str(test_rule_id)]

    for rule in rules:
        if str(rule.get("trigger") or "").lower() != clean_trigger:
            continue
        try:
            canonical = _canonical_rule_payload(
                name=rule.get("name"), trigger=rule.get("trigger"), conditions=rule.get("conditions"),
                actions=rule.get("actions"), guards=rule.get("guards"), enabled=rule.get("enabled"),
            )
            rule.update(canonical)
            if not _matches(rule.get("conditions"), event):
                continue
            allowed, reason = _guard_allows(db, rule, event)
        except Exception as exc:
            rule["last_error"] = f"{exc.__class__.__name__}:{str(exc)[:300]}"
            matched.append({"rule_id": rule.get("id"), "status": "invalid_rule", "error": rule["last_error"]})
            continue
        if not allowed:
            matched.append({"rule_id": rule["id"], "status": "guarded", "reason": reason})
            continue

        guards = _validate_guards(rule.get("guards"))
        dry_run = bool(guards.get("dry_run") or event.get("dry_run"))
        namespace = "dry" if dry_run else "live"
        unique = f"{namespace}:{rule['id']}:{event_key}"
        existing = idempotency.get(unique)
        if _idempotency_entry_active(existing):
            matched.append({
                "rule_id": rule["id"], "status": "duplicate",
                "run_id": existing.get("run_id") if isinstance(existing, dict) else existing,
                "dry_run": dry_run,
            })
            continue

        run_id = _run_id(db)
        attempt = int(existing.get("attempt", 0) or 0) + 1 if isinstance(existing, dict) else 1
        idempotency[unique] = {"status": "running", "run_id": run_id, "reserved_at": utc_iso(), "attempt": attempt}
        run = {
            "id": run_id, "rule_id": rule["id"], "event_key": event_key, "entity_id": _entity_id(event),
            "status": "running", "dry_run": dry_run, "created_at": utc_iso(), "actor_id": str(actor_id),
            "results": [], "attempt": attempt,
        }
        db.setdefault("automation_v2_runs", []).append(run)
        transaction_snapshot = _snapshot_sections(db)
        try:
            for index, action in enumerate(rule.get("actions", [])):
                run["results"].append(_execute_action(
                    db, rule, action, event, dry_run=dry_run, run_id=run_id, action_index=index,
                ))
            run["status"] = "completed"
            rule["success_count"] = int(rule.get("success_count", 0) or 0) + (0 if dry_run else 1)
            rule["consecutive_failure_count"] = 0
            rule["last_error"] = ""
            idempotency[unique] = {
                "status": "completed", "run_id": run_id, "completed_at": utc_iso(), "attempt": attempt,
            }
        except Exception as exc:
            _restore_sections(db, transaction_snapshot)
            error = f"{exc.__class__.__name__}:{str(exc)[:300]}"
            run["status"] = "failed"
            run["error"] = error
            rule["failure_count"] = int(rule.get("failure_count", 0) or 0) + 1
            rule["consecutive_failure_count"] = int(rule.get("consecutive_failure_count", 0) or 0) + 1
            rule["last_error"] = error
            threshold = guards.get("disable_after_failures", 0)
            if threshold and int(rule.get("consecutive_failure_count", 0)) >= threshold:
                rule["enabled"] = False
                rule["status"] = "paused"
            # Failed reservations remain diagnostic but do not block a retry.
            idempotency[unique] = {
                "status": "failed", "run_id": run_id, "failed_at": utc_iso(), "attempt": attempt, "error": error,
            }
        rule["last_run_at"] = utc_iso()
        run["completed_at"] = utc_iso()
        matched.append({
            "rule_id": rule["id"], "status": run["status"], "run_id": run_id,
            "dry_run": dry_run, "attempt": attempt,
        })
    return {
        "trigger": clean_trigger, "event_key": event_key, "matched": matched,
        "count": len(matched), "generated_at": utc_iso(),
    }
