from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from modules.prop_rules_v2 import PropRuleEngine
from repositories.v2.accounts import AccountRepository
from repositories.v2.common import json_dump, json_load, new_id, utc_iso
from repositories.v2.mt5_connectors import MT5ConnectorRepository
from repositories.v2.positions import PositionRepository


def _number(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _latest_snapshot(engine: DatabaseEngine, account_id: str) -> dict[str, Any] | None:
    with engine.transaction(read_only=True) as cursor:
        row = cursor.execute(
            "SELECT payload FROM v8_broker_snapshots WHERE account_id=? ORDER BY observed_at DESC LIMIT 1",
            (str(account_id),),
        ).fetchone()
    return json_load((row or {}).get("payload"), None)


def _broker_position_metrics(snapshot: dict[str, Any] | None, equity: float) -> dict[str, Any]:
    positions = snapshot.get("positions") if isinstance(snapshot, dict) and isinstance(snapshot.get("positions"), list) else []
    risk_money = 0.0
    missing_stop = 0
    negative_float = 0.0
    symbols: dict[str, int] = {}
    rows: list[dict[str, Any]] = []
    for raw in positions[:300]:
        if not isinstance(raw, dict):
            continue
        symbol = str(raw.get("symbol") or "").upper().replace("/", "")
        stop = _number(raw.get("sl") or raw.get("stop"))
        risk = max(0.0, _number(raw.get("risk_money")))
        profit = _number(raw.get("profit")) + _number(raw.get("swap")) + _number(raw.get("commission"))
        if stop <= 0:
            missing_stop += 1
        risk_money += risk
        negative_float += min(0.0, profit)
        if symbol:
            symbols[symbol] = symbols.get(symbol, 0) + 1
        rows.append({
            "ticket": str(raw.get("ticket") or raw.get("identifier") or ""),
            "symbol": symbol,
            "side": str(raw.get("side") or raw.get("type") or ""),
            "volume": _number(raw.get("volume")),
            "entry": _number(raw.get("price_open") or raw.get("entry")),
            "stop": stop,
            "take_profit": _number(raw.get("tp") or raw.get("take_profit")),
            "current_price": _number(raw.get("price_current") or raw.get("current_price")),
            "profit": profit,
            "risk_money": risk,
            "risk_percent": risk / max(equity, 1e-9) * 100,
            "missing_stop": stop <= 0,
        })
    duplicates = [{"symbol": symbol, "count": count} for symbol, count in symbols.items() if count > 1]
    return {
        "open_count": len(rows),
        "risk_money": round(risk_money, 4),
        "risk_percent": round(risk_money / max(equity, 1e-9) * 100, 4),
        "missing_stop_count": missing_stop,
        "floating_loss": round(abs(negative_float), 4),
        "symbol_concentration": sorted(duplicates, key=lambda item: item["count"], reverse=True),
        "items": rows,
    }


def _capacity(actual: float, limit: float) -> dict[str, Any]:
    remaining = max(0.0, limit - actual)
    usage = actual / max(limit, 1e-9) * 100 if limit > 0 else 100.0
    level = "danger" if usage >= 90 else "warning" if usage >= 75 else "watch" if usage >= 50 else "safe"
    return {"actual": round(actual, 4), "limit": round(limit, 4), "remaining": round(remaining, 4), "usage_percent": round(usage, 2), "level": level}


def _persist_alerts(
    engine: DatabaseEngine, user_id: str, account_id: str, alerts: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Persist the active alert set and return only newly activated alerts.

    A connector can upload a snapshot every few seconds. Returning only alerts
    that were not active before this transaction prevents duplicate Telegram
    notifications while still allowing an alert to notify again after it was
    resolved and later reappeared.
    """
    now = utc_iso()
    active_fingerprints: set[str] = set()
    newly_active: list[dict[str, Any]] = []
    with engine.transaction() as cursor:
        previous_rows = cursor.execute(
            "SELECT fingerprint FROM v8_prop_alerts WHERE account_id=? AND status='active'",
            (account_id,),
        ).fetchall()
        previously_active = {str(row.get("fingerprint") or "") for row in previous_rows}
        for raw_alert in alerts:
            alert = dict(raw_alert)
            fingerprint = hashlib.sha256(
                f"{account_id}|{alert.get('code')}|{alert.get('severity')}".encode("utf-8")
            ).hexdigest()
            active_fingerprints.add(fingerprint)
            alert["fingerprint"] = fingerprint
            alert["activated_at"] = now
            if fingerprint not in previously_active:
                newly_active.append(dict(alert))
            cursor.execute(
                """INSERT INTO v8_prop_alerts(id,user_id,account_id,code,severity,status,observed_at,resolved_at,fingerprint,payload)
                   VALUES(?,?,?,?,?,'active',?,NULL,?,?) ON CONFLICT(account_id,fingerprint) DO UPDATE SET
                   severity=excluded.severity,status='active',observed_at=excluded.observed_at,resolved_at=NULL,payload=excluded.payload""",
                (
                    new_id("palert"), user_id, account_id, str(alert.get("code") or "UNKNOWN"),
                    str(alert.get("severity") or "warning"), now, fingerprint, json_dump(alert),
                ),
            )
        rows = cursor.execute(
            "SELECT id,fingerprint FROM v8_prop_alerts WHERE account_id=? AND status='active'",
            (account_id,),
        ).fetchall()
        for row in rows:
            if str(row.get("fingerprint") or "") not in active_fingerprints:
                cursor.execute(
                    "UPDATE v8_prop_alerts SET status='resolved',resolved_at=? WHERE id=?",
                    (now, str(row["id"])),
                )
    return newly_active


def account_guardian_snapshot(
    user_id: int | str,
    account_id: int | str,
    *,
    candidate: dict[str, Any] | None = None,
    news_events: list[dict[str, Any]] | None = None,
    record: bool = False,
    engine: DatabaseEngine | None = None,
) -> dict[str, Any]:
    db = engine or normalized_engine()
    uid, aid = str(user_id), str(account_id)
    account = AccountRepository(db).get(uid, aid)
    if not account:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    normalized_candidate = dict(candidate or {})
    if normalized_candidate:
        normalized_candidate["actual_entry"] = _number(normalized_candidate.get("actual_entry") or normalized_candidate.get("entry"))
        normalized_candidate["actual_stop"] = _number(normalized_candidate.get("actual_stop") or normalized_candidate.get("stop") or normalized_candidate.get("stop_loss"))
        normalized_candidate["side"] = str(normalized_candidate.get("side") or normalized_candidate.get("direction") or "").upper()
        if _number(normalized_candidate.get("risk_percent")) <= 0 and _number(normalized_candidate.get("risk_money")) > 0:
            normalized_candidate["risk_percent"] = _number(normalized_candidate.get("risk_money")) / max(_number(account.get("equity") or account.get("balance")), 1e-9) * 100
    engine_decision = PropRuleEngine(db).evaluate(
        user_id=uid, account_id=aid, candidate=normalized_candidate or None, news_events=news_events or [], record=record,
    )
    snapshot = _latest_snapshot(db, aid)
    equity = _number(account.get("equity") or account.get("balance"))
    broker_positions = _broker_position_metrics(snapshot, equity)
    connectors = MT5ConnectorRepository(db).list_for_user(uid, aid)
    connector = connectors[0] if connectors else None
    metrics = dict(engine_decision.metrics)
    daily = _capacity(_number(metrics.get("daily_loss_percent")), _number(metrics.get("daily_loss_limit_percent")))
    total = _capacity(_number(metrics.get("total_drawdown_percent")), _number(metrics.get("total_loss_limit_percent")))
    open_risk_limit = _number((PropRuleEngine(db).get_template(engine_decision.template_id).get("rules") or {}).get("max_open_risk_percent"), _number(account.get("max_open_risk_percent"), 5.0))
    live_open_risk = max(_number(metrics.get("open_risk_percent")), _number(broker_positions.get("risk_percent")))
    open_risk = _capacity(live_open_risk, open_risk_limit)
    profit_progress = _number(metrics.get("profit_progress_percent"))

    alerts: list[dict[str, Any]] = []
    coach_blocks: list[dict[str, Any]] = []
    daily_plan: dict[str, Any] | None = None
    if normalized_candidate:
        try:
            from services.risk_coach_service import get_or_create_daily_plan
            daily_plan = get_or_create_daily_plan(uid, aid, engine=db)
        except (ValueError, PermissionError):
            daily_plan = None
        candidate_risk = _number(normalized_candidate.get("risk_percent"))
        if daily_plan and candidate_risk > _number(daily_plan.get("max_risk_per_trade_percent")) + 1e-9:
            coach_blocks.append({
                "code": "DAILY_PLAN_TRADE_RISK_EXCEEDED", "severity": "critical",
                "actual": candidate_risk, "limit": _number(daily_plan.get("max_risk_per_trade_percent")),
                "title_fa": "ریسک معامله از برنامه امروز بیشتر است", "title_en": "Trade risk exceeds today's plan",
            })
        entry = _number(normalized_candidate.get("actual_entry"))
        stop = _number(normalized_candidate.get("actual_stop"))
        target = _number(normalized_candidate.get("take_profit") or normalized_candidate.get("target"))
        if target > 0 and entry > 0 and stop > 0:
            rr = abs(target - entry) / max(abs(entry - stop), 1e-9)
            normalized_candidate["reward_risk_ratio"] = rr
            if daily_plan and rr + 1e-9 < _number(daily_plan.get("minimum_rr"), 2.0):
                coach_blocks.append({
                    "code": "DAILY_PLAN_MINIMUM_RR_NOT_MET", "severity": "critical", "actual": round(rr, 3),
                    "limit": _number(daily_plan.get("minimum_rr"), 2.0),
                    "title_fa": "ریسک به ریوارد از برنامه امروز کمتر است", "title_en": "Reward-to-risk is below today's plan",
                })
    for block in engine_decision.hard_blocks:
        alerts.append({**dict(block), "severity": "critical", "source": "prop_rule_engine"})
    for warning in engine_decision.warnings:
        alerts.append({**dict(warning), "severity": "warning", "source": "prop_rule_engine"})
    if broker_positions["missing_stop_count"]:
        alerts.append({
            "code": "OPEN_POSITION_WITHOUT_STOP", "severity": "critical",
            "title_fa": "معامله باز بدون حد ضرر", "title_en": "Open position without stop loss",
            "count": broker_positions["missing_stop_count"], "source": "mt5_connector",
        })
    for capacity_name, capacity in (("DAILY_LOSS_CAPACITY", daily), ("TOTAL_DRAWDOWN_CAPACITY", total), ("OPEN_RISK_CAPACITY", open_risk)):
        if capacity["usage_percent"] >= 50:
            alerts.append({
                "code": capacity_name, "severity": "critical" if capacity["usage_percent"] >= 90 else "warning",
                "usage_percent": capacity["usage_percent"], "remaining": capacity["remaining"], "source": "capacity_monitor",
            })
    if connector and connector.get("status") in {"offline", "stale"}:
        alerts.append({
            "code": "MT5_CONNECTION_STALE", "severity": "warning", "age_seconds": connector.get("age_seconds"),
            "title_fa": "اتصال متاتریدر تازه نیست", "title_en": "MetaTrader connection is stale", "source": "connector_health",
        })
    if broker_positions["symbol_concentration"]:
        alerts.append({
            "code": "SYMBOL_CONCENTRATION", "severity": "warning", "items": broker_positions["symbol_concentration"],
            "title_fa": "تمرکز چند معامله روی یک نماد", "title_en": "Multiple positions are concentrated in one symbol", "source": "portfolio",
        })

    alerts.extend(coach_blocks)

    passed = profit_progress >= 100 and int(metrics.get("trading_days") or 0) >= int(metrics.get("min_trading_days") or 0) and not engine_decision.hard_blocks
    if passed:
        status = "passed"
    elif engine_decision.hard_blocks or coach_blocks or broker_positions["missing_stop_count"]:
        status = "blocked"
    elif any(item.get("severity") in {"critical", "warning"} for item in alerts):
        status = "warning"
    else:
        status = "safe"
    worst_case_loss = broker_positions["risk_money"]
    projected_equity = equity - worst_case_loss
    starting = max(_number(account.get("starting_balance") or account.get("balance")), 1e-9)
    what_if = {
        "all_stops_loss_amount": round(worst_case_loss, 4),
        "equity_after_all_stops": round(projected_equity, 4),
        "projected_total_drawdown_percent": round(max(0.0, (starting - projected_equity) / starting * 100), 4),
        "would_breach_daily_loss": daily["remaining"] <= broker_positions["risk_percent"],
        "would_breach_total_loss": total["remaining"] <= broker_positions["risk_percent"],
    }
    newly_active_alerts = _persist_alerts(db, uid, aid, alerts) if record else []
    return {
        "account": account,
        "status": status,
        "decision": engine_decision.decision,
        "template_id": engine_decision.template_id,
        "rules_version": engine_decision.rules_version,
        "metrics": metrics,
        "capacity": {"daily_loss": daily, "total_drawdown": total, "open_risk": open_risk},
        "broker_positions": broker_positions,
        "connector": connector,
        "connectors": connectors,
        "alerts": alerts,
        "new_alerts": newly_active_alerts,
        "hard_blocks": [*list(engine_decision.hard_blocks), *coach_blocks],
        "warnings": list(engine_decision.warnings),
        "what_if": what_if,
        "daily_plan": daily_plan,
        "pretrade": {
            "candidate": normalized_candidate or None,
            "allowed": not engine_decision.hard_blocks and not coach_blocks,
            "decision": "allow" if not engine_decision.hard_blocks and not coach_blocks else "block",
            "coach_blocks": coach_blocks,
        },
        "generated_at": utc_iso(),
    }


def prop_guardian_dashboard(
    user_id: int | str,
    *,
    account_id: int | str | None = None,
    record: bool = False,
    engine: DatabaseEngine | None = None,
) -> dict[str, Any]:
    db = engine or normalized_engine()
    accounts = AccountRepository(db).list_for_user(user_id)
    rows: list[dict[str, Any]] = []
    for account in accounts:
        if account_id not in {None, ""} and str(account["id"]) != str(account_id):
            continue
        try:
            rows.append(account_guardian_snapshot(user_id, account["id"], record=record, engine=db))
        except (ValueError, PermissionError) as exc:
            rows.append({"account": account, "status": "unavailable", "reason": str(exc), "alerts": []})
    severity_order = {"blocked": 4, "warning": 3, "unavailable": 2, "safe": 1, "passed": 0}
    overall = max(rows, key=lambda row: severity_order.get(str(row.get("status")), 2), default={"status": "unconfigured"}).get("status", "unconfigured")
    return {
        "status": overall,
        "accounts": rows,
        "summary": {
            "account_count": len(rows),
            "connected_count": sum(1 for row in rows if (row.get("connector") or {}).get("status") == "online"),
            "blocked_count": sum(1 for row in rows if row.get("status") == "blocked"),
            "warning_count": sum(1 for row in rows if row.get("status") == "warning"),
            "active_alerts": sum(len(row.get("alerts") or []) for row in rows),
        },
        "generated_at": datetime.now(UTC).isoformat(),
    }
