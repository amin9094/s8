"""Shared reward-store operation for Telegram and Mini App transports.
Call claims only inside with_db: debit, delivery and claim evidence commit together.
"""

from core.domain import (
    activate_vip,
    add_points,
    assign_discount_from_pool,
    create_reward_request,
    discount_stock_snapshot,
    ensure_discount_system,
)
from core.utils import parse_dt, utc_iso, utc_now
from modules.advanced_features import record_user_reward


def available_rewards(db, user_id):
    uid = str(user_id)
    now = utc_now()
    claims = list(db.get("reward_shop_claims", {}).values())
    result = []
    for item in db.get("settings", {}).get("rewardItems", []):
        if not item.get("enabled", True) or not item.get("active", True):
            continue
        expiry, start = parse_dt(item.get("expires_at")), parse_dt(item.get("starts_at"))
        if (expiry and expiry <= now) or (start and start > now):
            continue
        related = [row for row in claims if str(row.get("item_id")) == str(item.get("id"))]
        if item.get("stock") is not None and len(related) >= int(item["stock"]):
            continue
        if item.get("per_user_limit") and sum(str(row.get("user_id")) == uid for row in related) >= int(
            item["per_user_limit"]
        ):
            continue
        result.append(dict(item))
    return result


def claim_reward(db: dict, user_id: int | str, reward_id: int, claim_key: str) -> tuple[str, dict | None, str | None]:
    ensure_discount_system(db)
    uid = str(user_id)
    if claim_key in db.setdefault("reward_shop_claims", {}):
        return "error", None, "این درخواست قبلاً ثبت شده؛ جایزه‌های من را بررسی کنید."
    item = next(
        (item for item in db.get("settings", {}).get("rewardItems", []) if int(item.get("id", -1)) == reward_id), None
    )
    if not item or not item.get("enabled", True) or not item.get("active", True):
        return "error", None, "جایزه پیدا نشد یا غیرفعال است."
    starts = parse_dt(item.get("starts_at"))
    if starts and starts > utc_now():
        return "error", None, "زمان دریافت این جایزه هنوز شروع نشده است."
    expiry = parse_dt(item.get("expires_at"))
    if expiry and expiry <= utc_now():
        return "error", None, "مهلت دریافت این جایزه تمام شده است."
    prior = [
        c
        for c in db["reward_shop_claims"].values()
        if str(c.get("user_id")) == uid and int(c.get("item_id", -1)) == reward_id
    ]
    if item.get("per_user_limit") and len(prior) >= int(item["per_user_limit"]):
        return "error", None, "سهم دریافت شما تکمیل شده است."
    total = sum(1 for c in db["reward_shop_claims"].values() if int(c.get("item_id", -1)) == reward_id)
    if item.get("stock") is not None and total >= int(item["stock"]):
        return "error", None, "موجودی جایزه تمام شده است."
    points = int(db.get("user_points", {}).get(uid, 0))
    cost = int(item.get("points", 0))
    if cost < 0:
        return "error", None, "هزینه جایزه معتبر نیست."
    if points < cost:
        return "error", None, f"امتیاز کافی ندارید ({points}/{cost})."
    add_points(db, uid, -cost, f"reward:{reward_id}")
    discount = int(item.get("discountPct", 0) or 0)
    if discount > 0:
        try:
            code, auto_created = assign_discount_from_pool(
                db,
                discount,
                uid,
                issued_via=f"reward:{reward_id}",
                allow_auto_create=True,
                coupon_expires_at=item.get("coupon_expires_at"),
                apply_expiry_policy="coupon_expires_at" in item,
            )
        except ValueError:
            # The caller rolls back the complete canonical transaction.
            raise
        remaining = discount_stock_snapshot(db).get(discount, 0)
        reward = record_user_reward(
            db,
            uid,
            item["name"],
            reward_type="discount",
            detail=f"{code['percent']}% | {code['code']}",
            source="reward_shop",
            status="delivered",
            reference_id=code["code"],
        )
        db["reward_shop_claims"][claim_key] = {
            "user_id": uid,
            "reward_id": reward["id"],
            "item_id": reward_id,
            "created_at": utc_iso(),
        }
        return (
            "discount",
            {"item": item, "code": code, "remaining": remaining, "auto_created": auto_created, "reward": reward},
            None,
        )
    if item.get("type") == "combined":
        from modules.prize_delivery import deliver_prize

        rewards = deliver_prize(
            db,
            uid,
            item["prize"],
            source_event=claim_key,
            title=item["name"],
            source="reward_shop",
            coupon_expires_at=item.get("coupon_expires_at"),
            apply_expiry_policy="coupon_expires_at" in item,
        )
        db["reward_shop_claims"][claim_key] = {
            "user_id": uid,
            "reward_id": rewards[0]["id"] if rewards else claim_key,
            "item_id": reward_id,
            "created_at": utc_iso(),
        }
        return "delivered", {"reward": rewards[0] if rewards else {"title": item["name"]}}, None
    if item.get("type") in {"points", "vip_days"}:
        value = int(item.get("value", 0))
        if value <= 0:
            raise ValueError("مقدار جایزه نامعتبر است.")
        if item["type"] == "points":
            add_points(db, uid, value, f"reward_delivery:{reward_id}", source_event=f"points:{claim_key}")
        else:
            activate_vip(db, uid, value, source_order_id=claim_key)
        reward = record_user_reward(
            db,
            uid,
            item["name"],
            reward_type=item["type"],
            detail=str(value),
            source="reward_shop",
            status="delivered",
            reference_id=claim_key,
        )
        db["reward_shop_claims"][claim_key] = {
            "user_id": uid,
            "reward_id": reward["id"],
            "item_id": reward_id,
            "created_at": utc_iso(),
        }
        return "delivered", {"reward": reward}, None
    request = create_reward_request(db, uid, item)
    reward = record_user_reward(
        db,
        uid,
        item["name"],
        reward_type="manual",
        detail="در انتظار تحویل ادمین",
        source="reward_shop",
        status="pending",
        reference_id=request["id"],
    )
    db["reward_shop_claims"][claim_key] = {
        "user_id": uid,
        "reward_id": reward["id"],
        "item_id": reward_id,
        "created_at": utc_iso(),
    }
    return "request", {"item": item, "request": request, "reward": reward}, None
