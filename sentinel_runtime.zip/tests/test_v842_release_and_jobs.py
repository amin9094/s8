from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import subprocess
import sys
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

import pytest

from modules import campaign_studio
from scripts import live_staging_attestation as live
from scripts import production_acceptance as acceptance
from scripts import quality_utils
from services import campaign_scheduler_service as scheduler


def campaign_state():
    now = datetime.now(UTC)
    return {"marketing_campaigns": {
        key: {"id": key, "status": "scheduled", "version": 1,
              "schedule_status": "processing", "schedule_attempts": 1,
              "schedule_max_attempts": 5, "schedule_claimed_at": now.isoformat(),
              "schedule_next_attempt_at": (now - timedelta(minutes=1)).isoformat()}
        for key in ("CMP-000001", "CMP-000002")}}


@pytest.mark.asyncio
async def test_delayed_campaign_result_cannot_change_next_campaign(monkeypatch):
    state = campaign_state()
    delayed = []
    calls = 0

    async def database(fn):
        nonlocal calls
        calls += 1
        if calls == 1:
            return {"enabled": True, "campaign_scheduler_enabled": True}
        if calls == 2:
            return [{"campaign_id": key, "actor_id": "1", "attempt": 1,
                     "version": 1} for key in state["marketing_campaigns"]]
        if calls == 3:
            # A timed-out thread may execute its callback after the batch moves on.
            delayed.append(fn)
            raise TimeoutError("database result delayed")
        return fn(state)

    async def dispatch(bot, campaign_id, actor_id, **kwargs):
        return {"errors": [] if campaign_id == "CMP-000001" else ["second delivery failed"]}

    monkeypatch.setattr(scheduler, "async_with_db", database)
    monkeypatch.setattr(scheduler, "dispatch_marketing_campaign", dispatch)
    await scheduler.run_campaign_scheduler(None)
    second = copy.deepcopy(state["marketing_campaigns"]["CMP-000002"])
    delayed[0](state)
    assert state["marketing_campaigns"]["CMP-000002"] == second


@pytest.mark.parametrize("status", ["cancelled", "archived", "completed", "paused", "draft"])
def test_late_schedule_result_does_not_reactivate_stopped_campaign(status):
    state = campaign_state()
    row = state["marketing_campaigns"]["CMP-000001"]
    row["status"] = status
    before = copy.deepcopy(state)
    campaign_studio.mark_scheduled_campaign_result(state, row["id"], success=True)
    assert state == before


@pytest.mark.parametrize("changed", ["attempt", "version", "claim"])
def test_stale_schedule_lease_is_rejected(changed):
    state = campaign_state()
    row = state["marketing_campaigns"]["CMP-000001"]
    claim = row["schedule_claimed_at"]
    if changed == "attempt":
        row["schedule_attempts"] = 2
    elif changed == "version":
        row["version"] = 2
    else:
        row["schedule_claimed_at"] = "2026-01-01T00:00:00+00:00"
    before = copy.deepcopy(state)
    campaign_studio.mark_scheduled_campaign_result(
        state, row["id"], success=True, expected_attempt=1,
        expected_version=1, expected_claimed_at=claim)
    assert state == before


def test_schedule_result_is_idempotent_and_failure_cannot_undo_success():
    state = campaign_state()
    row = state["marketing_campaigns"]["CMP-000001"]
    lease = dict(expected_attempt=1, expected_version=1,
                 expected_claimed_at=row["schedule_claimed_at"])
    campaign_studio.mark_scheduled_campaign_result(state, row["id"], success=True, **lease)
    before = copy.deepcopy(state)
    campaign_studio.mark_scheduled_campaign_result(state, row["id"], success=True, **lease)
    campaign_studio.mark_scheduled_campaign_result(state, row["id"], success=False, error="late", **lease)
    assert state == before


@pytest.mark.asyncio
async def test_campaign_database_failure_does_not_drop_remaining_batch(monkeypatch):
    state = campaign_state()
    calls = 0
    delivered = []

    async def database(fn):
        nonlocal calls
        calls += 1
        if calls == 1:
            return {"enabled": True}
        if calls == 2:
            return [{"campaign_id": key, "actor_id": "1", "attempt": 1,
                     "version": 1} for key in state["marketing_campaigns"]]
        if calls in {3, 4}:
            raise TimeoutError("first result and its failure report unavailable")
        return fn(state)

    async def dispatch(bot, campaign_id, actor_id, **kwargs):
        delivered.append(campaign_id)
        return {"errors": []}

    monkeypatch.setattr(scheduler, "async_with_db", database)
    monkeypatch.setattr(scheduler, "dispatch_marketing_campaign", dispatch)
    counts = await scheduler.run_campaign_scheduler(None)
    assert delivered == ["CMP-000001", "CMP-000002"]
    assert counts == {"campaign_failed": 1, "campaign_scheduled": 1}


@pytest.mark.asyncio
async def test_approval_failure_callback_survives_exception_scope(monkeypatch):
    import bot
    from bot_runtime import analytics_governance as handlers

    delayed = []
    state = {"pending_admin_actions": [{"token": "test-token"}]}
    answers = []

    async def permitted(*args, **kwargs):
        return True

    async def execute(*args, **kwargs):
        raise RuntimeError("controlled approval failure")

    async def database(fn):
        if not delayed:
            result = fn(state)
            if isinstance(result, dict):
                delayed.append(None)
                return result
        delayed.append(fn)
        raise TimeoutError("approval audit database slow")

    async def answer(text=None, **kwargs):
        answers.append(text)

    monkeypatch.setattr(handlers, "require_admin", permitted)
    monkeypatch.setattr(handlers, "_is_owner_admin", lambda uid: True)
    monkeypatch.setattr(handlers, "_execute_approved_action", execute)
    monkeypatch.setattr(handlers, "resolve_pending_approval", lambda *args: {"requested_by": "1"})
    monkeypatch.setattr(handlers, "async_with_db", database)
    query = SimpleNamespace(data="approval_accept:test-token", from_user=SimpleNamespace(id=1), answer=answer)
    update = SimpleNamespace(effective_user=SimpleNamespace(id=1), callback_query=query)
    try:
        await bot.approval_review_handler(update, SimpleNamespace())
    except TimeoutError:
        pass
    delayed[-1](state)
    assert state["pending_admin_actions"][0]["execution_error"] == "controlled approval failure"
    assert any(text and "ناموفق" in text for text in answers)


@pytest.mark.parametrize("digest", ["sha256:" + "x" * 64, "sha256:" + "a" * 65, "sha256:" + "a" * 63])
def test_production_rejects_malformed_docker_digest(monkeypatch, digest):
    monkeypatch.setenv("PRIMARY_ADMIN_ID", "1")
    monkeypatch.delenv("SENTINEL_IMAGE_DIGEST", raising=False)
    monkeypatch.setenv("SENTINEL_DOCKER_IMAGE_DIGEST", digest)
    assert acceptance._configuration_check()["ok"] is False


def test_production_accepts_the_quality_gate_digest_name(monkeypatch):
    monkeypatch.setenv("PRIMARY_ADMIN_ID", "1")
    monkeypatch.setenv("SENTINEL_IMAGE_DIGEST", "sha256:" + "a" * 64)
    monkeypatch.delenv("SENTINEL_DOCKER_IMAGE_DIGEST", raising=False)
    assert acceptance._configuration_check()["ok"] is True


def test_conflicting_docker_digest_aliases_are_rejected(monkeypatch):
    monkeypatch.setenv("PRIMARY_ADMIN_ID", "1")
    monkeypatch.setenv("SENTINEL_IMAGE_DIGEST", "sha256:" + "b" * 64)
    monkeypatch.setenv("SENTINEL_DOCKER_IMAGE_DIGEST", "sha256:" + "a" * 64)
    assert acceptance._configuration_check()["ok"] is False


@pytest.mark.parametrize("error,code", [(subprocess.TimeoutExpired(["python"], 600), 124),
                                       (FileNotFoundError("missing test executable"), 127)])
def test_acceptance_runner_reports_failures_instead_of_crashing(monkeypatch, error, code):
    def fail(*args, **kwargs):
        raise error
    monkeypatch.setattr(acceptance.subprocess, "run", fail)
    row = acceptance._run("broken-stage", ["python", "test-stage"])
    assert row["ok"] is False and row["returncode"] == code
    assert row["name"] == "broken-stage" and row["stderr"]


def test_redis_probe_closes_connection_on_failure(monkeypatch):
    import redis
    closed = []
    class Client:
        def ping(self): return True
        def set(self, *args, **kwargs): raise TimeoutError("redis probe failed")
        def close(self): closed.append(True)
    monkeypatch.setattr(redis.Redis, "from_url", lambda *args, **kwargs: Client())
    with pytest.raises(TimeoutError):
        live.redis_check("redis://test-only/0")
    assert closed == [True]


def test_postgres_probe_sets_query_and_lock_timeouts(monkeypatch):
    import psycopg
    kwargs_seen = {}
    class Cursor:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def execute(self, sql): self.sql = sql
        def fetchone(self): return ("test", "user", "stamp") if 'current_database' in self.sql else ("ok",)
    class Connection:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def cursor(self): return Cursor()
        def rollback(self): pass
    def connect(url, **kwargs):
        kwargs_seen.update(kwargs)
        return Connection()
    monkeypatch.setattr(psycopg, "connect", connect)
    assert live.postgres_check("postgresql://test-only/db")["ok"] is True
    assert "statement_timeout" in kwargs_seen.get("options", "")
    assert "lock_timeout" in kwargs_seen.get("options", "")


def fake_bot(monkeypatch, *, status="administrator", deleted=True, initialize_error=False):
    import telegram
    calls = []
    class Bot:
        def __init__(self, **kwargs): pass
        async def initialize(self):
            calls.append("initialize")
            if initialize_error: raise RuntimeError("bot initialization failed")
        async def shutdown(self): calls.append("shutdown")
        async def get_me(self): return SimpleNamespace(id=42, username="test_bot")
        async def get_chat_member(self, chat_id, uid):
            return SimpleNamespace(status=status, can_invite_users=True,
                                   can_post_messages=True, can_delete_messages=True)
        async def send_message(self, *args, **kwargs):
            calls.append("send")
            return SimpleNamespace(message_id=1)
        async def delete_message(self, *args): return deleted
    monkeypatch.setattr(telegram, "Bot", Bot)
    monkeypatch.setenv("TEST_PUBLIC_CHANNEL_ID", "-100001")
    monkeypatch.setenv("TEST_PRIVATE_CHANNEL_ID", "-100002")
    return calls


@pytest.mark.asyncio
@pytest.mark.parametrize("status,deleted", [("member", True), ("administrator", False)])
async def test_live_telegram_probe_rejects_missing_permissions_or_cleanup(monkeypatch, status, deleted):
    calls = fake_bot(monkeypatch, status=status, deleted=deleted)
    result = await live.telegram_check("123:test")
    assert result["ok"] is False
    assert calls[-1] == "shutdown"
    if status == "member": assert "send" not in calls


@pytest.mark.asyncio
async def test_live_telegram_initialization_failure_still_shuts_down(monkeypatch):
    calls = fake_bot(monkeypatch, initialize_error=True)
    with pytest.raises(RuntimeError, match="initialization failed"):
        await live.telegram_check("123:test")
    assert calls == ["initialize", "shutdown"]


@pytest.mark.asyncio
async def test_production_telegram_requires_both_test_channels(monkeypatch):
    calls = fake_bot(monkeypatch)
    monkeypatch.delenv("TEST_PRIVATE_CHANNEL_ID", raising=False)
    result = await live.telegram_check("123:test", require_channels=True)
    assert result["ok"] is False and "send" not in calls


@pytest.mark.asyncio
async def test_test_credentials_cannot_alias_production(monkeypatch, capsys):
    monkeypatch.setenv("TEST_DATABASE_URL", "postgres://same-host/db")
    monkeypatch.setenv("POSTGRES_URL", "postgresql://same-host/db")
    monkeypatch.setenv("TEST_REDIS_URL", "redis://different-test-host/0")
    monkeypatch.setenv("TEST_BOT_TOKEN", "123:stage")
    monkeypatch.setenv("BOT_TOKEN", "123:stage")
    ran = []
    monkeypatch.setattr(live, "postgres_check", lambda value: ran.append(value) or {"ok": True})
    monkeypatch.setattr(live, "redis_check", lambda value: {"ok": True})
    async def probe(*args, **kwargs): return {"ok": True}
    monkeypatch.setattr(live, "telegram_check", probe)
    code = await live.main()
    report = json.loads(capsys.readouterr().out)
    assert code != 0 and report["status"] != "PASSED" and not ran


def valid_acceptance():
    now = datetime.now(UTC)
    names = ["production_configuration", "dependency_lock_attestation", "security_audit_chain",
             "release_gate", "postdeploy_http", "live_staging", "gemini_live_generation",
             "miniapp_playwright", "mt5_compiled_connector"]
    return {"schema_version": 2, "status": "PASSED", "version": "8.42.0",
            "source_sha256": "a" * 64, "docker_image_digest": "sha256:" + "b" * 64,
            "started_at": (now - timedelta(minutes=1)).isoformat(), "finished_at": now.isoformat(),
            "base_url": "https://staging.example", "checks": [{"name": n, "ok": True} for n in names],
            "failures": []}


def acceptance_errors(report):
    return quality_utils.production_acceptance_errors(
        report, version="8.42.0", source_sha256="a" * 64,
        image_digest="sha256:" + "b" * 64)


def test_complete_current_production_attestation_is_valid():
    assert acceptance_errors(valid_acceptance()) == []


@pytest.mark.parametrize("change", ["minimal", "source", "image", "expired", "future", "missing", "failed", "truthy", "duplicate", "skip"])
def test_production_attestation_cannot_pass_with_stale_or_incomplete_evidence(change):
    report = valid_acceptance()
    if change == "minimal": report = {"status": "PASSED", "version": "8.42.0"}
    elif change == "source": report["source_sha256"] = "c" * 64
    elif change == "image": report["docker_image_digest"] = "sha256:" + "c" * 64
    elif change == "expired": report["started_at"] = (datetime.now(UTC) - timedelta(days=2)).isoformat()
    elif change == "future": report["finished_at"] = (datetime.now(UTC) + timedelta(days=1)).isoformat()
    elif change == "missing": report["checks"].pop()
    elif change == "failed": report["checks"][0]["ok"] = False
    elif change == "truthy": report["checks"][0]["ok"] = "yes"
    elif change == "duplicate": report["checks"].append(report["checks"][0])
    else: report["checks"][0]["skipped"] = True
    assert acceptance_errors(report)


def test_postdeploy_rejects_false_readiness_with_http_200(monkeypatch):
    from scripts import postdeploy_smoke
    def request(base, path, **kwargs):
        if path == "/healthz": return 200, b'{"status":"ok"}', {"strict-transport-security": "max-age=100"}
        if path == "/readyz": return 200, b'{"ready":false}', {}
        if path == "/app": return 200, b'SENTINEL', {"content-type": "text/html"}
        return (403 if path == "/metrics" else 401), b'{}', {}
    monkeypatch.setattr(postdeploy_smoke, "request", request)
    monkeypatch.setattr(sys, "argv", ["smoke", "--base-url", "https://staging.example"])
    with pytest.raises(RuntimeError, match="readiness"):
        postdeploy_smoke.main()


@pytest.mark.asyncio
async def test_isolated_telegram_probe_with_permissions_and_cleanup_passes(monkeypatch):
    calls = fake_bot(monkeypatch)
    result = await live.telegram_check("123:test", require_channels=True)
    assert result["ok"] is True and result["channels_attested"] == 2
    assert calls.count("send") == 2 and calls[-1] == "shutdown"


@pytest.mark.parametrize("changed", [False, True])
def test_generated_hash_lock_is_checked_without_nonexistent_attestation_flag(tmp_path, monkeypatch, changed):
    prod = tmp_path / 'requirements.lock.txt'
    dev = tmp_path / 'requirements-dev.lock.txt'
    prod.write_text('example==1.0\n')
    dev.write_text('pytest==8.3.5\n')
    payload = {"complete_transitive_lock": True, "hashes_required": True,
               "python_target": "3.12", "generated_by": "pip-tools==7.6.1",
               "production_lock_sha256": hashlib.sha256(prod.read_bytes()).hexdigest(),
               "development_lock_sha256": hashlib.sha256(dev.read_bytes()).hexdigest()}
    (tmp_path / 'DEPENDENCY_LOCK_STATUS.json').write_text(json.dumps(payload))
    if changed: prod.write_text('example==2.0\n')
    monkeypatch.setattr(acceptance, 'ROOT', tmp_path)
    invoked = []
    def verify(name, command):
        invoked.append(command)
        return {"ok": True}
    monkeypatch.setattr(acceptance, '_run', verify)
    assert acceptance._dependency_lock_check()['ok'] is (not changed)
    assert bool(invoked) is (not changed)


@pytest.mark.parametrize('row', ['example==2.0', 'example==1.*',
    'example==1.0\nexample==2.0', 'example==1.0 --extra-index-url=https://untrusted.example'])
def test_dependency_lock_rejects_version_drift_wildcards_duplicates_and_options(tmp_path, monkeypatch, row):
    from scripts import verify_dependency_lock as verifier
    (tmp_path / 'DEPENDENCY_LOCK_STATUS.json').write_text('{}')
    (tmp_path / 'requirements.txt').write_text('example==1.0\n')
    (tmp_path / 'requirements.lock.txt').write_text(row+'\n')
    (tmp_path / 'requirements-dev.txt').write_text('-r requirements.lock.txt\npytest==8.3.5\n')
    (tmp_path / 'requirements-dev.lock.txt').write_text('-r requirements.lock.txt\npytest==8.3.5\n')
    monkeypatch.setattr(verifier, 'ROOT', tmp_path)
    monkeypatch.setattr(sys, 'argv', ['verify-lock'])
    with pytest.raises(RuntimeError): verifier.main()


@pytest.mark.parametrize('change', ['missing', 'source', 'binary', 'real_account', 'failed_check', 'expired', 'valid'])
def test_mt5_presence_cannot_replace_current_compile_and_demo_evidence(tmp_path, change):
    downloads = tmp_path / 'webapp/downloads'
    downloads.mkdir(parents=True)
    source = downloads / 'SentinelConnector.mq5'
    binary = downloads / 'SentinelConnector.ex5'
    source.write_bytes(b'synthetic source fixture, not a real compilation')
    binary.write_bytes(b'synthetic binary fixture, not a real EX5')
    stamp = datetime.now(UTC).isoformat()
    evidence = {'schema_version': 1, 'compiler': 'MetaEditor', 'compiled_at': stamp,
                'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                'ex5_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                'demo': {'account_type': 'demo', 'passed': True, 'tested_at': stamp,
                         'checks': {name: True for name in ['connection', 'authentication', 'risk_limits',
                                                            'signal_sync', 'disconnect_recovery']}}}
    if change == 'source': evidence['source_sha256'] = '0' * 64
    elif change == 'binary': evidence['ex5_sha256'] = '0' * 64
    elif change == 'real_account': evidence['demo']['account_type'] = 'real'
    elif change == 'failed_check': evidence['demo']['checks']['risk_limits'] = False
    elif change == 'expired': evidence['compiled_at'] = (datetime.now(UTC) - timedelta(days=8)).isoformat()
    if change != 'missing':
        art = tmp_path / 'quality-artifacts';art.mkdir()
        (art / 'mt5_demo_acceptance.json').write_text(json.dumps(evidence))
    assert quality_utils.mt5_acceptance_details(tmp_path)['ok'] is (change == 'valid')


def test_credential_endpoint_uses_sdk_query_override_rules():
    assert live._endpoint('redis://host/5?db=0', 'redis') == live._endpoint('redis://host/0', 'redis')
    assert live._endpoint('postgresql://host/staging?dbname=production', 'postgresql') == live._endpoint('postgres://host/production', 'postgresql')


def test_credential_endpoint_rejects_implicit_production_defaults():
    with pytest.raises(ValueError): live._endpoint('dbname=production', 'postgresql')


def test_nonempty_ex5_without_compile_evidence_is_not_attested(tmp_path, monkeypatch):
    downloads = tmp_path / 'webapp/downloads'
    downloads.mkdir(parents=True)
    (downloads / 'SentinelConnector.mq5').write_text('synthetic fixture')
    (downloads / 'SentinelConnector.ex5').write_bytes(b'nonempty, not proof of compilation')
    monkeypatch.setattr(acceptance, 'ROOT', tmp_path)
    assert acceptance._mt5_artifact_check()['ok'] is False


@pytest.mark.asyncio
async def test_delayed_ticket_keeps_the_context_confirmed_by_user(monkeypatch):
    import bot
    from bot_runtime import account_support as handlers
    callbacks = []
    observed = []
    context = SimpleNamespace(user_data={'ticket_category': 'signal',
                                         'ticket_context': {'type': 'signal', 'id': '10'}})
    async def blocking(fn, *args, **kwargs):
        return 'fa' if fn is handlers._language_for_user else ('request body', None)
    async def delayed(fn):
        callbacks.append(fn)
        raise TimeoutError('database callback delayed')
    def create(db, uid, body, **kwargs):
        observed.append(kwargs)
        return {'id': 1}
    monkeypatch.setattr(handlers, 'run_blocking', blocking)
    monkeypatch.setattr(handlers, 'async_with_db', delayed)
    monkeypatch.setattr(handlers, 'create_ticket', create)
    update = SimpleNamespace(effective_user=SimpleNamespace(id=7, username='test'),
                             effective_message=SimpleNamespace(text='request body'))
    with pytest.raises(TimeoutError): await bot.ticket_new_message(update, context)
    context.user_data['ticket_context'] = {'type': 'payment', 'id': '99'}
    callbacks[0]({})
    assert (observed[0]['context_type'], observed[0]['context_id']) == ('signal', '10')


@pytest.mark.asyncio
async def test_delayed_ban_keeps_the_selected_user_and_duration(monkeypatch):
    import bot
    from bot_runtime import crm_content as handlers
    callbacks = []
    observed = []
    context = SimpleNamespace(user_data={'admin_user_uid': '7', 'admin_ban_days': 7})
    async def allowed(*args, **kwargs): return True
    async def delayed(fn):
        callbacks.append(fn)
        raise TimeoutError('database callback delayed')
    def ban(db, uid, **kwargs):
        observed.append((uid, kwargs['days']))
        return {'expires_at': 'synthetic fixture'}
    monkeypatch.setattr(handlers, 'require_admin', allowed)
    monkeypatch.setattr(handlers, 'async_with_db', delayed)
    monkeypatch.setattr(handlers, 'set_user_ban', ban)
    update = SimpleNamespace(effective_user=SimpleNamespace(id=1),
                             effective_message=SimpleNamespace(text='reason'))
    with pytest.raises(TimeoutError): await bot.admin_user_ban_reason(update, context)
    context.user_data.update(admin_user_uid='8', admin_ban_days=None)
    callbacks[0]({})
    assert observed == [('7', 7)]
