from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import content_hash, json_dump, json_load, utc_iso

SOURCE_BASE_CONFIDENCE={"broker":0.98,"provider":0.9,"verified_admin":0.85,"import":0.75,"manual":0.5,"unknown":0.25}

class DataConfidenceService:
    def __init__(self,engine:DatabaseEngine|None=None): self.engine=engine or normalized_engine()
    def record(self,*,entity_type:str,entity_id:str,field_name:str,value:Any,source:str,provider:str="",observed_at:str|None=None,ttl_seconds:int|None=None,confidence:float|None=None)->dict[str,Any]:
        observed=observed_at or utc_iso(); score=min(1.0,max(0.0,float(confidence if confidence is not None else SOURCE_BASE_CONFIDENCE.get(source,0.25))))
        expires=None
        if ttl_seconds:
            expires=datetime.fromtimestamp(self._parse(observed).timestamp()+int(ttl_seconds),tz=UTC).isoformat()
        payload={"value":value,"source":source,"provider":provider,"confidence":score,"observed_at":observed,"expires_at":expires}
        with self.engine.transaction() as cursor:
            cursor.execute("""INSERT INTO v8_data_provenance(entity_type,entity_id,field_name,source,provider,confidence,observed_at,expires_at,checksum,payload)
                VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(entity_type,entity_id,field_name) DO UPDATE SET source=excluded.source,provider=excluded.provider,
                confidence=excluded.confidence,observed_at=excluded.observed_at,expires_at=excluded.expires_at,checksum=excluded.checksum,payload=excluded.payload""",
                (entity_type,entity_id,field_name,source,provider or None,score,observed,expires,content_hash(value),json_dump(payload)))
        return payload
    def get(self,entity_type:str,entity_id:str,field_name:str)->dict[str,Any]|None:
        with self.engine.transaction(read_only=True) as cursor:
            row=cursor.execute("SELECT * FROM v8_data_provenance WHERE entity_type=? AND entity_id=? AND field_name=?",(entity_type,entity_id,field_name)).fetchone()
        if not row:return None
        payload=json_load(row.get("payload"),{}) or {}; now=datetime.now(UTC); observed=self._parse(str(row["observed_at"])); expires=self._parse(str(row["expires_at"])) if row.get("expires_at") else None
        payload.update({"age_seconds":max(0,int((now-observed).total_seconds())),"stale":bool(expires and expires<=now),"checksum":row.get("checksum")})
        return payload
    @staticmethod
    def _parse(value:str)->datetime:
        dt=datetime.fromisoformat(str(value).replace("Z","+00:00"));return dt if dt.tzinfo else dt.replace(tzinfo=UTC)
