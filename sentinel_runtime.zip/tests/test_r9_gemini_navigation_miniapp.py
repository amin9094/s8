from __future__ import annotations

import ast
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]


def _callback_literals(path: str, function_name: str) -> set[str]:
    tree = ast.parse((ROOT / path).read_text(encoding="utf-8"))
    function = next(
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == function_name
    )
    values: set[str] = set()
    for node in ast.walk(function):
        if not isinstance(node, ast.Call):
            continue
        for keyword in node.keywords:
            if (
                keyword.arg == "callback_data"
                and isinstance(keyword.value, ast.Constant)
                and isinstance(keyword.value.value, str)
            ):
                values.add(keyword.value.value)
    return values


def test_top_level_market_and_calculator_back_to_actual_parent() -> None:
    market = _callback_literals("bot_runtime/market_data.py", "u_price")
    calculator = _callback_literals("bot_runtime/commerce_calculator.py", "u_calc")
    result = _callback_literals("bot_runtime/commerce_calculator.py", "_finish_calculator")

    assert "home" in market
    assert "nav_user:markets" not in market
    assert "home" in calculator
    assert "nav_user:tools" not in calculator
    assert "home" in result
    assert "nav_user:tools" not in result


def test_contests_and_missions_are_direct_sibling_entries() -> None:
    navigation = (ROOT / "bot_runtime/navigation.py").read_text(encoding="utf-8")
    missions = _callback_literals("bot_runtime/account_support.py", "u_missions")
    contests = _callback_literals("bot_runtime/account_support.py", "u_contests")

    main = next(
        node for node in ast.parse(navigation).body
        if isinstance(node, ast.FunctionDef) and node.name == "main_menu"
    )
    main_source = ast.get_source_segment(navigation, main) or ""
    assert 'callback_data="u_contests"' in main_source
    assert 'callback_data="u_missions"' in main_source
    assert 'callback_data="u_challenges"' not in main_source
    assert missions == {"home"}
    assert "home" in contests
    assert "u_challenges" not in contests

    tree = ast.parse(navigation)
    nav_function = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_user_navigation_items"
    )
    club_segment = ast.get_source_segment(navigation, nav_function) or ""
    assert '("✅ My missions", "u_missions")' not in club_segment
    assert '("🎯 Contests", "u_contests")' not in club_segment
    assert '("✅ مأموریت‌های من", "u_missions")' not in club_segment
    assert '("🎯 مسابقه‌ها", "u_contests")' not in club_segment


def test_gemini_is_admin_only_and_chat_is_registered(monkeypatch) -> None:
    from bot_runtime import navigation as nav

    navigation = (ROOT / "bot_runtime/navigation.py").read_text(encoding="utf-8")
    platform = (ROOT / "bot_runtime/platform_expansion.py").read_text(encoding="utf-8")
    runtime = (ROOT / "bot_runtime/runtime_jobs.py").read_text(encoding="utf-8")

    main_block = navigation[navigation.index("def main_menu("):navigation.index("def user_category_menu")]
    assert 'callback_data="language_menu"' in main_block
    assert 'callback_data="u_ai_chat_start"' not in main_block
    monkeypatch.setattr(nav, "_admin_granted_permissions", lambda _: set())
    monkeypatch.setattr(nav, "_is_owner_admin", lambda _: True)
    assert "a_ai_chat_start" in {b.callback_data for row in nav.admin_category_menu("system",1) for b in row}
    monkeypatch.setattr(nav, "_is_owner_admin", lambda _: False)
    assert "a_ai_chat_start" not in {b.callback_data for row in nav.admin_category_menu("system",1) for b in row}
    assert "u_ai_hub:" not in navigation
    assert "u_ai_chat_start" in runtime
    assert "a_ai_chat_start" in runtime
    assert "ai_chat_conversation" in runtime
    assert "ai_chat_message_router" in runtime
    assert "'u_ai_hub'" in platform.split("__feature_exports__", 1)[1]


def test_inline_miniapp_uses_exact_canonical_telegram_url(monkeypatch) -> None:
    from bot_runtime import shared

    canonical = "https://sentinel.example/app?theme=dark"
    monkeypatch.setattr(
        shared,
        "SETTINGS",
        SimpleNamespace(has_webapp=True, webapp_url=canonical),
    )

    assert shared.telegram_webapp_launch_url("DifferentBot") == canonical
    navigation = (ROOT / "bot_runtime/navigation.py").read_text(encoding="utf-8")
    assert "WebAppInfo(url=SETTINGS.webapp_url)" not in navigation
    assert "telegram_webapp_launch_url(effective_bot_username())" in navigation
    assert navigation.count("with_webapp(rows)") == 1


def test_miniapp_waits_for_delayed_telegram_bridge_and_recovers_session() -> None:
    source = (ROOT / "webapp/src/core.js").read_text(encoding="utf-8")

    assert "waitForTelegramInitData(timeout = 6000)" in source
    assert "waitForTelegramInitData(4000)" in source
    assert "isRecoverableTelegramAuthError" in source
    for code in ("INIT_DATA_MISSING", "INIT_DATA_EXPIRED", "INIT_DATA_REPLAYED", "RATE_LIMITED"):
        assert code in source
