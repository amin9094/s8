function adminFieldMarkup(field, index) {
    const name = String(field?.name || `field_${index}`), id = `adminAction_${index}_${name.replace(/[^a-z0-9_]/gi, '_')}`, label = state.lang === 'fa' ? (field?.label_fa || field?.label_en || name) : (field?.label_en || field?.label_fa || name), required = field?.required ? 'required' : '', placeholder = esc(state.lang === 'fa' ? (field?.placeholder || '') : (field?.placeholder_en || field?.placeholder || '')), value = field?.default;
    const helpText = state.lang === 'fa' ? field?.help_fa : (field?.help_en || field?.help_fa);
    const help = helpText ? `<small class="field-help">${esc(helpText)}</small>` : '';
    if (field?.type === 'checkbox')
        return `<label class="check-row"><input id="${id}" data-admin-field="${esc(name)}" data-kind="checkbox" type="checkbox" ${value ? 'checked' : ''}> <span>${esc(label)}</span></label>${help}`;
    if (field?.type === 'select')
        return `<div class="field"><label for="${id}">${esc(label)}</label><select id="${id}" data-admin-field="${esc(name)}" data-kind="select" ${required}>${(field.options || []).map(x => `<option value="${esc(x.value)}" ${String(value ?? '') === String(x.value) ? 'selected' : ''}>${esc(state.lang === 'fa' ? (x.label_fa || x.label) : (x.label_en || x.label))}</option>`).join('')}</select>${help}</div>`;
    if (field?.type === 'textarea' || field?.type === 'json')
        return `<div class="field field-span"><label for="${id}">${esc(label)}</label><textarea id="${id}" data-admin-field="${esc(name)}" data-kind="${esc(field.type)}" rows="${field.type === 'json' ? 7 : 4}" placeholder="${placeholder}" ${required}>${esc(field.type === 'json' ? JSON.stringify(value ?? {}, null, 2) : (value ?? ''))}</textarea>${help}</div>`;
    const type = field?.type === 'password' ? 'password' : field?.type === 'number' ? 'number' : field?.type === 'datetime' ? 'datetime-local' : 'text';
    return `<div class="field"><label for="${id}">${esc(label)}</label><input id="${id}" data-admin-field="${esc(name)}" data-kind="${esc(field?.type || 'text')}" type="${type}" value="${esc(value ?? '')}" placeholder="${placeholder}" ${required}>${help}</div>`;
}
function collectAdminActionPayload(form) { const payload = {}; $$('[data-admin-field]', form).forEach(el => { const name = el.dataset.adminField, kind = el.dataset.kind || 'text'; let value = kind === 'checkbox' ? el.checked : el.value; if (kind === 'number' && value !== '')
    value = Number(value); if (kind === 'csv')
    value = String(value).split(/[,،\n]+/).map(x => x.trim()).filter(Boolean); if (kind === 'json') {
    try {
        value = JSON.parse(String(value || '{}'));
    }
    catch {
        throw new Error(state.lang === 'fa' ? `JSON فیلد «${name}» معتبر نیست.` : `Invalid JSON in ${name}`);
    }
} if (value !== '' && value !== undefined)
    payload[name] = value; }); return payload; }
function adminResultMarkup(result) { const data = result?.result ?? result; return `<div class="notice success"><strong>${state.lang === 'fa' ? 'عملیات با موفقیت انجام شد' : 'Operation completed'}</strong></div><pre class="code-block" dir="ltr">${esc(JSON.stringify(data ?? {}, null, 2))}</pre>`; }
function nativeAdminAction(row) { const name = row.action; if (name === 'miniapp_signal_publish') {
    closeModal();
    adminSignalComposer();
    return true;
} if (name === 'ticket_admin_reply' || name === 'ticket_admin_status_update') {
    closeModal();
    adminTicketCenter();
    return true;
} if (name === 'miniapp_announcement_publish') {
    closeModal();
    announcementPublishModal?.();
    return true;
} if (name === 'experiment_create') {
    closeModal();
    experimentCreateModal();
    return true;
} if (name === 'prop_template_create') {
    closeModal();
    propTemplateCreateModal();
    return true;
} return false; }
function openAdminCapability(row) {
    if (!row)
        return;
    if (row.ui_mode === 'native' && nativeAdminAction(row))
        return;
    const fields = Array.isArray(row.fields) ? row.fields : [];
    const rawFallback = !fields.length && row.ui_mode !== 'inspect' && row.ui_mode !== 'confirm';
    const rowLabel = state.lang === 'fa' ? (row.label_fa || row.action) : (row.label_en || row.label_fa || row.action), rowDescription = state.lang === 'fa' ? (row.description_fa || '') : (row.description_en || row.description_fa || '');
    const body = `<div class="notice info"><strong>${esc(rowLabel)}</strong><p>${esc(rowDescription)}</p><small>${state.lang === 'fa' ? 'دسترسی موردنیاز' : 'Required permission'}: ${esc(state.lang === 'fa' ? (row.permission_label || row.permission || 'مدیر') : (row.permission_label_en || row.permission_label || row.permission || 'Administrator'))}</small></div><form id="adminGenericActionForm"><div class="form-grid">${fields.map(adminFieldMarkup).join('')}${rawFallback ? adminFieldMarkup({ name: '__raw_payload', label_fa: 'داده ورودی JSON', label_en: 'JSON payload', type: 'json', default: {} }, 999) : ''}</div></form><div id="adminActionResult"></div>`;
    const run = async () => { const form = $('#adminGenericActionForm'); if (!form?.reportValidity())
        return; let payload = {}; try {
        payload = collectAdminActionPayload(form);
        if (payload.__raw_payload && typeof payload.__raw_payload === 'object')
            payload = payload.__raw_payload;
    }
    catch (err) {
        toast(localizedError(err), 'error');
        return;
    } const confirmation = state.lang === 'fa' ? row.confirmation_fa : (row.confirmation_en || row.confirmation_fa); if (confirmation && !confirm(confirmation))
        return; setBusy(true); try {
        const result = await action(row.action, payload, false);
        $('#adminActionResult').innerHTML = adminResultMarkup(result);
        (row.refresh || []).forEach(k => invalidate(k));
        toast(state.lang === 'fa' ? 'عملیات با موفقیت انجام شد.' : 'Operation completed');
    }
    catch (err) {
        $('#adminActionResult').innerHTML = `<div class="notice danger"><strong>${state.lang === 'fa' ? 'عملیات ناموفق بود' : 'Operation failed'}</strong><p>${esc(localizedError(err))}</p></div>`;
        toast(localizedError(err), 'error');
    }
    finally {
        setBusy(false);
    } };
    const actions = row.ui_mode === 'inspect' || row.ui_mode === 'confirm' ? [{ label: row.ui_mode === 'inspect' ? (state.lang === 'fa' ? 'دریافت اطلاعات' : 'Load') : (state.lang === 'fa' ? 'اجرا' : 'Run'), kind: 'primary', action: run }] : [{ label: state.lang === 'fa' ? 'ثبت و اجرا' : 'Submit', kind: 'primary', action: run }];
    openModal('ADMIN COMMAND', rowLabel, body, actions);
}
async function adminCommandCenter() { setBusy(true); try {
    const d = await loadResource('adminCapabilities', true), rows = d?.actions || [];
    const groupKey = x => state.lang === 'fa' ? (x.group || x.permission_label || 'سایر') : (x.group_en || x.group || x.permission_label_en || x.permission_label || 'Other');
    const groups = [...new Set(rows.map(groupKey))];
    openModal('SENTINEL ADMIN', state.lang === 'fa' ? 'مرکز کامل عملیات ادمین' : 'Full admin command center', `<div class="notice info"><strong>${num(rows.length, 0)} ${state.lang === 'fa' ? 'عملیات واقعی و مجاز' : 'authorized executable actions'}</strong><p>${state.lang === 'fa' ? 'هر گزینه مستقیماً از رجیستری مشترک ربات و مینی‌اپ اجرا می‌شود.' : 'Every option executes through the shared bot/Mini App registry.'}</p></div><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجوی عملیات' : 'Search actions'}</label><input data-admin-action-search placeholder="${state.lang === 'fa' ? 'نام ماژول یا عملیات...' : 'Module or action...'}"></div><div id="adminActionGroups">${groups.map(group => `<section class="panel compact-panel" data-admin-action-group><div class="panel-head"><h3>${esc(group)}</h3><span class="status-badge info">${rows.filter(x => groupKey(x) === group).length}</span></div><div class="panel-body permission-grid">${rows.filter(x => groupKey(x) === group).map(x => { const label = state.lang === 'fa' ? (x.label_fa || x.action) : (x.label_en || x.label_fa || x.action), description = state.lang === 'fa' ? (x.description_fa || x.action) : (x.description_en || x.description_fa || x.action); return `<button class="permission-chip enabled admin-action-button" data-admin-capability="${esc(x.action)}" data-search="${esc(`${x.label_fa || ''} ${x.label_en || ''} ${x.description_fa || ''} ${x.description_en || ''} ${x.action} ${group}`.toLowerCase())}"><strong>${esc(label)}</strong><small>${esc(description)}</small></button>`; }).join('')}</div></section>`).join('')}</div>`, []);
    state.adminCapabilities = Object.fromEntries(rows.map(x => [x.action, x]));
}
catch (err) {
    openModal('ADMIN ERROR', state.lang === 'fa' ? 'بارگذاری پنل ادمین ناموفق بود' : 'Admin panel failed', `<div class="notice danger"><strong>${esc(localizedError(err))}</strong><p>${state.lang === 'fa' ? 'اتصال، دسترسی یا وضعیت سرور را بررسی کنید.' : 'Check connectivity, permission, and server health.'}</p></div>`, [{ label: t('retry'), kind: 'primary', action: adminCommandCenter }]);
}
finally {
    setBusy(false);
} }
document.addEventListener('click', event => { const center = event.target.closest('[data-admin-command-center]'); if (center) {
    event.preventDefault();
    event.stopImmediatePropagation();
    adminCommandCenter();
    return;
} const button = event.target.closest('[data-admin-capability]'); if (button) {
    event.preventDefault();
    event.stopImmediatePropagation();
    const row = state.adminCapabilities?.[button.dataset.adminCapability] || (state.resources.adminCapabilities?.actions || []).find(x => x.action === button.dataset.adminCapability);
    openAdminCapability(row);
    return;
} }, true);
document.addEventListener('input', event => { if (!event.target.matches('[data-admin-action-search]'))
    return; const q = event.target.value.trim().toLowerCase(); $$('[data-admin-action-group]').forEach(group => { let visible = 0; $$('[data-admin-capability]', group).forEach(button => { const show = !q || (button.dataset.search || '').includes(q); button.hidden = !show; if (show)
    visible++; }); group.hidden = !visible; }); }, true);
document.addEventListener('click', event => { const periods = event.target.closest('[data-admin-signal-cycles]'); if (periods) {
    event.preventDefault();
    event.stopImmediatePropagation();
    adminSignalCyclesModal();
    return;
} const name = event.target.closest('[data-signal-cycle-name]'); if (name) {
    event.preventDefault();
    event.stopImmediatePropagation();
    signalCycleNameModal(name.dataset.signalCycleName || 'rollover');
    return;
} const close = event.target.closest('[data-signal-cycle-close]'); if (close) {
    event.preventDefault();
    event.stopImmediatePropagation();
    closeSignalCycleFromMiniApp();
    return;
} const detail = event.target.closest('[data-signal-cycle-detail]'); if (detail) {
    event.preventDefault();
    event.stopImmediatePropagation();
    adminSignalCycleDetail(detail.dataset.signalCycleDetail);
    return;
} const pdf = event.target.closest('[data-signal-cycle-pdf]'); if (pdf) {
    event.preventDefault();
    event.stopImmediatePropagation();
    downloadSignalCyclePdf(pdf.dataset.signalCyclePdf);
    return;
} const rename = event.target.closest('[data-signal-cycle-rename]'); if (rename) {
    event.preventDefault();
    event.stopImmediatePropagation();
    signalCycleNameModal('rename', rename.dataset.signalCycleRename);
    return;
} }, true);


function adminPermissionSet() {
    const admin = state.resources.overview?.admin || {};
    return { owner: String(admin.role || '').toLowerCase() === 'owner', values: new Set(admin.permissions || []) };
}
function adminCan(permission) { const p = adminPermissionSet(); return p.owner || p.values.has(permission); }
function adminUserCard(row) {
    const name = [row.first_name, row.last_name].filter(Boolean).join(' ') || row.username || row.user_id;
    return `<article class="journal-card" data-admin-user-row="${esc(row.user_id)}"><div class="row-between"><div><strong>${esc(name)}</strong><p><code>${esc(row.user_id)}</code>${row.username ? ` · @${esc(row.username)}` : ''}</p></div><span class="status-badge ${row.banned ? 'bad' : row.vip_active ? 'good' : 'info'}">${row.banned ? (state.lang === 'fa' ? 'مسدود' : 'BANNED') : row.vip_active ? 'VIP' : (state.lang === 'fa' ? 'فعال' : 'ACTIVE')}</span></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'امتیاز' : 'Points', num(row.points || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'آخرین حضور' : 'Last seen', row.last_seen_at ? date(row.last_seen_at) : '—', '', '')}</div><div class="card-actions"><button class="button primary small" data-admin-user-detail="${esc(row.user_id)}">${state.lang === 'fa' ? 'کنترل کاربر' : 'Manage user'}</button></div></article>`;
}
async function adminUsersCenter() {
    setBusy(true);
    try {
        const data = await loadResource('adminUsers', true), rows = data?.items || [];
        openModal('USER CONTROL', state.lang === 'fa' ? 'مدیریت و کنترل کاربران' : 'User management', `<div class="notice info"><strong>${num(data?.total || rows.length, 0)} ${state.lang === 'fa' ? 'کاربر ثبت‌شده' : 'registered users'}</strong><p>${state.lang === 'fa' ? 'وضعیت کاربر، VIP و مسدودی از دیتابیس مشترک ربات و مینی‌اپ خوانده می‌شود.' : 'User, VIP and ban state comes from the shared bot/Mini App database.'}</p></div><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجو' : 'Search'}</label><input data-admin-user-search placeholder="ID / @username / name"></div><div id="adminUsersList" class="journal-list">${rows.map(adminUserCard).join('') || empty()}</div>`, []);
        const input = $('[data-admin-user-search]');
        input?.addEventListener('input', () => { const q = String(input.value || '').trim().toLowerCase(); $$('#adminUsersList [data-admin-user-row]').forEach(card => { card.hidden = Boolean(q) && !card.textContent.toLowerCase().includes(q); }); });
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
async function adminUserDetail(userId) {
    setBusy(true);
    try {
        const row = await request(`./api/v1/admin/users/${encodeURIComponent(userId)}`), name = [row.first_name, row.last_name].filter(Boolean).join(' ') || row.username || row.user_id;
        const body = `<div class="notice ${row.banned ? 'danger' : 'success'}"><strong>${esc(name)}</strong><p><code>${esc(row.user_id)}</code>${row.username ? ` · @${esc(row.username)}` : ''}</p></div><div class="metric-grid">${metric('VIP', row.vip_active ? 'ACTIVE' : '—', row.vip_expires_at ? date(row.vip_expires_at) : '', row.vip_active ? 'good' : '')}${metric(state.lang === 'fa' ? 'امتیاز' : 'Points', num(row.points || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'وضعیت' : 'Status', row.banned ? (state.lang === 'fa' ? 'مسدود' : 'Banned') : (state.lang === 'fa' ? 'فعال' : 'Active'), row.ban?.reason || '', row.banned ? 'warn' : 'good')}</div>`;
        const canBan = adminCan('users') || adminCan('user_ban_manage');
        const actions = !canBan ? [] : row.banned ? [{ label: state.lang === 'fa' ? 'رفع مسدودی' : 'Unban', kind: 'primary', action: async () => { await action('admin_user_unban', { user_id: row.user_id }, false); invalidate('adminUsers', 'overview'); closeModal(); toast(t('success')); adminUsersCenter(); } }] : [{ label: state.lang === 'fa' ? 'مسدودسازی' : 'Ban user', kind: 'danger', action: () => adminUserBanModal(row) }];
        openModal('USER CONTROL', name, body, actions);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
function adminUserBanModal(row) {
    openModal('USER CONTROL', state.lang === 'fa' ? 'مسدودسازی کاربر' : 'Ban user', `<form id="adminUserBanForm"><div class="field"><label>${state.lang === 'fa' ? 'مدت به روز؛ خالی = دائم' : 'Days; blank = permanent'}</label><input id="adminBanDays" inputmode="numeric" type="number" min="1"></div><div class="field field-span"><label>${t('reason')}</label><textarea id="adminBanReason" rows="3" required></textarea></div></form>`, [{ label: state.lang === 'fa' ? 'تأیید مسدودی' : 'Confirm ban', kind: 'danger', action: async () => { const form = $('#adminUserBanForm'); if (!form?.reportValidity()) return; await action('admin_user_ban', { user_id: row.user_id, days: $('#adminBanDays').value || undefined, reason: $('#adminBanReason').value }, false); invalidate('adminUsers', 'overview'); closeModal(); toast(t('success')); adminUsersCenter(); } }]);
}
function adminAccessCard(row) {
    return `<article class="journal-card"><div class="row-between"><div><strong>${esc(row.first_name || row.username || row.user_id)}</strong><p><code>${esc(row.user_id)}</code>${row.username ? ` · @${esc(row.username)}` : ''}</p></div><span class="status-badge ${row.active !== false ? 'good' : 'bad'}">${row.active !== false ? 'ACTIVE' : 'OFF'}</span></div>${row.role_preset_label ? `<p><span class="status-badge warn">${esc(row.role_preset_label)}</span></p>` : ''}<p>${(row.permissions || []).map(x => `<span class="status-badge info">${esc(x)}</span>`).join(' ') || '—'}</p><div class="card-actions"><button class="button primary small" data-admin-access-edit="${esc(row.user_id)}">${state.lang === 'fa' ? 'ویرایش دسترسی' : 'Edit access'}</button><button class="button danger small" data-admin-access-remove="${esc(row.user_id)}">${state.lang === 'fa' ? 'حذف ادمین' : 'Remove admin'}</button></div></article>`;
}
async function adminAdminsCenter() {
    setBusy(true);
    try {
        const data = await loadResource('adminAdmins', true), rows = data?.items || [];
        openModal('ADMIN ACCESS', state.lang === 'fa' ? 'افزودن و مدیریت ادمین‌ها' : 'Add and manage administrators', `<div class="notice info"><strong>${num(rows.length, 0)} ${state.lang === 'fa' ? 'ادمین واگذارشده' : 'delegated admins'}</strong><p>${state.lang === 'fa' ? 'مجوزهای این صفحه همان مجوزهای ربات تلگرام است.' : 'These are the exact same permissions used by the Telegram bot.'}</p></div><div class="card-actions"><button class="button primary" data-admin-access-new>${icon('plus')}${state.lang === 'fa' ? 'افزودن ادمین' : 'Add admin'}</button></div><div class="journal-list">${rows.map(adminAccessCard).join('') || empty()}</div>`, []);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
function adminAccessModal(row = null) {
    const data = state.resources.adminAdmins || {}, current = new Set(row?.permissions || []), permissions = data.permissions || [], presets = data.role_presets || [];
    const presetOptions = presets.map(p => `<option value="${esc(p.key)}">${esc(state.lang === 'fa' ? p.label : p.key)}</option>`).join('');
    const presetBox = presets.length ? `<div class="field-span notice info"><strong>${state.lang === 'fa' ? 'نقش آماده با حداقل دسترسی' : 'Least-privilege role preset'}</strong><p>${state.lang === 'fa' ? 'نقش را انتخاب و روی «اعمال در فرم» بزنید؛ سپس می‌توانید مجوزها را دستی اصلاح کنید.' : 'Choose a role, apply it to the form, then adjust individual permissions.'}</p><div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'نقش آماده' : 'Role preset'}</label><select id="adminRolePreset">${presetOptions}</select></div><div class="field"><label>&nbsp;</label><button type="button" class="button secondary" data-admin-role-preview>${state.lang === 'fa' ? 'اعمال در فرم' : 'Apply to form'}</button></div></div><small id="adminRoleDescription"></small></div>` : '';
    openModal('ADMIN ACCESS', row ? (state.lang === 'fa' ? 'ویرایش مجوزهای ادمین' : 'Edit admin permissions') : (state.lang === 'fa' ? 'افزودن ادمین جدید' : 'Add administrator'), `<form id="adminAccessForm"><div class="field"><label>${state.lang === 'fa' ? 'آیدی عددی تلگرام' : 'Telegram numeric ID'}</label><input id="adminAccessUserId" inputmode="numeric" value="${esc(row?.user_id || '')}" ${row ? 'readonly' : ''} required></div>${presetBox}<div class="field-span permission-grid">${permissions.map(p => `<label class="check-row ${p.owner_only ? 'permission-owner-only' : ''}"><input type="checkbox" data-admin-permission="${esc(p.value)}" ${current.has(p.value) ? 'checked' : ''} ${p.owner_only ? 'disabled' : ''}> <span>${esc(state.lang === 'fa' ? p.label : p.value)}${p.owner_only ? ` · ${state.lang === 'fa' ? 'فقط مالک اصلی' : 'owner only'}` : ''}</span></label>`).join('')}</div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const form = $('#adminAccessForm'); if (!form?.reportValidity()) return; const values = $$('[data-admin-permission]:checked:not(:disabled)', form).map(x => x.dataset.adminPermission); if (!values.length) { toast(state.lang === 'fa' ? 'حداقل یک مجوز انتخاب کنید.' : 'Select at least one permission.', 'error'); return; } const presetKey = $('#adminRolePreset')?.value || ''; const preset = presets.find(item => item.key === presetKey); const selected = new Set(values), presetValues = new Set(preset?.permissions || []), exactPreset = Boolean(preset && selected.size === presetValues.size && [...selected].every(value => presetValues.has(value))); if (exactPreset) await action('delegated_admin_role_preset', { user_id: $('#adminAccessUserId').value, preset: presetKey }, false); else await action(row ? 'delegated_admin_permissions_set' : 'delegated_admin_upsert', { user_id: $('#adminAccessUserId').value, permissions: values }, false); invalidate('adminAdmins', 'adminCapabilities', 'overview'); closeModal(); toast(t('success')); adminAdminsCenter(); } }]);
}

function adminSignalCard(row) {
    return `<article class="journal-card"><div class="row-between"><div><strong>#${num(row.display_number || row.id, 0)} · ${esc(row.symbol || '—')}</strong><p>${esc(row.side)} · ${esc(row.entry || (row.entries || []).join(' - '))}</p></div><span class="status-badge ${row.status === 'open' ? 'good' : row.status === 'stop' ? 'bad' : 'info'}">${esc(row.status)}</span></div><p>TP: ${esc((row.targets || []).join(' · ') || '—')} · SL: ${esc(row.stop || '—')}</p><div class="card-actions"><button class="button primary small" data-admin-signal-detail="${esc(row.id)}">${state.lang === 'fa' ? 'ویرایش و نتیجه' : 'Edit & result'}</button></div></article>`;
}
async function adminSignalsCenter() {
    setBusy(true);
    try {
        const data = await loadResource('adminSignals', true), rows = data?.items || [];
        openModal('SIGNAL MANAGEMENT', state.lang === 'fa' ? 'مدیریت سیگنال‌های منتشرشده' : 'Published signal management', `<div class="notice info"><strong>${num(data?.total || rows.length, 0)} ${state.lang === 'fa' ? 'سیگنال' : 'signals'}</strong><p>${state.lang === 'fa' ? 'ویرایش و نتیجه فوراً در ربات، کانال و مینی‌اپ همگام می‌شود.' : 'Edits and results are immediately synchronized with the bot, channels and Mini App.'}</p></div><div class="journal-list">${rows.map(adminSignalCard).join('') || empty()}</div>`, []);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
async function adminSignalDetail(signalId) {
    setBusy(true);
    try {
        const row = await request(`./api/v1/admin/signals/${encodeURIComponent(signalId)}`), canEdit = adminCan('signal_edit'), canResult = adminCan('signal_status_manage') || adminCan('signal_results'), canDelete = adminCan('signal_delete');
        const body = `<div class="notice info"><strong>#${num(row.display_number || row.id, 0)} · ${esc(row.symbol || '—')} · ${esc(row.side)}</strong><p>${state.lang === 'fa' ? 'ورود' : 'Entry'}: ${esc(row.entry || (row.entries || []).join(' - '))} · SL: ${esc(row.stop || '—')}</p><p>TP: ${esc((row.targets || []).join(' · ') || '—')}</p></div><div class="metric-grid">${metric(t('status'), esc(row.status), row.result_at ? date(row.result_at) : '', row.status === 'open' ? 'good' : 'info')}${metric(t('riskPercent'), esc(row.risk || '—'), '', '')}</div>`;
        const actions = [];
        if (canEdit && row.can_edit) actions.push({ label: state.lang === 'fa' ? 'ویرایش سیگنال' : 'Edit signal', kind: 'primary', action: () => adminSignalEditModal(row) });
        if (canResult) actions.push({ label: row.status === 'open' ? (state.lang === 'fa' ? 'ثبت نتیجه' : 'Set result') : (state.lang === 'fa' ? 'بازکردن نتیجه' : 'Reset result'), kind: 'secondary', action: () => row.status === 'open' ? adminSignalResultModal(row) : adminSignalResetResult(row) });
        if (canDelete) actions.push({ label: state.lang === 'fa' ? 'حذف کامل' : 'Delete', kind: 'danger', action: async () => { if (!confirm(state.lang === 'fa' ? 'این سیگنال برای همیشه حذف شود؟' : 'Permanently delete this signal?')) return; await action('signal_delete', { signal_id: row.id }, false); invalidate('adminSignals', 'signals', 'overview'); closeModal(); toast(t('success')); adminSignalsCenter(); } });
        openModal('SIGNAL MANAGEMENT', `${row.symbol || ''} #${row.display_number || row.id}`, body, actions);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
function adminSignalEditModal(row) {
    const targetOptions = (row.targets || []).map((_, index) => `<option value="target_${index + 1}">TP${index + 1}</option>`).join('');
    openModal('SIGNAL MANAGEMENT', state.lang === 'fa' ? 'ویرایش سیگنال' : 'Edit signal', `<form id="adminSignalEditForm"><div class="field"><label>${state.lang === 'fa' ? 'فیلد' : 'Field'}</label><select id="adminSignalEditField"><option value="entry">Entry</option><option value="stop">Stop</option>${targetOptions}<option value="add_target">${state.lang === 'fa' ? 'افزودن تارگت' : 'Add target'}</option><option value="note">${state.lang === 'fa' ? 'یادداشت بروزرسانی' : 'Update note'}</option></select></div><div class="field"><label>${state.lang === 'fa' ? 'مقدار جدید' : 'New value'}</label><input id="adminSignalEditValue" required></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const form = $('#adminSignalEditForm'); if (!form?.reportValidity()) return; await action('signal_edit', { signal_id: row.id, field: $('#adminSignalEditField').value, value: $('#adminSignalEditValue').value }, false); invalidate('adminSignals', 'signals', 'revisions', 'overview'); closeModal(); toast(t('success')); adminSignalDetail(row.id); } }]);
}
function adminSignalResultModal(row) {
    const options = [['target','تارگت'],['tp1','TP1'],['tp2','TP2'],['tp3','TP3'],['tp4','TP4'],['tp5','TP5'],['breakeven','ریسک‌فری'],['partial_close','بستن بخشی'],['manual_close','بستن دستی'],['no_entry','ورود نداده'],['stop','استاپ'],['cancelled','کنسل‌شده']];
    openModal('SIGNAL RESULT', state.lang === 'fa' ? 'ثبت نتیجه سیگنال' : 'Set signal result', `<form id="adminSignalResultForm"><div class="field"><label>${t('status')}</label><select id="adminSignalResult">${options.map(([value,label]) => `<option value="${value}">${state.lang === 'fa' ? label : value.replaceAll('_',' ')}</option>`).join('')}</select></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { await action('signal_result_set', { signal_id: row.id, result: $('#adminSignalResult').value }, false); invalidate('adminSignals', 'signals', 'overview', 'track'); closeModal(); toast(t('success')); adminSignalDetail(row.id); } }]);
}
async function adminSignalResetResult(row) {
    if (!confirm(state.lang === 'fa' ? 'نتیجه قبلی پاک و سیگنال دوباره باز شود؟' : 'Clear the result and reopen this signal?')) return;
    await action('signal_result_reset', { signal_id: row.id }, false); invalidate('adminSignals', 'signals', 'overview', 'track'); closeModal(); toast(t('success')); adminSignalDetail(row.id);
}

document.addEventListener('click', async event => {
    const el = event.target.closest('[data-admin-users],[data-admin-user-detail],[data-admin-admins],[data-admin-access-new],[data-admin-access-edit],[data-admin-access-remove],[data-admin-role-preview],[data-admin-signals],[data-admin-signal-detail]');
    if (!el) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (el.dataset.adminUsers !== undefined) return adminUsersCenter();
    if (el.dataset.adminUserDetail) return adminUserDetail(el.dataset.adminUserDetail);
    if (el.dataset.adminAdmins !== undefined) return adminAdminsCenter();
    if (el.dataset.adminAccessNew !== undefined) return adminAccessModal();
    if (el.dataset.adminAccessEdit) { const row = (state.resources.adminAdmins?.items || []).find(x => String(x.user_id) === String(el.dataset.adminAccessEdit)); return adminAccessModal(row); }
    if (el.dataset.adminAccessRemove) { if (!confirm(state.lang === 'fa' ? 'این ادمین حذف شود؟' : 'Remove this administrator?')) return; await action('delegated_admin_remove', { user_id: el.dataset.adminAccessRemove }, false); invalidate('adminAdmins', 'adminCapabilities', 'overview'); toast(t('success')); return adminAdminsCenter(); }
    if (el.dataset.adminRolePreview !== undefined) { const key = $('#adminRolePreset')?.value || ''; const preset = (state.resources.adminAdmins?.role_presets || []).find(x => x.key === key); if (!preset) return; const allowed = new Set(preset.permissions || []); $$('[data-admin-permission]').forEach(box => { if (!box.disabled) box.checked = allowed.has(box.dataset.adminPermission); }); const desc = $('#adminRoleDescription'); if (desc) desc.textContent = preset.description || ''; toast(state.lang === 'fa' ? 'نقش در فرم اعمال شد؛ برای ثبت، ذخیره را بزنید.' : 'Role applied to the form; press Save to persist.'); return; }
    if (el.dataset.adminSignals !== undefined) return adminSignalsCenter();
    if (el.dataset.adminSignalDetail) return adminSignalDetail(el.dataset.adminSignalDetail);
}, true);

function moduleControlValue(field) {
    if (field.kind === 'bool') return field.value ? (state.lang === 'fa' ? 'روشن' : 'On') : (state.lang === 'fa' ? 'خاموش' : 'Off');
    return String(field.value ?? '—');
}
function moduleControlTone(field) { return field.capability_status === 'planned' ? 'warn' : field.kind === 'bool' ? (field.value ? 'good' : 'bad') : 'info'; }
function moduleControlCard(row) {
    return `<article class="journal-card" data-module-search="${esc(`${row.label} ${row.key} ${row.category} ${row.description}`.toLowerCase())}"><div class="row-between"><div><strong>${esc(row.label)}</strong><p>${esc(row.description || row.key)}</p></div><span class="status-badge ${row.enabled ? 'good' : 'bad'}">${row.enabled ? (state.lang === 'fa' ? 'فعال' : 'ON') : (state.lang === 'fa' ? 'خاموش' : 'OFF')}</span></div><small>${esc(row.category)} · ${num(row.connected_fields || 0, 0)}/${num((row.fields || []).length, 0)} ${state.lang === 'fa' ? 'تنظیم عملیاتی' : 'operational controls'}</small><div class="card-actions"><button class="button primary small" data-admin-module="${esc(row.key)}">${state.lang === 'fa' ? 'کنترل ماژول' : 'Control module'}</button></div></article>`;
}
function governanceCard(row) {
    const approvals = Array.isArray(row.approvals) ? row.approvals.length : 0;
    return `<article class="journal-card"><div class="row-between"><strong>#${esc(row.id)} · ${esc(row.title || row.action)}</strong><span class="status-badge ${row.status === 'approved' ? 'good' : row.status === 'failed' ? 'bad' : 'warn'}">${esc(row.status)}</span></div><p>${esc(row.action)} · ${esc(row.risk_level)} · ${approvals}/${num(row.required_approvals || 0, 0)}</p><div class="card-actions">${['pending','pending_second_approval'].includes(row.status) ? `<button class="button success small" data-governance-approve="${esc(row.id)}">${state.lang === 'fa' ? 'تأیید' : 'Approve'}</button><button class="button danger small" data-governance-reject="${esc(row.id)}">${state.lang === 'fa' ? 'رد' : 'Reject'}</button>` : ''}${row.status === 'approved' ? `<button class="button primary small" data-governance-apply="${esc(row.id)}">${state.lang === 'fa' ? 'اجرا' : 'Apply'}</button>` : ''}${row.status === 'failed' ? `<button class="button secondary small" data-governance-retry="${esc(row.id)}">${state.lang === 'fa' ? 'تلاش مجدد' : 'Retry'}</button>` : ''}</div></article>`;
}
async function adminModuleControlCenter() {
    setBusy(true);
    try {
        const d = await loadResource('adminPlatform', true), modules = d?.control_modules || [], governance = d?.governance?.pending || [], summary = d?.control_summary || {};
        state.adminControlModules = Object.fromEntries(modules.map(x => [x.key, x]));
        openModal('PLATFORM CONTROL', state.lang === 'fa' ? 'کنترل کامل ماژول‌های ربات و مینی‌اپ' : 'Full bot and Mini App module control', `<div class="notice info"><strong>${num(summary.modules || modules.length, 0)} ${state.lang === 'fa' ? 'ماژول مشترک' : 'shared modules'}</strong><p>${state.lang === 'fa' ? 'هر تغییر روی همان دیتابیس و رجیستری ربات تلگرام اعمال می‌شود. تغییرات حساس ابتدا وارد صف تأیید می‌شوند.' : 'Every change uses the same Telegram bot database and registry. Sensitive changes enter approval first.'}</p></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'فعال' : 'Enabled', num(summary.enabled_modules || 0, 0), '', 'good')}${metric(state.lang === 'fa' ? 'خاموش' : 'Disabled', num(summary.disabled_modules || 0, 0), '', 'warn')}${metric(state.lang === 'fa' ? 'کنترل‌ها' : 'Controls', num(summary.boolean_controls || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'در انتظار تأیید' : 'Pending review', num(governance.length, 0), '', governance.length ? 'warn' : 'good')}</div><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجوی ماژول' : 'Search modules'}</label><input data-module-control-search placeholder="${state.lang === 'fa' ? 'بازار، سیگنال، کاربران، امنیت...' : 'Markets, signals, users, security...'}"></div><div class="card-actions"><button class="button secondary" data-control-preset="safe">${state.lang === 'fa' ? 'درخواست حالت ایمن' : 'Request safe preset'}</button><button class="button secondary" data-control-preset="default">${state.lang === 'fa' ? 'درخواست پیش‌فرض' : 'Request defaults'}</button><button class="button secondary" data-control-preset="full">${state.lang === 'fa' ? 'درخواست کامل' : 'Request full preset'}</button></div><div id="moduleControlList" class="journal-list">${modules.map(moduleControlCard).join('') || empty()}</div>${governance.length ? `<details class="details-block" open><summary>${state.lang === 'fa' ? 'صف تغییرات حساس' : 'Sensitive change queue'}</summary><div class="journal-list">${governance.map(governanceCard).join('')}</div></details>` : ''}`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}
function adminModuleDetail(moduleKey) {
    const row = state.adminControlModules?.[moduleKey]; if (!row) return;
    const fields = row.fields || [];
    openModal('MODULE CONTROL', `${row.label} · ${row.key}`, `<div class="notice info"><strong>${esc(row.label)}</strong><p>${esc(row.description || '')}</p></div><div class="journal-list">${fields.map(field => `<article class="journal-card"><div class="row-between"><div><strong>${esc(field.label)}</strong><p><code>${esc(field.key)}</code>${field.help_text ? ` · ${esc(field.help_text)}` : ''}</p></div><span class="status-badge ${moduleControlTone(field)}">${esc(moduleControlValue(field))}</span></div><small>${esc(field.capability_status)}${field.free_mode_locked ? ` · ${state.lang === 'fa' ? 'قفل حالت رایگان' : 'free-mode locked'}` : ''}</small><div class="card-actions">${field.editable ? field.kind === 'bool' ? `<button class="button ${field.value ? 'danger' : 'success'} small" data-control-toggle="${esc(row.key)}:${esc(field.key)}" data-control-value="${field.value ? 'false' : 'true'}">${field.value ? (state.lang === 'fa' ? 'خاموش‌کردن' : 'Turn off') : (state.lang === 'fa' ? 'روشن‌کردن' : 'Turn on')}</button>` : `<button class="button secondary small" data-control-edit="${esc(row.key)}:${esc(field.key)}">${state.lang === 'fa' ? 'تغییر مقدار' : 'Edit value'}</button>` : `<span class="status-badge warn">${state.lang === 'fa' ? 'غیرقابل تغییر' : 'Read only'}</span>`}</div></article>`).join('')}</div>`, [{ label: state.lang === 'fa' ? 'بازنشانی ماژول' : 'Reset module', kind: 'danger', action: async () => { if (!confirm(state.lang === 'fa' ? 'تنظیمات این ماژول بازنشانی شود؟' : 'Reset this module?')) return; const result = await action('control_reset', { module: row.key }, false); invalidate('adminPlatform','overview'); closeModal(); toast(result?.result?.status === 'review_required' ? (state.lang === 'fa' ? 'درخواست تأیید ساخته شد.' : 'Approval request created.') : t('success')); adminModuleControlCenter(); } }]);
}
function adminModuleEdit(moduleKey, fieldKey) {
    const module = state.adminControlModules?.[moduleKey], field = (module?.fields || []).find(x => x.key === fieldKey); if (!field) return;
    const choices = Array.isArray(field.choices) ? field.choices : [];
    const control = field.kind === 'choice' ? `<select id="moduleControlInput">${choices.map(x => `<option value="${esc(x)}" ${String(x) === String(field.value) ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>` : `<input id="moduleControlInput" type="${['int','float'].includes(field.kind) ? 'number' : 'text'}" value="${esc(field.value ?? '')}" ${field.minimum != null ? `min="${esc(field.minimum)}"` : ''} ${field.maximum != null ? `max="${esc(field.maximum)}"` : ''} required>`;
    openModal('MODULE SETTING', field.label, `<form id="moduleControlEditForm"><div class="field"><label>${esc(field.label)}</label>${control}<small class="field-help">${esc(field.help_text || `${moduleKey}.${fieldKey}`)}</small></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const form = $('#moduleControlEditForm'); if (!form?.reportValidity()) return; let value = $('#moduleControlInput').value; if (field.kind === 'int') value = Number.parseInt(value, 10); if (field.kind === 'float') value = Number(value); const result = await action('control_change', { module: moduleKey, field: fieldKey, value }, false); invalidate('adminPlatform','overview'); closeModal(); toast(result?.result?.status === 'review_required' ? (state.lang === 'fa' ? 'درخواست تأیید ساخته شد.' : 'Approval request created.') : t('success')); adminModuleControlCenter(); } }]);
}

document.addEventListener('input', event => {
    const input = event.target.closest('[data-module-control-search]'); if (!input) return;
    const needle = String(input.value || '').trim().toLowerCase(); $$('[data-module-search]').forEach(card => card.hidden = needle && !String(card.dataset.moduleSearch || '').includes(needle));
});
document.addEventListener('click', async event => {
    const el = event.target.closest('[data-admin-module],[data-control-toggle],[data-control-edit],[data-control-preset],[data-governance-approve],[data-governance-reject],[data-governance-apply],[data-governance-retry]'); if (!el) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (el.dataset.adminModule) return adminModuleDetail(el.dataset.adminModule);
    if (el.dataset.controlToggle) { const [module, field] = el.dataset.controlToggle.split(':'); const value = el.dataset.controlValue === 'true'; const result = await action('control_change', { module, field, value }, false); invalidate('adminPlatform','overview'); closeModal(); toast(result?.result?.status === 'review_required' ? (state.lang === 'fa' ? 'درخواست تأیید ساخته شد.' : 'Approval request created.') : t('success')); return adminModuleControlCenter(); }
    if (el.dataset.controlEdit) { const [module, field] = el.dataset.controlEdit.split(':'); return adminModuleEdit(module, field); }
    if (el.dataset.controlPreset) { if (!confirm(state.lang === 'fa' ? 'درخواست تغییر سراسری ثبت شود؟' : 'Submit global preset request?')) return; await action('control_preset', { preset: el.dataset.controlPreset }, false); invalidate('adminPlatform'); toast(state.lang === 'fa' ? 'درخواست حاکمیت ساخته شد.' : 'Governance request created.'); return adminModuleControlCenter(); }
    if (el.dataset.governanceApprove) { await action('governance_request_approve', { request_id: el.dataset.governanceApprove }, false); invalidate('adminPlatform'); toast(t('success')); return adminModuleControlCenter(); }
    if (el.dataset.governanceReject) { const reason = prompt(state.lang === 'fa' ? 'دلیل رد:' : 'Rejection reason:') || ''; await action('governance_request_reject', { request_id: el.dataset.governanceReject, reason }, false); invalidate('adminPlatform'); toast(t('success')); return adminModuleControlCenter(); }
    if (el.dataset.governanceApply) { await action('governance_request_apply', { request_id: el.dataset.governanceApply }, false); invalidate('adminPlatform','overview'); toast(t('success')); return adminModuleControlCenter(); }
    if (el.dataset.governanceRetry) { await action('governance_request_retry', { request_id: el.dataset.governanceRetry }, false); invalidate('adminPlatform'); toast(t('success')); return adminModuleControlCenter(); }
}, true);


function aiAnswerMarkup(row) {
    const findings = Array.isArray(row?.findings) ? row.findings : [];
    const execution = row?.execution || {}, executed = execution?.executions || [], queued = execution?.queued || [], rejected = execution?.rejected || [];
    const executionMarkup = (executed.length || queued.length || rejected.length) ? `<div class="notice ${executed.some(x => x.status === 'failed') ? 'warning' : 'success'}"><strong>${state.lang === 'fa' ? 'نتیجه اجرای ابزارها' : 'Tool execution result'}</strong><p>${state.lang === 'fa' ? 'اجراشده' : 'Executed'}: ${num(executed.filter(x => x.status === 'executed').length,0)} · ${state.lang === 'fa' ? 'ناموفق' : 'Failed'}: ${num(executed.filter(x => x.status === 'failed').length,0)} · ${state.lang === 'fa' ? 'در انتظار' : 'Queued'}: ${num(queued.length,0)}</p></div>` : '';
    return `<article class="journal-card"><div class="row-between"><strong>${esc(row?.scope || (state.lang === 'fa' ? 'دستیار شخصی' : 'Personal assistant'))}</strong><span class="status-badge info">${esc(row?.engine || row?.model || 'SENTINEL AI')}</span></div><p class="field-help">${date(row?.created_at || new Date().toISOString())}</p><div class="notice info"><strong>${state.lang === 'fa' ? 'پرسش' : 'Question'}</strong><p>${esc(row?.question || '')}</p></div><div class="ai-answer"><p>${esc(row?.answer || '').replaceAll('\n', '<br>')}</p></div>${executionMarkup}${findings.length ? `<div class="journal-list">${findings.map(x => `<div class="notice"><p>${esc(typeof x === 'string' ? x : JSON.stringify(x))}</p></div>`).join('')}</div>` : ''}</article>`;
}

async function userAiCenter(latest = null) {
    setBusy(true);
    try {
        const d = await loadResource('ai', true), status = d?.status || {}, access = d?.access || {}, rows = d?.items || [];
        const allowed = access.allowed !== false, mode = access.mode || status?.user_access?.user_access_mode || 'vip_only';
        const current = latest ? `<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'نتیجه بررسی جدید' : 'New review result'}</h3></div><div class="panel-body">${aiAnswerMarkup({...latest, question: state.lang === 'fa' ? 'بررسی هوشمند حساب و رفتار' : 'Account and behavior review', created_at: new Date().toISOString()})}</div></section>` : '';
        const accessText = mode === 'all' ? (state.lang === 'fa' ? 'برای همه کاربران فعال' : 'Available to all users') : (state.lang === 'fa' ? 'فقط کاربران VIP' : 'VIP users only');
        openModal('SENTINEL AI REVIEW', state.lang === 'fa' ? 'بررسی هوشمند حساب' : 'Smart account review', `<div class="notice ${allowed ? (status.enabled ? 'success' : 'warning') : 'danger'}"><strong>${allowed ? (status.enabled ? (state.lang === 'fa' ? 'Gemini آماده بررسی است' : 'Gemini is ready') : (state.lang === 'fa' ? 'موتور جایگزین Sentinel فعال است' : 'Sentinel fallback is active')) : (state.lang === 'fa' ? 'دسترسی این حساب فعال نیست' : 'This account is not eligible')}</strong><p>${state.lang === 'fa' ? 'کاربر گفت‌وگوی مستقیم با AI ندارد. با زدن دکمه، فقط حساب‌های MT5، ژورنال، نگهبان پراپ، مربی ریسک و رفتار معاملاتی خودش بررسی می‌شود.' : 'There is no direct AI chat. The button reviews only the user’s own MT5, journal, prop-guardian, risk-coach and trading behavior data.'}</p><small>${esc(accessText)}</small></div><div class="card-actions"><button class="button primary wide" data-user-ai-review ${allowed ? '' : 'disabled'}>${state.lang === 'fa' ? '🧠 بررسی هوشمند' : '🧠 Run smart review'}</button></div>${current}<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'بررسی‌های قبلی' : 'Previous reviews'}</h3></div><div class="panel-body journal-list">${rows.map(aiAnswerMarkup).join('') || empty()}</div></section>`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}

async function _adminAiCenterLegacy(latest = null) {
    setBusy(true);
    try {
        const d = await loadResource('adminAI', true), status = d?.status || {}, usage = d?.usage || {}, access = d?.access || {}, scopes = (d?.scopes || []).filter(x => x.enabled), rows = d?.items || [], proposals = (d?.proposals || []).filter(x => x.status === 'pending');
        const commands = d?.pending_commands || [], pendingAdmins = d?.pending_admins || [], execution = d?.execution_settings || {}, isPrimary = d?.is_primary_admin === true;
        const proposalMarkup = proposals.map(p => `<article class="journal-card"><div class="row-between"><strong>#${num(p.id,0)} · ${esc(p.title || p.type)}</strong><span class="status-badge warn">${esc(p.type)}</span></div><p>${esc(p.reason || '')}</p><pre class="code-block" dir="ltr">${esc(JSON.stringify(p.payload || {}, null, 2))}</pre><div class="card-actions">${d.can_confirm_standard ? `<button class="button primary small" data-ai-proposal-approve="${esc(p.id)}">${state.lang === 'fa' ? 'تأیید انسانی' : 'Human approve'}</button><button class="button danger small" data-ai-proposal-reject="${esc(p.id)}">${state.lang === 'fa' ? 'رد پیشنهاد' : 'Reject'}</button>` : ''}</div></article>`).join('');
        const commandMarkup = commands.map(c => `<article class="journal-card"><div class="row-between"><strong>#${num(c.id,0)} · ${esc(c.action || '')}</strong><span class="status-badge warn">${state.lang === 'fa' ? 'منتظر ادمین اصلی' : 'Awaiting primary'}</span></div><p>${esc(c.reason || c.question || '')}</p><small>${state.lang === 'fa' ? 'درخواست‌کننده' : 'Requested by'}: ${esc(c.requested_by || '')}</small><pre class="code-block" dir="ltr">${esc(JSON.stringify(c.payload || {}, null, 2))}</pre>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-ai-command-approve="${esc(c.id)}">${state.lang === 'fa' ? 'تأیید و اجرا' : 'Approve & execute'}</button><button class="button danger small" data-ai-command-reject="${esc(c.id)}">${state.lang === 'fa' ? 'رد دستور' : 'Reject command'}</button></div>` : ''}</article>`).join('');
        const adminMarkup = pendingAdmins.map(a => `<article class="journal-card"><div class="row-between"><strong>${esc(a.user_id || '')}</strong><span class="status-badge warn">${state.lang === 'fa' ? 'ادمین در انتظار تأیید' : 'Pending admin'}</span></div><p>${esc((a.permissions || []).join(' · '))}</p>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-delegated-admin-approve="${esc(a.user_id)}">${state.lang === 'fa' ? 'تأیید ادمین' : 'Approve admin'}</button><button class="button danger small" data-delegated-admin-reject="${esc(a.user_id)}">${state.lang === 'fa' ? 'رد درخواست' : 'Reject request'}</button></div>` : ''}</article>`).join('');
        const latestMarkup = latest ? `<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'پاسخ جدید' : 'New answer'}</h3></div><div class="panel-body">${aiAnswerMarkup({...latest, created_at: new Date().toISOString()})}</div></section>` : '';
        const mode = access.user_access_mode || 'vip_only', healthTone = status.authenticated && status.model_available ? 'success' : status.configured ? 'warning' : 'danger';
        const daily = usage.today || {}, monthly = usage.month || {}, remaining = usage.remaining || {};
        const directMode = isPrimary && execution.autonomous_primary_admin && execution.execution_enabled;
        const executionText = directMode ? (state.lang === 'fa' ? 'دستورات ادمین اصلی بدون تأیید اضافه اجرا می‌شوند.' : 'Primary-admin commands execute without extra confirmation.') : isPrimary ? (state.lang === 'fa' ? 'اجرای ابزارها با کلید اضطراری متوقف شده است.' : 'Tool execution is stopped by the emergency switch.') : (state.lang === 'fa' ? 'دستورات شما برای تأیید ادمین اصلی ارسال می‌شوند.' : 'Your commands are sent to the primary admin for approval.');
        openModal('AI COMMAND CENTER', state.lang === 'fa' ? 'مرکز فرماندهی هوش مصنوعی' : 'AI Command Center', `<div class="notice ${healthTone}"><strong>${status.authenticated && status.model_available ? (state.lang === 'fa' ? 'Gemini فعال و احراز هویت شده' : 'Gemini authenticated and ready') : status.configured ? (state.lang === 'fa' ? 'کلید تنظیم شده؛ تست زنده لازم است' : 'Key configured; live test required') : (state.lang === 'fa' ? 'Gemini تنظیم نشده است' : 'Gemini is not configured')}</strong><p>${executionText}</p><small>${state.lang === 'fa' ? 'ادمین اصلی' : 'Primary admin'}: ${esc(d.primary_admin_id || '—')} · ${state.lang === 'fa' ? 'آخرین تست' : 'Last check'}: ${esc(status.last_checked_at || '—')} · ${num(status.latency_ms || 0,0)} ms · ${esc(status.last_error || 'OK')}</small></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'درخواست امروز' : 'Requests today', num(daily.requests || 0,0),'','info')}${metric(state.lang === 'fa' ? 'توکن امروز' : 'Tokens today', num(daily.total_tokens || 0,0),'','info')}${metric(state.lang === 'fa' ? 'توکن ماه' : 'Monthly tokens', num(monthly.total_tokens || 0,0),'','warn')}${metric(state.lang === 'fa' ? 'دستور منتظر' : 'Pending commands', num(commands.length,0),'','warn')}</div><div class="card-actions"><button class="button secondary" data-admin-ai-health-test>${state.lang === 'fa' ? 'تست زنده Gemini' : 'Live Gemini test'}</button><button class="button secondary" data-admin-ai-daily-report>${state.lang === 'fa' ? 'گزارش روزانه مدیر' : 'Daily manager report'}</button>${d.can_confirm_standard ? `<button class="button ${mode === 'all' ? 'success' : 'warning'}" data-admin-ai-access-toggle>${mode === 'all' ? (state.lang === 'fa' ? 'AI کاربران: همه' : 'User AI: everyone') : (state.lang === 'fa' ? 'AI کاربران: فقط VIP' : 'User AI: VIP only')}</button>` : ''}${isPrimary ? `<button class="button ${execution.execution_enabled ? 'danger' : 'success'}" data-admin-ai-execution-toggle data-enabled="${execution.execution_enabled ? 'false' : 'true'}">${execution.execution_enabled ? (state.lang === 'fa' ? '⛔ توقف اجرای AI' : '⛔ Stop AI execution') : (state.lang === 'fa' ? '✅ فعال‌کردن اجرای AI' : '✅ Enable AI execution')}</button>` : ''}</div><form id="adminAiForm"><div class="form-grid"><div class="field"><label for="adminAiScope">${state.lang === 'fa' ? 'حوزه تحلیل و کنترل' : 'Analysis and control scope'}</label><select id="adminAiScope">${scopes.map(x => `<option value="${esc(x.key)}">${esc(state.lang === 'fa' ? x.label_fa : x.key)}</option>`).join('')}</select></div><div class="field"><label for="adminAiTargetUser">${state.lang === 'fa' ? 'آیدی کاربر هدف (اختیاری)' : 'Target user ID (optional)'}</label><input id="adminAiTargetUser" inputmode="numeric" placeholder="123456789"></div><div class="field field-span"><label for="adminAiQuestion">${state.lang === 'fa' ? 'دستور یا سؤال مدیریتی' : 'Administrative instruction or question'}</label><textarea id="adminAiQuestion" required minlength="2" maxlength="4000" rows="5" placeholder="${state.lang === 'fa' ? 'مثلاً آخرین عکس را قالب BUY کن و یک پیش‌نمایش بساز.' : 'Use the latest image as the BUY template and create a preview.'}"></textarea></div></div></form><div class="card-actions"><button class="button primary" data-admin-ai-send>${state.lang === 'fa' ? (directMode ? 'اجرا با Gemini' : 'ارسال دستور') : (directMode ? 'Execute with Gemini' : 'Send command')}</button></div>${latestMarkup}<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'دستورهای ادمین‌های دیگر' : 'Delegated-admin commands'}</h3><span class="status-badge warn">${num(commands.length,0)}</span></div><div class="panel-body journal-list">${commandMarkup || empty()}</div></section><section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'ادمین‌های در انتظار تأیید' : 'Admins pending approval'}</h3><span class="status-badge warn">${num(pendingAdmins.length,0)}</span></div><div class="panel-body journal-list">${adminMarkup || empty()}</div></section><section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'پیشنهادهای قدیمی در انتظار تأیید' : 'Legacy proposals pending approval'}</h3><span class="status-badge warn">${num(proposals.length,0)}</span></div><div class="panel-body journal-list">${proposalMarkup || empty()}</div></section><section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'تاریخچه فرمان‌ها' : 'Command history'}</h3></div><div class="panel-body journal-list">${rows.map(aiAnswerMarkup).join('') || empty()}</div></section>`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}


async function adminAiCenter(latest = null) {
    setBusy(true);
    try {
        const d = await loadResource('adminAI', true);
        const status = d?.status || {}, usage = d?.usage || {}, access = d?.access || {};
        const scopes = (d?.scopes || []).filter(item => item.enabled);
        const history = d?.items || [], proposals = (d?.proposals || []).filter(item => item.status === 'pending');
        const commands = d?.pending_commands || [], pendingAdmins = d?.pending_admins || [];
        const execution = d?.execution_settings || {}, isPrimary = d?.is_primary_admin === true;
        const fa = state.lang === 'fa', mode = access.user_access_mode || 'vip_only';
        const healthTone = status.authenticated && status.model_available ? 'success' : status.configured ? 'warning' : 'danger';
        const directMode = isPrimary && execution.autonomous_primary_admin && execution.execution_enabled;
        const daily = usage.today || {}, monthly = usage.month || {};
        const latestMarkup = latest ? `<section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'پاسخ جدید Gemini' : 'New Gemini answer'}</h3></div><div class="panel-body">${aiAnswerMarkup({...latest, created_at:new Date().toISOString()})}</div></section>` : '';
        const commandMarkup = commands.map(item => `<article class="journal-card"><div class="row-between"><strong>#${num(item.id,0)} · ${esc(item.action || '')}</strong><span class="status-badge warn">${fa ? 'منتظر تأیید انسانی' : 'Awaiting human approval'}</span></div><p>${esc(item.reason || item.question || '')}</p><pre class="code-block" dir="ltr">${esc(JSON.stringify(item.payload || {}, null, 2))}</pre>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-ai-command-approve="${esc(item.id)}">${fa ? 'تأیید و اجرا' : 'Approve & execute'}</button><button class="button danger small" data-ai-command-reject="${esc(item.id)}">${fa ? 'رد دستور' : 'Reject'}</button></div>` : ''}</article>`).join('');
        const proposalMarkup = proposals.map(item => `<article class="journal-card"><div class="row-between"><strong>#${num(item.id,0)} · ${esc(item.title || item.type)}</strong><span class="status-badge warn">${esc(item.type || '')}</span></div><p>${esc(item.reason || '')}</p><pre class="code-block" dir="ltr">${esc(JSON.stringify(item.payload || {}, null, 2))}</pre>${d.can_confirm_standard ? `<div class="card-actions"><button class="button primary small" data-ai-proposal-approve="${esc(item.id)}">${fa ? 'تأیید انسانی' : 'Human approve'}</button><button class="button danger small" data-ai-proposal-reject="${esc(item.id)}">${fa ? 'رد' : 'Reject'}</button></div>` : ''}</article>`).join('');
        const adminMarkup = pendingAdmins.map(item => `<article class="journal-card"><div class="row-between"><strong>${esc(item.user_id || '')}</strong><span class="status-badge warn">${fa ? 'ادمین منتظر تأیید' : 'Pending admin'}</span></div><p>${esc((item.permissions || []).join(' · '))}</p>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-delegated-admin-approve="${esc(item.user_id)}">${fa ? 'تأیید ادمین' : 'Approve admin'}</button><button class="button danger small" data-delegated-admin-reject="${esc(item.user_id)}">${fa ? 'رد درخواست' : 'Reject'}</button></div>` : ''}</article>`).join('');
        const executionText = directMode
            ? (fa ? 'فرمان‌های مجاز ادمین اصلی مستقیم اجرا می‌شوند؛ کد تخفیف و دسترسی ادمین همیشه تأیید انسانی می‌خواهند.' : 'Allowed primary-admin commands execute directly; discounts and admin access always require human approval.')
            : isPrimary
                ? (fa ? 'اجرای خودکار متوقف است؛ فرمان‌ها برای تأیید انسانی در صف می‌مانند.' : 'Automatic execution is stopped; commands stay queued for human approval.')
                : (fa ? 'فرمان‌های شما پس از کنترل مجوز برای تأیید ادمین اصلی ارسال می‌شوند.' : 'Your permission-checked commands are sent to the primary admin for approval.');
        const html = `
          <div class="notice ${healthTone}">
            <strong>${status.authenticated && status.model_available ? (fa ? 'Gemini آماده گفت‌وگو و فرمان است' : 'Gemini is ready for chat and commands') : status.configured ? (fa ? 'کلید تنظیم شده؛ تست زنده لازم است' : 'Key configured; live test required') : (fa ? 'Gemini تنظیم نشده است' : 'Gemini is not configured')}</strong>
            <p>${executionText}</p>
            <small>${fa ? 'مدل' : 'Model'}: ${esc(status.model || '—')} · ${fa ? 'آخرین بررسی' : 'Last check'}: ${esc(status.last_checked_at || '—')} · ${num(status.latency_ms || 0,0)} ms</small>
          </div>
          <div class="notice info">
            <strong>${fa ? 'فرمان مستقیم به کل بخش‌های عملیاتی مجاز' : 'Direct command access to allowed operations'}</strong>
            <p>${fa ? 'می‌توانید درباره کاربران، CRM، کمپین، کانال، تیکت، سیگنال، آموزش، مسابقه، ریسک و سلامت سیستم صحبت کنید. نمونه: «کمپین کاربران غیرفعال را بساز» یا «کد WELCOME15 با ۱۵٪ تخفیف و اعتبار ۷ روز بساز».' : 'Talk about users, CRM, campaigns, channels, tickets, signals, education, contests, risk and system health. Example: create a dormant-user campaign or a 15% seven-day WELCOME15 code.'}</p>
            <small>${fa ? 'پرداخت، رسید، TXID، بازپرداخت، تغییر VIP، Shell، SQL، Deploy و اسرار مسدود هستند.' : 'Payments, receipts, TXIDs, refunds, VIP changes, Shell, SQL, deploy and secrets are blocked.'}</small>
          </div>
          <div class="metric-grid">
            ${metric(fa ? 'درخواست امروز' : 'Requests today', num(daily.requests || 0,0),'','info')}
            ${metric(fa ? 'توکن امروز' : 'Tokens today', num(daily.total_tokens || 0,0),'','info')}
            ${metric(fa ? 'توکن ماه' : 'Monthly tokens', num(monthly.total_tokens || 0,0),'','warn')}
            ${metric(fa ? 'دستور منتظر' : 'Pending commands', num(commands.length,0),'','warn')}
          </div>
          <div class="card-actions">
            <button class="button secondary" data-admin-ai-health-test>${fa ? 'تست زنده Gemini' : 'Live Gemini test'}</button>
            <button class="button secondary" data-admin-ai-daily-report>${fa ? 'گزارش روزانه مدیر' : 'Daily manager report'}</button>
            ${d.can_confirm_standard ? `<button class="button ${mode === 'all' ? 'success' : 'warning'}" data-admin-ai-access-toggle>${mode === 'all' ? (fa ? 'AI کاربران: همه' : 'User AI: everyone') : (fa ? 'AI کاربران: فقط VIP' : 'User AI: VIP only')}</button>` : ''}
            ${isPrimary ? `<button class="button ${execution.execution_enabled ? 'danger' : 'success'}" data-admin-ai-execution-toggle data-enabled="${execution.execution_enabled ? 'false' : 'true'}">${execution.execution_enabled ? (fa ? '⛔ توقف اجرای AI' : '⛔ Stop AI execution') : (fa ? '✅ فعال‌کردن اجرای AI' : '✅ Enable AI execution')}</button>` : ''}
          </div>
          <form id="adminAiForm">
            <div class="form-grid">
              <div class="field"><label for="adminAiScope">${fa ? 'حوزه گفت‌وگو و کنترل' : 'Chat and control scope'}</label><select id="adminAiScope">${scopes.map(item => `<option value="${esc(item.key)}">${esc(fa ? item.label_fa : item.key)}</option>`).join('')}</select></div>
              <div class="field"><label for="adminAiTargetUser">${fa ? 'آیدی کاربر هدف (اختیاری)' : 'Target user ID (optional)'}</label><input id="adminAiTargetUser" inputmode="numeric" placeholder="123456789"></div>
              <div class="field field-span"><label for="adminAiQuestion">${fa ? 'با Gemini صحبت کنید یا فرمان بدهید' : 'Talk to Gemini or issue a command'}</label><textarea id="adminAiQuestion" required minlength="2" maxlength="4000" rows="8" placeholder="${fa ? 'مثال: یک کمپین برای کاربران غیرفعال بساز و سپس کد تخفیف عمومی WELCOME15 با ۱۵ درصد، ۷ روز اعتبار و یک‌بار مصرف برای هر کاربر آماده کن.' : 'Example: create a dormant-user campaign, then prepare public code WELCOME15 at 15% for seven days and one use per user.'}"></textarea></div>
            </div>
          </form>
          <div class="card-actions"><button class="button primary wide" data-admin-ai-send>${fa ? (directMode ? 'ارسال و اجرای امن با Gemini' : 'ارسال فرمان برای بررسی') : (directMode ? 'Send and safely execute' : 'Send command for review')}</button></div>
          ${latestMarkup}
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'دستورهای منتظر تأیید' : 'Commands awaiting approval'}</h3><span class="status-badge warn">${num(commands.length,0)}</span></div><div class="panel-body journal-list">${commandMarkup || empty()}</div></section>
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'درخواست ادمین جدید' : 'Pending admins'}</h3><span class="status-badge warn">${num(pendingAdmins.length,0)}</span></div><div class="panel-body journal-list">${adminMarkup || empty()}</div></section>
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'پیشنهادهای منتظر' : 'Pending proposals'}</h3><span class="status-badge warn">${num(proposals.length,0)}</span></div><div class="panel-body journal-list">${proposalMarkup || empty()}</div></section>
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'تاریخچه گفت‌وگو و فرمان' : 'Chat and command history'}</h3></div><div class="panel-body journal-list">${history.map(aiAnswerMarkup).join('') || empty()}</div></section>`;
        openModal('GEMINI ADMIN CHAT', fa ? 'گفت‌وگو و فرمان به Gemini' : 'Chat and command Gemini', html, []);
    } catch (err) {
        toast(localizedError(err), 'error');
    } finally {
        setBusy(false);
    }
}

function vipPlanFormMarkup(plan = {}) {
    return `<form id="vipPlanForm"><div class="form-grid"><div class="field"><label for="vipPlanName">${state.lang === 'fa' ? 'نام پلن' : 'Plan name'}</label><input id="vipPlanName" required minlength="2" maxlength="80" value="${esc(plan.name || '')}"></div><div class="field"><label for="vipPlanPrice">${state.lang === 'fa' ? 'قیمت' : 'Price'}</label><input id="vipPlanPrice" type="number" min="0" max="10000000000" required value="${esc(plan.price ?? 0)}"></div><div class="field"><label for="vipPlanDays">${state.lang === 'fa' ? 'مدت (روز)' : 'Duration (days)'}</label><input id="vipPlanDays" type="number" min="1" max="3650" required value="${esc(plan.duration_days ?? 30)}"></div><div class="field"><label for="vipPlanOriginalPrice">${state.lang === 'fa' ? 'قیمت قبلی' : 'Original price'}</label><input id="vipPlanOriginalPrice" type="number" min="0" value="${esc(plan.original_price ?? 0)}"></div><div class="field"><label for="vipPlanAudience">${state.lang === 'fa' ? 'مخاطب' : 'Audience'}</label><select id="vipPlanAudience"><option value="all">all</option><option value="new">new</option><option value="renewal">renewal</option></select></div><div class="field"><label for="vipPlanSalesLimit">${state.lang === 'fa' ? 'سقف فروش (۰ نامحدود)' : 'Sales limit (0 unlimited)'}</label><input id="vipPlanSalesLimit" type="number" min="0" value="${esc(plan.sales_limit ?? 0)}"></div><div class="field field-span"><label for="vipPlanDescription">${state.lang === 'fa' ? 'توضیحات' : 'Description'}</label><textarea id="vipPlanDescription" maxlength="500" rows="3">${esc(plan.description || '')}</textarea></div><div class="field field-span"><label for="vipPlanFeatures">${state.lang === 'fa' ? 'امکانات؛ هر خط یک مورد' : 'Features; one per line'}</label><textarea id="vipPlanFeatures" rows="5">${esc((plan.features || []).join('\n'))}</textarea></div></div></form>`;
}

async function adminVipPlanCenter() {
    setBusy(true);
    try {
        const d = await loadResource('adminVipPlans', true), perms = d?.permissions || {}, rows = d?.items || [];
        openModal('VIP PLAN ADMIN', state.lang === 'fa' ? 'مدیریت پلن‌های VIP' : 'VIP plan management', `<div class="notice warning"><strong>${state.lang === 'fa' ? 'دسترسی Gemini ادمین اصلی فعال است' : 'Primary-admin Gemini access is enabled'}</strong><p>${state.lang === 'fa' ? 'ادمین اصلی می‌تواند همین عملیات ثبت‌شده را از مرکز فرماندهی Gemini نیز اجرا کند.' : 'The primary admin can also execute these registered actions from Gemini Command Center.'}</p></div><div class="card-actions">${perms.settings ? `<button class="button primary" data-vip-settings-edit>${state.lang === 'fa' ? 'شماره کارت، نام و قیمت پیش‌فرض' : 'Card, owner & defaults'}</button>` : ''}${perms.create ? `<button class="button primary" data-vip-plan-create>${state.lang === 'fa' ? 'ساخت پلن جدید' : 'Create new plan'}</button>` : ''}</div><div class="journal-list">${rows.map(p => `<article class="journal-card"><div class="row-between"><div><strong>#${num(p.id,0)} · ${esc(p.name || '')}</strong><p>${num(p.duration_days,0)} ${state.lang === 'fa' ? 'روز' : 'days'} · ${money(p.price || 0, 'T')}</p></div><span class="status-badge ${p.archived ? 'bad' : p.active ? 'good' : 'warn'}">${p.archived ? 'ARCHIVED' : p.active ? 'ACTIVE' : 'OFF'}</span></div><p>${esc(p.description || '')}</p><div class="metric-grid">${metric(state.lang === 'fa' ? 'فروش' : 'Sales', num(p.sales_count || 0,0),'','info')}${metric(state.lang === 'fa' ? 'مخاطب' : 'Audience', esc(p.audience || 'all'),'','')}</div><div class="card-actions">${perms.edit ? `<button class="button secondary small" data-vip-plan-edit="${esc(p.id)}">${state.lang === 'fa' ? 'ویرایش' : 'Edit'}</button>` : ''}${perms.activate ? `<button class="button small" data-vip-plan-mode="${p.active ? 'deactivate' : 'activate'}" data-plan-id="${esc(p.id)}">${p.active ? (state.lang === 'fa' ? 'غیرفعال' : 'Deactivate') : (state.lang === 'fa' ? 'فعال' : 'Activate')}</button>` : ''}${perms.archive && !p.archived ? `<button class="button danger small" data-vip-plan-mode="archive" data-plan-id="${esc(p.id)}">${state.lang === 'fa' ? 'آرشیو' : 'Archive'}</button>` : ''}${perms.delete ? `<button class="button danger small" data-vip-plan-delete="${esc(p.id)}">${state.lang === 'fa' ? 'حذف' : 'Delete'}</button>` : ''}</div></article>`).join('') || empty()}</div>`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}

function adminVipSettingsModal() {
    const d = state.resources.adminVipPlans || {}, x = d.settings || {};
    openModal('VIP SETTINGS', state.lang === 'fa' ? 'تنظیمات پرداخت و پیش‌فرض VIP' : 'VIP payment defaults', `<form id="vipSettingsForm"><div class="form-grid"><div class="field"><label for="vipSettingsCard">${state.lang === 'fa' ? 'شماره کارت ۱۶ رقمی' : '16-digit card number'}</label><input id="vipSettingsCard" inputmode="numeric" required minlength="16" maxlength="24" value="${esc(x.card_number || '')}"></div><div class="field"><label for="vipSettingsOwner">${state.lang === 'fa' ? 'نام صاحب کارت' : 'Card holder'}</label><input id="vipSettingsOwner" required minlength="2" maxlength="60" value="${esc(x.owner_name || '')}"></div><div class="field"><label for="vipSettingsPrice">${state.lang === 'fa' ? 'قیمت پیش‌فرض (تومان)' : 'Default price'}</label><input id="vipSettingsPrice" type="number" min="0" max="10000000000" required value="${esc(x.price ?? 0)}"></div><div class="field"><label for="vipSettingsDays">${state.lang === 'fa' ? 'مدت پیش‌فرض (روز)' : 'Default duration'}</label><input id="vipSettingsDays" type="number" min="1" max="3650" required value="${esc(x.duration_days ?? 30)}"></div></div></form>`, [{label: state.lang === 'fa' ? 'ذخیره تنظیمات' : 'Save settings', kind:'primary', action: async () => {
        const f=$('#vipSettingsForm'); if(!f?.reportValidity()) return;
        const values=[['card_number',$('#vipSettingsCard').value],['owner_name',$('#vipSettingsOwner').value],['price',Number($('#vipSettingsPrice').value)],['duration_days',Number($('#vipSettingsDays').value)]];
        setBusy(true); try { for(const [field,value] of values) await action('admin_vip_settings_update',{field,value},false); invalidate('adminVipPlans','overview'); closeModal(); await adminVipPlanCenter(); toast(t('success')); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); }
    }}]);
}

function adminVipPlanCreateModal() {
    openModal('VIP PLAN', state.lang === 'fa' ? 'ساخت پلن جدید' : 'Create a new plan', vipPlanFormMarkup(), [{label: state.lang === 'fa' ? 'ساخت پلن' : 'Create plan', kind:'primary', action: async () => {
        const f = $('#vipPlanForm'); if (!f?.reportValidity()) return;
        const payload = {name: $('#vipPlanName').value.trim(), price: Number($('#vipPlanPrice').value), duration_days: Number($('#vipPlanDays').value), original_price: Number($('#vipPlanOriginalPrice').value || 0), audience: $('#vipPlanAudience').value, sales_limit: Number($('#vipPlanSalesLimit').value || 0), description: $('#vipPlanDescription').value.trim(), features: $('#vipPlanFeatures').value.split('\n').map(x => x.trim()).filter(Boolean)};
        await action('admin_vip_plan_create', payload, false); invalidate('adminVipPlans','overview'); closeModal(); await adminVipPlanCenter(); toast(t('success'));
    }}]);
}

async function adminVipPlanEditModal(planId) {
    const d = state.resources.adminVipPlans || await loadResource('adminVipPlans', true), p = (d.items || []).find(x => String(x.id) === String(planId));
    if (!p) return toast('VIP_PLAN_NOT_FOUND','error');
    openModal('VIP PLAN', state.lang === 'fa' ? 'ویرایش پلن' : 'Edit plan', vipPlanFormMarkup(p), [{label: state.lang === 'fa' ? 'ذخیره تغییرات' : 'Save changes', kind:'primary', action: async () => {
        const f = $('#vipPlanForm'); if (!f?.reportValidity()) return;
        const updates = [['name',$('#vipPlanName').value.trim()],['price',Number($('#vipPlanPrice').value)],['duration_days',Number($('#vipPlanDays').value)],['original_price',Number($('#vipPlanOriginalPrice').value || 0)],['sales_limit',Number($('#vipPlanSalesLimit').value || 0)],['description',$('#vipPlanDescription').value.trim()],['audience',$('#vipPlanAudience').value],['features',$('#vipPlanFeatures').value.split('\n').map(x=>x.trim()).filter(Boolean)]];
        setBusy(true); try { for (const [field,value] of updates) await action('admin_vip_plan_update',{plan_id: planId,field,value},false); invalidate('adminVipPlans','overview'); closeModal(); await adminVipPlanCenter(); toast(t('success')); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); }
    }}]);
    $('#vipPlanAudience').value = p.audience || 'all';
}

document.addEventListener('click', async event => {
    const userReview = event.target.closest('[data-user-ai-review]');
    if (userReview) { event.preventDefault(); setBusy(true); try { const r=await action('user_ai_review',{language:state.lang},false); invalidate('ai'); closeModal(); await userAiCenter(r); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    if (event.target.closest('[data-admin-ai-health-test]')) { event.preventDefault(); setBusy(true); try { await action('admin_ai_health_test',{generation_test:true},false); invalidate('adminAI'); closeModal(); await adminAiCenter(); toast(state.lang==='fa'?'تست زنده انجام شد':'Live test completed'); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    if (event.target.closest('[data-admin-ai-access-toggle]')) { event.preventDefault(); if(!confirm(state.lang==='fa'?'حالت دسترسی کاربران بین فقط VIP و همه تغییر کند؟':'Toggle user AI access between VIP-only and everyone?')) return; await action('admin_ai_user_access_toggle',{},true); invalidate('adminAI','ai','overview'); closeModal(); await adminAiCenter(); return; }
    if (event.target.closest('[data-admin-ai-daily-report]')) { event.preventDefault(); setBusy(true); try { const r=await action('admin_ai_daily_report',{language:state.lang,force:true},false); invalidate('adminAI'); closeModal(); await adminAiCenter({...r,scope:'management',question:state.lang==='fa'?'گزارش روزانه مدیر':'Daily manager report'}); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    const adminSend = event.target.closest('[data-admin-ai-send]');
    if (adminSend) { event.preventDefault(); const f=$('#adminAiForm'), q=$('#adminAiQuestion')?.value.trim(), selectedScope=$('#adminAiScope')?.value || 'management', targetUser=$('#adminAiTargetUser')?.value.trim() || null; if(!f?.reportValidity()) return; setBusy(true); try { const r=await action('admin_ai_query',{question:q,scope:selectedScope,target_user_id:targetUser,language:state.lang},false); invalidate('adminAI'); closeModal(); await adminAiCenter({...r,question:q,scope:selectedScope}); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    const approve = event.target.closest('[data-ai-proposal-approve]');
    if (approve) { event.preventDefault(); if(!confirm(state.lang==='fa'?'این پیشنهاد فقط پس از تأیید انسانی اجرا شود؟':'Approve this proposal as a human admin?')) return; await action('admin_ai_proposal_approve',{proposal_id:Number(approve.dataset.aiProposalApprove)},true); invalidate('adminAI','adminCampaigns','adminTickets','adminOps'); closeModal(); await adminAiCenter(); return; }
    const reject = event.target.closest('[data-ai-proposal-reject]');
    if (reject) { event.preventDefault(); await action('admin_ai_proposal_reject',{proposal_id:Number(reject.dataset.aiProposalReject),reason:'rejected_by_human_admin'},true); invalidate('adminAI'); closeModal(); await adminAiCenter(); return; }
    const commandApprove = event.target.closest('[data-ai-command-approve]');
    if (commandApprove) { event.preventDefault(); await action('admin_ai_command_approve',{command_id:Number(commandApprove.dataset.aiCommandApprove)},true); invalidate('adminAI','overview'); closeModal(); await adminAiCenter(); return; }
    const commandReject = event.target.closest('[data-ai-command-reject]');
    if (commandReject) { event.preventDefault(); const reason=prompt(state.lang==='fa'?'دلیل رد دستور:':'Rejection reason:') || 'rejected_by_primary_admin'; await action('admin_ai_command_reject',{command_id:Number(commandReject.dataset.aiCommandReject),reason},true); invalidate('adminAI'); closeModal(); await adminAiCenter(); return; }
    const adminApprove = event.target.closest('[data-delegated-admin-approve]');
    if (adminApprove) { event.preventDefault(); await action('delegated_admin_approve',{user_id:adminApprove.dataset.delegatedAdminApprove},true); invalidate('adminAI','adminAdmins','overview'); closeModal(); await adminAiCenter(); return; }
    const adminReject = event.target.closest('[data-delegated-admin-reject]');
    if (adminReject) { event.preventDefault(); const reason=prompt(state.lang==='fa'?'دلیل رد ادمین:':'Rejection reason:') || 'rejected_by_primary_admin'; await action('delegated_admin_reject',{user_id:adminReject.dataset.delegatedAdminReject,reason},true); invalidate('adminAI','adminAdmins','overview'); closeModal(); await adminAiCenter(); return; }
    const executionToggle = event.target.closest('[data-admin-ai-execution-toggle]');
    if (executionToggle) { event.preventDefault(); const enabled=executionToggle.dataset.enabled==='true'; if(!confirm(enabled ? (state.lang==='fa'?'اجرای دستورات Gemini فعال شود؟':'Enable Gemini tool execution?') : (state.lang==='fa'?'اجرای دستورات Gemini فوراً متوقف شود؟':'Immediately stop Gemini tool execution?'))) return; await action('admin_ai_execution_toggle',{enabled},true); invalidate('adminAI'); closeModal(); await adminAiCenter(); return; }
    if (event.target.closest('[data-admin-ai-center]')) { event.preventDefault(); adminAiCenter(); return; }
    if (event.target.closest('[data-admin-vip-plans]')) { event.preventDefault(); adminVipPlanCenter(); return; }
    if (event.target.closest('[data-vip-settings-edit]')) { event.preventDefault(); adminVipSettingsModal(); return; }
    if (event.target.closest('[data-vip-plan-create]')) { event.preventDefault(); adminVipPlanCreateModal(); return; }
    const edit = event.target.closest('[data-vip-plan-edit]'); if(edit){event.preventDefault();adminVipPlanEditModal(edit.dataset.vipPlanEdit);return;}
    const mode = event.target.closest('[data-vip-plan-mode]'); if(mode){event.preventDefault();await action('admin_vip_plan_toggle',{plan_id:Number(mode.dataset.planId),mode:mode.dataset.vipPlanMode},true);invalidate('adminVipPlans','overview');closeModal();await adminVipPlanCenter();return;}
    const del = event.target.closest('[data-vip-plan-delete]'); if(del){event.preventDefault();if(!confirm(state.lang==='fa'?'پلن بدون سابقه فروش حذف شود؟':'Delete this plan only if it has no sales history?'))return;await action('admin_vip_plan_delete',{plan_id:Number(del.dataset.vipPlanDelete)},true);invalidate('adminVipPlans','overview');closeModal();await adminVipPlanCenter();return;}
}, true);
