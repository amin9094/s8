from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from config import SETTINGS
from core.async_runtime import run_blocking
from core.metrics_v2 import observe
from core.observability import increment
from repositories.v2.events import EventRepository

logger = logging.getLogger(__name__)
_REDIS_POOL: Any = None
_REDIS_POOL_LOCK = threading.Lock()


def _redis_pool() -> Any:
    global _REDIS_POOL
    if _REDIS_POOL is not None:
        return _REDIS_POOL
    with _REDIS_POOL_LOCK:
        if _REDIS_POOL is not None:
            return _REDIS_POOL
        import redis

        timeout = max(0.5, float(os.getenv("REDIS_SOCKET_TIMEOUT_SECONDS", "2") or 2))
        _REDIS_POOL = redis.ConnectionPool.from_url(
            SETTINGS.redis_url,
            decode_responses=True,
            socket_connect_timeout=timeout,
            socket_timeout=max(timeout, float(os.getenv("REDIS_STREAM_SOCKET_TIMEOUT_SECONDS", "16") or 16)),
            health_check_interval=30,
            max_connections=max(4, int(os.getenv("REDIS_STREAM_MAX_CONNECTIONS", "50") or 50)),
            retry_on_timeout=True,
        )
        return _REDIS_POOL


def close_event_stream_pool() -> None:
    global _REDIS_POOL
    pool, _REDIS_POOL = _REDIS_POOL, None
    if pool is not None:
        try:
            pool.disconnect()
        except Exception:
            logger.debug("Could not close Redis event stream pool", exc_info=True)


@dataclass(frozen=True)
class EventBatch:
    events: list[dict[str, Any]]
    cursor: int
    gap: bool = False
    backend: str = "database"


def _record_event_lag(rows: list[dict[str, Any]]) -> None:
    lags: list[float] = []
    now = datetime.now(UTC)
    for row in rows:
        raw = str(row.get("created_at") or "").strip()
        if not raw:
            continue
        try:
            observed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            if observed.tzinfo is None:
                observed = observed.replace(tzinfo=UTC)
            lags.append(max(0.0, (now - observed.astimezone(UTC)).total_seconds()))
        except ValueError:
            continue
    if lags:
        observe("sse_event_lag", max(lags))


class EventStreamService:
    """Durable SSE source with Redis Streams acceleration.

    Database sequence numbers are the canonical cursor. Redis stream IDs are
    explicitly written as ``<sequence>-0`` so Last-Event-ID survives reconnects
    and replicas without translation or duplicate delivery.
    """

    def __init__(self, repository: EventRepository | None = None):
        self.repository = repository or EventRepository()

    async def read(self, user_id: int | str, last_sequence: int, *, block_ms: int = 12_000, limit: int = 200) -> EventBatch:
        cursor = max(0, int(last_sequence or 0))
        if SETTINGS.redis_url:
            try:
                batch = await run_blocking(self._redis_read, str(user_id), cursor, block_ms, limit, timeout=max(5.0, block_ms / 1000.0 + 5.0), acquire_timeout=2)
                if batch.events:
                    _record_event_lag(batch.events)
                    if batch.gap:
                        increment("sse_retention_gap_total")
                    return batch
            except Exception:
                logger.warning("Redis stream read failed; falling back to durable events", exc_info=True)
        rows = await run_blocking(self.repository.since, user_id, cursor, limit=limit, timeout=10)
        next_cursor = max([cursor, *[int(row.get("sequence") or 0) for row in rows]])
        _record_event_lag(rows)
        return EventBatch(rows, next_cursor, False, "database")

    def _redis_read(self, user_id: str, cursor: int, block_ms: int, limit: int) -> EventBatch:
        import redis

        client = redis.Redis(connection_pool=_redis_pool())
        streams = (f"sentinel:v8:events:user:{user_id}", "sentinel:v8:events:global")
        earliest_sequences: list[int] = []
        for stream in streams:
            first = client.xrange(stream, min="-", max="+", count=1)
            if first:
                try:
                    earliest_sequences.append(int(str(first[0][0]).split("-", 1)[0]))
                except (IndexError, TypeError, ValueError):
                    logger.debug("invalid Redis stream identifier: %r", first[0][0] if first else None)
        gap = bool(earliest_sequences) and cursor > 0 and cursor < min(earliest_sequences) - 1
        response = client.xread(
            {stream: f"{cursor}-0" for stream in streams},
            count=max(1, min(limit, 1000)),
            block=max(0, block_ms),
        )
        by_sequence: dict[int, dict[str, Any]] = {}
        next_cursor = cursor
        for _stream, records in response or []:
            for stream_id, fields in records:
                try:
                    event = json.loads(str(fields.get("event") or "{}"))
                    sequence = int(event.get("sequence") or str(stream_id).split("-", 1)[0])
                except (json.JSONDecodeError, TypeError, ValueError):
                    logger.debug("invalid Redis event payload for stream id %s", stream_id)
                    continue
                if str(event.get("user_id")) not in {user_id, "*"}:
                    continue
                event["sequence"] = sequence
                by_sequence[sequence] = event
                next_cursor = max(next_cursor, sequence)
        events = [by_sequence[key] for key in sorted(by_sequence)][: max(1, min(limit, 1000))]
        if gap:
            events.insert(0, {
                "sequence": cursor,
                "event_id": f"resync-{cursor}",
                "user_id": user_id,
                "event_type": "stream.resync_required",
                "entity_type": "system",
                "entity_id": "",
                "created_at": "",
                "payload": {"reason": "retention_gap"},
            })
        return EventBatch(events, next_cursor, gap, "redis_stream")

