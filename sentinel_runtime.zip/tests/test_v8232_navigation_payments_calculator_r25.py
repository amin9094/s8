from __future__ import annotations

from pathlib import Path

import pytest

from modules.calculator import calculate_crypto_position_size, calculate_position_size

ROOT = Path(__file__).resolve().parents[1]


def test_signal_wizard_back_is_registered_for_every_stage() -> None:
    runtime = (ROOT / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    wizard = (ROOT / "bot_runtime" / "growth_campaigns.py").read_text(encoding="utf-8")

    for state in (
        "SIG_MARKET",
        "SIG_SYMBOL",
        "SIG_TYPE",
        "SIG_ENTRY",
        "SIG_TP",
        "SIG_SL",
        "SIG_RISK",
        "SIG_CHART_IMAGE",
        "SIG_TARGET",
        "SIG_SCHEDULE_TIME",
    ):
        start = runtime.index(f"{state}:")
        end = runtime.find("\n            SIG_", start + 1)
        block = runtime[start : end if end != -1 else start + 1000]
        assert "signal_wizard_back" in block, state

    for stage in ("market", "symbol", "type", "entry", "targets", "stop", "risk", "chart", "target", "preview"):
        assert f'if stage == "{stage}"' in wizard
    assert "sig_back:preview" in wizard
    assert "sig_back:symbol" in wizard
    assert "sig_back:market" in wizard


def test_forex_calculator_never_exceeds_risk_or_margin() -> None:
    result = calculate_position_size(
        "XAUUSD",
        balance_usd=1_000,
        risk_percent=10,
        entry_price=2_000,
        stop_price=1_990,
        leverage=1,
        available_margin_usd=1_000,
    )
    assert result["effective_risk"] <= result["risk_amount"] + 1e-9
    assert result["estimated_margin"] <= result["available_margin"] + 1e-9
    assert result["lot"] <= result["risk_limited_lot"] + 1e-12
    assert result["lot"] <= result["margin_limited_lot"] + 1e-12
    assert result["capped_by_margin"] is True


def test_forex_cross_notional_is_converted_to_usd() -> None:
    result = calculate_position_size(
        "EURGBP",
        balance_usd=10_000,
        risk_percent=1,
        entry_price=0.85,
        stop_price=0.845,
        current_price=0.85,
        cross_rate=1.25,
        leverage=100,
    )
    assert result["quote_to_usd"] == pytest.approx(1.25)
    assert result["notional"] == pytest.approx(result["notional_quote"] * 1.25)
    assert result["margin_usage_percent"] <= 100.0 + 1e-9


def test_crypto_calculator_caps_quantity_to_available_margin() -> None:
    result = calculate_crypto_position_size(
        balance_usd=100,
        risk_percent=20,
        entry_price=50_000,
        stop_price=49_999,
        leverage=1,
        fee_percent_round_trip=0.2,
        available_margin_usd=100,
        quantity_step=0.000001,
    )
    assert result["quantity"] <= result["max_affordable_quantity"] + 1e-12
    assert result["estimated_margin"] <= 100 + 1e-9
    assert result["effective_risk"] <= result["risk_amount"] + 1e-9
    assert result["capped_by_margin"] is True


def test_miniapp_has_dedicated_payment_review_and_receipt_sync() -> None:
    shell = (ROOT / "webapp" / "src" / "shell-events.js").read_text(encoding="utf-8")
    bootstrap = (ROOT / "webapp" / "src" / "bootstrap.js").read_text(encoding="utf-8")
    read_service = (ROOT / "services" / "miniapp_read_service_v2.py").read_text(encoding="utf-8")

    assert "async function adminPaymentsModal" in shell
    assert "data-admin-payments" in shell
    assert "data-admin-payment-filter" in shell
    assert "data-admin-order-approve" in shell
    assert "data-admin-order-reject" in shell
    assert "adminPaymentsModal(true)" in bootstrap
    assert "['orders', 'adminOrders', 'overview']" in shell
    assert 'row.get("receipt_attached")' in read_service


def test_miniapp_calculator_exposes_advanced_broker_fields() -> None:
    source = (ROOT / "webapp" / "src" / "experience-v2.js").read_text(encoding="utf-8")
    action = (ROOT / "services" / "actions_v2" / "trading.py").read_text(encoding="utf-8")
    for field in (
        "calcAvailableMargin",
        "calcContractSize",
        "calcLotStep",
        "calcQuantityStep",
        "calcMinNotional",
        "risk_budget_usage_percent",
        "margin_usage_percent",
    ):
        assert field in source
    for field in (
        "available_margin_usd",
        "contract_size=ctx.payload.get",
        "lot_step=ctx.payload.get",
        "quantity_step=ctx.payload.get",
        "min_notional=ctx.payload.get",
    ):
        assert field in action
