from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from core.utils import parse_dt, utc_iso
from modules.management_suite import FINAL_SIGNAL_STATUSES
from modules.provider_health import provider_health_summary
from modules.retention_engine import retention_summary

CHECKLIST_ITEMS: tuple[tuple[str, str], ...] = (
    ("signals", "بررسی سیگنال‌های باز و تأییدهای منتظر"),
    ("payments", "رسیدگی به پرداخت‌ها و مغایرت‌های مالی"),
    ("support", "رسیدگی به تیکت‌های باز و فوری"),
    ("providers", "کنترل سلامت منابع قیمت و ردیاب"),
    ("backup", "کنترل آخرین بکاپ و امکان بازیابی"),
)


def _today_key(now: datetime | None = None) -> str:
    current = now or datetime.now(UTC)
    if current.tzinfo is None:
        current = current.replace(tzinfo=UTC)
    return current.astimezone(ZoneInfo("Asia/Tehran")).date().isoformat()


def _open_status(row: dict[str, Any]) -> bool:
    return str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES


def _require_owner(actor_id: int | str, owner_id: int | str) -> None:
    try:
        allowed = int(actor_id) == int(owner_id)
    except (TypeError, ValueError):
        allowed = False
    if not allowed:
        raise PermissionError("چک‌لیست «ادمین امروز» فقط برای ادمین اصلی است.")


def admin_today_snapshot(
    db: dict[str, Any],
    *,
    actor_id: int | str,
    owner_id: int | str,
    now: datetime | None = None,
) -> dict[str, Any]:
    _require_owner(actor_id, owner_id)
    current = now or datetime.now(UTC)
    day_key = _today_key(current)
    checklist_root = db.setdefault("admin_today_checklists", {})
    checklist = checklist_root.setdefault(day_key, {})
    if not isinstance(checklist, dict):
        checklist = {}
        checklist_root[day_key] = checklist
    providers = provider_health_summary(db)
    retention = retention_summary(db)
    pending_approvals = sum(
        1
        for row in db.get("signal_approvals", [])
        if isinstance(row, dict) and row.get("status") == "pending"
    )
    pending_payments = sum(
        1
        for row in db.get("vip_orders", [])
        if isinstance(row, dict) and row.get("status") in {"pending", "approving"}
    )
    payment_review = sum(
        1
        for row in db.get("payment_reconciliations", [])
        if isinstance(row, dict) and row.get("status") in {"review_required", "blocked"}
    )
    open_tickets = [
        row
        for row in db.get("tickets", [])
        if isinstance(row, dict) and row.get("status") == "open"
    ]
    urgent_tickets = sum(1 for row in open_tickets if row.get("priority") in {"urgent", "high"})
    active_signals = sum(
        1 for row in db.get("signals", []) if isinstance(row, dict) and _open_status(row)
    )
    failed_deliveries = sum(
        1
        for row in db.get("signals", [])
        if isinstance(row, dict)
        and (
            row.get("delivery_status") in {"failed", "retry"}
            or bool(row.get("delivery_error"))
        )
    )
    expiring_vip = 0
    for row in (db.get("vip_users", {}) or {}).values():
        if not isinstance(row, dict):
            continue
        expiry = parse_dt(row.get("expires_at"))
        if expiry and current <= expiry <= current + timedelta(days=3):
            expiring_vip += 1
    latest_backup = None
    backups = [row for row in db.get("backup_history", []) if isinstance(row, dict)]
    if backups:
        latest_backup = max(
            (row.get("created_at") for row in backups if row.get("created_at")),
            default=None,
        )
    rows = []
    for key, label in CHECKLIST_ITEMS:
        state = checklist.get(key, {})
        rows.append(
            {
                "key": key,
                "label": label,
                "done": bool(state.get("done", False)) if isinstance(state, dict) else False,
                "done_at": state.get("done_at") if isinstance(state, dict) else None,
            }
        )
    return {
        "date": day_key,
        "signals": {"open": active_signals, "pending_approval": pending_approvals},
        "payments": {"pending": pending_payments, "review": payment_review},
        "support": {"open": len(open_tickets), "urgent": urgent_tickets},
        # Incident details intentionally remain private to Incident Center.
        "delivery_failures": failed_deliveries,
        "providers": {
            "healthy": int(providers.get("healthy", 0) or 0),
            "total": int(providers.get("total", 0) or 0),
            "offline": int(providers.get("offline", 0) or 0),
        },
        "retention": {
            "pending": int(retention.get("pending", 0) or 0),
            "conversion_rate": float(retention.get("conversion_rate", 0) or 0),
            "expiring_vip": expiring_vip,
        },
        "backup": {"latest_at": latest_backup},
        "checklist": rows,
        "completed": sum(1 for row in rows if row["done"]),
        "total": len(rows),
        "generated_at": utc_iso(current),
    }


def toggle_admin_today_item(
    db: dict[str, Any],
    item_key: str,
    actor_id: int | str,
    *,
    owner_id: int | str,
    now: datetime | None = None,
) -> dict[str, Any]:
    _require_owner(actor_id, owner_id)
    allowed = {key for key, _ in CHECKLIST_ITEMS}
    key = str(item_key or "").strip()
    if key not in allowed:
        raise ValueError("آیتم چک‌لیست معتبر نیست.")
    day_key = _today_key(now)
    checklist = db.setdefault("admin_today_checklists", {}).setdefault(day_key, {})
    current = checklist.get(key, {}) if isinstance(checklist.get(key), dict) else {}
    done = not bool(current.get("done", False))
    checklist[key] = {
        "done": done,
        "done_at": utc_iso(now or datetime.now(UTC)) if done else None,
        "done_by": str(actor_id) if done else None,
    }
    db["admin_today_checklists"] = dict(
        sorted(db["admin_today_checklists"].items())[-90:]
    )
    return checklist[key]
