#!/usr/bin/env python3
"""Credential-gated production-readiness attestation for SENTINEL.

This script intentionally refuses to use production BOT_TOKEN/DATABASE_URL or
production channel IDs.  It runs only when the explicit TEST_* variables are
present, so a local/offline release cannot accidentally claim a live pass.
"""
from __future__ import annotations

import asyncio
import argparse
import json
import os
import secrets
import sys
from datetime import UTC, datetime
from typing import Any

REQUIRED = ("TEST_DATABASE_URL", "TEST_REDIS_URL", "TEST_BOT_TOKEN")
OPTIONAL_CHANNELS = ("TEST_PUBLIC_CHANNEL_ID", "TEST_PRIVATE_CHANNEL_ID")


def now() -> str:
    return datetime.now(UTC).isoformat()


def emit(report: dict[str, Any], code: int) -> int:
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return code


def postgres_check(url: str) -> dict[str, Any]:
    import psycopg

    with psycopg.connect(url, connect_timeout=10,
                         options="-c statement_timeout=10000 -c lock_timeout=5000") as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT current_database(), current_user, NOW()")
            database, user, stamp = cur.fetchone()
            cur.execute("CREATE TEMP TABLE sentinel_attestation_probe(id INTEGER PRIMARY KEY, value TEXT)")
            cur.execute("INSERT INTO sentinel_attestation_probe VALUES (1, 'ok')")
            cur.execute("SELECT value FROM sentinel_attestation_probe WHERE id=1")
            value = cur.fetchone()[0]
        conn.rollback()
    return {"ok": value == "ok", "database": database, "user": user, "server_time": str(stamp)}


def redis_check(url: str) -> dict[str, Any]:
    import redis

    client = redis.Redis.from_url(url, socket_connect_timeout=10, socket_timeout=10, decode_responses=True)
    key = f"sentinel:attestation:{secrets.token_hex(12)}"
    try:
        pong = bool(client.ping())
        client.set(key, "ok", ex=30)
        value = client.get(key)
        client.delete(key)
        info = client.info(section="server")
        return {"ok": pong and value == "ok", "redis_version": info.get("redis_version", "unknown")}
    finally:
        client.close()


async def telegram_check(token: str, *, require_channels: bool = False) -> dict[str, Any]:
    from telegram import Bot

    configured = {name: str(os.getenv(name) or "").strip() for name in OPTIONAL_CHANNELS}
    if require_channels and (not all(configured.values()) or len(set(configured.values())) != 2):
        return {"ok": False, "error": "two distinct explicit TEST_* channels are required"}
    bot = Bot(token=token)
    messages: list[dict[str, Any]] = []
    try:
        async with asyncio.timeout(45):
            await bot.initialize()
            me = await bot.get_me()
            for env_name, raw in configured.items():
                if not raw:
                    continue
                chat_id = int(raw)
                member = await bot.get_chat_member(chat_id, me.id)
                status = str(member.status)
                permitted = status == "creator" or (status == "administrator"
                    and getattr(member, "can_invite_users", False) is True
                    and getattr(member, "can_delete_messages", False) is True
                    and getattr(member, "can_post_messages", False) is True)
                if not permitted:
                    messages.append({"scope": env_name, "chat_id": chat_id,
                                     "member_status": status, "ok": False,
                                     "error": "required channel admin permissions are missing"})
                    continue
                message = await bot.send_message(
                    chat_id,
                    "SENTINEL staging attestation — this message will be deleted automatically.",
                    disable_notification=True,
                )
                deleted = False
                try:
                    deleted = bool(await bot.delete_message(chat_id, message.message_id))
                except Exception:
                    deleted = False
                messages.append({
                    "scope": env_name, "chat_id": chat_id,
                    "member_status": status, "message_id": int(message.message_id),
                    "deleted": deleted, "ok": deleted,
                })
        return {
            "ok": all(row["ok"] is True for row in messages)
                  and (not require_channels or len(messages) == 2),
            "bot_id": int(me.id),
            "username": str(me.username or ""),
            "channel_probes": messages,
            "channels_attested": len(messages),
        }
    finally:
        await asyncio.wait_for(bot.shutdown(), timeout=5)


def _endpoint(value: str, kind: str) -> tuple[str, int, str] | None:
    if not value:
        return None
    try:
        if kind == "redis":
            from redis.connection import parse_url
            parsed = parse_url(value)
            host, port, database = parsed.get("host"), parsed.get("port", 6379), str(parsed.get("db", 0))
        else:
            from psycopg.conninfo import conninfo_to_dict
            parsed = conninfo_to_dict(value)
            host, port, database = parsed.get("host"), parsed.get("port", 5432), parsed.get("dbname")
        if not host or not database or "," in str(host):
            raise ValueError("staging requires an explicit single host and database")
        return (str(host).lower(), int(port), str(database))
    except Exception as exc:
        raise ValueError("invalid or implicit service endpoint") from exc


def _production_credential_conflicts() -> list[str]:
    conflicts = []
    pairs = (("TEST_DATABASE_URL", ("POSTGRES_URL", "DATABASE_URL"), "postgresql"),
             ("TEST_REDIS_URL", ("REDIS_URL",), "redis"))
    for test_name, production_names, kind in pairs:
        target = _endpoint(str(os.getenv(test_name) or ""), kind)
        if target is not None and any(target == _endpoint(str(os.getenv(name) or ""), kind)
                                      for name in production_names):
            conflicts.append(test_name)
    if str(os.getenv("TEST_BOT_TOKEN") or "").strip() == str(os.getenv("BOT_TOKEN") or "").strip():
        conflicts.append("TEST_BOT_TOKEN")
    production_channels = {str(os.getenv(n) or "").strip() for n in ("PUBLIC_CHANNEL_ID", "PRIVATE_CHANNEL_ID")}
    for name in OPTIONAL_CHANNELS:
        value = str(os.getenv(name) or "").strip()
        if value and value in production_channels:
            conflicts.append(name)
    return conflicts


async def main(*, require_channels: bool = False) -> int:
    required = REQUIRED + OPTIONAL_CHANNELS if require_channels else REQUIRED
    missing = [name for name in required if not str(os.getenv(name) or "").strip()]
    report: dict[str, Any] = {
        "status": "NOT_ATTESTED" if missing else "RUNNING",
        "started_at": now(),
        "missing": missing,
        "checks": {},
    }
    if missing:
        report["message"] = "Live staging checks were not run because explicit TEST_* credentials are absent."
        return emit(report, 3)
    try:
        conflicts = _production_credential_conflicts()
    except ValueError:
        conflicts = ["invalid TEST_* URL"]
    if conflicts:
        report.update({"status": "NOT_ATTESTED", "production_conflicts": conflicts,
                       "message": "Staging credentials must target isolated test services and channels."})
        return emit(report, 3)
    failures: list[str] = []
    checks = report["checks"]
    for name, fn, value in (
        ("postgresql", postgres_check, os.environ["TEST_DATABASE_URL"]),
        ("redis", redis_check, os.environ["TEST_REDIS_URL"]),
    ):
        try:
            checks[name] = await asyncio.to_thread(fn, value)
            if not checks[name].get("ok"):
                failures.append(name)
        except Exception as exc:
            checks[name] = {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"}
            failures.append(name)
    try:
        checks["telegram"] = await telegram_check(os.environ["TEST_BOT_TOKEN"], require_channels=require_channels)
        if not checks["telegram"].get("ok"):
            failures.append("telegram")
    except Exception as exc:
        checks["telegram"] = {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"}
        failures.append("telegram")
    report["finished_at"] = now()
    report["status"] = "FAILED" if failures else "PASSED"
    report["failures"] = failures
    return emit(report, 1 if failures else 0)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-channels", action="store_true")
    args = parser.parse_args()
    raise SystemExit(asyncio.run(main(require_channels=args.require_channels)))
