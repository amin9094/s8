from __future__ import annotations
import asyncio
import copy
import inspect
import time
from datetime import timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from core.db import DEFAULT_DB, migrate_db
from core.utils import utc_iso, utc_now
from core.domain import assign_discount_from_pool
from modules.reward_wallet import wallet_items, point_summary
from modules.referral_milestones import save_milestone, claim_milestone, milestone_progress
from modules.vip_gifts import create_gift, redeem_gift, gift_for_owner, approve_gift_order
from modules.admin_work_queue import reconcile_work_queue, work_items, assign_work, handoff_work, accept_handoff, palette_search
from modules.ticket_context import attach_context, ticket_context_view
from modules.notification_router import notification_decision, set_notification_filters
from modules.admin_control_center import notification_preferences

OWNER = 354678485

@pytest.fixture
def state():
    db = copy.deepcopy(DEFAULT_DB)
    db['users'] = {'1':{'id':1},'2':{'id':2},'3':{'id':3}}
    db['vip_plans'] = [{'id':1,'name':'VIP','active':True,'price':150000,'duration_days':30}]
    db['delegated_admins'] = {'99':{'id':'99','user_id':'99','active':True,'approval_status':'approved','permissions':['tickets']}}
    return db

@pytest.mark.parametrize('source',['admin','mission','referral','campaign','competition','automation','reward_shop'])
def test_all_owned_coupons_appear_without_duplication(state,source):
    coupon,_=assign_discount_from_pool(state,10,1,issued_via=source)
    state['user_rewards']=[{'id':1,'user_id':'1','reference_id':coupon['code'],'type':'discount'}]
    assert len(wallet_items(state,1))==1
    assert wallet_items(state,1)[0]['code']==coupon['code']
    assert wallet_items(state,2)==[]


def test_wallet_expired_used_and_old_points(state):
    coupon,_=assign_discount_from_pool(state,10,1)
    coupon['expires_at']=utc_iso(utc_now()-timedelta(days=1))
    assert wallet_items(state,1)[0]['status']=='expired'
    coupon['used_at']=utc_iso()
    assert wallet_items(state,1)[0]['status']=='used'
    state['user_points']['1']=321
    assert point_summary(state,1)['balance']==321


def milestone(db, **kwargs):
    return save_milestone(db,OWNER,{'title':'معرفی','description':'پاداش دعوت','trigger_type':'referrals_joined',
         'required_count':3,'reward_type':'points','reward_value':100,**kwargs})

@pytest.mark.parametrize('kind,value',[('points',100),('vip_days',7),('discount_coupon',10),('reward_item',1)])
def test_milestone_transactional_rewards(state,kind,value):
    state['settings']['rewardItems']=[{'id':1,'name':'جایزه','points':100}]
    row=milestone(state,reward_type=kind,reward_value=value)
    state['user_referrals']['1']={'code':'ABC','invited':['2','3','4']}
    for uid in ['2','3','4']:state['users'].setdefault(uid,{'id':uid})['referred_by']='1'
    first=claim_milestone(state,1,row['id'],expected_cycle=1)
    second=claim_milestone(state,1,row['id'],expected_cycle=1)
    assert first==second
    assert len(state['referral_milestone_claims'])==1
    assert len(wallet_items(state,1))==1
    assert milestone_progress(state,1)[0]['claimed']==1


def test_repeatable_milestone_doubleclick_and_next_cycle(state):
    row=milestone(state,repeatable=True,max_claims=2)
    state['user_referrals']['1']={'code':'ABC','invited':['2','3','4','5','6','7','8','9','10']}
    for uid in ['2','3','4','5','6','7','8','9','10']:state['users'].setdefault(uid,{'id':uid})['referred_by']='1'
    claim_milestone(state,1,row['id'],expected_cycle=1)
    claim_milestone(state,1,row['id'],expected_cycle=1)
    assert state['user_points']['1']==100
    claim_milestone(state,1,row['id'],expected_cycle=2)
    assert state['user_points']['1']==200
    with pytest.raises(ValueError):claim_milestone(state,1,row['id'],expected_cycle=3)


def test_milestone_dates_permissions_and_revenue(state):
    with pytest.raises(PermissionError): save_milestone(state,2,{})
    row=milestone(state,trigger_type='referral_revenue',required_count=200)
    state['user_referrals']['1']={'code':'ABC','purchase_order_ids':['A','B'],'invited':[]}
    state['users']['2']['referred_by']='1'
    state['vip_orders']=[{'order_id':'A','user_id':'2','price':200,'status':'approved'},{'order_id':'B','user_id':'2','price':200,'status':'pending'}]
    assert milestone_progress(state,1)[0]['progress']==200
    save_milestone(state,OWNER,{'expire_at':utc_iso(utc_now()-timedelta(seconds=1))},row['id'])
    assert milestone_progress(state,1)==[]


def paid_gift(db,recipient=None):
    row=create_gift(db,1,1,recipient,request_key='unique')
    db['vip_gifts'][row['gift_id']]['status']='paid'
    return row


def test_gift_redeem_is_idempotent_and_exclusive(state):
    gift=paid_gift(state)
    one=redeem_gift(state,2,gift['gift_token']); expiry=state['vip_users']['2']['expires_at']
    assert redeem_gift(state,2,gift['gift_token'])==one
    assert state['vip_users']['2']['expires_at']==expiry
    with pytest.raises(ValueError):redeem_gift(state,3,gift['gift_token'])
    assert len(wallet_items(state,2))==1
    assert '1' not in state['vip_users']


def test_direct_gift_owner_expiry_and_pending(state):
    gift=create_gift(state,1,1,2,request_key='gift')
    assert create_gift(state,1,1,2,request_key='gift')['gift_id']==gift['gift_id']
    with pytest.raises(ValueError):redeem_gift(state,2,gift['gift_token'])
    with pytest.raises(PermissionError):gift_for_owner(state,2,gift['gift_id'])
    state['vip_gifts'][gift['gift_id']]['status']='paid'
    with pytest.raises(PermissionError):redeem_gift(state,3,gift['gift_token'])
    state['vip_gifts'][gift['gift_id']]['expires_at']=utc_iso(utc_now()-timedelta(seconds=1))
    with pytest.raises(ValueError):redeem_gift(state,2,gift['gift_token'])


def test_gift_payment_does_not_activate_buyer(state):
    gift=create_gift(state,1,1)
    state['vip_orders']=[{'order_id':'A','user_id':1,'gift_id':gift['gift_id'],'status':'pending','price':150000,'receipt_file_id':'receipt','payment_method':'card'}]
    with pytest.raises(PermissionError):approve_gift_order(state,'A',2)
    assert approve_gift_order(state,'A',OWNER)['status']=='paid'
    assert approve_gift_order(state,'A',OWNER)['status']=='paid'
    assert '1' not in state['vip_users']


def ticket(db):
    row={'id':10,'user_id':'1','status':'open','waiting_for':'admin','assigned_admin':'','created_at':utc_iso(),'subject':'test'}
    db['tickets']=[row]
    return row


def test_queue_reconcile_duplicate_assign_complete(state):
    original=ticket(state)
    assert len(reconcile_work_queue(state))==1
    assert len(reconcile_work_queue(state))==1
    row=work_items(state,99)[0]
    assign_work(state,99,row['id'])
    assert original['assigned_admin']=='99'
    assert len(work_items(state,99,'mine'))==1
    assert work_items(state,2)==[]
    original['status']='closed'
    assert work_items(state,99)==[]
    assert state['admin_work_queue']['ticket:10']['status']=='completed'


def test_handoff_permissions_and_history(state):
    ticket(state); row=work_items(state,OWNER)[0]
    with pytest.raises(PermissionError):handoff_work(state,2,row['id'],99,'please handle','a')
    with pytest.raises(PermissionError):handoff_work(state,OWNER,row['id'],2,'please handle','a')
    h=handoff_work(state,OWNER,row['id'],99,'please handle','a')
    assert state['tickets'][0]['assigned_admin']=='99'
    with pytest.raises(PermissionError):accept_handoff(state,OWNER,h['id'])
    assert accept_handoff(state,99,h['id'])['status']=='accepted'
    assert accept_handoff(state,99,h['id'])['status']=='accepted'


def test_palette_whitelist_permission_and_secret_exclusion(state):
    ticket(state)
    state['vip_gifts']['g']={'gift_id':'g','token':'SECRET','status':'paid'}
    assert palette_search(state,2,'ticket 10')==[]
    assert palette_search(state,99,'ticket 10')[0]['reference_id']=='10'
    assert palette_search(state,OWNER,'SECRET')==[]
    assert palette_search(state,OWNER,'DROP TABLE users')==[]


def test_ticket_context_ownership_deleted_entity(state):
    t=ticket(state)
    state['vip_orders']=[{'order_id':'A','user_id':1,'status':'pending'},{'order_id':'B','user_id':2,'status':'pending'}]
    attach_context(state,t,'payment','A')
    assert ticket_context_view(state,99,t)['status']=='pending'
    with pytest.raises(PermissionError):attach_context(state,t,'payment','B')
    with pytest.raises(PermissionError):ticket_context_view(state,2,t)
    state['vip_orders']=[]
    assert ticket_context_view(state,99,t) is None

@pytest.mark.parametrize('key',['signals','results','tp','sl','risk_free','high_impact','payment','vip','referral','reward','general','support','alerts','retention','contests','missions','education'])
def test_notification_categories_filter(state,key):
    pref=notification_preferences(state,1);pref['quiet_enabled']=False;pref[key]=False
    assert not notification_decision(state,1,key).allowed
    pref[key]=True
    assert notification_decision(state,1,key).allowed


def test_notification_market_symbol_filters(state):
    notification_preferences(state,1)['quiet_enabled']=False
    set_notification_filters(state,1,markets=['gold','energy'],symbols=['XAUUSD'])
    assert notification_decision(state,1,'signals',market='gold',symbol='XAUUSD').allowed
    assert not notification_decision(state,1,'signals',market='crypto',symbol='BTCUSDT').allowed


def test_additive_old_data_migration(state):
    state.pop('vip_gifts',None);state.pop('referral_milestones',None)
    state['user_points']['1']=55
    upgraded=migrate_db(state)
    assert upgraded['vip_gifts']=={}
    assert upgraded['referral_milestones']=={}
    assert upgraded['user_points']['1']==55

@pytest.mark.asyncio
async def test_signal_back_preserves_draft_in_new_and_old_buttons(monkeypatch):
    import bot
    from bot_runtime import navigation
    from ui.button_factory import InlineKeyboardButton
    assert InlineKeyboardButton('⬅️ برگشت',callback_data='sig_back:entry').callback_data=='sig_back:entry'
    context=SimpleNamespace(user_data={'signal':{'symbol':'XAUUSD'}})
    async def handler(update,ctx):
        assert ctx.user_data['signal']['symbol']=='XAUUSD'
        assert update.callback_query.data=='sig_back:entry'
        return 123
    monkeypatch.setattr(navigation,'signal_wizard_back',handler)
    query=SimpleNamespace(data='nb:sig_back:entry',from_user=SimpleNamespace(id=1))
    assert await navigation.navigation_back(SimpleNamespace(callback_query=query),context)==123
    assert context.user_data['signal']['symbol']=='XAUUSD'

@pytest.mark.asyncio
async def test_deleted_message_replacement_sends_before_deleting(monkeypatch):
    import bot
    from bot_runtime import navigation
    from telegram.error import BadRequest
    order=[]
    async def send(**kw):order.append('send')
    async def delete():order.append('delete')
    query=SimpleNamespace(data='u_rewards',from_user=SimpleNamespace(id=1),message=SimpleNamespace(chat_id=1,delete=delete),
                          edit_message_text=AsyncMock(side_effect=BadRequest('Message to edit not found')),get_bot=lambda:SimpleNamespace(send_message=send))
    await navigation.edit(query,'test',[])
    assert order==['send','delete']

@pytest.mark.asyncio
async def test_expired_callback_does_not_abort(monkeypatch):
    from core.resilient_bot import ResilientBot
    from telegram.ext import ExtBot
    from telegram.error import BadRequest
    monkeypatch.setattr(ExtBot,'answer_callback_query',AsyncMock(side_effect=BadRequest('Query is too old and response timeout expired')))
    bot=ResilientBot('123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert await bot.answer_callback_query('q') is False

@pytest.mark.asyncio
async def test_executor_submit_failure_releases_capacity(monkeypatch):
    import core.async_runtime as runtime
    limit=asyncio.Semaphore(1)
    monkeypatch.setattr(runtime,'_semaphore',lambda:limit)
    monkeypatch.setattr(runtime,'_executor',lambda:SimpleNamespace(submit=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('closed'))))
    with pytest.raises(RuntimeError):await runtime.run_blocking(lambda:None)
    assert limit._value==1

@pytest.mark.asyncio
async def test_update_timeout_and_busy_user_release_slots(monkeypatch):
    from core.update_processor import KeyedUpdateProcessor
    p=KeyedUpdateProcessor(2);p.processing_timeout=.04;p.lock_timeout=.01
    p._key=lambda update:str(update)
    done=[]
    async def hang():await asyncio.Event().wait()
    async def fast():done.append(True)
    a=asyncio.create_task(p.process_update('one',hang()))
    await asyncio.sleep(.001)
    b=asyncio.create_task(p.process_update('one',fast()))
    c=asyncio.create_task(p.process_update('two',fast()))
    await asyncio.wait_for(asyncio.gather(a,b,c),1)
    assert done==[True]
    assert p.is_healthy() and not p._active
    await p.process_update('one',fast())
    assert len(done)==2

@pytest.mark.asyncio
async def test_real_ptb_conversation_exit_is_user_scoped():
    from core.conversation_reset import reset_conversations_on_exit
    from telegram import Update, Message, Chat, User
    from telegram.ext import ConversationHandler, MessageHandler, filters
    handler=ConversationHandler(entry_points=[],states={1:[MessageHandler(filters.TEXT,AsyncMock())]},fallbacks=[])
    handler._conversations[(1,1)]=1;handler._conversations[(2,2)]=1
    update=Update(1,message=Message(1,utc_now(),Chat(1,'private'),from_user=User(1,'A',False),text='/start'))
    await reset_conversations_on_exit(update,SimpleNamespace(application=SimpleNamespace(handlers={0:[handler]})))
    assert (1,1) not in handler._conversations
    assert handler._conversations[(2,2)]==1


def test_database_rollback_and_competing_gift_claims(tmp_path,state):
    from core.db import SQLiteStore
    from concurrent.futures import ThreadPoolExecutor
    store=SQLiteStore(tmp_path/'gift.sqlite3',tmp_path/'backups')
    gift=paid_gift(state)
    store.transaction(lambda db: db.update(state))
    def broken(db):
        redeem_gift(db,2,gift['gift_token'])
        raise RuntimeError('rollback')
    with pytest.raises(RuntimeError):store.transaction(broken)
    assert store._read()['vip_gifts'][gift['gift_id']]['status']=='paid'
    def claim(uid):
        try:return store.transaction(lambda db:redeem_gift(db,uid,gift['gift_token']))[0]['redeemed_by']
        except ValueError:return 'already_claimed'
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(claim,[2,3]))
    assert results.count('already_claimed')==1
    reopened=SQLiteStore(tmp_path/'gift.sqlite3',tmp_path/'backups')
    final=reopened._read()
    assert final['vip_gifts'][gift['gift_id']]['status']=='redeemed'
    assert len([r for r in final['user_rewards'] if r['source']=='gift_vip'])==1


def test_personal_notification_queue_access_and_restart_idempotency(state):
    from modules.personal_notifications import queue_personal_notifications
    state['notification_defaults']['experience_started_at']='2000-01-01T00:00:00+00:00'
    for uid in state['users']:notification_preferences(state,uid)['quiet_enabled']=False
    state['vip_users']['2']={'status':'active','expires_at':utc_iso(utc_now()+timedelta(days=1))}
    state['signals']=[{'id':1,'symbol':'XAUUSD','created_at':utc_iso(),'delivered_channels':['private']}]
    assert queue_personal_notifications(state)==1
    assert state['broadcast_queue'][0]['recipients']==['2']
    restarted=copy.deepcopy(state)
    assert queue_personal_notifications(restarted)==0
    assert len(restarted['broadcast_queue'])==1


def test_gift_secret_is_encrypted_and_redacted(state):
    from core.sensitive_data import protect_sensitive_payload,unprotect_sensitive_payload
    from core.logging_context import redact
    gift=create_gift(state,1,1)
    key='test encryption key of sufficient length'
    encrypted=protect_sensitive_payload(state,key)
    assert gift['gift_token'] not in str(encrypted)
    assert unprotect_sensitive_payload(encrypted,key)['vip_gifts'][gift['gift_id']]['gift_token']==gift['gift_token']
    assert gift['gift_token'] not in redact('https://t.me/bot?start=gift_'+gift['gift_token'])

@pytest.mark.asyncio
async def test_rewards_hub_referral_share_and_wallet_render(monkeypatch,state):
    import bot
    from bot_runtime import account_support as feature
    user=SimpleNamespace(id=1)
    q=SimpleNamespace(data='u_rewards',from_user=user,answer=AsyncMock())
    update=SimpleNamespace(callback_query=q)
    ctx=SimpleNamespace(bot=SimpleNamespace(username='sentinel_bot'),user_data={})
    monkeypatch.setattr(feature,'async_snapshot',AsyncMock(side_effect=lambda:copy.deepcopy(state)))
    async def transact(fn):return fn(state)
    monkeypatch.setattr(feature,'async_with_db',transact)
    monkeypatch.setattr(feature,'_language_for_user',lambda uid:'fa')
    monkeypatch.setattr(feature,'_remember_runtime_bot_username',lambda name:name)
    monkeypatch.setattr(feature,'edit',AsyncMock())
    await feature.u_rewards(update,ctx)
    buttons=[b.callback_data for row in feature.edit.call_args.args[2] for b in row]
    assert {'u_reward_catalog','u_score','u_my_rewards'}<=set(buttons)
    await feature.u_referral(update,ctx)
    markup=feature.edit.call_args.args[2]
    assert markup[0][0].url.startswith('https://t.me/share/url?')
    coupon,_=assign_discount_from_pool(state,10,1)
    await feature.u_my_rewards(update,ctx)
    assert coupon['code'] in feature.edit.call_args.args[1]

@pytest.mark.asyncio
async def test_reward_shop_duplicate_survives_reload(monkeypatch,state):
    import bot
    from bot_runtime import account_support as feature
    state['settings']['rewardItems']=[{'id':1,'name':'هدیه','points':100,'discountPct':10}]
    state['user_points']['1']=300
    q=SimpleNamespace(data='redeem:1:0123456789abcdef',from_user=SimpleNamespace(id=1),answer=AsyncMock())
    update=SimpleNamespace(callback_query=q)
    monkeypatch.setattr(feature,'_language_for_user',lambda uid:'fa')
    monkeypatch.setattr(feature,'_admin_ids_for_permission',lambda p:[])
    monkeypatch.setattr(feature,'edit',AsyncMock())
    async def transact(fn):return fn(state)
    monkeypatch.setattr(feature,'async_with_db',transact)
    await feature.redeem_reward(update,SimpleNamespace(bot=SimpleNamespace()))
    state.update(migrate_db(copy.deepcopy(state)))
    await feature.redeem_reward(update,SimpleNamespace(bot=SimpleNamespace()))
    assert state['user_points']['1']==200
    assert len(wallet_items(state,1))==1
    assert len(state['reward_shop_claims'])==1


def test_normalized_pending_payment_projection_is_read_only(state,monkeypatch):
    from services import experience_state as service
    class Repo:
        def list_all_orders(self,**kwargs):
            return {'items':[{'id':'ord_new','user_id':'2','amount_toman':10,'status':'pending'}] if kwargs['status']=='pending' else [],'next_cursor':None}
    monkeypatch.setattr(service,'CommerceRepository',Repo)
    rows=service.pending_orders(state)
    assert rows[0]['order_id']=='ord_new'
    assert state['vip_orders']==[]
    queue=reconcile_work_queue(state,external_payments=rows)
    assert queue['payment:ord_new']['status']=='open'
    assert reconcile_work_queue(state)['payment:ord_new']['status']=='open'
    rows[0]['status']='approved'
    assert reconcile_work_queue(state,external_payments=rows)['payment:ord_new']['status']=='completed'

@pytest.mark.asyncio
async def test_soak_repeated_start_menu_db_jobs_and_transient_failures(monkeypatch,tmp_path,state):
    import gc,json,tracemalloc
    from pathlib import Path
    import bot
    from bot_runtime import navigation
    from core.db import SQLiteStore
    from core.update_processor import KeyedUpdateProcessor
    from core.async_runtime import run_blocking
    from core.observability import observed_job
    from telegram import User
    store=SQLiteStore(tmp_path/'soak.sqlite3',tmp_path/'backups')
    user=User(OWNER,'Test',False,username='test')
    state['users'][str(OWNER)]={'id':OWNER,'language':'fa','first_name':'Test'}
    store.transaction(lambda db: db.update(state))
    async def transact(fn):return await run_blocking(lambda:store.transaction(fn)[0])
    async def snapshot():return await run_blocking(store._read)
    monkeypatch.setattr(navigation,'async_with_db',transact)
    monkeypatch.setattr(navigation,'async_snapshot',snapshot)
    monkeypatch.setattr(navigation,'load_db',store._read)
    monkeypatch.setattr(navigation,'_language_for_user',lambda uid:'fa')
    monkeypatch.setattr(navigation,'_is_any_admin',lambda uid:True)
    monkeypatch.setattr(navigation,'_has_any_admin_permission',lambda *a:False)
    monkeypatch.setattr(navigation,'_is_owner_admin',lambda uid:False)
    monkeypatch.setattr(navigation,'ensure_quick_access_keyboard',AsyncMock())
    monkeypatch.setattr(navigation,'reply',AsyncMock())
    monkeypatch.setattr(navigation,'edit',AsyncMock())
    monkeypatch.setattr(navigation,'register_current_user',lambda update:None)
    monkeypatch.setenv('JOB_TRANSIENT_RETRIES','0')
    context=SimpleNamespace(args=[],user_data={},bot=SimpleNamespace())
    update=SimpleNamespace(effective_user=user)
    query=SimpleNamespace(data='home',from_user=user,answer=AsyncMock())
    callback=SimpleNamespace(effective_user=user,callback_query=query)
    processor=KeyedUpdateProcessor(8)
    ticks=0
    async def optional_job():
        nonlocal ticks
        ticks+=1
        if ticks%7==0:raise ConnectionError('temporary provider failure')
    job=observed_job('soak_provider',optional_job)
    started=time.monotonic();tracemalloc.start();gc.collect();before=tracemalloc.get_traced_memory()[0]
    cycles=120
    for index in range(cycles):
        await processor.process_update('start',navigation.start(update,context))
        await processor.process_update('menu',navigation.home_callback(callback,context))
        try:await job()
        except ConnectionError:pass
        assert processor.is_healthy()
    gc.collect();after,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    assert navigation.reply.await_count==cycles
    assert navigation.edit.await_count==cycles
    assert not processor._active
    assert after-before<20_000_000
    proof={'cycles':cycles,'start_responses':cycles,'menu_responses':cycles,'job_cycles':ticks,
           'simulated_provider_failures':ticks//7,'retained_memory_growth_bytes':after-before,'peak_traced_bytes':peak,
           'elapsed_seconds':round(time.monotonic()-started,3),'kind':'accelerated mocked reliability test, not a live one-hour deployment'}
    target=Path('quality-artifacts/reliability_soak.json');target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(proof,indent=2))


def test_purchase_gift_purchase_preserves_all_days(tmp_path, monkeypatch, state):
    from core import db as storage
    from core.storage.engine import DatabaseEngine
    from repositories.v2.commerce import CommerceRepository
    from tests.test_manual_payment_repository import quote
    from core.membership_bridge import membership_snapshot
    from core.utils import parse_dt
    store = storage.SQLiteStore(tmp_path/'joined.sqlite3', tmp_path/'backup')
    store.write(state)
    engine = DatabaseEngine(database_url='', sqlite_path=store.path); engine.ensure_schema()
    repo = CommerceRepository(engine)
    monkeypatch.setattr(storage, '_STORE', store); storage.reset_cache_for_tests()

    def purchase(key):
        q = quote(repo, '2', payable=0, quote_id=key)
        order = repo.submit_order_from_quote('2', quote_id=q['quote_id'])
        repo.claim_order_for_approval(order['id'], actor_id=str(OWNER))
        return repo.finalize_order_approval(order['id'], actor_id=str(OWNER), invite_link='https://t.me/+test')
    try:
        first = purchase('one')
        gift = storage.with_db(lambda db: paid_gift(db, recipient=2))
        second = storage.with_db(lambda db: redeem_gift(db, 2, gift['gift_token']))
        assert parse_dt(second['vip_expires_at']) == parse_dt(first['expires_at']) + timedelta(days=30)
        assert membership_snapshot()['vip_users']['2']['expires_at'] == second['vip_expires_at']
        third = purchase('two')
        assert parse_dt(third['expires_at']) == parse_dt(second['vip_expires_at']) + timedelta(days=30)
        assert membership_snapshot()['vip_users']['2']['expires_at'] == third['expires_at']
        assert len(store._read()['vip_orders']) == 0  # no mirrored orders
        assert storage.with_db(lambda db: redeem_gift(db,2,gift['gift_token']))['vip_expires_at'] == second['vip_expires_at']
    finally:
        storage.reset_cache_for_tests(); engine.close()


def test_gift_retries_if_purchase_commits_during_claim(tmp_path, monkeypatch, state):
    from core import db as storage
    from core.storage.engine import DatabaseEngine
    from repositories.v2.commerce import CommerceRepository
    from tests.test_manual_payment_repository import quote
    from core.utils import parse_dt
    store = storage.SQLiteStore(tmp_path/'race.sqlite3', tmp_path/'backup')
    gift = paid_gift(state, recipient=2); store.write(state)
    engine = DatabaseEngine(database_url='', sqlite_path=store.path); engine.ensure_schema()
    repo = CommerceRepository(engine)
    q = quote(repo, '2', payable=0)
    order = repo.submit_order_from_quote('2', quote_id=q['quote_id'])
    repo.claim_order_for_approval(order['id'], actor_id=str(OWNER))
    monkeypatch.setattr(storage, '_STORE', store); storage.reset_cache_for_tests()
    attempts = 0; approved = None
    def claim(db):
        nonlocal attempts, approved
        attempts += 1
        result = redeem_gift(db,2,gift['gift_token'])
        if attempts == 1:
            approved = repo.finalize_order_approval(order['id'], actor_id=str(OWNER), invite_link='https://t.me/+test')
        return result
    try:
        result = storage.with_db(claim)
        assert attempts == 2
        assert parse_dt(result['vip_expires_at']) == parse_dt(approved['expires_at']) + timedelta(days=30)
        assert len(store._read()['user_rewards']) == 1
    finally:
        storage.reset_cache_for_tests(); engine.close()


def test_personal_delivery_survives_broadcast_disable_and_migration(state):
    from modules.admin_control_center import notification_preferences
    notification_preferences(state, 1)["quiet_enabled"] = False
    from modules.broadcast_queue import enqueue_broadcast, claim_broadcast_batch
    from modules.personal_notifications import queue_personal_notifications
    state['notification_defaults']['experience_started_at'] = '2000-01-01T00:00:00+00:00'
    marketing = enqueue_broadcast(state,admin_id=OWNER,segment='all',recipients=['1'],message='marketing')
    state['user_rewards'] = [{'id':1,'user_id':'1','title':'reward','created_at':utc_iso()}]
    assert queue_personal_notifications(state) == 1
    batch = claim_broadcast_batch(state,10,personal_only=True)
    assert batch['id'] != marketing['id']
    assert batch['notification_event']['kind'] == 'reward'
    restored = migrate_db(copy.deepcopy(state))
    assert restored['user_rewards'][0]['personal_notification_queued']
    assert queue_personal_notifications(restored) == 0


def test_normalized_referral_revenue_is_durable_and_not_double_counted(state,monkeypatch):
    from repositories.v2.commerce import CommerceRepository
    monkeypatch.setattr(CommerceRepository,"get",lambda self,key: {"id":"ord_normalized","user_id":"2","amount_toman":200,"status":"approved"})
    from core.domain import record_referral_purchase
    state['users']['2']['referred_by'] = '1'
    row = milestone(state,trigger_type='referral_revenue',required_count=200)
    record_referral_purchase(state,2,'ord_normalized',amount=200)
    record_referral_purchase(state,2,'ord_normalized',amount=200)
    assert milestone_progress(state,1)[0]['progress'] == 200
    restored = migrate_db(copy.deepcopy(state))
    assert milestone_progress(restored,1)[0]['progress'] == 200
    assert claim_milestone(restored,1,row['id'],expected_cycle=1)


def test_purchase_points_ledger_survives_retry_and_legacy_flag(state,monkeypatch):
    from repositories.v2.commerce import CommerceRepository
    monkeypatch.setattr(CommerceRepository,"get",lambda self,key: {"id":key,"user_id":"1","amount_toman":150000,"status":"approved","purchase_points_awarded":key=="legacy"})
    from core.domain import record_vip_purchase_rewards
    order={'id':'ord_new','user_id':'1','status':'approved','amount_toman':150000}
    record_vip_purchase_rewards(state,order)
    restored=migrate_db(copy.deepcopy(state))
    record_vip_purchase_rewards(restored,order)
    assert restored['user_points']['1']==100
    record_vip_purchase_rewards(restored,{**order,'id':'legacy','purchase_points_awarded':True})
    assert restored['user_points']['1']==100


def test_normalized_ticket_queue_handoff_reply_and_completion(sqlite_engine,state,monkeypatch):
    from repositories.v2.support import SupportRepository
    from services import experience_state as service
    support=SupportRepository(sqlite_engine)
    ticket=support.create_ticket('1',subject='پشتیبانی',body='پیام تست')
    monkeypatch.setattr(service,'SupportRepository',lambda:support)
    monkeypatch.setattr(service,'snapshot',lambda:copy.deepcopy(state))
    queue=reconcile_work_queue(state,external_tickets=[{**ticket,'normalized_ticket':True}])
    item=queue[f"ticket:{ticket['id']}"]
    assign_work(state,OWNER,item['id'])
    handoff=handoff_work(state,OWNER,item['id'],'99','تحویل تیکت برای بررسی','normalized-ticket-test')
    accept_handoff(state,'99',handoff['id'])
    with pytest.raises(PermissionError):service.update_normalized_ticket('2',ticket['id'],body='unauthorized')
    service.update_normalized_ticket('99',ticket['id'],body='پاسخ مدیر',request_key='reply-one')
    service.update_normalized_ticket('99',ticket['id'],body='پاسخ مدیر',request_key='reply-one')
    assert len(support.get(ticket['id'])['messages'])==2
    row=support.get(ticket['id'])
    reconcile_work_queue(state,external_tickets=[{**row,'normalized_ticket':True,'waiting_for':'user'}])
    assert item['assigned_admin_id']=='99' and item['status']=='waiting_user'
    service.update_normalized_ticket('99',ticket['id'],close=True)
    reconcile_work_queue(state,external_tickets=[{**support.get(ticket['id']),'normalized_ticket':True}])
    assert item['status']=='completed'
    assert state['shift_handoffs'][0]['status']=='completed'


def test_all_literal_navigation_targets_have_real_handlers(tmp_path):
    import json,os,subprocess,sys
    from pathlib import Path
    env=os.environ.copy()
    for name in list(env):
        if name.lower().endswith('_proxy'):env.pop(name)
    root=Path(__file__).resolve().parents[1]
    report=root/'quality-artifacts/navigation_audit.json'
    result=subprocess.run([sys.executable,str(root/'scripts/audit_navigation.py'),str(report)],cwd=root,env=env,capture_output=True,text=True,timeout=45)
    assert result.returncode==0,result.stdout+result.stderr
    proof=json.loads(report.read_text())
    assert proof['literal_buttons_checked']>900
    assert proof['literal_back_targets_checked']>200


@pytest.mark.asyncio
async def test_paginated_reward_and_referral_menus_keep_remaining_items_reachable(monkeypatch,state):
    import bot
    from bot_runtime import account_support as rewards, experience
    q=SimpleNamespace(data='u_reward_catalog:1',from_user=SimpleNamespace(id=1),answer=AsyncMock())
    update=SimpleNamespace(callback_query=q)
    state['settings']['rewardItems']=[{'id':i,'name':f'Reward {i}','points':i} for i in range(1,20)]
    monkeypatch.setattr(rewards,'async_snapshot',AsyncMock(return_value=state))
    monkeypatch.setattr(rewards,'async_with_db',AsyncMock())
    monkeypatch.setattr(rewards,'edit',AsyncMock())
    monkeypatch.setattr(rewards,'_language_for_user',lambda uid:'fa')
    await rewards.u_reward_catalog(update,SimpleNamespace())
    buttons=[b.callback_data for row in rewards.edit.call_args.args[2] for b in row]
    assert any(b.startswith('redeem:9:') for b in buttons)
    assert 'u_reward_catalog:2' in buttons and 'u_reward_catalog:0' in buttons
    for i in range(7):milestone(state,title=f'Milestone {i}')
    q.data='referral_milestones:1'
    monkeypatch.setattr(experience,'async_snapshot',AsyncMock(return_value=state))
    monkeypatch.setattr(experience,'edit',AsyncMock())
    await experience.referral_milestones_menu(update,SimpleNamespace())
    text=experience.edit.call_args.args[1]
    assert 'Milestone 6' in text and 'Milestone 0' not in text


def test_context_coupons_and_all_contest_types_are_owned_and_stable(state):
    from modules.ticket_context import resolve_context, reward_context_reference, competition_contexts
    coupon,_=assign_discount_from_pool(state,10,1)
    item=wallet_items(state,1)[0];ref=reward_context_reference(item)
    assert resolve_context(state,1,'reward',ref)['code']==coupon['code']
    assert resolve_context(state,2,'reward',ref) is None
    state['contests']=[{'id':11,'status':'active','symbol':'XAUUSD'}]
    for section in ('chart_contest','candle_contest','news_direction_contest'):
        state[section]={'id':22,'status':'active','created_at':utc_iso()}
    records=competition_contexts(state)
    assert {r for r,_ in records}=={'11','chart_22','candle_22','news_22'}
    for reference,_ in records:assert resolve_context(state,1,'competition',reference)
    del state['chart_contest']
    assert resolve_context(state,1,'competition','chart_22') is None


@pytest.mark.asyncio
async def test_payment_menu_and_alert_context_are_reachable(monkeypatch,state):
    import bot
    from bot_runtime import experience,signals_portfolio
    from services import experience_state
    from modules.ticket_context import context_for_route
    order={'order_id':'ord_123','user_id':'1','price':100,'status':'pending','created_at':utc_iso()}
    state['vip_orders']=[order]
    monkeypatch.setattr(experience_state,'user_orders',lambda uid:[order])
    monkeypatch.setattr(experience,'async_snapshot',AsyncMock(return_value=state))
    monkeypatch.setattr(experience,'edit',AsyncMock())
    q=SimpleNamespace(data='user_orders',from_user=SimpleNamespace(id=1),answer=AsyncMock())
    update=SimpleNamespace(callback_query=q)
    await experience.user_payments_menu(update,SimpleNamespace())
    assert experience.edit.call_args.args[2][0][0].callback_data=='user_payment:ord_123'
    q.data='user_payment:ord_123'
    assert context_for_route(q.data,1)==('payment','ord_123')
    await experience.user_payments_menu(update,SimpleNamespace())
    assert 'ord_123' in experience.edit.call_args.args[1]
    state['price_alerts']=[{'id':i,'user_id':'1','asset':'XAUUSD','status':'disabled' if i==9 else 'active','condition':'above','target_price':3000} for i in range(1,10)]
    monkeypatch.setattr(signals_portfolio,'async_snapshot',AsyncMock(return_value=state))
    monkeypatch.setattr(signals_portfolio,'_language_for_user',lambda uid:'fa')
    monkeypatch.setattr(signals_portfolio,'edit',AsyncMock())
    q.data='price_alert_list'
    await signals_portfolio._render_price_alert_list(q)
    buttons=[b.callback_data for row in signals_portfolio.edit.call_args.args[2] for b in row]
    assert 'pa_toggle:9' in buttons  # a paused alert stays reachable
    assert 'ticket_from:price_alert:9' in buttons and 'price_alert_list:1' in buttons
