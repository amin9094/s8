from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAVIGATION = ROOT / "bot_runtime" / "navigation.py"
RUNTIME_JOBS = ROOT / "bot_runtime" / "runtime_jobs.py"
REGISTRATION = ROOT / "handlers" / "registration_plan.py"


def _function(path: Path, name: str) -> ast.AsyncFunctionDef | ast.FunctionDef:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return node
    raise AssertionError(f"function not found: {name}")


def test_legacy_reply_keyboard_is_removed_instead_of_rendered():
    node = _function(NAVIGATION, "quick_access_keyboard")
    calls = [item for item in ast.walk(node) if isinstance(item, ast.Call)]
    target = next(call for call in calls if getattr(call.func, "id", "") == "ReplyKeyboardRemove")
    values = {kw.arg: kw.value for kw in target.keywords}
    assert "remove_keyboard" not in values  # fixed True by python-telegram-bot
    assert isinstance(values["selective"], ast.Constant)
    assert values["selective"].value is True
    source = NAVIGATION.read_text(encoding="utf-8")
    assert "ReplyKeyboardMarkup(" not in source
    assert "is_persistent=" not in source
    assert "one_time_keyboard=" not in source


def test_main_menu_has_no_restart_or_cancel_buttons():
    node = _function(NAVIGATION, "main_menu")
    literals = {
        item.value
        for item in ast.walk(node)
        if isinstance(item, ast.Constant) and isinstance(item.value, str)
    }
    assert "cancel_current" not in literals
    assert "restart_bot" not in literals
    assert "✖️ لغو عملیات" not in literals
    assert "🔄 شروع مجدد" not in literals


def test_command_menu_replaces_miniapp_menu_button():
    source = RUNTIME_JOBS.read_text(encoding="utf-8")
    post_init = _function(RUNTIME_JOBS, "post_init")
    calls = [item for item in ast.walk(post_init) if isinstance(item, ast.Call)]
    assert any(getattr(call.func, "id", "") == "MenuButtonCommands" for call in calls)
    post_source = ast.get_source_segment(source, post_init) or ""
    assert "MenuButtonWebApp(" not in post_source
    assert "set_chat_menu_button" in post_source


def test_command_menu_contains_user_entry_points_and_id():
    source = RUNTIME_JOBS.read_text(encoding="utf-8")
    post_init = _function(RUNTIME_JOBS, "post_init")
    post_source = ast.get_source_segment(source, post_init) or ""
    for command in (
        "start", "menu", "vip", "prices", "calculator", "referral",
        "account", "trading", "signals", "support",
        "language", "id", "cancel",
    ):
        assert f'(\"{command}\",' in post_source
    assert '(\"miniapp\",' not in post_source


def test_command_routes_match_visible_command_menu():
    source = REGISTRATION.read_text(encoding="utf-8")
    for route in (
        '("vip", "vip_command")',
        '("calculator", "calculator_command")',
        '("referral", "referral_command")',
        '("trading", "trading_command")',
        '("language", "language_command")',
        '("miniapp", "miniapp_command")',
    ):
        assert route in source
    assert '("restart", "restart_command")' not in source


def test_command_state_key_forces_migration_from_old_keyboard():
    source = NAVIGATION.read_text(encoding="utf-8")
    assert 'sentinel_command_menu_v1' in source
    assert 'commands-v1:' in source
    assert 'sentinel_quick_keyboard_v4_transient' not in source


def test_command_menu_notice_is_silent_and_removed_immediately():
    source = NAVIGATION.read_text(encoding="utf-8")
    assert "منوی دستورات تلگرام فعال شد" not in source
    assert "Telegram's command menu is active" not in source
    node = _function(NAVIGATION, "ensure_quick_access_keyboard")
    function_source = ast.get_source_segment(source, node) or ""
    assert 'text="\u2063"' in function_source
    assert "disable_notification=True" in function_source
    assert "delete_message" in function_source
