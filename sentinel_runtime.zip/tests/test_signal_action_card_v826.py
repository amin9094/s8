from __future__ import annotations


def _callbacks(rows):
    return [getattr(button, "callback_data", "") for row in rows for button in row]


def test_signal_detail_exposes_direct_risk_and_alert_actions(monkeypatch):
    import bot

    monkeypatch.setattr(bot, "_language_for_user", lambda _user_id: "en")
    monkeypatch.setattr(bot, "watchlist_for_user", lambda _db, _user_id: [])
    monkeypatch.setattr(bot, "normalize_market_symbol", lambda value: value.upper())
    monkeypatch.setattr(bot, "signal_market_category", lambda _row: "forex")

    rows = bot._user_signal_detail_rows({}, 1, {"id": 77, "symbol": "XAUUSD"})
    callbacks = _callbacks(rows)

    assert "signal_calc:77" in callbacks
    assert "signal_alert:77" in callbacks


def test_runtime_registers_signal_action_conversation_entry_points():
    import bot

    application = bot.build_application()
    patterns = []
    for handlers in application.handlers.values():
        for handler in handlers:
            entry_points = getattr(handler, "entry_points", None)
            if not entry_points:
                continue
            for entry in entry_points:
                pattern = getattr(entry, "pattern", None)
                if pattern is not None:
                    patterns.append(str(pattern))

    assert any("signal_calc" in pattern for pattern in patterns)
    assert any("signal_alert" in pattern for pattern in patterns)
