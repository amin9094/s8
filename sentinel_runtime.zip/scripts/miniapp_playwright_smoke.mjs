#!/usr/bin/env node
/** Real browser smoke for the Telegram Mini App shell.
 * Install with: npm install --no-save playwright && npx playwright install chromium
 */
import process from 'node:process';

const base = String(process.argv[2] || '').replace(/\/$/, '');
if (!base.startsWith('https://')) throw new Error('HTTPS base URL is required');
let chromium;
try {
  ({ chromium } = await import('playwright'));
} catch (error) {
  throw new Error('Playwright is not installed. Run npm install --no-save playwright and npx playwright install chromium.');
}
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const failures = [];
  page.on('pageerror', (error) => failures.push(`pageerror:${error.message}`));
  page.on('console', (message) => { if (message.type() === 'error') failures.push(`console:${message.text()}`); });
  const response = await page.goto(`${base}/app`, { waitUntil: 'networkidle', timeout: 45_000 });
  if (!response || response.status() !== 200) throw new Error(`/app status=${response?.status()}`);
  const text = await page.locator('body').innerText();
  if (!/SENTINEL/i.test(text)) throw new Error('SENTINEL shell is missing');
  await page.waitForTimeout(4500); // exercise the four-second video loading transition
  const loaders = page.locator('#boot-loader, .boot-loader, [data-loader]');
  let loaderVisible = false;
  for (let i = 0; i < await loaders.count(); i += 1) {
    if (await loaders.nth(i).isVisible().catch(() => false)) { loaderVisible = true; break; }
  }
  if (loaderVisible) throw new Error('loading overlay is still visible after 4.5 seconds');
  const buttons = await page.locator('button, [role="button"]').count();
  if (buttons < 1) throw new Error('Mini App has no interactive controls');
  if (failures.length) throw new Error(failures.slice(0, 10).join(' | '));
  console.log(JSON.stringify({ ok: true, base_url: base, buttons }));
} finally {
  await browser.close();
}
