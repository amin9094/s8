from __future__ import annotations

from typing import Any

from modules.outcome_engine import calculate_signal_outcome

STATUS_LABELS = {
    "open": "در انتظار ورود",
    "entry": "ورود فعال شد",
    "tp1": "تارگت ۱ ثبت شد",
    "tp2": "تارگت ۲ ثبت شد",
    "tp3": "تارگت ۳ ثبت شد",
    "breakeven": "حد ضرر به نقطه ورود منتقل شد",
    "partial_close": "خروج جزئی ثبت شد",
    "target_complete": "تمام تارگت‌ها تکمیل شد",
    "stop": "حد ضرر فعال شد",
    "manual_close": "معامله دستی بسته شد",
    "no_entry": "بدون ورود",
    "cancelled": "لغو شد",
    "expired": "منقضی شد",
}


def _history(signal: dict[str, Any]) -> list[dict[str, Any]]:
    rows = signal.get("lifecycle_history", [])
    return [dict(row) for row in rows if isinstance(row, dict)]


def live_card_payload(signal: dict[str, Any]) -> dict[str, Any]:
    status = str(signal.get("status") or "open").lower()
    outcome = calculate_signal_outcome(signal)
    timeline = []
    for row in _history(signal)[-12:]:
        event = str(row.get("event") or row.get("status") or "")
        timeline.append(
            {
                "event": event,
                "label": STATUS_LABELS.get(event, event.replace("_", " ").title()),
                "at": row.get("created_at") or row.get("at"),
                "actor_id": row.get("actor_id"),
                "source": row.get("source"),
            }
        )
    return {
        "signal_id": int(signal.get("id", 0) or 0),
        "display_number": int(signal.get("display_number", signal.get("id", 0)) or 0),
        "symbol": str(signal.get("symbol") or ""),
        "side": str(signal.get("side") or "").lower(),
        "status": status,
        "status_label": STATUS_LABELS.get(status, status.replace("_", " ").title()),
        "entry_active": bool(signal.get("entry_at") or status not in {"open", "no_entry", "expired"}),
        "highest_target_hit": int(signal.get("highest_target_hit", 0) or 0),
        "remaining_percent": outcome.remaining_percent,
        "net_r": outcome.net_r,
        "outcome": outcome.bucket,
        "revision": int(signal.get("revision", 1) or 1),
        "updated_at": signal.get("updated_at") or signal.get("closed_at") or signal.get("created_at"),
        "timeline": timeline,
    }


def live_card_text(signal: dict[str, Any]) -> str:
    payload = live_card_payload(signal)
    return (
        f"#{payload['display_number']} • {payload['symbol']} • {payload['side'].upper()}\n"
        f"وضعیت: {payload['status_label']}\n"
        f"آخرین تارگت: {payload['highest_target_hit']} | باقی‌مانده: {payload['remaining_percent']:.0f}%\n"
        f"برآیند فعلی: {payload['net_r']:+.2f}R | نسخه: {payload['revision']}"
    )

