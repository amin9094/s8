from __future__ import annotations

import os


def railway_runtime_detected() -> bool:
    return any(
        str(os.getenv(name) or "").strip()
        for name in (
            "RAILWAY_PROJECT_ID",
            "RAILWAY_SERVICE_ID",
            "RAILWAY_ENVIRONMENT_ID",
            "RAILWAY_REPLICA_ID",
        )
    )


def replica_count() -> int:
    """Return the configured logical replica count with a fail-closed Railway default.

    Railway exposes a unique replica ID but not the total replica count inside
    each container.  Startup validation requires ``SENTINEL_REPLICA_COUNT`` on
    Railway.  If a caller reaches topology-sensitive code before validation,
    assume multi-replica (2) rather than silently enabling single-process
    fallbacks or writable failover. Local development keeps a default of one.
    """
    raw = str(os.getenv("SENTINEL_REPLICA_COUNT") or "").strip()
    if not raw:
        return 2 if railway_runtime_detected() else 1
    try:
        return max(1, int(raw))
    except (TypeError, ValueError):
        return 1


def replica_count_is_explicit() -> bool:
    raw = str(os.getenv("SENTINEL_REPLICA_COUNT") or "").strip()
    if not raw:
        return False
    try:
        return int(raw) >= 1
    except (TypeError, ValueError):
        return False


def railway_replica_identity() -> str:
    return str(os.getenv("RAILWAY_REPLICA_ID") or "").strip()
