from __future__ import annotations

import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from telegram import Bot, InlineKeyboardButton
from telegram.error import BadRequest, TimedOut
from telegram.request import BaseRequest

from bot_runtime import navigation
from modules.crm_navigation import crm_action_uid, crm_case_parent, crm_open_parent, select_crm_case
from modules.reward_wallet import mark_wallet_seen, reward_seen_key, rewards_badge, wallet_items, wallet_unread_keys
from modules.signal import send_signal_with_receipts
from modules.signal_slideshow import edit_signal_slideshow
from modules.signal_template_editor import (
    normalize_field_color,
    set_signal_template_color,
    signal_color_palette,
    signal_template_layout,
)


def wallet_db():
    return {
        "users": {"1": {}, "2": {}},
        "user_rewards": [
            {"id": 1, "user_id": "1", "title": "VIP", "type": "vip_days", "created_at": "2026-10-04T20:00:00Z"},
            {"id": 2, "user_id": "2", "title": "Other", "created_at": "2026-10-04T20:00:00Z"},
        ],
        "discount_codes": {"ONLYME": {"assigned_to": "1", "percent": 15, "assigned_at": "2026-10-04T21:00:00Z"}},
    }


@pytest.mark.parametrize("language", ["fa", "en"])
def test_owner_menu_order_and_every_existing_entry_preserved(monkeypatch, language):
    db = wallet_db()
    monkeypatch.setattr(navigation, "load_db", lambda: db)
    monkeypatch.setattr(navigation, "_language_for_user", lambda _: language)
    monkeypatch.setattr(navigation, "is_vip", lambda *_: False)
    monkeypatch.setattr(navigation, "_is_any_admin", lambda _: True)
    monkeypatch.setattr(navigation, "_has_any_admin_permission", lambda *_: True)
    monkeypatch.setattr(
        navigation, "with_webapp", lambda rows: rows + [[InlineKeyboardButton("Mini App", callback_data="test_app")]]
    )
    rows = navigation.main_menu(1)
    assert [[b.callback_data for b in r] for r in rows[:4]] == [
        ["u_vip"],
        ["u_edu", "u_calc"],
        ["u_price", "u_account"],
        ["u_contests", "u_missions"],
    ]
    assert all(len(row) == 2 for row in rows[1:-1])
    callbacks = {b.callback_data for row in rows for b in row}
    assert {
        "u_signal_portal",
        "nav_user:trade",
        "u_today",
        "u_rewards",
        "u_referral",
        "u_leaderboard",
        "u_calendar:today",
        "nav_user:tools",
        "u_settings",
        "u_support",
        "nav_user:support",
        "learning_rules",
        "language_menu",
        "kpi_trader_home",
        "admin_home",
        "home",
        "test_app",
    } <= callbacks
    assert len(callbacks) == sum(map(len, rows))
    assert any("🔴 2" in b.text for r in rows for b in r if b.callback_data == "u_rewards")


def test_seen_is_user_bound_partial_and_new_award_reappears():
    db = wallet_db()
    keys = [reward_seen_key(item) for item in wallet_items(db, 1)]
    other = reward_seen_key(wallet_items(db, 2)[0])
    assert len(wallet_unread_keys(db, 1)) == 2
    assert mark_wallet_seen(db, 1, [keys[0], other, "forged"]) == 1
    assert mark_wallet_seen(db, 1, keys) == 0
    assert rewards_badge(db, 1) == ""
    assert rewards_badge(db, 2) == " · 🔴 1"
    db["user_rewards"].append({"id": 3, "user_id": "1", "title": "Points", "created_at": "2026-10-04T22:00:00Z"})
    assert rewards_badge(db, 1) == " · 🔴 1"
    db["discount_codes"]["ONLYME"]["status"] = "used"
    assert rewards_badge(db, 1) == " · 🔴 1"


def test_crm_back_keeps_case_and_page_but_discards_form(monkeypatch):
    context = SimpleNamespace(user_data={"crm_form_uid": "1", "unfinished_amount": 20})
    select_crm_case(context, "1", "crm_pipeline_stage:lead:8")
    captured = []

    async def dispatch(update, ctx, target):
        captured.append((target, dict(ctx.user_data)))
        return -1

    monkeypatch.setattr(navigation, "_dispatch_back_target", dispatch)
    update = SimpleNamespace(callback_query=SimpleNamespace(data="nb:crm_open:1"))
    asyncio.run(navigation.navigation_back(update, context))
    assert captured[0][0] == "crm_open:1"
    assert context.user_data["admin_user_uid"] == "1"
    assert crm_case_parent(context, 1) == "crm_pipeline_stage:lead:8"
    assert "crm_form_uid" not in context.user_data and "unfinished_amount" not in context.user_data
    navigation._clear_current_operation(context)
    assert "admin_user_uid" not in context.user_data


def test_crm_old_case_button_uses_explicit_uid_not_last_selected():
    context = SimpleNamespace(user_data={})
    select_crm_case(context, "2", "crm_segment:vip:5")
    assert crm_action_uid(context, "crm_note:1") == "1"
    assert context.user_data["admin_user_uid"] == "1"
    assert crm_case_parent(context, 1) == "a_crm"
    assert crm_open_parent("crm_open:1:p:lead:8") == "crm_pipeline_stage:lead:8"
    assert crm_open_parent("crm_open:1:s:vip:5") == "crm_segment:vip:5"
    assert crm_open_parent("crm_open:1:p:forged:abc") is None
    assert crm_open_parent("crm_open:1:f:abandoned:30:8") == "funnel_users:abandoned:30:8"


@pytest.mark.asyncio
async def test_opening_case_ends_only_current_admin_form(monkeypatch):
    from telegram.ext import CommandHandler, ConversationHandler

    from core.conversation_reset import reset_conversations_on_exit

    handler = ConversationHandler(entry_points=[CommandHandler("start", AsyncMock())], states={1: []}, fallbacks=[])
    handler._conversations[(1, 1)] = 1
    handler._conversations[(2, 2)] = 1
    monkeypatch.setattr(ConversationHandler, "_get_key", lambda self, update: (1, 1))
    context = SimpleNamespace(user_data={}, application=SimpleNamespace(handlers={0: [handler]}))
    select_crm_case(context, "10", "crm_pipeline_stage:lead:8")
    update = SimpleNamespace(
        callback_query=SimpleNamespace(data="crm_open:20"), effective_message=SimpleNamespace(text="")
    )
    await reset_conversations_on_exit(update, context)
    assert (1, 1) not in handler._conversations
    assert handler._conversations[(2, 2)] == 1
    assert crm_case_parent(context, "10") == "crm_pipeline_stage:lead:8"


def test_large_crm_page_keeps_origin_and_all_members(monkeypatch):
    import bot
    from bot_runtime import admin_operations as admin

    context = SimpleNamespace(user_data={})
    db = {"users": {str(i): {"first_name": f"User {i}"} for i in range(1, 206)}}
    update = SimpleNamespace(callback_query=SimpleNamespace(data="crm_pipeline_stage:lead:12", answer=AsyncMock()))
    monkeypatch.setattr(admin, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(admin, "async_snapshot", AsyncMock(return_value=db))
    monkeypatch.setattr(admin, "crm_pipeline_snapshot", lambda _: {"lead": list(reversed(list(db["users"])))})

    async def mutate(fn):
        return fn(db)

    monkeypatch.setattr(admin, "async_with_db", mutate)
    rendered = AsyncMock()
    monkeypatch.setattr(admin, "edit", rendered)
    asyncio.run(admin.crm_pipeline_stage_members(update, context))
    assert "205" in rendered.call_args.args[1]
    buttons = [button for row in rendered.call_args.args[2] for button in row]
    case_callbacks = [button.callback_data for button in buttons if str(button.callback_data).startswith("crm_open:")]
    assert case_callbacks == [f"crm_open:{uid}:p:lead:12" for uid in range(121, 131)]
    assert len(db["users"]) == 205


def test_color_palette_remains_valid_after_pillow_caches_rgb():
    from PIL import ImageColor

    for name in ("black", "gold", "rebeccapurple"):
        ImageColor.getrgb(name)
    palette = signal_color_palette()
    assert len(palette) > 140
    assert dict(palette)["black"] == "#000000"


def test_crm_note_back_and_submission_stay_on_selected_user(monkeypatch):
    import bot  # Initialize the production cross-feature export map.
    from bot_runtime import analytics_governance as crm

    db = {"users": {"1": {}, "2": {}}}
    context = SimpleNamespace(user_data={"admin_user_uid": "2"})
    update = SimpleNamespace(
        callback_query=SimpleNamespace(data="crm_note:1", answer=AsyncMock()),
        effective_user=SimpleNamespace(id=99),
        effective_message=SimpleNamespace(text="note"),
    )
    monkeypatch.setattr(crm, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(crm, "async_snapshot", AsyncMock(return_value=db))
    edit = AsyncMock()
    monkeypatch.setattr(crm, "edit", edit)
    asyncio.run(crm.crm_note_start(update, context))
    assert context.user_data["crm_form_uid"] == "1"
    assert edit.call_args.args[2][0][0].callback_data.removeprefix("nb:") == "crm_open:1"
    # Selecting another case cannot redirect an already-started form.
    context.user_data["admin_user_uid"] = "2"
    recorded = []
    monkeypatch.setattr(crm, "add_crm_note", lambda _, uid, *args: recorded.append(uid))
    monkeypatch.setattr(crm, "audit", lambda *_: None)

    async def mutate(fn):
        return fn(db)

    monkeypatch.setattr(crm, "async_with_db", mutate)
    monkeypatch.setattr(crm, "_crm_view_payload", lambda uid, **_: (uid, []))
    monkeypatch.setattr(crm, "reply", AsyncMock())
    asyncio.run(crm.crm_note_input(update, context))
    assert recorded == ["1"]


@pytest.mark.parametrize("value,expected", [("gold", "#FFD700"), ("#0af", "#00AAFF"), ("#12ab34", "#12AB34")])
def test_custom_colors_cover_names_and_rgb(value, expected):
    assert normalize_field_color(value) == expected


@pytest.mark.parametrize("value", ["#12345678", "url(http://x)", "<script>", "rgb(0,0,0)"])
def test_color_input_rejects_non_color_values(value):
    with pytest.raises(ValueError):
        normalize_field_color(value)


def test_field_color_persists_without_changing_layout_and_side():
    db = {}
    before = signal_template_layout(db, "sell")
    set_signal_template_color(db, "sell", "tp1", "#123456")
    after = signal_template_layout(db, "sell")
    assert after["fields"]["tp1"]["color"] == "#123456"
    assert after["fields"]["tp1"]["box"] == before["fields"]["tp1"]["box"]
    assert signal_template_layout(db, "buy")["fields"]["tp1"]["color"] != "#123456"
    assert after["fields"]["entry"]["color"] != after["fields"]["stop"]["color"]
    assert after["fields"]["tp2"]["color"] != after["fields"]["stop"]["color"]
    assert len(signal_color_palette()) > 140


def test_renderer_applies_each_saved_field_color(monkeypatch):
    from modules import signal_image

    db = {}
    colors = {"entry": "#123456", "stop": "#234567", "tp1": "#345678", "tp2": "#456789", "tp3": "#56789A"}
    for field, color in colors.items():
        set_signal_template_color(db, "sell", field, color)
    captured = {}
    monkeypatch.setattr(
        signal_image, "_draw_template_value", lambda _, box, value, **kwargs: captured.update({value: kwargs["accent"]})
    )
    path = Path(
        signal_image.create_signal_image(
            "XAUUSD",
            "2000",
            ["1900", "1800", "1700"],
            "2100",
            "SELL",
            layout_overrides=signal_template_layout(db, "sell"),
        )
    )
    try:
        for value, field in zip(["2000", "2100", "1900", "1800", "1700"], colors, strict=True):
            assert captured[value] == tuple(int(colors[field][i : i + 2], 16) for i in (1, 3, 5))
    finally:
        path.unlink(missing_ok=True)


class RichRequest(BaseRequest):
    def __init__(self, failure=None):
        self.calls = []
        self.failure = failure

    @property
    def read_timeout(self):
        return 30

    async def initialize(self):
        pass

    async def shutdown(self):
        pass

    async def do_request(self, url, method, request_data=None, **kwargs):
        self.calls.append((url, request_data, kwargs))
        if self.failure:
            raise self.failure
        rich = json.loads(request_data.parameters["rich_message"])
        blocks = [
            {
                "type": "photo",
                "photo": [{"file_id": f"file-{i}", "file_unique_id": f"unique-{i}", "width": 100, "height": 200}],
            }
            for i, _ in enumerate(rich["media"])
        ]
        return 200, json.dumps(
            {
                "ok": True,
                "result": {
                    "message_id": 901,
                    "date": 1,
                    "chat": {"id": -1001, "type": "channel"},
                    "rich_message": {"blocks": [{"type": "slideshow", "blocks": blocks}]},
                },
            }
        ).encode()


def test_real_ptb_transport_uploads_slideshow_and_receipts(tmp_path):
    request = RichRequest()
    bot = Bot("123456:ABCDEF", request=request)
    image = tmp_path / "card.png"
    image.write_bytes(b"image-bytes")
    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot,
            {"text": "<b>SELL</b>\nTP1: 1900", "image_path": str(image), "chart_photo_file_id": "chart-file"},
            "both",
            -1001,
            -1001,
        )
    )
    assert errors == [] and len(request.calls) == 1 and len(deliveries) == 2
    url, data, _ = request.calls[0]
    assert url.endswith("/sendRichMessage")
    rich = json.loads(data.parameters["rich_message"])
    assert "<tg-slideshow>" in rich["html"] and rich["html"].count("<img ") == 2
    assert "<p><b>SELL</b></p>" in rich["html"]
    assert rich["media"][0]["media"]["media"] == "attach://sentinel_card"
    assert data.multipart_data["sentinel_card"][1] == b"image-bytes"
    assert rich["media"][1]["media"]["media"] == "chart-file"
    assert all(d["message_type"] == "slideshow" and d["message_ids"] == [901] for d in deliveries)
    assert deliveries[0]["rich_media"][0]["media"]["media"] == "file-0"
    assert not image.exists()


def test_rich_edit_keeps_all_slides_and_uses_text_endpoint():
    request = RichRequest()
    bot = Bot("123456:ABCDEF", request=request)
    media = [
        {"id": "slide0", "media": {"type": "photo", "media": "card-file"}},
        {"id": "slide1", "media": {"type": "photo", "media": "chart-file"}},
    ]
    asyncio.run(edit_signal_slideshow(bot, -1001, 901, "Updated", media))
    url, data, _ = request.calls[0]
    assert url.endswith("/editMessageText")
    assert json.loads(data.parameters["rich_message"])["media"] == media


def test_ambiguous_timeout_never_retries_as_album(tmp_path):
    request = RichRequest(TimedOut())
    bot = Bot("123456:ABCDEF", request=request)
    image = tmp_path / "card.png"
    image.write_bytes(b"image")
    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot, {"text": "signal", "image_path": str(image), "chart_photo_file_id": "chart"}, "public", -1001, 0
        )
    )
    assert errors and deliveries == []
    assert len(request.calls) == 1
    assert not image.exists()


def test_unsupported_rich_api_falls_back_only_after_explicit_rejection(tmp_path):
    bot = SimpleNamespace(
        _post=AsyncMock(side_effect=BadRequest("Method not found")),
        send_media_group=AsyncMock(return_value=[SimpleNamespace(message_id=1), SimpleNamespace(message_id=2)]),
    )
    image = tmp_path / "card.png"
    image.write_bytes(b"image")
    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot, {"text": "signal", "image_path": str(image), "chart_photo_file_id": "chart"}, "public", -1001, 0
        )
    )
    assert errors == [] and deliveries[0]["message_type"] == "media_group"
    bot.send_media_group.assert_awaited_once()
