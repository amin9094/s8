from __future__ import annotations

import logging
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest

from core.smart_logging import DuplicateNoiseFilter
from modules.app_migrations import apply_migration, migration_status, rollback_migration
from modules.broadcast_queue import claim_broadcast_batch, enqueue_broadcast
from modules.feature_flags import feature_enabled, feature_flag_snapshot, set_feature_flag
from modules.operations_intelligence import memory_guardian_snapshot, run_safe_self_healing
from modules.provider_health import record_provider_result, select_healthy_provider
from modules.provider_intelligence import provider_score
from modules.trading_coach import trading_coach_snapshot


def test_feature_flags_toggle_and_audit() -> None:
    db: dict = {}
    assert feature_enabled(db, "ops.self_healing") is True
    row = set_feature_flag(db, "ops.self_healing", False, actor_id=123)
    assert row["enabled"] is False
    assert feature_enabled(db, "ops.self_healing") is False
    snap = feature_flag_snapshot(db)
    assert snap["total"] >= 8 and snap["enabled"] == snap["total"] - 1
    assert db["feature_flag_audit"][-1]["actor_id"] == "123"


def test_memory_guardian_snapshot_is_bounded() -> None:
    snap = memory_guardian_snapshot()
    assert snap["rss_bytes"] > 0
    assert snap["state"] in {"healthy", "warning", "critical", "unknown"}
    if snap["percent"] is not None:
        assert snap["percent"] >= 0


def test_self_healing_cooldown(monkeypatch: pytest.MonkeyPatch) -> None:
    import modules.operations_intelligence as oi

    monkeypatch.setattr(oi, "memory_guardian_snapshot", lambda: {
        "state": "critical", "rss_bytes": 1000, "rss_mb": 1, "limit_bytes": 1100,
        "limit_mb": 1.1, "percent": 91, "warning_percent": 75, "critical_percent": 90,
        "generated_at": "now",
    })
    monkeypatch.setattr("core.shared_cache.trim_local_cache", lambda **_kwargs: {"removed": 3})
    db: dict = {}
    first = run_safe_self_healing(db, now=datetime(2026, 9, 26, tzinfo=UTC))
    second = run_safe_self_healing(db, now=datetime(2026, 9, 26, 0, 1, tzinfo=UTC))
    assert first["status"] == "acted"
    assert first["actions"][0]["cache_removed"] == 3
    assert second["status"] == "cooldown"


def test_smart_logging_never_suppresses_warning() -> None:
    filt = DuplicateNoiseFilter(window_seconds=60)
    info = logging.LogRecord("sentinel.test", logging.INFO, __file__, 1, "same", (), None)
    assert filt.filter(info) is True
    assert filt.filter(info) is False
    warning = logging.LogRecord("sentinel.test", logging.WARNING, __file__, 1, "same", (), None)
    assert filt.filter(warning) is True
    assert filt.filter(warning) is True


def test_broadcast_priority_queue_claims_critical_first() -> None:
    db: dict = {}
    low = enqueue_broadcast(db, admin_id=1, segment="marketing", recipients=[10], message="low", priority="low")
    critical = enqueue_broadcast(db, admin_id=1, segment="safety", recipients=[11], message="critical", priority="critical")
    claimed = claim_broadcast_batch(db, 1)
    assert claimed is not None
    assert claimed["id"] == critical["id"]
    assert claimed["priority"] == "critical"
    assert low["status"] == "queued"


def test_priority_queue_can_be_feature_disabled() -> None:
    db: dict = {}
    set_feature_flag(db, "messaging.priority_queue", False, actor_id=1)
    first = enqueue_broadcast(db, admin_id=1, segment="first", recipients=[10], message="first", priority="low")
    enqueue_broadcast(db, admin_id=1, segment="second", recipients=[11], message="second", priority="critical")
    claimed = claim_broadcast_batch(db, 1)
    assert claimed and claimed["id"] == first["id"]


def test_provider_intelligence_prefers_reliable_low_latency_provider() -> None:
    db: dict = {}
    for _ in range(5):
        record_provider_result(db, "fast", success=True, latency_ms=80)
        record_provider_result(db, "slow", success=True, latency_ms=2500)
    assert provider_score(db["provider_health"]["fast"]) > provider_score(db["provider_health"]["slow"])
    assert select_healthy_provider(db, ["slow", "fast"]) == "fast"
    for _ in range(5):
        record_provider_result(db, "fast", success=False, latency_ms=100, error="offline")
    assert db["provider_health"]["fast"].get("quarantine_until")
    assert select_healthy_provider(db, ["fast", "slow"]) == "slow"


def test_trading_coach_detects_hour_and_setup_patterns() -> None:
    db = {
        "trade_journal": {
            "7": [
                {"id": i + 1, "symbol": "XAUUSD", "side": "BUY", "status": "closed", "result_r": 2 if i < 6 else -1,
                 "setup": "breakout" if i < 6 else "chase", "created_at": f"2026-09-{10+i:02d}T10:00:00+00:00", "closed_at": f"2026-09-{10+i:02d}T11:00:00+00:00"}
                for i in range(10)
            ]
        }
    }
    report = trading_coach_snapshot(db, 7)
    assert report["sample_size"] == 10
    assert report["best_hours"][0]["key"] == "10"
    assert report["best_setups"][0]["key"] == "breakout"
    assert report["findings"]


def test_application_migration_apply_and_rollback_are_persistent() -> None:
    db: dict = {}
    name = "operations-intelligence-foundation"
    assert apply_migration(db, name)["status"] == "applied"
    assert name in migration_status(db)["applied"]
    assert rollback_migration(db, name)["status"] == "rolled_back"
    status = migration_status(db)
    assert name not in status["applied"]
    assert status["rolled_back"][-1]["migration"] == name
    assert feature_enabled(db, "ops.self_healing") is False


def test_callback_routes_include_operations_and_coach() -> None:
    from handlers.callback_routes import callback_routes

    class Missing(dict):
        def __missing__(self, key):
            value = object()
            self[key] = value
            return value

    patterns = [pattern for pattern, _ in callback_routes(Missing())]
    assert "^a_ops_intelligence$" in patterns
    assert "^a_feature_flags$" in patterns
    assert "^u_trading_coach$" in patterns


def test_miniapp_admin_operations_exposes_intelligence(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import miniapp_read_service_v2 as service

    monkeypatch.setattr(service.legacy, "admin_operations", lambda _identity: {"system_health": {}})
    monkeypatch.setattr(service, "read_db_sections", lambda _sections: {"provider_health": {}, "operations": {}, "feature_flags": {}})
    identity = SimpleNamespace(user_id=1)
    payload = service.admin_operations(identity)
    assert "operations_intelligence" in payload
    assert "memory" in payload["operations_intelligence"]
