from __future__ import annotations

from collections import Counter, defaultdict
from statistics import median
from typing import Any

from core.utils import parse_dt
from modules.market_scope import signal_market_category
from modules.kpi_trader import kpi_trader_dashboard
from modules.outcome_engine import (
    OUTCOME_BREAKEVEN,
    OUTCOME_FULL_WIN,
    OUTCOME_LOSS,
    OUTCOME_PARTIAL_WIN,
    SETTLED_OUTCOMES,
    calculate_signal_outcome,
)


def _maximum_drawdown(values: list[float]) -> float:
    equity = 0.0
    peak = 0.0
    drawdown = 0.0
    for value in values:
        equity += value
        peak = max(peak, equity)
        drawdown = max(drawdown, peak - equity)
    return round(drawdown, 6)


def _duration_minutes(start: Any, end: Any) -> float | None:
    left = parse_dt(start)
    right = parse_dt(end)
    if not left or not right or right < left:
        return None
    return (right - left).total_seconds() / 60


def analyst_dashboard(db: dict[str, Any], admin_id: int | str) -> dict[str, Any]:
    target = str(admin_id)
    rows = [
        row
        for row in db.get("signals", [])
        if isinstance(row, dict) and str(row.get("admin_id") or "unknown") == target
    ]
    rows.sort(key=lambda row: str(row.get("created_at") or ""))
    outcomes = [calculate_signal_outcome(row) for row in rows]
    settled = [item for item in outcomes if item.bucket in SETTLED_OUTCOMES]
    wins = [
        item
        for item in settled
        if item.bucket in {OUTCOME_FULL_WIN, OUTCOME_PARTIAL_WIN}
    ]
    losses = [item for item in settled if item.bucket == OUTCOME_LOSS]
    breakeven = [item for item in settled if item.bucket == OUTCOME_BREAKEVEN]
    net_values = [item.net_r for item in settled]
    positive = sum(max(0.0, value) for value in net_values)
    negative = abs(sum(min(0.0, value) for value in net_values))

    by_market: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"signals": 0, "settled": 0, "wins": 0, "losses": 0, "net_r": 0.0}
    )
    by_session: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"signals": 0, "settled": 0, "wins": 0, "losses": 0, "net_r": 0.0}
    )
    for row, outcome in zip(rows, outcomes, strict=True):
        market = signal_market_category(row)
        session = str(row.get("market_session") or "off_hours")
        for bucket in (by_market[market], by_session[session]):
            bucket["signals"] += 1
            if outcome.settled:
                bucket["settled"] += 1
                bucket["net_r"] += outcome.net_r
            if outcome.bucket in {OUTCOME_FULL_WIN, OUTCOME_PARTIAL_WIN}:
                bucket["wins"] += 1
            elif outcome.bucket == OUTCOME_LOSS:
                bucket["losses"] += 1

    for collection in (by_market, by_session):
        for item in collection.values():
            item["net_r"] = round(float(item["net_r"]), 6)
            item["win_rate"] = round(
                int(item["wins"]) / max(1, int(item["wins"]) + int(item["losses"])) * 100,
                4,
            )

    revisions = [
        row
        for row in db.get("signal_revisions", [])
        if isinstance(row, dict) and str(row.get("actor_id")) == target
    ]
    approvals = [
        row
        for row in db.get("signal_approvals", [])
        if isinstance(row, dict)
        and target in {str(row.get("requested_by")), str(row.get("resolved_by"))}
    ]
    review_minutes = [
        value
        for value in (
            _duration_minutes(row.get("created_at"), row.get("resolved_at"))
            for row in approvals
            if str(row.get("resolved_by")) == target
        )
        if value is not None
    ]
    rejected = sum(
        1
        for row in approvals
        if str(row.get("requested_by")) == target and row.get("status") == "rejected"
    )
    outcome_events = [
        row
        for row in db.get("signal_outcome_events", [])
        if isinstance(row, dict) and str(row.get("actor_id")) == target
    ]
    incidents = [
        row
        for row in db.get("incidents", [])
        if isinstance(row, dict)
        and str((row.get("metadata") or {}).get("user_id") or "") == target
    ]

    delegated = (db.get("delegated_admins", {}) or {}).get(target, {})
    user = (db.get("users", {}) or {}).get(target, {})
    display_name = (
        delegated.get("name")
        or user.get("full_name")
        or " ".join(
            filter(None, [user.get("first_name"), user.get("last_name")])
        )
        or user.get("username")
        or f"Admin {target}"
    )
    return {
        "admin_id": target,
        "display_name": str(display_name),
        "signals": len(rows),
        "active": sum(1 for item in outcomes if not item.final),
        "settled": len(settled),
        "wins": len(wins),
        "full_wins": sum(1 for item in wins if item.bucket == OUTCOME_FULL_WIN),
        "partial_wins": sum(
            1 for item in wins if item.bucket == OUTCOME_PARTIAL_WIN
        ),
        "losses": len(losses),
        "breakeven": len(breakeven),
        "win_rate": round(len(wins) / max(1, len(wins) + len(losses)) * 100, 4),
        "net_r": round(sum(net_values), 6),
        "expectancy_r": round(sum(net_values) / max(1, len(settled)), 6),
        "profit_factor": round(positive / negative, 6) if negative else (999.0 if positive else None),
        "maximum_drawdown_r": _maximum_drawdown(net_values),
        "revisions": len(revisions),
        "rejected_signals": rejected,
        "outcome_updates": len(outcome_events),
        "incidents": len(incidents),
        "median_review_minutes": round(median(review_minutes), 2) if review_minutes else None,
        "by_market": dict(by_market),
        "by_session": dict(by_session),
        "symbols": dict(Counter(str(row.get("symbol") or "-") for row in rows).most_common(10)),
        "recent_signals": list(reversed(rows[-10:])),
        "sample_warning": len(settled) < 20,
        "kpi": kpi_trader_dashboard(db, target),
    }


def all_analyst_dashboards(db: dict[str, Any]) -> list[dict[str, Any]]:
    ids = {
        str(row.get("admin_id") or "unknown")
        for row in db.get("signals", [])
        if isinstance(row, dict)
    }
    ids.update(str(value) for value in (db.get("delegated_admins", {}) or {}))
    ids.update(
        str(row.get("trader_id") or "")
        for row in db.get("kpi_trader_submissions", [])
        if isinstance(row, dict) and row.get("trader_id")
    )
    output = [analyst_dashboard(db, admin_id) for admin_id in ids if admin_id]
    output.sort(key=lambda item: (float(item.get("net_r", 0) or 0), int(item.get("settled", 0) or 0)), reverse=True)
    return output
