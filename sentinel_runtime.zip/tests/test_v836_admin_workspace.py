from __future__ import annotations

import copy
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

import bot  # noqa: F401 -- initialize the existing feature facade and shared cross-feature functions
from config import SETTINGS
from modules import admin_access as access
from modules.admin_permission_ui import PAGE_SIZE, PERMISSIONS, TOKEN_TO_PERMISSION
from modules.automation_admin import BUILTINS, FIELDS, builtin_state, can_edit_key, remove_rule, save_rule_draft
from modules.automation_outbox import claim_due_automation_messages, enqueue_automation_message
from modules.automation_v2 import (
    create_automation_rule,
    list_automation_rules,
    process_automation_event,
    update_automation_rule,
)
from modules.management_suite import (
    AUTOMATION_DEFAULTS,
    approval_settings,
    create_pending_approval,
    operation_requires_approval,
    resolve_pending_approval,
)
from modules.referral_milestones import milestone_progress, remove_milestone, save_milestone
from modules.referral_ui import progress_line

OWNER = SETTINGS.primary_admin_id


@pytest.fixture
def db():
    return {
        "users": {"1": {}, "2": {}},
        "delegated_admins": {
            "99": {
                "user_id": 99,
                "active": True,
                "approval_status": "approved",
                "permissions": [
                    access.PERMISSION_AUTOMATIONS,
                    access.PERMISSION_TWO_STEP_APPROVALS,
                    access.PERMISSION_REWARD_POINTS,
                ],
            }
        },
        "next_ids": {},
        "automation_settings": {"crm_quiet_hours_enabled": False},
    }


def update(data, uid=OWNER, text=""):
    user = SimpleNamespace(id=uid)
    query = SimpleNamespace(data=data, from_user=user, answer=AsyncMock(), id="query")
    return SimpleNamespace(callback_query=query, effective_user=user, effective_message=SimpleNamespace(text=text))


def patch_runtime(monkeypatch, module, db):
    monkeypatch.setattr(module, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(module, "async_snapshot", AsyncMock(side_effect=lambda: copy.deepcopy(db)))

    async def mutate(fn):
        return fn(db)

    monkeypatch.setattr(module, "async_with_db", mutate)
    monkeypatch.setattr(module, "edit", AsyncMock())
    monkeypatch.setattr(module, "reply", AsyncMock())


def test_every_old_admin_feature_has_one_direct_button(monkeypatch):
    from bot_runtime import navigation as nav

    monkeypatch.setattr(nav, "_admin_granted_permissions", lambda _: set(access.ALL_PERMISSIONS))
    monkeypatch.setattr(nav, "_is_owner_admin", lambda _: True)
    rows = nav.admin_menu(OWNER)
    root_callbacks = [b.callback_data for row in rows for b in row]
    callbacks = [b.callback_data for category in nav._admin_navigation_categories() for row in nav.admin_category_menu(category,OWNER) for b in row if b.callback_data != "nb:admin_home"]
    assert {cb for _, cb, _ in nav._admin_menu_items()} <= set(callbacks)
    assert any(cb.startswith("admin_cat:") for cb in root_callbacks)
    assert not any(cb.startswith("admin_cat:") for cb in callbacks)
    assert len(callbacks) == len(set(callbacks))
    assert all(len(row) <= 2 for row in rows)
    # Telegram's limit applies to each displayed keyboard, not to the combined
    # inventory of tools in separate working categories.
    assert all(len([b for row in nav.admin_category_menu(category, OWNER) for b in row]) <= 100
               for category in nav._admin_navigation_categories())


def test_limited_admin_only_sees_granted_direct_features(monkeypatch):
    from bot_runtime import navigation as nav

    monkeypatch.setattr(nav, "_admin_granted_permissions", lambda _: {access.PERMISSION_CRM_VIEW})
    monkeypatch.setattr(nav, "_is_owner_admin", lambda _: False)
    cbs = {b.callback_data for category in nav._admin_navigation_categories() for row in nav.admin_category_menu(category,99) for b in row}
    assert {"a_crm", "crm_pipeline"} <= cbs
    assert not {"a_signal", "a_approvals", "a_admins", "owner_kpi_center"} & cbs


def test_all_permissions_are_direct_and_callbacks_bounded():
    from bot_runtime.crm_content import _delegated_admin_rows

    found = []
    for page in range((len(PERMISSIONS) + PAGE_SIZE - 1) // PAGE_SIZE):
        rows = _delegated_admin_rows("123456789012345", {"permissions": []}, page)
        callbacks = [b.callback_data for row in rows for b in row]
        assert not any(cb.startswith("admin_perm_group:") for cb in callbacks)
        assert all(len(cb.encode()) <= 64 for cb in callbacks)
        found += [TOKEN_TO_PERMISSION[cb.split(":")[2]] for cb in callbacks if cb.startswith("ap_set:")]
    assert found == list(PERMISSIONS)


def test_revoked_child_stays_revoked_and_other_children_stay(db):
    access.upsert_delegated_admin(db, 88, [access.PERMISSION_TICKETS], OWNER)
    child = access.PERMISSION_TICKETS_REPLY
    access.set_permission_state(db, 88, child, False, OWNER)
    access.normalize_delegated_admins(db)
    assert not access.has_permission(db, 88, child)
    assert access.has_permission(db, 88, access.PERMISSION_TICKETS_VIEW)
    access.set_permission_state(db, 88, child, False, OWNER)
    assert not access.has_permission(db, 88, child)
    access.set_permission_state(db, 88, child, True, OWNER)
    assert access.has_permission(db, 88, child)


def test_owner_only_permissions_cannot_be_assigned(db):
    for permission in access.OWNER_ONLY_PERMISSIONS:
        with pytest.raises(PermissionError):
            access.set_permission_state(db, 99, permission, True, OWNER)


def test_all_builtin_settings_are_editable_and_no_technical_defaults_lost():
    keys = {spec[2] for spec in BUILTINS.values()} | set(FIELDS)
    assert keys == set(AUTOMATION_DEFAULTS)


def test_builtin_remove_restore_and_explicit_state_are_safe(db):
    builtin_state(db, OWNER, "welcome", enabled=True)
    builtin_state(db, OWNER, "welcome", enabled=True)
    assert db["automation_settings"]["crm_welcome_enabled"] is True
    builtin_state(db, OWNER, "welcome", remove=True)
    assert not db["automation_settings"]["crm_welcome_enabled"]
    with pytest.raises(ValueError):
        builtin_state(db, OWNER, "welcome", enabled=True)
    builtin_state(db, OWNER, "welcome", restore=True)
    assert not db["automation_settings"]["crm_welcome_enabled"]
    assert "welcome" not in db["automation_settings"]["admin_hidden_builtins"]
    with pytest.raises(ValueError):
        builtin_state(db, OWNER, "general", remove=True)


def test_renewal_permission_cannot_modify_other_automations(db):
    db["delegated_admins"]["77"] = {
        "user_id": 77,
        "active": True,
        "approval_status": "approved",
        "permissions": [access.PERMISSION_RENEWALS],
    }
    assert can_edit_key(db, 77, "vip_reminder_days")
    assert not can_edit_key(db, 77, "crm_max_attempts")
    assert not can_edit_key(db, 77, "enabled")


def rule(db, enabled=True):
    return create_automation_rule(
        db,
        name="Example",
        trigger="payment_approved",
        conditions=[],
        actions=[{"type": "write_log", "payload": {"message": "Approved"}}],
        guards={},
        actor_id=OWNER,
        enabled=enabled,
    )


def test_draft_saving_idempotent_and_never_publishes(db):
    values = {
        "name": "Test",
        "trigger": "payment_approved",
        "conditions": [],
        "actions": [{"type": "write_log", "payload": {"message": "text"}}],
        "guards": {},
    }
    a = save_rule_draft(db, OWNER, "SERVER_TOKEN", values)
    b = save_rule_draft(db, OWNER, "SERVER_TOKEN", values)
    assert a["id"] == b["id"] and len(db["automation_rules_v2"]) == 1
    assert not a["enabled"]
    with pytest.raises(PermissionError):
        save_rule_draft(db, 1, "OTHER", values)


def test_rule_delete_preserves_history_cancels_pending_and_blocks_api_resurrection(db):
    r = rule(db)
    db["automation_v2_runs"] = [{"rule_id": r["id"], "status": "completed"}]
    db["automation_v2_jobs"] = {"j": {"rule_id": r["id"], "status": "retry"}}
    db["automation_outbox"] = {"m": {"dedupe_key": f"av2:{r['id']}:run:0", "status": "pending"}}
    remove_rule(db, OWNER, r["id"])
    assert db["automation_v2_runs"]
    assert db["automation_v2_jobs"]["j"]["status"] == "cancelled"
    assert db["automation_outbox"]["m"]["status"] == "cancelled"
    assert not list_automation_rules(db)
    with pytest.raises(ValueError):
        update_automation_rule(db, r["id"], {"enabled": True}, actor_id=OWNER)
    assert (
        process_automation_event(db, "payment_approved", {"event_id": "e", "user_id": "1"}, actor_id=OWNER)["count"]
        == 0
    )


def test_global_pause_stops_v2_generation_and_both_delivery_queues(db):
    from services.automation_v2_dispatcher import claim_due_automation_v2_jobs

    r = rule(db)
    db["automation_settings"]["enabled"] = False
    assert process_automation_event(db, "payment_approved", {"event_id": "e", "user_id": "1"}, actor_id=OWNER)["paused"]
    assert not db.get("automation_custom_log")
    enqueue_automation_message(
        db,
        dedupe_key="plain",
        kind="notify_admin",
        recipient_id=OWNER,
        recipient_scope="admin",
        payload={"text": "test"},
    )
    db["automation_v2_jobs"] = {"j": {"kind": "webhook", "rule_id": r["id"], "status": "pending"}}
    assert not claim_due_automation_messages(db)
    assert not claim_due_automation_v2_jobs(db)


def test_disabled_rule_pauses_its_pending_delivery(db):
    r = rule(db)
    enqueue_automation_message(
        db,
        dedupe_key=f"av2:{r['id']}:run:0",
        kind="notify_admin",
        recipient_id=OWNER,
        recipient_scope="admin",
        payload={"text": "test"},
    )
    update_automation_rule(db, r["id"], {"enabled": False}, actor_id=OWNER)
    assert not claim_due_automation_messages(db)
    update_automation_rule(db, r["id"], {"enabled": True}, actor_id=OWNER)
    assert len(claim_due_automation_messages(db)) == 1


@pytest.mark.asyncio
async def test_simple_rule_creation_preview_save_activate_and_back(monkeypatch, db):
    from bot_runtime import automation_ui as ui

    patch_runtime(monkeypatch, ui, db)
    ctx = SimpleNamespace(user_data={})
    await ui.automation_ui_callback(update("au:new"), ctx)
    await ui.automation_ui_input(update("", text="Reminder"), ctx)
    await ui.automation_ui_callback(update("au:trigger:payment_approved"), ctx)
    await ui.automation_ui_callback(update("au:action:notify_admin"), ctx)
    await ui.automation_ui_input(update("", text="Hello <user>"), ctx)
    assert not db.get("automation_rules_v2")
    assert ctx.user_data["automation_ui_wizard"]["step"] == "preview"
    await ui.automation_ui_callback(update("au:wback"), ctx)
    assert ctx.user_data["automation_ui_wizard"]["values"]["value"] == "Hello <user>"
    await ui.automation_ui_callback(update("au:keep"), ctx)
    token = ctx.user_data["automation_ui_wizard"]["token"]
    await ui.automation_ui_callback(update(f"au:save:{token}"), ctx)
    r = next(iter(db["automation_rules_v2"].values()))
    assert not r["enabled"]
    assert r["actions"][0]["payload"]["recipient_id"] == str(OWNER)
    assert "&lt;user&gt;" in r["actions"][0]["payload"]["text"]
    await ui.automation_ui_callback(update(f"au:rstate:{r['id']}:1"), ctx)
    assert r["enabled"]


@pytest.mark.asyncio
async def test_stale_rule_editor_cannot_overwrite_concurrent_change(monkeypatch, db):
    from bot_runtime import automation_ui as ui

    patch_runtime(monkeypatch, ui, db)
    r = rule(db)
    ctx = SimpleNamespace(user_data={})
    await ui.automation_ui_callback(update(f"au:rename:{r['id']}"), ctx)
    update_automation_rule(db, r["id"], {"name": "New by another admin"}, actor_id=OWNER)
    await ui.automation_ui_input(update("", text="Stale"), ctx)
    assert db["automation_rules_v2"][r["id"]]["name"] == "New by another admin"


def test_approval_policy_check_does_not_disable_itself(db):
    approval_settings(db).update(enabled=True, operations=["admin_remove"])
    assert operation_requires_approval(db, "admin_remove")
    assert not operation_requires_approval(db, "admin_all_permissions")
    assert db["approval_settings"]["enabled"] is True
    assert db["approval_settings"]["operations"] == ["admin_remove"]


def test_approval_policy_survives_migration_and_storage_restart(tmp_path, db):
    from core.db import SQLiteStore, migrate_db

    approval_settings(db).update(enabled=True, operations=["admin_remove", "broadcast_all"], expires_minutes=45)
    request = create_pending_approval(db, "admin_remove", {"uid": "88"}, 99, description="restart test")
    normalized = migrate_db(db)
    assert normalized["approval_settings"] == db["approval_settings"]
    path = tmp_path / "approval.sqlite3"
    SQLiteStore(path, tmp_path / "backups").write(normalized)
    reopened = SQLiteStore(path, tmp_path / "backups")._read()
    assert reopened["approval_settings"] == db["approval_settings"]
    assert operation_requires_approval(reopened, "admin_remove")
    pending = next(r for r in reopened["pending_admin_actions"] if r["token"] == request["token"])
    assert pending["status"] == "pending"


@pytest.mark.parametrize("actor", [99, 100, 1])
@pytest.mark.parametrize("approve", [True, False])
def test_only_numeric_primary_admin_can_resolve_any_request(db, actor, approve):
    r = create_pending_approval(db, "admin_remove", {"uid": "88"}, 99, description="test")
    with pytest.raises(PermissionError):
        resolve_pending_approval(db, r["token"], actor, approve)
    assert r["status"] == "pending"


def test_owner_approval_is_single_use_and_self_approval_still_forbidden(db):
    r = create_pending_approval(db, "admin_remove", {"uid": "88"}, 99, description="test")
    resolve_pending_approval(db, r["token"], OWNER, True)
    with pytest.raises(ValueError):
        resolve_pending_approval(db, r["token"], OWNER, True)
    own = create_pending_approval(db, "admin_remove", {"uid": "88"}, OWNER, description="self")
    with pytest.raises(ValueError):
        resolve_pending_approval(db, own["token"], OWNER, True)
    resolve_pending_approval(db, own["token"], OWNER, False)
    assert own["status"] == "rejected"


@pytest.mark.asyncio
async def test_nonprimary_configured_admin_cannot_toggle_or_approve(monkeypatch, db):
    from bot_runtime import analytics_governance as gov

    patch_runtime(monkeypatch, gov, db)
    monkeypatch.setattr(gov, "_is_owner_admin", lambda actor: actor == OWNER)
    ctx = SimpleNamespace(user_data={})
    before = copy.deepcopy(db)
    for fn, cb in (
        (gov.approval_toggle_handler, "approval_toggle"),
        (gov.approval_operation_toggle, "approval_op:admin_remove"),
        (gov.approval_expiry_handler, "approval_expiry:15"),
        (gov.approval_review_handler, "approval_accept:FORGED"),
    ):
        await fn(update(cb, uid=99), ctx)
    assert db == before


@pytest.mark.asyncio
async def test_approval_notifications_only_go_to_primary(monkeypatch, db):
    from bot_runtime import analytics_governance as gov

    monkeypatch.setattr(gov, "_telegram_request_with_button_fallback", AsyncMock())
    ctx = SimpleNamespace(bot=SimpleNamespace(send_message=AsyncMock()))
    r = create_pending_approval(db, "admin_remove", {"uid": "88"}, 99, description="test")
    await gov._notify_pending_approval(ctx, r)
    calls = gov._telegram_request_with_button_fallback.await_args_list
    assert len(calls) == 1 and calls[0].args[1] == OWNER


@pytest.mark.asyncio
async def test_approved_backup_preserves_policy_and_consumed_approval(monkeypatch, tmp_path, db):
    import hashlib

    from bot_runtime import analytics_governance as gov
    from core.backup_service import create_payload_backup
    from core.db import migrate_db

    key = "test-approved-backup-key-0123456789abcdef"
    old = migrate_db({"users": {"8": {"name": "Backup user"}}})
    backup = create_payload_backup(old, tmp_path, encryption_key=key)
    approval_settings(db).update(enabled=True, operations=["restore_backup"])
    request = create_pending_approval(db, "restore_backup", {
        "filename": backup.name, "sha256": hashlib.sha256(backup.read_bytes()).hexdigest(),
    }, 99, description="Restore")
    approved = resolve_pending_approval(db, request["token"], OWNER, True)
    patch_runtime(monkeypatch, gov, db)
    monkeypatch.setattr(gov, "SETTINGS", SimpleNamespace(
        backup_dir=tmp_path, backup_encryption_key=key, backup_previous_keys=(), backup_key_version="v1",
    ))
    await gov._execute_approved_action(SimpleNamespace(), approved)
    assert "8" in db["users"] and "1" not in db["users"]
    assert db["approval_settings"]["enabled"] is True
    assert db["approval_settings"]["operations"] == ["restore_backup"]
    with pytest.raises(ValueError):
        resolve_pending_approval(db, request["token"], OWNER, True)


@pytest.mark.asyncio
async def test_approved_broadcast_preserves_media_and_recalculates_recipients(monkeypatch, db):
    from bot_runtime import analytics_governance as gov

    request = create_pending_approval(db, "broadcast_all", {
        "payloads": [{"type": "photo", "file_id": "tg-file", "caption": "approved content"}],
        "recipients": [999999],
    }, 99, description="Broadcast")
    approved = resolve_pending_approval(db, request["token"], OWNER, True)
    db["users"]["3"] = {}
    patch_runtime(monkeypatch, gov, db)
    await gov._execute_approved_action(SimpleNamespace(), approved)
    jobs = db["broadcast_queue"]
    assert len(jobs) == 1
    assert set(jobs[0]["recipients"]) == {"1", "2", "3"}
    assert jobs[0]["content"]["type"] == "photo"
    assert jobs[0]["content"]["file_id"] == "tg-file"
    with pytest.raises(ValueError):
        resolve_pending_approval(db, request["token"], OWNER, True)


def milestone(db):
    return save_milestone(
        db,
        OWNER,
        {
            "title": "Invite",
            "trigger_type": "referrals_joined",
            "required_count": 5,
            "reward_type": "points",
            "reward_value": 50,
            "enabled": True,
            "repeatable": False,
        },
    )


def test_stage_delete_preserves_claims_and_prevents_resurrection(db):
    r = milestone(db)
    mid = str(r["id"])
    db["referral_milestone_claims"] = {"1:1:1": {"user_id": "1", "milestone_id": r["id"], "reward_id": 1}}
    remove_milestone(db, OWNER, mid)
    assert db["referral_milestone_claims"]
    assert not milestone_progress(db, 1)
    with pytest.raises(ValueError):
        save_milestone(db, OWNER, {"enabled": True}, mid)


def test_issued_stage_economics_immutable_but_titles_editable(db):
    r = milestone(db)
    mid = str(r["id"])
    db["referral_milestone_claims"] = {"c": {"user_id": "1", "milestone_id": r["id"]}}
    with pytest.raises(ValueError):
        save_milestone(db, OWNER, {"reward_value": 1000}, mid)
    assert save_milestone(db, OWNER, {"title": "Renamed"}, mid)["title"] == "Renamed"


def test_referral_progress_bar_is_bounded_and_repeatable_goal_advances():
    row = {"required_count": 5, "progress": 7, "claimed": 1, "repeatable": True}
    line = progress_line(row)
    assert "7 / 10" in line and line.count("🟩") == 7
    assert progress_line({**row, "progress": 999}).count("🟩") == 10


@pytest.mark.asyncio
async def test_milestone_text_edit_requires_final_confirmation(monkeypatch, db):
    from bot_runtime import experience as exp

    patch_runtime(monkeypatch, exp, db)
    r = milestone(db)
    mid = str(r["id"])
    ctx = SimpleNamespace(user_data={})
    await exp.experience_input_start(update(f"milestone_field:{mid}:title"), ctx)
    await exp.experience_input_message(update("", text="Updated"), ctx)
    assert db["referral_milestones"][mid]["title"] == "Invite"
    token = ctx.user_data["milestone_edit_preview"]["token"]
    await exp.milestone_config_callback(update(f"ms:save:{mid}:{token}"), ctx)
    assert db["referral_milestones"][mid]["title"] == "Updated"


@pytest.mark.asyncio
async def test_reward_type_choice_is_bound_and_asks_relevant_amount(monkeypatch, db):
    from bot_runtime import experience as exp

    patch_runtime(monkeypatch, exp, db)
    r = milestone(db)
    mid = str(r["id"])
    ctx = SimpleNamespace(user_data={})
    await exp.experience_input_start(update(f"milestone_field:{mid}:reward_type"), ctx)
    result = await exp.milestone_config_callback(update(f"ms:choice:{mid}:reward_type:vip_days"), ctx)
    assert result == exp.EXPERIENCE_INPUT
    await exp.experience_input_message(update("", text="7"), ctx)
    assert db["referral_milestones"][mid]["reward_type"] == "points"
    token = ctx.user_data["milestone_edit_preview"]["token"]
    await exp.milestone_config_callback(update(f"ms:save:{mid}:{token}"), ctx)
    assert db["referral_milestones"][mid]["reward_type"] == "vip_days"
    assert db["referral_milestones"][mid]["reward_value"] == 7
