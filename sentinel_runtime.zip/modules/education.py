from __future__ import annotations

import copy
import hashlib
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from core.db import next_id
from core.utils import utc_iso


_ALLOWED_ATTACHMENT_TYPES = {"video", "voice", "audio", "pdf", "document", "file", "photo", "link", "animation"}
_MAX_ATTACHMENTS_PER_LESSON = 20


def normalize_lesson_link(value: Any) -> str:
    """Return a safe HTTP(S) lesson link suitable for Telegram buttons."""
    raw = str(value or "").strip()
    if not raw or len(raw) > 2048:
        raise ValueError("لینک آموزش نامعتبر است")
    parsed = urlsplit(raw)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        raise ValueError("لینک آموزش باید با http:// یا https:// شروع شود")
    if parsed.username or parsed.password:
        raise ValueError("لینک آموزش نباید شامل نام کاربری یا رمز باشد")
    host = parsed.hostname or ""
    if not host or any(ch.isspace() for ch in host):
        raise ValueError("دامنه لینک آموزش نامعتبر است")
    # Fragments are harmless but add no value to stored content and can create
    # accidental duplicates, so normalize them away.
    normalized = urlunsplit((parsed.scheme.lower(), parsed.netloc, parsed.path or "", parsed.query, ""))
    return normalized[:2048]


def normalize_attachment(item: dict[str, Any]) -> dict[str, Any]:
    kind = str(item.get("type") or item.get("kind") or "document").strip().lower()
    if kind not in _ALLOWED_ATTACHMENT_TYPES:
        kind = "document"
    url = ""
    if kind == "link":
        url = normalize_lesson_link(item.get("url") or item.get("link"))
    generated_id = hashlib.sha256(url.encode("utf-8")).hexdigest()[:32] if url else ""
    return {
        "id": str(item.get("id") or item.get("file_unique_id") or item.get("file_id") or generated_id or "")[:160],
        "type": kind,
        "media_group_id": str(item.get("media_group_id") or "")[:120],
        "file_id": str(item.get("file_id") or "")[:512],
        "file_unique_id": str(item.get("file_unique_id") or "")[:160],
        "url": url,
        "file_name": str(item.get("file_name") or "")[:255],
        "mime_type": str(item.get("mime_type") or "")[:120],
        "file_size": max(0, int(item.get("file_size", 0) or 0)),
        "duration": max(0, int(item.get("duration", 0) or 0)),
        "width": max(0, int(item.get("width", 0) or 0)),
        "height": max(0, int(item.get("height", 0) or 0)),
        "caption": str(item.get("caption") or "")[:1000],
        "created_at": str(item.get("created_at") or utc_iso()),
    }


def lesson_has_content(lesson: dict[str, Any]) -> bool:
    return bool(str(lesson.get("text") or "").strip() or lesson.get("attachments"))


def add_lesson_attachment(db: dict[str, Any], lesson_id: int | str, attachment: dict[str, Any]) -> dict[str, Any]:
    lesson = find_lesson(db, lesson_id)
    if not lesson:
        raise ValueError("درس پیدا نشد")
    row = normalize_attachment(attachment)
    if row["type"] == "link":
        if not row["url"]:
            raise ValueError("لینک آموزش موجود نیست")
        duplicate_key = row["url"]
    elif not row["file_id"]:
        raise ValueError("شناسه فایل تلگرام موجود نیست")
    else:
        duplicate_key = str(row.get("file_unique_id") or row.get("file_id"))
    attachments = lesson.setdefault("attachments", [])
    duplicate = next(
        (
            item
            for item in attachments
            if str(item.get("url") or item.get("file_unique_id") or item.get("file_id")) == duplicate_key
        ),
        None,
    )
    if duplicate:
        return duplicate
    if len(attachments) >= _MAX_ATTACHMENTS_PER_LESSON:
        raise ValueError(f"حداکثر {_MAX_ATTACHMENTS_PER_LESSON} فایل برای هر درس مجاز است")
    attachments.append(row)
    lesson["updated_at"] = utc_iso()
    return row


def append_lesson_text(db: dict[str, Any], lesson_id: int | str, text: str) -> dict[str, Any]:
    lesson = find_lesson(db, lesson_id)
    if not lesson:
        raise ValueError("درس پیدا نشد")
    value = str(text or "").strip()
    if not value:
        raise ValueError("متن خالی است")
    current = str(lesson.get("text") or "").strip()
    lesson["text"] = (current + ("\n\n" if current else "") + value)[:100_000]
    lesson["updated_at"] = utc_iso()
    return lesson


def remove_lesson_attachment(db: dict[str, Any], lesson_id: int | str, attachment_id: str) -> bool:
    lesson = find_lesson(db, lesson_id)
    if not lesson:
        raise ValueError("درس پیدا نشد")
    before = list(lesson.get("attachments") or [])
    key = str(attachment_id or "")
    lesson["attachments"] = [row for row in before if str(row.get("id") or row.get("file_unique_id") or row.get("file_id")) != key]
    changed = len(before) != len(lesson["attachments"])
    if changed:
        lesson["updated_at"] = utc_iso()
    return changed


def normalize_lesson(item: dict[str, Any]) -> dict[str, Any]:
    item.setdefault("category", "عمومی")
    item.setdefault("course", str(item.get("category") or "عمومی"))
    item.setdefault("chapter", "فصل ۱")
    item.setdefault("position", int(item.get("id", 0) or 0))
    item.setdefault("access_type", "paid" if item.get("paid") else "free")
    item.setdefault("price", 0)
    item.setdefault("vip", False)
    item.setdefault("status", "published")
    item.setdefault("active", True)
    item.setdefault("duration_minutes", 5)
    item.setdefault("prerequisite_ids", [])
    item.setdefault("attachments", [])
    if not isinstance(item.get("attachments"), list):
        item["attachments"] = []
    item["attachments"] = [normalize_attachment(row) for row in item["attachments"] if isinstance(row, dict)]
    item.setdefault("quiz", [])
    item.setdefault("views", 0)
    item.setdefault("ratings", {})
    item.setdefault("rating_total", 0)
    item.setdefault("rating_count", 0)
    item.setdefault("created_at", utc_iso())
    item.setdefault("updated_at", item.get("created_at"))
    return item


def ensure_education(db: dict[str, Any]) -> None:
    lessons = db.setdefault("lessons", [])
    for item in lessons:
        if isinstance(item, dict):
            normalize_lesson(item)
    db.setdefault("education_progress", {})
    db.setdefault("education_certificates", [])


def find_lesson(db: dict[str, Any], lesson_id: int | str) -> dict[str, Any] | None:
    ensure_education(db)
    try:
        wanted = int(lesson_id)
    except (TypeError, ValueError):
        return None
    return next(
        (item for item in db.get("lessons", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == wanted),
        None,
    )


def create_lesson(
    db: dict[str, Any],
    *,
    category: str,
    title: str,
    access_type: str,
    price: int,
    text: str,
    course: str = "",
    chapter: str = "فصل ۱",
    duration_minutes: int = 5,
    status: str = "published",
    actor_id: int | str = 0,
) -> dict[str, Any]:
    ensure_education(db)
    access = str(access_type).lower()
    if access not in {"free", "paid"}:
        raise ValueError("نوع دسترسی باید free یا paid باشد")
    if not str(category).strip() or not str(title).strip():
        raise ValueError("دسته و عنوان الزامی است")
    if status != "draft" and not str(text).strip():
        raise ValueError("برای انتشار مستقیم، متن درس یا فایل آموزشی لازم است")
    amount = max(0, int(price)) if access == "paid" else 0
    if access == "paid" and amount <= 0:
        raise ValueError("قیمت آموزش پولی باید بیشتر از صفر باشد")
    if status not in {"draft", "published", "archived"}:
        raise ValueError("وضعیت درس نامعتبر است")
    lesson = normalize_lesson({
        "id": next_id(db, "lesson"),
        "category": str(category).strip()[:80],
        "course": str(course or category).strip()[:120],
        "chapter": str(chapter or "فصل ۱").strip()[:120],
        "title": str(title).strip()[:150],
        "access_type": access,
        "price": amount,
        "vip": False,
        "text": str(text).strip()[:100_000],
        "status": status,
        "active": status == "published",
        "duration_minutes": max(1, min(int(duration_minutes), 10_000)),
        "created_by": str(actor_id),
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
        "views": 0,
    })
    db["lessons"].append(lesson)
    return lesson


def update_lesson(db: dict[str, Any], lesson_id: int | str, **changes: Any) -> dict[str, Any]:
    lesson = find_lesson(db, lesson_id)
    if not lesson:
        raise ValueError("درس پیدا نشد")
    allowed = {
        "category", "course", "chapter", "title", "access_type", "price", "text",
        "duration_minutes", "status", "active", "position", "prerequisite_ids", "attachments", "quiz",
    }
    for key, value in changes.items():
        if key not in allowed or value is None:
            continue
        if key in {"category", "course", "chapter"}:
            lesson[key] = str(value).strip()[:120]
        elif key == "title":
            lesson[key] = str(value).strip()[:150]
        elif key == "text":
            lesson[key] = str(value).strip()[:100_000]
        elif key == "access_type":
            access = str(value).lower()
            if access not in {"free", "paid"}:
                raise ValueError("نوع دسترسی نامعتبر است")
            lesson[key] = access
            if access == "free":
                lesson["price"] = 0
        elif key in {"price", "duration_minutes", "position"}:
            lesson[key] = max(0, int(value))
        elif key == "status":
            status = str(value)
            if status not in {"draft", "published", "archived"}:
                raise ValueError("وضعیت نامعتبر است")
            lesson["status"] = status
            lesson["active"] = status == "published"
        elif key == "active":
            lesson[key] = bool(value)
        else:
            lesson[key] = copy.deepcopy(value)
    if lesson.get("access_type") == "paid" and int(lesson.get("price", 0) or 0) <= 0:
        raise ValueError("قیمت آموزش پولی باید بیشتر از صفر باشد")
    lesson["updated_at"] = utc_iso()
    return lesson


def set_lesson_status(db: dict[str, Any], lesson_id: int | str, status: str) -> dict[str, Any]:
    return update_lesson(db, lesson_id, status=status)


def duplicate_lesson(db: dict[str, Any], lesson_id: int | str, actor_id: int | str) -> dict[str, Any]:
    original = find_lesson(db, lesson_id)
    if not original:
        raise ValueError("درس پیدا نشد")
    clone = copy.deepcopy(original)
    clone["id"] = next_id(db, "lesson")
    clone["title"] = f"کپی {original.get('title', '')}"[:150]
    clone["status"] = "draft"
    clone["active"] = False
    clone["views"] = 0
    clone["ratings"] = {}
    clone["rating_total"] = 0
    clone["rating_count"] = 0
    clone["created_by"] = str(actor_id)
    clone["created_at"] = utc_iso()
    clone["updated_at"] = utc_iso()
    db.setdefault("lessons", []).append(clone)
    return clone


def delete_lesson(db: dict[str, Any], lesson_id: int | str) -> dict[str, Any] | None:
    lesson = find_lesson(db, lesson_id)
    if not lesson:
        return None
    db["lessons"] = [item for item in db.get("lessons", []) if item is not lesson]
    for rows in db.setdefault("education_progress", {}).values():
        if isinstance(rows, dict):
            rows.pop(str(lesson["id"]), None)
    return lesson


def visible_lessons(db: dict[str, Any], *, access_type: str | None = None) -> list[dict[str, Any]]:
    ensure_education(db)
    rows = [
        item for item in db.get("lessons", [])
        if isinstance(item, dict) and item.get("active", True) and item.get("status", "published") == "published"
    ]
    if access_type:
        rows = [item for item in rows if str(item.get("access_type") or "free") == access_type]
    rows.sort(key=lambda item: (str(item.get("course") or ""), str(item.get("chapter") or ""), int(item.get("position", item.get("id", 0)) or 0)))
    return rows


def mark_lesson_complete(db: dict[str, Any], user_id: int | str, lesson_id: int | str) -> dict[str, Any]:
    lesson = find_lesson(db, lesson_id)
    if not lesson or not lesson.get("active", True) or lesson.get("status", "published") != "published":
        raise ValueError("درس در دسترس نیست")
    from modules.management_suite import has_education_access
    from core.domain import is_vip
    if not has_education_access(db, user_id, lesson) or (lesson.get("vip") and not is_vip(db, user_id)):
        raise ValueError("دسترسی به درس ندارید")
    uid = str(user_id)
    progress = db.setdefault("education_progress", {}).setdefault(uid, {})
    row = progress.setdefault(str(lesson["id"]), {})
    if row.get("completed"):
        return row
    row.update({"completed": True, "completed_at": utc_iso(), "updated_at": utc_iso()})
    from core.domain import record_event
    record_event(db, uid, "complete_lesson")
    return row


def lesson_progress(db: dict[str, Any], user_id: int | str, lesson_id: int | str) -> dict[str, Any]:
    ensure_education(db)
    return dict(db.get("education_progress", {}).get(str(user_id), {}).get(str(lesson_id), {}))


def rate_lesson(db: dict[str, Any], user_id: int | str, lesson_id: int | str, rating: int) -> dict[str, Any]:
    lesson = find_lesson(db, lesson_id)
    if not lesson:
        raise ValueError("درس پیدا نشد")
    value = int(rating)
    if not 1 <= value <= 5:
        raise ValueError("امتیاز باید بین ۱ تا ۵ باشد")
    uid = str(user_id)
    ratings = lesson.setdefault("ratings", {})
    previous = ratings.get(uid)
    if previous is not None:
        lesson["rating_total"] = int(lesson.get("rating_total", 0) or 0) - int(previous)
    else:
        lesson["rating_count"] = int(lesson.get("rating_count", 0) or 0) + 1
    ratings[uid] = value
    lesson["rating_total"] = int(lesson.get("rating_total", 0) or 0) + value
    lesson["updated_at"] = utc_iso()
    return lesson


def education_statistics(db: dict[str, Any]) -> dict[str, Any]:
    ensure_education(db)
    lessons = [item for item in db.get("lessons", []) if isinstance(item, dict)]
    progress = db.get("education_progress", {})
    completions = sum(
        1 for rows in progress.values() if isinstance(rows, dict)
        for row in rows.values() if isinstance(row, dict) and row.get("completed")
    )
    return {
        "total": len(lessons),
        "published": sum(item.get("status") == "published" for item in lessons),
        "drafts": sum(item.get("status") == "draft" for item in lessons),
        "archived": sum(item.get("status") == "archived" for item in lessons),
        "views": sum(int(item.get("views", 0) or 0) for item in lessons),
        "completions": completions,
    }


def publish_scheduled_lessons(db):
    from modules.admin_access import has_permission
    from core.utils import parse_dt, utc_now
    published=[]
    for lesson in db.get('lessons',[]):
        if lesson.get('status')!='draft' or not lesson.get('scheduled_at'):continue
        when=parse_dt(lesson['scheduled_at'])
        if not when or when>utc_now():continue
        actor=lesson.get('created_by','')
        if not has_permission(db,actor,'education_publish') or not has_permission(db,actor,'education.schedule'):
            lesson['schedule_error']='PUBLISH_PERMISSION_REVOKED';continue
        if not lesson_has_content(lesson):
            lesson['schedule_error']='EMPTY_CONTENT';continue
        set_lesson_status(db,lesson['id'],'published');lesson['published_at']=utc_iso();published.append(lesson['id'])
    return published
