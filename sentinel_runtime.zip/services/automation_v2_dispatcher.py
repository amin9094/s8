from __future__ import annotations

import asyncio
import copy
import ipaddress
import logging
import socket
from datetime import timedelta
from typing import Any
from urllib.parse import urlparse

import httpx

from core.async_db import async_with_db
from core.async_runtime import run_blocking
from core.utils import parse_dt, utc_iso, utc_now
from modules.automation_event_bus import collect_scheduled_automation_events
from modules.automation_v2 import _validate_webhook_url, process_automation_event

logger = logging.getLogger(__name__)
_CLAIM_TTL_SECONDS = 300


def run_scheduled_automation_cycle(db: dict[str, Any]) -> dict[str, Any]:
    enabled_triggers = {
        str(row.get("trigger") or "").strip().lower()
        for row in db.setdefault("automation_rules_v2", {}).values()
        if isinstance(row, dict) and row.get("enabled")
    }
    now = utc_now()
    if not enabled_triggers:
        return {"events": 0, "matched_rules": 0, "generated_at": utc_iso(now)}
    events = collect_scheduled_automation_events(db, now=now, active_triggers=enabled_triggers)
    results: list[dict[str, Any]] = []
    for trigger, payload in events:
        results.append(process_automation_event(db, trigger, payload, actor_id="scheduler"))
    if "scheduled" in enabled_triggers:
        minute_key = now.strftime("%Y%m%d%H%M")
        results.append(process_automation_event(
            db,
            "scheduled",
            {
                "event_id": f"scheduled:{minute_key}",
                "entity_id": minute_key,
                "date": now.date().isoformat(),
                "hour": now.hour,
                "minute": now.minute,
                "weekday": now.weekday(),
                "occurred_at": utc_iso(now),
            },
            actor_id="scheduler",
        ))
    return {
        "events": len(events) + (1 if "scheduled" in enabled_triggers else 0),
        "matched_rules": sum(int(item.get("count", 0) or 0) for item in results),
        "generated_at": utc_iso(now),
    }


def claim_due_automation_v2_jobs(db: dict[str, Any], *, limit: int = 20) -> list[dict[str, Any]]:
    from modules.management_suite import automation_settings
    if not automation_settings(db).get("enabled",True):return []
    now = utc_now()
    rows: list[dict[str, Any]] = []
    for row in db.setdefault("automation_v2_jobs", {}).values():
        if not isinstance(row, dict) or row.get("kind") != "webhook":
            continue
        rule=db.get('automation_rules_v2',{}).get(str(row.get('rule_id') or ''))
        if rule and (not rule.get('enabled') or rule.get('deleted_at')):continue
        status = str(row.get("status") or "pending")
        if status not in {"pending", "retry", "processing"}:
            continue
        claimed = parse_dt(row.get("claimed_at"))
        if status == "processing" and claimed and (now - claimed).total_seconds() < _CLAIM_TTL_SECONDS:
            continue
        due = parse_dt(row.get("next_attempt_at")) or now
        if due > now:
            continue
        rows.append(row)
    rows.sort(key=lambda item: (str(item.get("next_attempt_at") or ""), str(item.get("id") or "")))
    claimed_rows: list[dict[str, Any]] = []
    for row in rows[: max(1, min(int(limit), 100))]:
        row["status"] = "processing"
        row["claimed_at"] = utc_iso(now)
        row["attempts"] = int(row.get("attempts", 0) or 0) + 1
        row["updated_at"] = utc_iso(now)
        claimed_rows.append(copy.deepcopy(row))
    return claimed_rows


def mark_automation_v2_job_result(
    db: dict[str, Any], job_id: str, *, success: bool, status_code: int = 0, detail: str = "",
) -> dict[str, Any]:
    row = db.setdefault("automation_v2_jobs", {}).get(str(job_id))
    if not isinstance(row, dict):
        raise ValueError("AUTOMATION_JOB_NOT_FOUND")
    row["claimed_at"] = None
    row["updated_at"] = utc_iso()
    row["last_status_code"] = int(status_code or 0)
    row["last_error"] = str(detail or "")[:1000]
    if success:
        row["status"] = "completed"
        row["completed_at"] = row["updated_at"]
        row["next_attempt_at"] = None
        return row
    attempts = int(row.get("attempts", 0) or 0)
    maximum = max(1, int(row.get("max_attempts", 4) or 4))
    if attempts >= maximum:
        row["status"] = "dead_letter"
        row["next_attempt_at"] = None
        db.setdefault("automation_v2_dead_letter", []).append(copy.deepcopy(row))
        db["automation_v2_dead_letter"] = db["automation_v2_dead_letter"][-5000:]
    else:
        delay = min(30 * (2 ** max(attempts - 1, 0)), 3600)
        row["status"] = "retry"
        row["next_attempt_at"] = utc_iso(utc_now() + timedelta(seconds=delay))
    return row


def _resolve_public_addresses(host: str) -> list[str]:
    results = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    addresses = sorted({str(item[4][0]) for item in results if item and item[4]})
    if not addresses:
        raise ValueError("AUTOMATION_WEBHOOK_DNS_EMPTY")
    for value in addresses:
        address = ipaddress.ip_address(value)
        if address.is_private or address.is_loopback or address.is_link_local or address.is_reserved or address.is_multicast:
            raise ValueError("AUTOMATION_WEBHOOK_PRIVATE_ADDRESS_BLOCKED")
    return addresses


async def _deliver_webhook(row: dict[str, Any], client: httpx.AsyncClient) -> tuple[bool, int, str]:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    url = _validate_webhook_url(payload.get("url"))
    parsed = urlparse(url)
    await run_blocking(_resolve_public_addresses, str(parsed.hostname or ""))
    method = str(payload.get("method") or "POST").upper()
    body = payload.get("body") if isinstance(payload.get("body"), (dict, list, str, int, float, bool)) else {}
    headers = {
        str(key)[:80]: str(value)[:1000]
        for key, value in (payload.get("headers") or {}).items()
        if isinstance(payload.get("headers"), dict)
        and str(key).lower() not in {"host", "content-length", "connection", "transfer-encoding"}
    }
    try:
        async with client.stream(method, url, json=body, headers=headers) as response:
            preview = bytearray()
            async for chunk in response.aiter_bytes():
                if len(preview) < 8192:
                    preview.extend(chunk[: 8192 - len(preview)])
                if len(preview) >= 8192:
                    break
            success = 200 <= response.status_code < 300
            detail_text = bytes(preview).decode("utf-8", errors="replace")[:500]
            detail = "" if success else f"HTTP_{response.status_code}:{detail_text}"
            return success, response.status_code, detail
    except httpx.HTTPError as exc:
        return False, 0, f"{exc.__class__.__name__}:{str(exc)[:500]}"


async def deliver_automation_v2_jobs(*, limit: int = 20) -> dict[str, int]:
    rows = await async_with_db(lambda db: claim_due_automation_v2_jobs(db, limit=limit))
    counts = {"completed": 0, "failed": 0}
    timeout = httpx.Timeout(10.0, connect=5.0)
    limits = httpx.Limits(max_connections=10, max_keepalive_connections=5, keepalive_expiry=30.0)
    async with httpx.AsyncClient(timeout=timeout, limits=limits, follow_redirects=False, trust_env=False) as client:
        for row in rows:
            success, status_code, detail = await _deliver_webhook(row, client)
            await async_with_db(lambda db, row_id=str(row["id"]), ok=success, code=status_code, msg=detail: mark_automation_v2_job_result(
                db, row_id, success=ok, status_code=code, detail=msg,
            ))
            counts["completed" if success else "failed"] += 1
    return counts


def run_ai_ad_asset_cleanup_cycle(db: dict[str, Any]) -> dict[str, Any]:
    now = utc_now()
    watermarks = db.setdefault("automation_v2_schedule_watermarks", {})
    last = parse_dt(watermarks.get("ai_ad_asset_cleanup"))
    if last and (now - last).total_seconds() < 3600:
        return {"skipped": True, "last_run_at": utc_iso(last)}
    from modules.gemini_ads import cleanup_generated_ad_assets

    result = cleanup_generated_ad_assets(db, now=now)
    watermarks["ai_ad_asset_cleanup"] = utc_iso(now)
    db.setdefault("automation_v2_audit", []).append({
        "action": "ai_ad_asset_cleanup", "result": dict(result), "created_at": utc_iso(now),
    })
    db["automation_v2_audit"] = db["automation_v2_audit"][-5000:]
    return {"skipped": False, **result}


async def automation_v2_runtime_job(_context: Any = None) -> None:
    try:
        await async_with_db(run_scheduled_automation_cycle)
    except Exception:
        logger.exception("Automation V2 scheduled cycle failed")
    try:
        await deliver_automation_v2_jobs(limit=20)
    except Exception:
        logger.exception("Automation V2 job delivery failed")
    try:
        await async_with_db(run_ai_ad_asset_cleanup_cycle)
    except Exception:
        logger.exception("AI advertisement asset cleanup failed")
