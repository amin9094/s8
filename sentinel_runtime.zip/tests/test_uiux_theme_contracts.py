from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _calls(path: Path, name: str) -> list[ast.Call]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == name
    ]


def _literal_keyword(call: ast.Call, keyword: str):
    for item in call.keywords:
        if item.arg == keyword and isinstance(item.value, ast.Constant):
            return item.value.value
    return None


def test_command_menu_replaces_reply_keyboard_and_message_menu_is_categorized() -> None:
    source = (ROOT / "bot_runtime" / "navigation.py").read_text(encoding="utf-8")
    assert "return [[" in source
    assert "ReplyKeyboardRemove(selective=True)" in source
    assert "ReplyKeyboardMarkup(" not in source
    assert "sentinel_command_menu_v1" in source
    assert 'callback_data="u_vip"' in source
    assert 'callback_data="u_account"' in source
    assert 'callback_data="nav_user:trade"' in source
    main_menu_source = ast.get_source_segment(
        source,
        next(
            node
            for node in ast.parse(source).body
            if isinstance(node, ast.FunctionDef) and node.name == "main_menu"
        ),
    )
    assert 'callback_data="account_rewards"' not in main_menu_source
    assert 'callback_data="cancel_current"' not in main_menu_source


def test_admin_toggle_panels_use_state_button() -> None:
    required = {
        ROOT / "bot_runtime" / "analytics_governance.py": 8,
        ROOT / "bot_runtime" / "market_data.py": 4,
        ROOT / "bot_runtime" / "growth_campaigns.py": 4,
        ROOT / "bot_runtime" / "admin_operations.py": 4,
        ROOT / "bot_runtime" / "runtime_jobs.py": 3,
    }
    for path, minimum in required.items():
        assert len(_calls(path, "state_button")) >= minimum, path
    # Category browsing controls were removed. Check the actual module switch
    # instead of counting calls in the obsolete intermediary panel.
    import bot  # noqa: F401 -- initialize the feature facade
    from bot_runtime.navigation import _control_module_rows
    from modules.admin_control_center import set_control_value
    db = {}
    for key in ("signals", "market_v2", "crm", "subscriptions", "edu", "automation", "security"):
        for enabled in (True, False):
            set_control_value(db, key, "enabled", enabled, 1)
            button = next(b for row in _control_module_rows(key, db) for b in row
                          if b.callback_data == f"ecc_bool:{key}:enabled")
            assert button.style == ("success" if enabled else "danger")
            assert button.text.endswith("روشن" if enabled else "خاموش")


def test_no_literal_ambiguous_toggle_buttons_remain() -> None:
    offenders: list[str] = []
    for path in [*ROOT.glob("bot_runtime/*.py"), *ROOT.glob("modules/*.py")]:
        for call in _calls(path, "InlineKeyboardButton"):
            if not call.args or not isinstance(call.args[0], ast.Constant):
                continue
            label = str(call.args[0].value or "")
            callback = str(_literal_keyword(call, "callback_data") or "")
            if any(marker in label for marker in ("روشن/خاموش", "فعال/غیرفعال")) and "a_miniapp_runtime" not in callback:
                offenders.append(f"{path.relative_to(ROOT)}:{call.lineno}:{label}")
    assert not offenders, offenders


def test_button_factory_has_native_fallback_and_state_contract() -> None:
    source = (ROOT / "ui" / "button_factory.py").read_text(encoding="utf-8")
    assert 'return "success"' in source
    assert 'return "danger"' in source
    assert 'return "primary"' in source
    assert "def state_button(" in source
    assert "remove_style=True" in source


def test_back_is_neutral_and_cancel_is_destructive() -> None:
    from ui.button_factory import InlineKeyboardButton, clone_button_with_text_and_callback
    back = InlineKeyboardButton("⬅️ Back", callback_data="u_rewards", style="danger")
    assert back.callback_data == "nb:u_rewards"
    assert back.style is None
    clone = clone_button_with_text_and_callback(back, "⬅️ Back", "nb:u_rewards")
    assert clone.style is None
    assert InlineKeyboardButton("✖️ Cancel", callback_data="cancel_current").style == "danger"


def test_final_user_palette_uses_real_style_contracts() -> None:
    from ui.button_factory import InlineKeyboardButton
    assert InlineKeyboardButton("VIP", callback_data="u_vip").style == "success"
    assert InlineKeyboardButton("Signals", callback_data="u_signal_portal").style == "primary"
    for callback in ("u_edu", "u_price", "u_calc", "nav_user:tools", "u_rewards"):
        assert InlineKeyboardButton("Browse", callback_data=callback, style="primary").style is None


def test_miniapp_vip_cta_uses_shared_success_palette() -> None:
    source = (ROOT / "webapp" / "src" / "styles.css").read_text(encoding="utf-8")
    assert 'button[data-open="vip"]' in source
    assert '#244d3d' in source and '#d6f8e4' in source


def test_miniapp_r32_refresh_separates_surfaces_from_background() -> None:
    source = (ROOT / "webapp" / "src" / "styles.css").read_text(encoding="utf-8")
    index = (ROOT / "webapp" / "index.html").read_text(encoding="utf-8")
    manifest = (ROOT / "webapp" / "manifest.webmanifest").read_text(encoding="utf-8")
    assert "R32 calm contrast refresh" in source
    assert "--bg:#071426" in source
    assert ".ambient-video-layer.active .ambient-video{opacity:.28}" in source
    assert "rgba(17,41,67,.97)" in source
    assert '<meta name="theme-color" content="#0c1525">' in index
    assert '"theme_color": "#0c1525"' in manifest
    assert '--bg:#0c1525' in source
    assert '.user-menu-grid' in source
