from __future__ import annotations

from datetime import UTC, datetime

import pytest

from modules import ai_signal_lab
from modules.knowledge_index import build_index, search
from modules.market_data import MarketRange


def test_hybrid_knowledge_index_versions_sources_and_returns_citations() -> None:
    index = build_index([
        {"source": "risk-policy", "version": "2.1", "status": "approved", "text": "پس از دو استاپ متوالی، ارسال سیگنال سه ساعت متوقف شود."},
        {"source": "draft-secret", "version": "1", "status": "draft", "text": "این متن نباید وارد پاسخ شود."},
    ])
    assert index["schema_version"] == 3
    assert index["source_count"] == 1
    rows = search(index, "توقف بعد از ضررهای پشت سر هم", limit=5)
    assert rows and rows[0]["source"] == "risk-policy"
    assert rows[0]["source_version"] == "2.1"
    assert str(rows[0]["citation"]).startswith("KB:")
    assert "semantic" in rows[0]["score_breakdown"]


@pytest.mark.asyncio
async def test_signal_lab_is_shadow_only_and_never_publishes(monkeypatch: pytest.MonkeyPatch) -> None:
    state: dict = {"ai_signal_lab": {"strategies": [], "runs": [], "candidates": [], "next_strategy_id": 1, "next_run_id": 1, "next_candidate_id": 1}}
    monkeypatch.setattr(ai_signal_lab, "with_db", lambda fn: fn(state))
    strategy = ai_signal_lab.create_strategy_version(
        state, name="Gold Momentum", rules={"minimum_rr": 2, "buy_close_position": 0.6}, actor_id=1, status="shadow",
    )
    run = ai_signal_lab.queue_shadow_scan(state, strategy_id=strategy["id"], symbols=["XAUUSD"], actor_id=1, timeframes=["15m", "1h"])

    async def fetcher(symbol: str, *, interval: str, limit: int, snapshot_fallback: bool) -> MarketRange:
        assert snapshot_fallback is False
        return MarketRange(
            symbol=symbol, low=100, high=110, close=109,
            opened_at=datetime(2026, 7, 28, 10, tzinfo=UTC).isoformat(),
            closed_at=datetime(2026, 7, 28, 11, tzinfo=UTC).isoformat(),
            source="test", interval=interval, confidence=1.0,
        )

    result = await ai_signal_lab.process_shadow_scan(run["id"], fetcher=fetcher)
    assert result["run"]["status"] == "completed"
    assert len(result["candidates"]) == 1
    candidate = result["candidates"][0]
    assert candidate["status"] == "shadow_draft"
    assert candidate["publication_allowed"] is False
    assert candidate["requires_admin_entry_stop_targets_confirmation"] is True
    assert state.get("scheduled_signals", []) == []
    assert state.get("signals", []) == []


@pytest.mark.asyncio
async def test_pending_shadow_scan_records_failure_after_exception_scope(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from core import db as core_db

    state = {
        "ai_signal_lab": {
            "runs": [{"id": 7, "status": "pending"}],
            "strategies": [],
            "candidates": [],
        }
    }
    monkeypatch.setattr(core_db, "read_db_sections", lambda sections: state)
    monkeypatch.setattr(ai_signal_lab, "with_db", lambda fn: fn(state))

    async def fail_scan(run_id: int, *, fetcher) -> dict:
        raise ValueError(f"bad scan {run_id}")

    monkeypatch.setattr(ai_signal_lab, "process_shadow_scan", fail_scan)
    assert await ai_signal_lab.process_pending_shadow_scans(limit=1) == []
    run = state["ai_signal_lab"]["runs"][0]
    assert run["status"] == "failed"
    assert run["error"] == "ValueError"
    assert run["detail"] == "bad scan 7"


def test_ai_queue_claim_is_atomic_and_human_only(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import ai_control_service

    state = {"ai_admin_command_queue": [{"id": 7, "status": "pending_primary_approval", "action": "ticket_admin_reply", "payload": {}}]}
    monkeypatch.setattr(ai_control_service, "is_primary_admin", lambda actor: int(actor) == 1)
    monkeypatch.setattr(ai_control_service, "with_db", lambda fn: fn(state))
    with pytest.raises(PermissionError, match="HUMAN_CONFIRMATION_REQUIRED"):
        ai_control_service._claim_queued_ai_command(7, 1, source="gemini_primary_autonomous")
    first = ai_control_service._claim_queued_ai_command(7, 1, source="telegram_callback")
    assert first["status"] == "executing"
    with pytest.raises(ValueError, match="ALREADY_RESOLVED"):
        ai_control_service._claim_queued_ai_command(7, 1, source="telegram_callback")


def test_reversible_batch_restores_snapshot_on_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    from modules import ai_undo

    state = {"announcements": [{"id": 1}], "publisher_channels": [], "security_audit_log": []}
    monkeypatch.setattr(ai_undo, "with_db", lambda fn: fn(state))
    snapshot = ai_undo.create_undo_snapshot(1, ["miniapp_announcement_publish"])
    state["announcements"].append({"id": 2})
    restored = ai_undo.restore_undo_snapshot(snapshot["token"], 1, automatic=True)
    assert restored["status"] == "restored"
    assert state["announcements"] == [{"id": 1}]


def test_shadow_candidate_promotion_creates_human_review_not_publication(monkeypatch: pytest.MonkeyPatch) -> None:
    state: dict = {
        "ai_signal_lab": {
            "candidates": [{
                "id": 9, "status": "shadow_draft", "symbol": "XAUUSD", "side": "BUY",
                "entry": 2400.0, "stop": 2390.0, "targets": [2420.0, 2430.0],
                "risk_reward": 2.0, "publication_allowed": False,
            }],
        },
        "signal_approvals": [],
    }
    result = ai_signal_lab.promote_candidate_to_review(
        state, candidate_id=9, actor_id=354678485, target="public",
    )
    assert result["candidate"]["status"] == "admin_review"
    approval = result["approval"]
    assert approval["status"] == "pending"
    assert approval["source"] == "gemini_signal_lab"
    assert set(approval["review_requirements"]) == {"entry", "stop", "targets"}
    assert state.get("signals", []) == []
    assert state.get("scheduled_signals", []) == []
