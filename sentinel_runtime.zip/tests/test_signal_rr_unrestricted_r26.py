from __future__ import annotations

from modules.admin_control_center import ensure_control_center
from modules.signal import normalize_signal_risk, validate_signal_levels
from modules.signal_safety import evaluate_signal_safety
from modules.signal_team_rules import team_rules, update_team_rules


def _low_rr_payload() -> dict[str, object]:
    return {
        "symbol": "XAUUSD",
        "side": "buy",
        "entries": ["100"],
        "entry": "100",
        "targets": ["100.25"],
        "stop": "99",
        "risk": "1",
        "market_category": "forex",
    }


def test_low_rr_never_blocks_signal_publication_even_with_stale_high_limits() -> None:
    db: dict = {}
    ensure_control_center(db)
    # Simulate a production database that still contains old R/R values.
    db["enterprise_control"]["modules"]["signals"]["min_rr"] = 20
    db["signal_team_rules"] = {"minimum_rr": 50}

    report = evaluate_signal_safety(db, _low_rr_payload(), calendar_events=[])

    assert report.ok is True
    assert report.metrics["rr"] == 0.25
    assert report.metrics["rr_enforced"] is False
    assert report.metrics["rr_policy"] == "informational_only"
    assert not any("ریسک‌به‌ریوارد" in error or "R/R" in error for error in report.errors)


def test_legacy_minimum_rr_updates_are_normalized_to_disabled() -> None:
    db: dict = {}
    result = update_team_rules(db, 1, {"minimum_rr": 12})
    assert result["minimum_rr"] == 0.0
    assert team_rules(db)["minimum_rr"] == 0.0


def test_directional_level_validation_remains_active_after_rr_gate_removal() -> None:
    # Removing the minimum R/R threshold must not permit targets or stops on
    # the wrong side of the entry.
    try:
        validate_signal_levels("100", ["99"], "98", "buy")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid BUY target direction was accepted")


def test_admin_signal_risk_and_publication_policy_have_no_numeric_ceiling() -> None:
    assert normalize_signal_risk("250.125%") == "250.125"

    db: dict = {}
    ensure_control_center(db)
    controls = db["enterprise_control"]["modules"]["signals"]
    controls.update({
        "max_risk_percent": 0.1,
        "max_open": 1,
        "max_same_symbol_open": 1,
        "block_opposite": True,
        "exposure_guard": True,
        "correlation_guard": True,
        "max_total_open_risk": 0.1,
        "max_market_open_risk": 0.1,
        "max_symbol_open_risk": 0.1,
        "max_correlated_risk": 0.1,
        "max_daily_new_risk": 0.1,
    })
    db["signal_team_rules"] = {
        "enabled": True,
        "max_daily_signals": 1,
        "max_weekly_signals": 1,
        "max_daily_forex": 1,
        "max_consecutive_stops": 1,
        "cooldown_minutes": 9999,
        "max_daily_loss_r": 0.1,
    }
    db["signals"] = [
        {
            "id": 1, "symbol": "XAUUSD", "side": "sell", "status": "open",
            "risk": "50", "created_at": "2026-07-28T10:00:00+00:00",
            "market_category": "forex",
        },
        {
            "id": 2, "symbol": "EURUSD", "side": "buy", "status": "open",
            "risk": "50", "created_at": "2026-07-28T10:05:00+00:00",
            "market_category": "forex",
        },
        {
            "id": 3, "symbol": "GBPUSD", "side": "buy", "status": "open",
            "risk": "50", "created_at": "2026-07-28T10:10:00+00:00",
            "market_category": "forex",
        },
    ]
    payload = {
        "symbol": "XAUUSD", "side": "buy", "entries": ["100"], "entry": "100",
        "targets": ["110"], "stop": "90", "risk": "250.125", "market_category": "forex",
    }
    report = evaluate_signal_safety(db, payload, calendar_events=[])
    assert report.ok is True
    assert report.errors == ()
    assert report.metrics["publication_limits_enforced"] is False
    assert report.metrics["risk_percent"] == 250.125
    assert report.metrics["active_signals"] == 3
    assert report.metrics["same_symbol_open"] == 1
