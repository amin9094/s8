from __future__ import annotations

from pathlib import Path

import pytest

from modules import admin_access as access
from services.actions_v2 import action_specs

ROOT = Path(__file__).resolve().parents[1]
DELEGATED_ID = "987654321"
OWNER_ID = "123456789"


def _db(permissions=()):
    return {
        "delegated_admins": {
            DELEGATED_ID: {
                "user_id": int(DELEGATED_ID),
                "permissions": list(permissions),
                "active": True,
                "approval_status": "approved",
                "created_by": OWNER_ID,
                "created_at": "2026-08-03T00:00:00+00:00",
                "updated_at": "2026-08-03T00:00:00+00:00",
            }
        }
    }


def test_r27_permission_catalog_is_unique_labeled_and_grouped() -> None:
    values = tuple(access.ALL_PERMISSIONS)
    assert len(values) == len(set(values))
    assert len(values) >= 160
    assert set(values) <= set(access.PERMISSION_LABELS)
    assert set(values) <= set(access.PERMISSION_SHORT_LABELS)
    grouped = {item for _label, items in access.PERMISSION_GROUPS.values() for item in items}
    assert set(values) <= grouped
    assert access.OWNER_ONLY_PERMISSIONS <= set(values)


def test_role_presets_are_least_privilege_and_persist_across_normalization() -> None:
    assert set(access.ADMIN_ROLE_PRESETS) == {
        "signal_analyst", "signal_manager", "support_operator",
        "finance_manager", "content_manager", "read_only_auditor",
    }
    for spec in access.ADMIN_ROLE_PRESETS.values():
        permissions = tuple(spec["permissions"])
        assert permissions
        assert not set(permissions).intersection(access.OWNER_ONLY_PERMISSIONS)
        assert set(permissions) <= set(access.ALL_PERMISSIONS)

    db = _db()
    row = access.apply_admin_role_preset(db, DELEGATED_ID, "support_operator", OWNER_ID)
    assert row["role_preset"] == "support_operator"
    assert access.has_permission(db, DELEGATED_ID, access.PERMISSION_TICKETS_REPLY)
    assert not access.has_permission(db, DELEGATED_ID, access.PERMISSION_USER_BAN_MANAGE)

    access.normalize_delegated_admins(db)
    normalized = access.get_delegated_admin(db, DELEGATED_ID)
    assert normalized and normalized["role_preset"] == "support_operator"
    assert normalized["role_preset_label"] == "اپراتور پشتیبانی"


def test_manual_permission_edit_clears_stale_role_name() -> None:
    db = _db()
    access.apply_admin_role_preset(db, DELEGATED_ID, "read_only_auditor", OWNER_ID)
    row = access.set_permissions(db, DELEGATED_ID, [access.PERMISSION_USERS_VIEW], OWNER_ID)
    assert "role_preset" not in row
    assert row["permissions"] == [access.PERMISSION_USERS_VIEW]


def test_legacy_broad_permissions_expand_and_toggle_off_atomically() -> None:
    db = _db()
    row = access.set_permissions(db, DELEGATED_ID, [access.PERMISSION_TICKETS], OWNER_ID)
    assert access.PERMISSION_TICKETS in row["permissions"]
    for child in access.LEGACY_PERMISSION_CHILDREN[access.PERMISSION_TICKETS]:
        assert child in row["permissions"]
        assert access.has_permission(db, DELEGATED_ID, child)

    row = access.toggle_permission(db, DELEGATED_ID, access.PERMISSION_TICKETS, OWNER_ID)
    assert access.PERMISSION_TICKETS not in row["permissions"]
    assert not set(access.LEGACY_PERMISSION_CHILDREN[access.PERMISSION_TICKETS]).intersection(row["permissions"])


def test_owner_only_permissions_cannot_be_delegated() -> None:
    db = _db()
    row = access.set_permissions(
        db,
        DELEGATED_ID,
        [access.PERMISSION_USERS_VIEW, access.PERMISSION_BACKUP_RESTORE, access.PERMISSION_API_CREDENTIALS_MANAGE],
        OWNER_ID,
    )
    assert row["permissions"] == [access.PERMISSION_USERS_VIEW]
    assert not access.has_permission(db, DELEGATED_ID, access.PERMISSION_BACKUP_RESTORE)
    with pytest.raises(PermissionError, match="PRIMARY_ADMIN_ONLY_PERMISSION"):
        access.toggle_permission(db, DELEGATED_ID, access.PERMISSION_BACKUP_RESTORE, OWNER_ID)


def test_miniapp_action_registry_uses_granular_permissions() -> None:
    specs = action_specs()
    expected = {
        "admin_user_ban": access.PERMISSION_USER_BAN_MANAGE,
        "admin_user_unban": access.PERMISSION_USER_BAN_MANAGE,
        "signal_result_set": access.PERMISSION_SIGNAL_STATUS_MANAGE,
        "signal_result_reset": access.PERMISSION_SIGNAL_STATUS_MANAGE,
        "miniapp_signal_publish": access.PERMISSION_SIGNAL_PUBLISH_NOW,
        "signal_job_retry": access.PERMISSION_SIGNAL_SCHEDULE,
        "signal_cycle_start": access.PERMISSION_SIGNAL_BOARD_MANAGE,
        "ticket_admin_reply": access.PERMISSION_TICKETS_REPLY,
        "ticket_admin_assign": access.PERMISSION_TICKETS_ASSIGN,
        "ticket_admin_status_update": access.PERMISSION_TICKETS_STATUS_MANAGE,
        "ticket_admin_priority_update": access.PERMISSION_TICKETS_PRIORITY_MANAGE,
        "ticket_admin_internal_note": access.PERMISSION_TICKET_INTERNAL_NOTES,
        "miniapp_announcement_publish": access.PERMISSION_ANNOUNCEMENT_PUBLISH,
        "delegated_admin_role_preset": access.PERMISSION_ADMIN_MANAGEMENT,
    }
    for name, permission in expected.items():
        assert specs[name].permission == permission, name


def test_telegram_and_miniapp_expose_role_presets_and_owner_locks() -> None:
    telegram = (ROOT / "bot_runtime" / "crm_content.py").read_text(encoding="utf-8")
    routes = (ROOT / "handlers" / "callback_routes.py").read_text(encoding="utf-8")
    miniapp = (ROOT / "webapp" / "src" / "admin-parity.js").read_text(encoding="utf-8")
    read_service = (ROOT / "services" / "miniapp_read_service_v2.py").read_text(encoding="utf-8")
    assert "admin_role_preset_handler" in telegram
    assert "admin_role:" in telegram and "admin_role_preset_handler" in routes
    assert "OWNER_ONLY_PERMISSIONS" in telegram
    assert "data-admin-role-preview" in miniapp
    assert "delegated_admin_role_preset" in miniapp
    assert "owner_only" in miniapp and "owner_only" in read_service
    assert '"role_presets"' in read_service


def test_granular_roles_surface_correct_telegram_menu_centers() -> None:
    navigation = (ROOT / "bot_runtime" / "navigation.py").read_text(encoding="utf-8")
    expected = {
        '"a_signal", PERMISSION_SIGNAL_SCHEDULE': "signal analyst menu",
        '"a_signal_results", PERMISSION_SIGNALS_VIEW': "signal view menu",
        '"a_edu", PERMISSION_EDUCATION_VIEW': "education menu",
        '"a_contest", PERMISSION_CONTEST_VIEW': "contest menu",
        '"a_missions", PERMISSION_MISSION_VIEW': "missions menu",
        '"a_tickets", PERMISSION_TICKETS_VIEW': "tickets menu",
        '"a_users", PERMISSION_USERS_VIEW': "users menu",
        '"a_crm", PERMISSION_CRM_VIEW': "CRM menu",
        '"a_provider_health", PERMISSION_INTEGRATION_HEALTH_VIEW': "health menu",
        '"a_miniapp_runtime", PERMISSION_MAINTENANCE_MODE_MANAGE': "maintenance menu",
    }
    for needle, label in expected.items():
        assert needle in navigation, label


def test_price_and_reward_mutations_have_secondary_permission_guards() -> None:
    from bot_runtime.admin_operations import _education_pricing_changed, _mission_rewards_changed

    assert not _education_pricing_changed(None, "free", 0)
    assert _education_pricing_changed(None, "paid", 100_000)
    assert not _education_pricing_changed({"access_type": "paid", "price": 100_000}, "paid", 100_000)
    assert _education_pricing_changed({"access_type": "paid", "price": 100_000}, "paid", 120_000)

    assert not _mission_rewards_changed(None, {"reward": 0, "random_bonus_max": 0})
    assert _mission_rewards_changed(None, {"reward": 10, "random_bonus_max": 0})
    assert not _mission_rewards_changed(
        {"reward": 10, "random_bonus_max": 5}, {"reward": 10, "random_bonus_max": 5}
    )
    assert _mission_rewards_changed(
        {"reward": 10, "random_bonus_max": 5}, {"reward": 20, "random_bonus_max": 5}
    )


def test_ai_mutations_cannot_bypass_price_reward_or_publish_permissions() -> None:
    source = (ROOT / "services" / "actions_v2" / "ai.py").read_text(encoding="utf-8")
    assert "_require(ctx, PERMISSION_EDUCATION_PRICE_MANAGE)" in source
    assert "_require(ctx, PERMISSION_EDUCATION_PUBLISH)" in source
    assert "_require(ctx, PERMISSION_MISSION_REWARD_MANAGE)" in source
    assert "_require(ctx, PERMISSION_MISSION_PUBLISH)" in source


def test_runtime_logs_crm_export_and_channel_operations_are_wired() -> None:
    navigation = (ROOT / "bot_runtime" / "navigation.py").read_text(encoding="utf-8")
    routes = (ROOT / "handlers" / "callback_routes.py").read_text(encoding="utf-8")
    admin_ops = (ROOT / "bot_runtime" / "admin_operations.py").read_text(encoding="utf-8")
    crm = (ROOT / "bot_runtime" / "crm_content.py").read_text(encoding="utf-8")
    ai = (ROOT / "services" / "actions_v2" / "ai.py").read_text(encoding="utf-8")

    assert '"a_runtime_logs", PERMISSION_RUNTIME_LOGS_VIEW' in navigation
    assert "a_runtime_logs" in routes and "PERMISSION_RUNTIME_LOGS_VIEW" in admin_ops
    assert "PERMISSION_CRM_EXPORT, PERMISSION_EXPORT_CSV" in crm
    assert '"a_export_csv", PERMISSION_CRM_EXPORT' in navigation
    assert "PERMISSION_CHANNEL_POSTS_EDIT" in ai
    assert "PERMISSION_CHANNEL_POSTS_DELETE" in ai
    assert "PERMISSION_CHANNEL_PIN_MANAGE" in ai
