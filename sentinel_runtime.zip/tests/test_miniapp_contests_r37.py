from __future__ import annotations

import copy
from pathlib import Path
from types import SimpleNamespace

import pytest

from core.webapp_auth import TelegramWebAppIdentity
from services import miniapp_read_service_v2 as read
from services.actions_v2 import contests as actions

ROOT = Path(__file__).resolve().parents[1]


def identity(uid: int = 42) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(uid, "user", "First", "Last", 1, "q")


def active_db() -> dict:
    return {
        "contests": [{
            "id": "price_1", "type": "price", "status": "active", "active": True,
            "symbol": "XAUUSD", "question": "قیمت طلا؟", "ends_at": "2999-01-01T00:00:00+00:00",
            "participants": {"99": {"guess": 3000, "submitted_at": "2026-01-01T00:00:00+00:00"}},
            "reward_points": 5, "photo_file_id": "tg-price-photo",
        }],
        "chart_contest": {
            "id": "chart_1", "status": "active", "active": True, "question": "جهت؟",
            "ends_at": "2999-01-01T00:00:00+00:00", "answers": {}, "reward_points": 7,
            "photo_file_id": "tg-chart-photo",
        },
        "candle_contest": {
            "id": "candle_1", "status": "active", "active": True, "question": "کلوز؟",
            "ends_at": "2999-01-01T00:00:00+00:00", "answers": {"42": {"guess": 2450, "submitted_at": "2026-01-01T00:00:00+00:00"}},
            "reward_by_rank": {"1": 10, "2": 7, "3": 5, "4": 3},
        },
        "news_direction_contest": {
            "id": "news_1", "type": "news_direction", "status": "active", "active": True,
            "news_name": "NFP", "ends_at": "2999-01-01T00:00:00+00:00", "answers": {}, "reward_points": 6,
        },
        "contest_history": [{
            "id": "chart_old", "type": "chart", "status": "closed", "question": "قدیمی",
            "answers": {"42": {"choice": "UP"}, "99": {"choice": "DOWN"}},
            "winners": ["42"], "reward_points": 9, "answer": "UP", "closed_at": "2026-01-02T00:00:00+00:00",
        }],
        "admin_control_center": {},
    }


def test_read_snapshot_lists_all_active_contest_types_without_leaking_other_answers(monkeypatch) -> None:
    db = active_db()
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: copy.deepcopy(db))
    result = read.contests(identity())
    assert {row["kind"] for row in result["items"]} == {"price", "chart", "candle", "news_direction"}
    price = next(row for row in result["items"] if row["kind"] == "price")
    candle = next(row for row in result["items"] if row["kind"] == "candle")
    assert price["participants_count"] == 1
    assert price["participated"] is False
    assert "participants" not in price and "answers" not in price
    assert price["image_url"] == "./api/v1/contests/price/image"
    assert candle["participated"] is True and candle["my_answer"] == 2450
    assert result["recent_results"][0]["won"] is True
    assert result["recent_results"][0]["points"] == 9


def test_contest_image_file_id_only_returns_active_supported_media(monkeypatch) -> None:
    db = active_db()
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: copy.deepcopy(db))
    assert read.contest_image_file_id(identity(), "price") == "tg-price-photo"
    assert read.contest_image_file_id(identity(), "chart") == "tg-chart-photo"
    assert read.contest_image_file_id(identity(), "candle") == ""


def test_miniapp_contest_submit_uses_same_contest_store_and_duplicate_semantics(monkeypatch) -> None:
    db = active_db()
    monkeypatch.setattr(actions, "with_db", lambda operation: operation(db))
    ctx = SimpleNamespace(user_id="42", payload={"kind": "chart", "answer": "UP"})
    result = actions.contest_submit(ctx)
    assert result == {"kind": "chart", "result": "OK", "accepted": True}
    assert db["chart_contest"]["answers"]["42"]["choice"] == "UP"
    second = actions.contest_submit(ctx)
    assert second["result"] == "ALREADY" and second["accepted"] is False


def test_miniapp_numeric_contest_rejects_nonpositive_answers(monkeypatch) -> None:
    db = active_db()
    monkeypatch.setattr(actions, "with_db", lambda operation: operation(db))
    with pytest.raises(ValueError, match="CONTEST_ANSWER_INVALID"):
        actions.contest_submit(SimpleNamespace(user_id="42", payload={"kind": "price", "answer": 0}))


def test_frontend_and_server_contest_contract_is_wired() -> None:
    core = (ROOT / "webapp/src/core.js").read_text(encoding="utf-8")
    experience = (ROOT / "webapp/src/experience-v2.js").read_text(encoding="utf-8")
    contests = (ROOT / "webapp/src/contests.js").read_text(encoding="utf-8")
    server = (ROOT / "core/miniapp_server.py").read_text(encoding="utf-8")
    build = (ROOT / "scripts/build_webapp_assets.py").read_text(encoding="utf-8")
    assert "contests: './api/v1/contests'" in core
    assert "sentinelService('trophy', 'مسابقه‌ها'" in experience
    assert "target === 'contests'" in experience
    assert "action('contest_submit'" in contests
    assert "data-contest-submit" in contests
    assert '@app.get("/api/v1/contests")' in server
    assert '@app.get("/api/v1/contests/{kind}/image")' in server
    assert '"contests.js"' in build
