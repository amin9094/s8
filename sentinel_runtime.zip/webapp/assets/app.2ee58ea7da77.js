(()=>{'use strict';
const APP_VERSION = '8.44.1';
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
let tg = window.Telegram?.WebApp;
const state = { lang: ['fa', 'en'].includes(localStorage.getItem('sentinelLanguage')) ? localStorage.getItem('sentinelLanguage') : 'fa', page: 'home', pageHistory: [], csrf: '', preview: false, online: false, busy: 0, modalReturn: null, modalSubmit: null, mainButtonHandler: null, telegramNavigationInstalled: false, telegramBackMode: 'none', resources: {}, loaded: new Set(), signalFilter: 'all', signalAccessFilter: 'all', signalQuery: '', feedFilter: 'all', tradeHubTab: 'overview', journalFilter: 'all', journalQuery: '', orderFilter: 'all', ticketFilter: 'all', selectedAccount: null, eventSource: null, eventReconnectTimer: null, eventFailureCount: 0, pollTimer: null, livePriceTimer: null, adminSignalQuote: null, lastEventId: Number(sessionStorage.getItem('sentinelLastEventId') || 0), pageSize: 24 };
const resourceInflight = new Map(), actionInflight = new Map();
let overviewInflight = null;
const I18N = {
    fa: { home: 'خانه', signals: 'سیگنال‌ها', risk: 'ریسک', journal: 'ژورنال', more: 'بیشتر', welcome: 'خوش آمدید', member: 'عضو SENTINEL', secure: 'اتصال امن برقرار است', offline: 'اتصال قطع است', loading: 'در حال بارگذاری…', retry: 'تلاش مجدد', activeSignals: 'سیگنال فعال', openRisk: 'ریسک باز', dailyRisk: 'ریسک امروز', journalWin: 'برد ژورنال', decisionCenter: 'مرکز تصمیم سیگنال', riskOS: 'سیستم‌عامل ریسک', tradeJournal: 'ژورنال هوشمند', trust: 'شفافیت عملکرد', viewAll: 'مشاهده همه', details: 'جزئیات', execute: 'ثبت ورود واقعی', skip: 'رد کردن', watch: 'زیرنظر', late: 'ورود دیرهنگام', copy: 'کپی سطوح', account: 'حساب', entry: 'نقطه ورود', stop: 'حد ضرر', volume: 'حجم', riskPercent: 'درصد ریسک', confirmExecution: 'تأیید می‌کنم این اطلاعات اجرای واقعی معامله است', override: 'عبور آگاهانه از هشدار', overrideReason: 'دلیل عبور از هشدار', submit: 'ثبت', cancel: 'انصراف', close: 'بستن', save: 'ذخیره', addAccount: 'افزودن حساب', editAccount: 'ویرایش حساب', whatIf: 'شبیه‌ساز بدترین سناریو', correlation: 'تمرکز هم‌بستگی', positions: 'پوزیشن‌های باز', noData: 'اطلاعاتی برای نمایش وجود ندارد', market: 'مرکز بازار', calendar: 'تقویم اقتصادی', calendarSettings: 'تنظیمات تقویم', calendarAlerts: 'اعلان رویدادها', actualAlerts: 'اعلان نتیجه واقعی', currencies: 'ارزها', minImpact: 'حداقل اهمیت', reminderMinutes: 'یادآوری پیش از خبر', vip: 'اشتراک VIP', support: 'پشتیبانی', orders: 'سفارش‌ها', settings: 'تنظیمات', trackRecord: 'Verified Track Record', replay: 'بازپخش و کالبدشکافی', share: 'کارت اشتراک شفاف', marketRegime: 'رژیم بازار', onboarding: 'راه‌اندازی هوشمند', experience: 'سطح تجربه', goal: 'هدف اصلی', riskTolerance: 'تحمل ریسک', completeSetup: 'تکمیل راه‌اندازی', revisions: 'تغییرات سیگنال', success: 'عملیات با موفقیت انجام شد', error: 'خطایی رخ داد', positionOpened: 'معامله با ریسک واقعی ثبت شد', archived: 'رکورد بایگانی شد', newTrade: 'معامله دستی جدید', exportCsv: 'خروجی CSV', importCsv: 'ورود CSV', closeTrade: 'بستن معامله', partialClose: 'خروج بخشی', price: 'قیمت', updated: 'به‌روزرسانی', selectPlan: 'انتخاب پلن', paymentMethod: 'روش پرداخت', coupon: 'کد تخفیف', getQuote: 'دریافت مبلغ قطعی', uploadReceipt: 'بارگذاری رسید', transactionHash: 'TXID', payable: 'مبلغ قابل پرداخت', expires: 'اعتبار تا', createTicket: 'تیکت جدید', language: 'زبان', rules: 'قوانین', acceptRules: 'پذیرش قوانین', preview: 'حالت پیش‌نمایش', openFromTelegram: 'برای داده واقعی، مینی‌اپ را از تلگرام باز کنید.', searchSignals: 'جست‌وجوی نماد یا شماره سیگنال', all: 'همه', open: 'باز', closed: 'بسته', forex: 'فارکس', crypto: 'کریپتو', green: 'مجاز', yellow: 'احتیاط', red: 'غیرمجاز', copyDone: 'کپی شد', refreshDone: 'اطلاعات تازه شد', accountDisabled: 'برای محاسبه حجم، حساب و مدیریت ریسک را فعال کنید.', noSignals: 'سیگنالی مطابق فیلتر پیدا نشد.', costs: 'هزینه‌ها', behavior: 'تحلیل رفتاری', lateLossRate: 'نرخ زیان ورود دیرهنگام', slippage: 'میانگین انحراف ورود', safetyGate: 'دروازه ایمنی پیش از معامله', currentPrice: 'قیمت فعلی', distance: 'فاصله تا Entry', nearbyNews: 'اخبار نزدیک', history: 'تاریخچه تغییرات', evidenceHash: 'هش شواهد', ack: 'مشاهده و تأیید', status: 'وضعیت', reason: 'دلیل', name: 'نام', balance: 'موجودی', equity: 'اکویتی', timezone: 'منطقه زمانی', accountType: 'نوع حساب', personal: 'شخصی', propChallenge: 'چالش پراپ', propFunded: 'Funded', demo: 'دمو', maxDailyRisk: 'حداکثر ریسک روزانه', maxOpenRisk: 'حداکثر ریسک باز', dailyLoss: 'حد ضرر روزانه', totalLoss: 'حد ضرر کل', profitTarget: 'هدف سود', riskEnabled: 'مدیریت ریسک فعال', journalNote: 'یادداشت', setup: 'ستاپ', emotion: 'حالت روانی', tags: 'برچسب‌ها', pnlPercent: 'سود/زیان درصدی', pnlAmount: 'سود/زیان مبلغی', fees: 'کارمزد', commission: 'کمیسیون', swap: 'سواپ', exitPrice: 'قیمت خروج', file: 'فایل', ticketSubject: 'موضوع', message: 'پیام', priority: 'اولویت', logout: 'خروج از نشست', notAvailable: 'در دسترس نیست', globalSearch: 'جست‌وجوی سراسری', searchPlaceholder: 'سیگنال، سفارش، تیکت یا ژورنال را جست‌وجو کنید', notifications: 'مرکز اعلان هوشمند', resubmit: 'ارسال مجدد', orderDetails: 'جزئیات سفارش', brokerImport: 'ورود گزارش MT5/بروکر', todayActions: 'اقدام‌های امروز', maintenance: 'این قابلیت توسط مدیر غیرفعال شده است', appVersion: 'نسخه برنامه', currency: 'ارز', closeFraction: 'درصد بستن', symbol: 'نماد', side: 'جهت', sample: 'نمونه', winRate: 'نرخ برد', averageR: 'میانگین R', maxDrawdown: 'بیشترین افت', normal: 'عادی', high: 'مهم', accepted: 'پذیرفته شده', pending: 'در انتظار', adminConsole: 'کنسول عملیات مدیر', dailyBrief: 'گزارش روزانه عملیات', shiftHandoff: 'تحویل شیفت', experimentLab: 'آزمایشگاه رشد', newHandoff: 'تحویل شیفت جدید', newExperiment: 'آزمایش جدید', acknowledge: 'دریافت شد', complete: 'تکمیل', hypothesis: 'فرضیه', primaryMetric: 'شاخص اصلی', minimumSample: 'حداقل نمونه', reloadApp: 'بارگذاری نسخه جدید' },
    en: { home: 'Home', signals: 'Signals', risk: 'Risk', journal: 'Journal', more: 'More', welcome: 'Welcome', member: 'SENTINEL member', secure: 'Secure connection active', offline: 'Connection lost', loading: 'Loading…', retry: 'Retry', activeSignals: 'Active signals', openRisk: 'Open risk', dailyRisk: 'Today risk', journalWin: 'Journal win rate', decisionCenter: 'Signal Decision Center', riskOS: 'Personal Risk OS', tradeJournal: 'Smart Journal', trust: 'Verified Track Record', viewAll: 'View all', details: 'Details', execute: 'Confirm real execution', skip: 'Skip', watch: 'Watch', late: 'Late entry', copy: 'Copy levels', account: 'Account', entry: 'Entry', stop: 'Stop', volume: 'Volume', riskPercent: 'Risk percent', confirmExecution: 'I confirm these are my real execution details', override: 'Conscious risk override', overrideReason: 'Override reason', submit: 'Submit', cancel: 'Cancel', close: 'Close', save: 'Save', addAccount: 'Add account', editAccount: 'Edit account', whatIf: 'Worst-case simulator', correlation: 'Correlation concentration', positions: 'Open positions', noData: 'No data to display', market: 'Market Center', calendar: 'Economic Calendar', calendarSettings: 'Calendar settings', calendarAlerts: 'Event alerts', actualAlerts: 'Actual-result alerts', currencies: 'Currencies', minImpact: 'Minimum impact', reminderMinutes: 'Reminder before event', vip: 'VIP Subscription', support: 'Support', orders: 'Orders', settings: 'Settings', trackRecord: 'Verified Track Record', replay: 'Signal Replay & Post-Mortem', share: 'Transparent Share Card', marketRegime: 'Market Regime', onboarding: 'Smart Onboarding', experience: 'Experience level', goal: 'Primary goal', riskTolerance: 'Risk tolerance', completeSetup: 'Complete setup', revisions: 'Signal revisions', success: 'Done successfully', error: 'Something went wrong', positionOpened: 'Position recorded with actual risk', archived: 'Record archived', newTrade: 'New manual trade', exportCsv: 'Export CSV', importCsv: 'Import CSV', closeTrade: 'Close trade', partialClose: 'Partial close', price: 'Price', updated: 'Updated', selectPlan: 'Select plan', paymentMethod: 'Payment method', coupon: 'Coupon', getQuote: 'Get binding quote', uploadReceipt: 'Upload receipt', transactionHash: 'TXID', payable: 'Payable amount', expires: 'Expires', createTicket: 'New ticket', language: 'Language', rules: 'Rules', acceptRules: 'Accept rules', preview: 'Preview mode', openFromTelegram: 'Open the Mini App from Telegram for live data.', searchSignals: 'Search symbol or signal number', all: 'All', open: 'Open', closed: 'Closed', forex: 'Forex', crypto: 'Crypto', green: 'Allowed', yellow: 'Caution', red: 'Blocked', copyDone: 'Copied', refreshDone: 'Data refreshed', accountDisabled: 'Enable your account and risk settings to calculate position size.', noSignals: 'No signals match the selected filters.', costs: 'Costs', behavior: 'Behavioral review', lateLossRate: 'Late-entry loss rate', slippage: 'Average entry slippage', safetyGate: 'Pre-trade safety gate', currentPrice: 'Current price', distance: 'Distance to entry', nearbyNews: 'Nearby news', history: 'Revision history', evidenceHash: 'Evidence hash', ack: 'Acknowledge', status: 'Status', reason: 'Reason', name: 'Name', balance: 'Balance', equity: 'Equity', timezone: 'Timezone', accountType: 'Account type', personal: 'Personal', propChallenge: 'Prop challenge', propFunded: 'Prop funded', demo: 'Demo', maxDailyRisk: 'Max daily risk', maxOpenRisk: 'Max open risk', dailyLoss: 'Daily loss limit', totalLoss: 'Total loss limit', profitTarget: 'Profit target', riskEnabled: 'Risk management enabled', journalNote: 'Note', setup: 'Setup', emotion: 'Emotion', tags: 'Tags', pnlPercent: 'PnL percent', pnlAmount: 'PnL amount', fees: 'Fees', commission: 'Commission', swap: 'Swap', exitPrice: 'Exit price', file: 'File', ticketSubject: 'Subject', message: 'Message', priority: 'Priority', logout: 'Log out', notAvailable: 'Unavailable', globalSearch: 'Global search', searchPlaceholder: 'Search signals, orders, tickets or journal', notifications: 'Smart notification center', resubmit: 'Resubmit', orderDetails: 'Order details', brokerImport: 'Import MT5/broker statement', todayActions: 'Today actions', maintenance: 'This feature is disabled by the administrator.', appVersion: 'App version', currency: 'Currency', closeFraction: 'Close fraction', symbol: 'Symbol', side: 'Side', sample: 'Sample', winRate: 'Win rate', averageR: 'Average R', maxDrawdown: 'Max drawdown', normal: 'Normal', high: 'High', accepted: 'Accepted', pending: 'Pending', adminConsole: 'Admin Operations Console', dailyBrief: 'Daily operations brief', shiftHandoff: 'Shift handoff', experimentLab: 'Growth Experiment Lab', newHandoff: 'New handoff', newExperiment: 'New experiment', acknowledge: 'Acknowledge', complete: 'Complete', hypothesis: 'Hypothesis', primaryMetric: 'Primary metric', minimumSample: 'Minimum sample', reloadApp: 'Load new version' }
};
const t = k => I18N[state.lang]?.[k] ?? I18N.fa[k] ?? k;
const ui = (fa, en) => state.lang === 'fa' ? fa : en;
const UI_EN_EXACT = {
    "امتیاز کافی ندارید": "Not enough points",
    "تأیید دریافت جایزه": "Confirm reward claim",
    "در حال دریافت…": "Claiming\u2026",
    "دریافت جایزه": "Claim reward",
    "رزرو برای سفارش": "Reserved for order",
    "هزینه دریافت": "Redemption cost",
    "هنوز شروع نشده": "Not started yet",
    "کپی لینک یا کد": "Copy link or code",

    "میز معامله‌گری": "Trading workspace",
    "تصمیم روشن، ریسک مشخص، اجرای منظم.": "Clear decisions. Defined risk. Disciplined execution.",
    "نمای حساب": "Account overview",
    "ارزش حساب": "Account equity",
    "موجودی": "Balance",
    "ظرفیت ریسک امروز": "Daily risk capacity",
    "معامله باز": "Open positions",
    "رصد سیگنال‌ها": "Watch signals",
    "مرور ژورنال": "Review journal",
    "برنامه ریسک": "Risk plan",
    "ابزارهای روزانه": "Daily tools",
    "آخرین سیگنال‌ها": "Latest signals",
    "روند عملکرد": "Performance history",
    "پس از ثبت معاملات، روند واقعی عملکرد اینجا نمایش داده می‌شود.": "Your actual performance history appears here after trades are recorded.",
    "هنوز داده‌ای ثبت نشده": "No recorded data yet",
    "انتخاب یا افزودن حساب": "Select or add account",
    "داده در دسترس نیست": "Data unavailable",
    "براساس آخرین اطلاعات دریافت‌شده": "Based on the latest received data",
    "خلاصه امروز": "Today at a glance",
    "تقویم اقتصادی": "Economic calendar",
    "بازار و واچ‌لیست": "Market & watchlist",
    "محاسبه حجم": "Position sizing",
    "پشتیبانی": "Support",
    "مرکز مدیریت": "Administration",
    "جست‌وجو": "Search",
    "روز معاملاتی": "Trading day",
    "ریسک مصرف‌شده": "Risk used",
    "برای مشاهده وضعیت مالی، حساب معامله‌گری خود را اضافه کنید.": "Add a trading account to see your financial overview.",
    'مسابقه': 'Contest',
    'مسابقه‌ها': 'Contests',
    'پیش‌بینی قیمت': 'Price prediction',
    'مسابقه چارت': 'Chart challenge',
    'مسابقه کندل': 'Candle challenge',
    'جهت بازار بعد از خبر': 'News direction',
    'نزدیک‌ترین قیمت برنده است': 'Closest price wins',
    'جهت بعدی بازار را انتخاب کنید': 'Choose the next market direction',
    'قیمت بسته‌شدن کندل را حدس بزنید': 'Predict the candle close',
    'حرکت بازار بعد از خبر را پیش‌بینی کنید': 'Predict the post-news move',
    'صعودی': 'Bullish',
    'نزولی': 'Bearish',
    'خنثی': 'Flat',
    'رنج': 'Range',
    'برنده': 'Winner',
    'پایان‌یافته': 'Completed',
    'رتبه': 'Rank',
    'نتایج اخیر من': 'My recent results',
    'فقط مسابقه‌هایی که در آن‌ها شرکت کرده‌اید': 'Only contests you joined',
    'پاسخ را وارد کنید.': 'Enter your answer.',
    'پاسخ مسابقه با موفقیت ثبت شد.': 'Contest entry submitted.',
    'قبلاً در این مسابقه پاسخ ثبت کرده‌اید.': 'You already entered this contest.',
    'زمان مسابقه تمام شده یا دیگر فعال نیست.': 'This contest is no longer active.',
    'ثبت پاسخ انجام نشد.': 'Could not submit the entry.',
    'پاسخ واردشده معتبر نیست.': 'The submitted answer is invalid.',
    'مالک سیستم': 'System owner', 'مدیر': 'Administrator', 'عضو VIP': 'VIP member', 'عضو عمومی': 'Public member',
    'عمومی': 'Public', 'خصوصی': 'Private', 'کریپتو': 'Crypto', 'فارکس': 'Forex', 'قفل': 'Locked',
    'مرکز فرمان معامله‌گری': 'Trading Command Center', 'سیگنال، بازار، ریسک و ژورنال شما در یک نمای زنده و محافظت‌شده.': 'Your signals, market, risk and journal in one live protected view.',
    'مشاهده سیگنال‌ها': 'View signals', 'مرکز معامله': 'Trading Center', 'محافظ فعال': 'Protection active',
    'سیگنال عمومی': 'Public signals', 'اتاق VIP': 'VIP Room', 'سیگنال‌های اختصاصی زنده': 'Live exclusive signals', 'برای دسترسی اشتراک تهیه کنید': 'Subscribe to unlock access',
    'وضعیت محافظت حساب': 'Account protection status', 'محافظت‌شده': 'Protected', 'ریسک باز': 'Open risk', 'ظرفیت روزانه': 'Daily capacity', 'معامله باز': 'open trades', 'نرخ برد ژورنال': 'journal win rate',
    'بازار زنده': 'Live market', 'قیمت و واچ‌لیست': 'Prices and watchlist', 'محاسبه حجم': 'Position sizing', 'معاملات من': 'My trades', 'ژورنال و نتیجه': 'Journal and outcomes', 'اعلان‌ها': 'Notifications', 'کنترل بدون مزاحمت': 'Quiet controls',
    'سیگنال‌های تازه': 'Recent signals', 'عمومی و VIP بر اساس دسترسی حساب': 'Public and VIP based on account access', 'مشاهده همه': 'View all',
    'انتخاب': 'Decision', 'منتظر تصمیم شما': 'Waiting for your decision', 'جزئیات': 'Details', 'بگیرش': 'Take it', 'نمی‌گیرم': 'Skip',
    'این سیگنال بسته شده است': 'This signal is closed', 'فقط مشخص کنید آن را گرفته بودید یا نگرفته بودید؛ معامله جدیدی باز نمی‌شود.': 'Record whether you took it; no new position will be opened.',
    'این تصمیم قفل شده و رکورد تکراری ایجاد نمی‌شود.': 'This decision is locked and will not be duplicated.', 'بگیرش و ثبت کن': 'Take and journal',
    'چارت نتیجه نهایی سیگنال': 'Final signal result chart', 'مدرک تصویری نتیجه نهایی': 'Final result evidence',
    'وضعیت، مدرک نتیجه و چارت تحلیل در اسلایدهای جداگانه': 'Status, result evidence and analysis chart in separate slides',
    'مرکز سیگنال SENTINEL': 'SENTINEL Signal Center', 'تفکیک عمومی، VIP، فارکس و کریپتو؛ هر تصمیم مستقیم به ژورنال و مربی ریسک متصل است.': 'Public, VIP, Forex and Crypto signals; every decision connects directly to your journal and risk coach.',
    'همه بازارها': 'All markets', 'باز': 'Open', 'بسته': 'Closed', 'اتاق سیگنال VIP': 'VIP Signal Room', 'مشاهده پلن‌ها': 'View plans', 'نماد یا شماره سیگنال': 'Symbol or signal number',
    'گرفته شد و در ژورنال ثبت شد': 'Taken and journaled', 'تصمیم ثبت شد': 'Decision recorded', 'بررسی': 'Review',
    'نبض زنده کانال': 'Live Channel Pulse', 'سیگنال، خبر و اعلان هم‌زمان با تلگرام': 'Signals, news and announcements synchronized with Telegram', 'زنده': 'Live', 'اعلان دستگاه': 'Device notifications',
    'همه': 'All', 'سیگنال': 'Signal', 'خبر و بازار': 'News & market', 'اعلان': 'Announcement', 'تحلیل بازار': 'Market analysis', 'انتشار': 'Publication',
    'نمای کلی': 'Overview', 'تمرین معامله': 'Paper trading', 'نگهبان Prop': 'Prop Guardian', 'مربی ریسک': 'Risk Coach', 'مرکز معامله و محافظت': 'Trading & Protection Center',
    'حساب آزمایشی، قوانین Prop و رفتار معاملاتی در سه بخش روشن و مستقل.': 'Paper accounts, Prop rules and trading behavior in three clear sections.',
    'حساب تمرینی': 'Paper account', 'انضباط': 'Discipline', 'ریسک سیگنال': 'Signal risk', 'ثبت و مدیریت تمام TPها': 'Record and manage all take-profit levels', 'کنترل نقض قوانین': 'Control rule breaches', 'تحلیل سیگنال‌های گرفته‌شده': 'Analyze taken signals', 'قبل از ورود': 'Before entry',
    'حساب آزمایشی و همه سناریوهای خروج در یکجا': 'Paper account and every exit scenario in one place', 'حساب جدید': 'New account', 'معامله جدید': 'New trade', 'لغو': 'Cancelled', 'باقی‌مانده': 'remaining',
    'فاصله تا نقض قانون و آمادگی چالش': 'Distance to rule breach and challenge readiness', 'قوانین این حساب هنوز تنظیم نشده است.': 'Rules are not configured for this account yet.', 'فعال‌کردن الگوی استاندارد': 'Enable standard template', 'ضرر روزانه': 'Daily loss', 'افت کل': 'Total drawdown', 'هدف سود': 'Profit target', 'هیچ نقض فعالی ثبت نشده است.': 'No active breach is recorded.',
    'مربی رفتار و ریسک': 'Behavior & Risk Coach', 'متصل به سیگنال‌های گرفته‌شده و ژورنال واقعی شما': 'Connected to taken signals and your real journal', 'تحلیل مجدد': 'Run analysis again', 'الگوی پرخطر واضحی دیده نشد.': 'No clear high-risk pattern was detected.',
    'ساخت حساب آزمایشی': 'Create paper account', 'نام حساب': 'Account name', 'سرمایه اولیه': 'Starting balance', 'ساخت حساب': 'Create account', 'حساب ساخته شد': 'Account created',
    'ثبت معامله آزمایشی': 'Record paper trade', 'حساب': 'Account', 'نماد': 'Symbol', 'جهت': 'Side', 'ورود': 'Entry', 'حد ضرر': 'Stop loss', 'تارگت‌ها': 'Targets', 'ریسک درصدی': 'Risk percent', 'ثبت معامله': 'Record trade', 'معامله ثبت شد': 'Trade recorded',
    'تغییر حد ضرر': 'Move stop loss', 'SL جدید': 'New SL', 'دلیل': 'Reason', 'ذخیره': 'Save', 'وضعیت معامله به‌روزرسانی شد': 'Trade status updated', 'نگهبان Prop فعال شد': 'Prop Guardian enabled',
    'مرکز کاربر': 'User Center', 'فید کانال': 'Channel feed', 'سیگنال، خبر و اعلان زنده': 'Live signals, news and announcements', 'مرکز تمرین و ریسک': 'Trading Practice & Risk', 'جست‌وجو در تمام داده‌های شخصی': 'Search all personal data', 'خبرهای مهم هفته': 'Important news this week', 'عملکرد قابل راستی‌آزمایی': 'Verifiable performance', 'تغییرات سیگنال‌های گرفته‌شده': 'Changes to taken signals', 'زبان، قوانین و نشست': 'Language, rules and session', 'تیکت و پاسخ‌ها': 'Tickets and replies',
    'مرکز اختصاصی ادمین': 'Admin Workspace', 'این بخش فقط با نقش و مجوز ادمین از سمت سرور باز می‌شود.': 'This area opens only with a server-authorized admin role.', 'عملیات، Audit، شیفت و کنترل سامانه': 'Operations, audit, shifts and system control', 'دسترسی‌های کاربر و ادمین کاملاً از هم جدا شده‌اند.': 'User and admin permissions are fully separated.',
    'مرکز کامل عملیات ادمین': 'Full Admin Command Center', 'عملیات واقعی و مجاز': 'authorized executable actions', 'هر گزینه مستقیماً از رجیستری مشترک ربات و مینی‌اپ اجرا می‌شود.': 'Every option runs through the shared bot and Mini App registry.', 'جست‌وجوی عملیات': 'Search actions', 'نام ماژول یا عملیات...': 'Module or action...', 'سایر': 'Other',
    'دسترسی موردنیاز': 'Required permission', 'داده ورودی JSON': 'JSON payload', 'عملیات با موفقیت انجام شد.': 'Operation completed successfully.', 'عملیات ناموفق بود': 'Operation failed', 'دریافت اطلاعات': 'Load data', 'اجرا': 'Run', 'ثبت و اجرا': 'Submit and run', 'بارگذاری پنل ادمین ناموفق بود': 'Admin panel failed to load', 'اتصال، دسترسی یا وضعیت سرور را بررسی کنید.': 'Check connectivity, permissions and server health.',
    'مرکز مدیریت ساده و عملیاتی': 'Simple Operations Center', 'پرداخت منتظر': 'Pending payments', 'تیکت نیازمند پاسخ': 'Tickets awaiting reply', 'سیگنال در صف': 'Signals queued', 'دسترسی فعال': 'Active access', 'همه ابزارهای ادمین': 'All admin tools', 'صف ارسال سیگنال': 'Signal delivery queue', 'گزارش ممیزی': 'Audit log',
    'دسترسی کاربران': 'User access', 'مینی‌اپ برای کاربران روشن است.': 'The Mini App is enabled for users.', 'مینی‌اپ برای کاربران خاموش است؛ دسترسی ادمین حفظ شده.': 'The Mini App is disabled for users; admin access remains available.', 'خاموش‌کردن': 'Disable', 'روشن‌کردن': 'Enable', 'همگام‌سازی اطلاعات': 'Reconcile data', 'تطبیق دوباره': 'Reconcile again',
    'دوره‌های نام‌دار سیگنال': 'Named signal periods', 'دوره فعلی': 'Current period', 'با بستن دوره، تاریخچه و سیگنال‌ها حذف نمی‌شوند.': 'Closing a period does not delete its history or signals.', 'کل سیگنال': 'Total signals', 'برد': 'Wins', 'باخت': 'Losses', 'نرخ برد': 'Win rate', 'آرشیو و گزارش دوره‌ها': 'Period archive and reports', 'شروع دوره جدید': 'Start new period', 'بستن و شروع دوره جدید': 'Close and start new period', 'فقط بستن دوره': 'Close period only',
    'رسیدهای منتظر بررسی': 'Receipts awaiting review', 'کاربر': 'User', 'بررسی رسید': 'Review receipt', 'تیکت‌های نیازمند پاسخ': 'Tickets awaiting reply', 'بازکردن و پاسخ': 'Open and reply', 'ابزارها و جزئیات پیشرفته': 'Advanced tools and details', 'سلامت سیستم': 'System health', 'قالب سیگنال': 'Signal template', 'بارگذاری': 'Upload', 'قالب اصلی': 'Primary template',
    'مدیریت رسیدها و پرداخت‌ها': 'Manage receipts and payments', 'رسیدها و پرداخت‌های VIP': 'VIP receipts and payments', 'منتظر بررسی': 'Pending review', 'در حال تأیید': 'Approving', 'تأییدشده': 'Approved', 'ردشده': 'Rejected', 'منقضی': 'Expired', 'بازکردن رسید و بررسی': 'Open receipt and review', 'مشاهده و بررسی': 'View and review', 'مبلغ': 'Amount', 'رسید': 'Receipt', 'پیوست‌شده': 'Attached', 'ندارد': 'Missing', '✅ رسید پیوست شده': '✅ Receipt attached', '⚠️ بدون رسید': '⚠️ No receipt', 'محاسبه‌گر دقیق حجم و مارجین SENTINEL': 'SENTINEL precise position and margin calculator', 'بودجه ریسک': 'Risk budget', 'ظرفیت مارجین': 'Margin capacity',
    'بازار، شفافیت، اعلان، اشتراک و پشتیبانی در یک مرکز.': 'Market, transparency, notifications, subscriptions and support in one center.', 'قیمت‌ها و واچ‌لیست': 'Prices and watchlist', 'آمار واقعی و هش شواهد': 'Verified statistics and evidence hash', 'تغییرات پوزیشن‌های Taken': 'Changes to taken positions', 'فیلتر بازار، ساعات سکوت و خلاصه‌ها': 'Market filters, quiet hours and digests', 'پلن‌ها و پرداخت امن': 'Plans and secure payment', 'پیگیری، لغو و ارسال مجدد': 'Track, cancel and resubmit', 'تیکت و پاسخ‌ها': 'Tickets and replies', 'تحویل شیفت، گزارش روزانه و آزمایش‌های رشد': 'Shift handoff, daily brief and growth experiments',
    'در انتظار ادمین': 'Waiting for admin', 'پاسخ داده شد': 'Answered', 'پشتیبانی یکپارچه ربات و مینی‌اپ': 'Unified bot and Mini App support', 'تمام پاسخ‌ها در هر دو محیط هم‌زمان ثبت و اطلاع‌رسانی می‌شوند.': 'All replies are recorded and delivered in both environments.', 'پاسخ ادمین آماده است': 'Admin reply is ready', 'در انتظار بررسی پشتیبانی': 'Waiting for support review', 'بستن تیکت': 'Close ticket', 'تیکت بسته است': 'Ticket is closed', 'بازگشایی': 'Reopen',
    'اعلان سیستم در این دستگاه پشتیبانی نمی‌شود': 'System notifications are not supported on this device', 'اعلان دستگاه فعال شد': 'Device notifications enabled', 'مجوز اعلان داده نشد': 'Notification permission was not granted',
    'لغو TP': 'Cancel TP', 'سر‌به‌سر': 'Break even', 'تغییر SL': 'Move SL', 'لغو معامله': 'Cancel trade', 'لغوشده': 'Cancelled', 'بدون نقض فعال': 'No active breach',
    'اطلاعات ورود تلگرام دریافت نشد.': 'Telegram login data was not received.', 'ورود امن تلگرام تکمیل نشده است': 'Secure Telegram login is incomplete', 'ورود به SENTINEL تکمیل نشد': 'SENTINEL login was not completed', 'این صفحه را کامل ببندید.': 'Close this page completely.', 'به گفت‌وگوی ربات برگردید.': 'Return to the bot chat.', 'تلاش دوباره': 'Try again', 'بستن مینی‌اپ': 'Close Mini App', 'جزئیات تشخیص': 'Diagnostic details', 'Telegram WebView شناسایی شد؛ اطلاعات امضاشده هنوز نرسیده است.': 'Telegram WebView was detected, but signed data has not arrived yet.', 'این صفحه خارج از محیط Web App تلگرام باز شده است.': 'This page was opened outside Telegram Web App.', 'در حال دریافت مجوز تلگرام…': 'Requesting Telegram authorization…', 'در حال بررسی ورود امن تلگرام…': 'Checking secure Telegram login…',
    'در حال برقراری اتصال امن…': 'Establishing secure connection…', 'حالت پیش‌نمایش': 'Preview mode', 'برای داده واقعی، از دکمه Mini App ربات وارد شوید.': 'Open the Mini App from the bot for live data.', 'در حال انجام…': 'Working…', 'برای اجرای SENTINEL باید JavaScript فعال باشد.': 'JavaScript must be enabled to run SENTINEL.',
    'بازگشت': 'Back', 'انصراف': 'Cancel', 'ارسال': 'Send', 'تأیید': 'Confirm', 'رد پرداخت': 'Reject payment', 'تأیید پرداخت': 'Approve payment', 'پاسخ مدیر': 'Admin reply', 'پیام کاربر': 'User message', 'شما': 'You', 'فایل ضمیمه': 'Attachment',
    'فعال': 'Active', 'غیرفعال': 'Disabled', 'در انتظار': 'Pending', 'ارسال‌شده': 'Sent', 'در حال انتشار': 'Publishing', 'ناموفق': 'Failed', 'شکست دائمی': 'Permanently failed', 'در انتظار تلاش مجدد': 'Waiting to retry',
    'آخرین همگام‌سازی': 'Last sync', 'قدیمی': 'Stale', 'در دسترس نیست': 'Unavailable', 'اطلاعاتی برای نمایش وجود ندارد': 'No data to display', 'قیمت فعلی': 'Current price', 'فاصله تا Entry': 'Distance to entry', 'نزدیک‌ترین تارگت': 'Nearest target', 'قیمت داخل محدوده ورود است': 'Price is inside the entry zone', 'سطوح Entry را وارد کنید': 'Enter entry levels', 'رسیده': 'Reached', 'فاصله': 'distance', 'R نامشخص': 'R unavailable',
    'نماد را وارد کنید تا ردیاب چندمنبعی فعال شود.': 'Enter a symbol to activate multi-source tracking.', 'در حال دریافت بهترین قیمت از APIهای فعال…': 'Fetching the best price from active APIs…', 'ارسال سیگنال با ردیاب زنده': 'Publish signal with live tracker', 'ورودها': 'Entries', 'مقصد': 'Destination', 'کانال عمومی': 'Public channel', 'کانال VIP': 'VIP channel', 'هر دو کانال': 'Both channels', 'تایم‌فریم': 'Timeframe', 'دریافت قیمت و محاسبه فاصله‌ها': 'Fetch price and calculate distances', 'یادداشت/تحلیل': 'Note / analysis', 'اعتبارسنجی و انتشار': 'Validate and publish',
    'انتشار اعلان کانال': 'Publish channel announcement', 'عنوان': 'Title', 'متن اعلان': 'Announcement text', 'ثبت و انتشار': 'Save and publish', 'اعلان در صف پایدار انتشار قرار گرفت': 'Announcement was added to the durable delivery queue',
    'دوره‌های سیگنال و گزارش عملکرد': 'Signal periods and performance', 'تاریخچه دائمی دوره‌ها': 'Permanent period history', 'بستن دوره فقط آن را آرشیو می‌کند؛ سیگنال‌ها، نتایج و PDF آن باقی می‌مانند.': 'Closing only archives the period; its signals, results and PDF remain available.', 'فقط بستن دوره فعلی': 'Close current period only', 'تغییر نام': 'Rename', 'نام دوره': 'Period name', 'دریافت PDF کامل': 'Download full PDF', 'بازگشت به دوره‌ها': 'Back to periods',
    'دروازه ایمنی پیش از معامله': 'Pre-trade safety gate', 'اخبار نزدیک': 'Nearby news', 'تاریخچه تغییرات': 'Revision history', 'تقویم اقتصادی هنوز همگام نشده است.': 'The economic calendar has not been synchronized yet.', 'خبر مهم مرتبطی در بازه نزدیک این سیگنال وجود ندارد.': 'No relevant high-impact news is near this signal.', 'ثبت اولیه سیگنال': 'Initial signal',
    'برای محاسبه دقیق ریسک، ابتدا یک حساب معاملاتی انتخاب یا ایجاد کنید.': 'Select or create a trading account before calculating risk.', 'همه کنترل‌های فعال ریسک با موفقیت پاس شدند.': 'All active risk controls passed.', 'محدودیت زیان روزانه اجازه ورود نمی‌دهد.': 'The daily loss limit blocks this entry.', 'محدودیت افت کل حساب اجازه ورود نمی‌دهد.': 'The total drawdown limit blocks this entry.', 'ریسک باز حساب از سقف مجاز عبور می‌کند.': 'The account open risk would exceed its limit.', 'تعداد معاملات باز به سقف مجاز رسیده است.': 'The maximum number of open trades has been reached.', 'اطلاعات حساب قدیمی است و باید تازه‌سازی شود.': 'Account data is stale and must be refreshed.', 'اعتماد داده‌های حساب برای تصمیم قطعی کافی نیست.': 'Account data confidence is too low for a definitive decision.'
};
Object.assign(UI_EN_EXACT, {
    "گفت‌وگو و فرمان به Gemini": "Chat and command Gemini",
    "فرمان‌های مجاز ادمین اصلی مستقیم اجرا می‌شوند؛ کد تخفیف و دسترسی ادمین همیشه تأیید انسانی می‌خواهند.": "Allowed primary-admin commands execute directly; discounts and admin access always require human approval.",
    "اجرای خودکار متوقف است؛ فرمان‌ها برای تأیید انسانی در صف می‌مانند.": "Automatic execution is stopped; commands stay queued for human approval.",
    "فرمان‌های شما پس از کنترل مجوز برای تأیید ادمین اصلی ارسال می‌شوند.": "Your permission-checked commands are sent to the primary admin for approval.",
    "اتصال MT5": "Connect MT5",
    "اتصال این متاتریدر قطع شود؟": "Revoke this MetaTrader connection?",
    "اتصال کاملاً فقط‌خواندنی است و رمز حساب دریافت نمی‌شود.": "The connection is fully read-only and never asks for the account password.",
    "این حساب هنوز به MT5 متصل نیست.": "This account is not connected to MT5 yet.",
    "برنامه ریسک امروز": "Today's risk plan",
    "بروکر": "Broker",
    "تأیید برنامه": "Accept plan",
    "ثبت وضعیت قبل از معامله": "Record pre-trade state",
    "حالت": "Mode",
    "دانلود بسته": "Download package",
    "در حال حاضر هشدار فعالی وجود ندارد.": "There are no active alerts right now.",
    "ذخیره و تأیید": "Save and accept",
    "ساخت کد": "Create code",
    "ساخت کد اتصال یک‌بارمصرف": "Create one-time pairing code",
    "فقط‌خواندنی": "Read only",
    "قطع اتصال": "Revoke connection",
    "کد اتصال آماده است": "Pairing code is ready",
    "کد اتصال جدید": "New pairing code",
    "کنترل کامل ماژول‌های ربات و مینی‌اپ": "Full bot and Mini App module control",
    "صف تغییرات حساس": "Sensitive change queue",
    "بازنشانی ماژول": "Reset module",
    "تنظیمات این ماژول بازنشانی شود؟": "Reset this module's settings?",
    "روشن": "On",
    "خاموش": "Off",
    "درخواست تأیید ساخته شد.": "An approval request was created.",
    "درخواست تغییر سراسری ثبت شود؟": "Submit the global change request?",
    "درخواست حاکمیت ساخته شد.": "A governance request was created.",
    "دلیل رد:": "Rejection reason:",
    "رد": "Reject",
    "در حال بارگذاری SENTINEL": "Loading SENTINEL",
    "در حال بارگذاری و برقراری اتصال امن": "Loading and establishing a secure connection",
    "حساب کاربری": "User account",
    "تغییرات مهم سیگنال‌ها": "Important signal revisions",
    "تازه‌سازی": "Refresh",
    "تغییر زبان": "Change language",
    "نمودار خلاصه": "Summary chart",
    "فارکس و کریپتو": "Forex and Crypto",
    "ناوبری اصلی": "Main navigation",
    "خانه": "Home",
    "سیگنال‌ها": "Signals",
    "ریسک": "Risk",
    "ژورنال": "Journal",
    "بیشتر": "More",
    "خوش آمدید": "Welcome",
    "عضو SENTINEL": "SENTINEL member",
    "تمام خدمات": "All services",
    "ابزارها بر اساس کاری که می‌خواهید انجام دهید دسته‌بندی شده‌اند.": "Tools are grouped by what you want to do.",
    "معامله و تصمیم": "Trading and decisions",
    "از سیگنال تا ثبت نتیجه": "From signal to recorded outcome",
    "مرکز معامله": "Trading Center",
    "تمرین، Prop و مربی ریسک": "Paper trading, Prop and risk coaching",
    "محاسبه‌گر حجم": "Position Size Calculator",
    "ژورنال و معاملات": "Journal and Trades",
    "ورود، خروج و تحلیل": "Entries, exits and analysis",
    "قیمت و بازار": "Prices and Market",
    "واچ‌لیست و رژیم بازار": "Watchlist and market regime",
    "اشتراک و دسترسی": "Subscription and Access",
    "VIP، سفارش و پرداخت": "VIP, orders and payments",
    "اشتراک VIP": "VIP Subscription",
    "مشاهده پلن‌ها و خرید": "View plans and subscribe",
    "سفارش‌ها": "Orders",
    "رسید و وضعیت پرداخت": "Receipt and payment status",
    "نبض کانال": "Channel Pulse",
    "سیگنال، خبر و اعلان": "Signals, news and announcements",
    "اطلاعات و ارتباط": "Information and Communication",
    "اعلان، تقویم و پشتیبانی": "Notifications, calendar and support",
    "مرکز اعلان": "Notification Center",
    "فیلتر و ساعات سکوت": "Filters and quiet hours",
    "تقویم اقتصادی": "Economic Calendar",
    "خبرهای مهم بازار": "Important market news",
    "پشتیبانی": "Support",
    "تیکت و پاسخ": "Tickets and replies",
    "جست‌وجوی سراسری": "Global Search",
    "تمام اطلاعات حساب": "All account information",
    "اعتماد و حساب": "Trust and Account",
    "شفافیت، قوانین و تنظیمات": "Transparency, rules and settings",
    "عملکرد تأییدشده": "Verified Performance",
    "Track Record و شواهد": "Track Record and evidence",
    "تغییرات سیگنال": "Signal Revisions",
    "نسخه‌ها و اصلاحیه‌ها": "Versions and amendments",
    "تنظیمات حساب": "Account Settings",
    "عمومی و VIP، با تصمیم‌گیری مستقیم و ثبت خودکار در ژورنال.": "Public and VIP signals with direct decisions and automatic journal recording.",
    "همه": "All",
    "عمومی": "Public",
    "همه بازارها": "All markets",
    "باز": "Open",
    "فارکس": "Forex",
    "کریپتو": "Crypto",
    "منتظر تصمیم شما": "Waiting for your decision",
    "جزئیات": "Details",
    "بگیرش": "Take it",
    "نمی‌گیرم": "Skip",
    "فا": "FA",
    "حذف": "Delete",
    "خبر": "News",
    "مالک": "Owner",
    "نسخه": "Version",
    "وویس": "Voice message",
    "تصویر": "Image",
    "دقیقه": "minutes",
    "مسئول": "Assignee",
    "ویدئو": "Video",
    "گرفتم": "Taken",
    "تا خبر": "until event",
    "نسخه ۱": "Revision 1",
    "نگرفتم": "Skip",
    "ساخت PDF": "Generate PDF",
    "سود/زیان": "Profit/Loss",
    "فایل/PDF": "File/PDF",
    "اخبار مهم": "Important news",
    "ذخیره نام": "Save name",
    "سقف هفتگی": "Weekly limit",
    "فایل صوتی": "Audio file",
    "میز اعلان": "Announcement Desk",
    "ویرایش صف": "Edit queue",
    "ارسال پاسخ": "Send reply",
    "تحلیل شخصی": "Personal analysis",
    "مرکز کمپین": "Campaign Center",
    "هشدار قیمت": "Price alert",
    "همگام‌سازی": "Synchronize",
    "خطای انتشار": "Publishing error",
    "خلاصه هفتگی": "Weekly digest",
    "گزارش بازار": "Market report",
    "ارسال سیگنال": "Send signal",
    "از خبر گذشته": "since event",
    "خلاصه روزانه": "Daily digest",
    "روز معاملاتی": "trading days",
    "سیگنال کانال": "Channel signal",
    "نتایج سیگنال": "Signal results",
    "کنسول عملیات": "Operations Console",
    "روزهای معامله": "Trading days",
    "یادداشت داخلی": "Internal note",
    "ادمین SENTINEL": "SENTINEL Admin",
    "انتشار لغو شد.": "Publishing was cancelled.",
    "تغییر نام دوره": "Rename period",
    "دلیل رد پرداخت": "Payment rejection reason",
    "ذخیره پیش‌نویس": "Save draft",
    "کمپین ایجاد شد": "Campaign created",
    "گرفتم و ثبت کن": "Take and record",
    "در انتظار بررسی": "Awaiting review",
    "قالب‌های سیگنال": "Signal templates",
    "آخرین قیمت معتبر": "Latest valid price",
    "بازکردن و مدیریت": "Open and manage",
    "خروجی PDF ژورنال": "Journal PDF export",
    "سیگنال گرفته‌شده": "Taken signals",
    "قوانین حساب پراپ": "Prop account rules",
    "تیکت پشتیبانی باز": "Open support ticket",
    "تیکت‌های پشتیبانی": "Support tickets",
    "صف، تحویل و خطاها": "Queue, delivery and errors",
    "پرداخت و رسید VIP": "VIP payment and receipt",
    "پس‌زمینه و چیدمان": "Background and layout",
    "پشتیبانی SENTINEL": "SENTINEL Support",
    "انتشار امن اطلاعیه": "Secure announcement publishing",
    "سفارش در حال بررسی": "Order under review",
    "مرکز دقیق کمپین‌ها": "Campaign Operations Center",
    "وضعیت تمام ماژول‌ها": "Status of all modules",
    "پاسخ مدیر آماده است": "Admin reply is ready",
    "پیگیری ارسال سیگنال": "Signal delivery tracking",
    "حاکمیت، شیفت و سلامت": "Governance, shifts and health",
    "رسید را انتخاب کنید.": "Select a receipt.",
    "مدیریت کامل پشتیبانی": "Full support management",
    "مشاهده و پاسخ دوطرفه": "View and reply in both directions",
    "نکته آموزشی تحلیل‌گر": "Analyst coaching note",
    "گرفته شد · در ژورنال": "Taken · Journaled",
    "ساخت قالب قوانین پراپ": "Create Prop rules template",
    "سیگنال‌های محاسبه‌شده": "Calculated signals",
    "نمادهای موقتاً ناموفق": "Temporarily failed symbols",
    "هشدار نقض قوانین پراپ": "Prop rule breach alert",
    "تأیید یا رد از مینی‌اپ": "Approve or reject in Mini App",
    "محاسبه‌گر حجم SENTINEL": "SENTINEL Position Size Calculator",
    "مرکز اطلاع‌رسانی کانال": "Channel Communications Center",
    "همگام‌سازی فقط‌خواندنی": "Read-only synchronization",
    "دسترسی فقط‌خواندنی": "Read-only access",
    "مشاهده تیکت": "View ticket",
    "نقش در فرم اعمال شد؛ برای ثبت، ذخیره را بزنید.": "Role applied to the form; press Save to persist.",
    "وضعیت اتصال قابل مشاهده است؛ اجرای تطبیق نیازمند کنترل کامل سیستم است.": "Integration health is visible; reconciliation requires full system control.",
    "وضعیت انتشار سیگنال‌ها": "Signal publishing status",
    "این سیگنال را گرفته‌اید": "You took this signal",
    "تأیید دستی و ارسال لینک": "Manual approval and link delivery",
    "ساخت، ارسال و آمار دقیق": "Create, deliver and measure precisely",
    "مهلت پاسخ SLA گذشته است": "SLA response deadline has passed",
    "جزئیات ماژول‌های مدیریتی": "Administrative module details",
    "لغو از پنل ادمین مینی‌اپ": "Cancelled from the Mini App admin panel",
    "گزارش PDF دوره آماده شد.": "Period PDF report is ready.",
    "گزارش ممیزی قابل جست‌وجو": "Searchable audit log",
    "این سیگنال را رد کرده‌اید": "You skipped this signal",
    "سیگنال دوباره وارد صف شد.": "The signal was queued again.",
    "ویرایش مقصد و زمان انتشار": "Edit destination and publishing time",
    "متن یا فایل را اضافه کنید.": "Add text or a file.",
    "متن یا یک فایل اضافه کنید.": "Add text or a file.",
    "گزارش PDF ژورنال آماده شد.": "Journal PDF report is ready.",
    "ابتدا تصویر را انتخاب کنید.": "Select an image first.",
    "ساخت کمپین قابل‌اندازه‌گیری": "Create a measurable campaign",
    "حداقل یک ارز را انتخاب کنید.": "Select at least one currency.",
    "دسترسی، اتصال و زیرسامانه‌ها": "Access, connectivity and subsystems",
    "ظرفیت ریسک حساب تمام شده است": "The account has no remaining risk capacity",
    "SENTINEL | سیستم مدیریت معامله": "SENTINEL | Trading Management System",
    "دوره با موفقیت به‌روزرسانی شد.": "The period was updated successfully.",
    "مدیریت تیکت‌های ربات و مینی‌اپ": "Manage Bot and Mini App tickets",
    "انتشار در کانال، ربات و مینی‌اپ": "Publish to channel, Bot and Mini App",
    "بستن دوره فعلی و شروع دوره جدید": "Close current period and start a new one",
    "حداکثر حجم فایل ۱۵ مگابایت است.": "The maximum file size is 15 MB.",
    "مرکز تمرین معامله و مدیریت ریسک": "Trading Practice and Risk Management Center",
    "دوره بسته و در آرشیو نگهداری شد.": "The period was closed and retained in the archive.",
    "سیگنال در کانال و مینی‌اپ ثبت شد.": "The signal was recorded in the channel and Mini App.",
    "ظرفیت ریسک روزانه رو به پایان است": "Daily risk capacity is nearly exhausted",
    "اطلاعات فقط‌خواندنی بروکر همگام شد": "Read-only broker data was synchronized",
    "تغییر مهم سیگنال نیاز به تأیید دارد": "An important signal revision requires acknowledgement",
    "کمپین در صف پایدار انتشار قرار گرفت": "The campaign was placed in the durable publishing queue",
    "دوره فعلی بسته و دوره جدید آغاز شود؟": "Close the current period and start a new one?",
    "پروفایل معامله‌گری خود را تکمیل کنید": "Complete your trading profile",
    "انتشار از صف امن ربات در حال انجام است…": "Publishing through the Bot secure queue…",
    "برای این سیگنال قبلاً تصمیم ثبت شده است.": "A decision has already been recorded for this signal.",
    "نسخه جدید آماده است؛ برنامه را باز کنید.": "A new version is ready; reopen the app.",
    "دوره فعلی بسته شود؟ هیچ سیگنالی حذف نخواهد شد.": "Close the current period? No signals will be deleted.",
    "اطلاعات مشترک ربات و مینی‌اپ دوباره تطبیق داده شد.": "Shared Bot and Mini App data was reconciled again.",
    "ژورنال مشترک ربات و مینی‌اپ با نتیجه R و دلیل ورود.": "A shared Bot and Mini App journal with R result and entry rationale.",
    "خلاصه روشن ریسک، معاملات گرفته‌شده و ظرفیت باقی‌مانده.": "A clear summary of risk, taken trades and remaining capacity.",
    "معامله‌های شخصی و سیگنال‌های کانال در یک ژورنال مشترک.": "Personal trades and channel signals in one shared journal.",
    "هر سیگنال را با وضعیت لحظه‌ای و اثر آن روی حساب بررسی کن.": "Review every signal with live status and its effect on your account.",
    "ریسک واقعی پوزیشن‌ها، قوانین پراپ و بدترین سناریو در یک نما.": "Actual position risk, Prop rules and worst-case scenario in one view.",
    "این تصمیم قفل شده و دوباره سیگنال یا ژورنال جدید ایجاد نمی‌شود.": "This decision is locked and will not create another signal or journal entry.",
    "SENTINEL — سیستم‌عامل مستقل مدیریت سیگنال، ریسک، ژورنال و شفافیت عملکرد": "SENTINEL — independent signal, risk, journal and verified-performance operating system",
    "اول ظرفیت ریسک این هفته را ببین؛ جزئیات پیشرفته فقط در صورت نیاز باز می‌شوند.": "Check this week’s risk capacity first; advanced details open only when needed.",
    "در حال بررسی ورود امن تلگرام…": "Checking secure Telegram login…",
    "اتصال بیشتر از حد معمول طول کشید؛ تلاش در پس‌زمینه ادامه دارد.": "Connection is taking longer than expected; retry continues in the background.",
    "در حال اتصال به SENTINEL": "Connecting to SENTINEL",
    "لودر پس از ۱۰ ثانیه بسته شد. اتصال امن در پس‌زمینه ادامه دارد.": "The loader closed after 10 seconds. Secure connection continues in the background.",
    "اطلاعات ورود تلگرام هنوز دریافت نشده است؛ صفحه را ببندید و از دکمه پایین ربات دوباره وارد شوید.": "Telegram login data has not arrived yet. Close this page and reopen it from the Bot button.",
    "اطلاعات ورود تلگرام دریافت نشد؛ از دکمه Mini App داخل ربات وارد شوید.": "Telegram login data was not received. Open the Mini App from the Bot.",
    "ورود امن تلگرام تکمیل نشده است": "Secure Telegram login is incomplete",
    "ورود به SENTINEL تکمیل نشد": "SENTINEL login was not completed",
    "این صفحه را کامل ببندید.": "Close this page completely.",
    "به گفت‌وگوی ربات برگردید.": "Return to the Bot chat.",
    "دکمه SENTINEL پایین صفحه یا دکمه Mini App داخل منو را بزنید.": "Tap the SENTINEL button at the bottom or the Mini App button in the menu.",
    "تلاش دوباره": "Try again",
    "بستن مینی‌اپ": "Close Mini App",
    "جزئیات تشخیص": "Diagnostic details",
    "خبر و بازار": "News and Market",
    "تحلیل بازار": "Market Analysis",
    "عملکرد قابل راستی‌آزمایی": "Verifiable Performance",
    "مرکز کاربر": "User Center",
    "تمام ابزارها و تنظیمات در یک نمای مرتب.": "All tools and settings in one organized view.",
    "هیچ داده‌ای برای نمایش وجود ندارد.": "No data to display.",
    "بارگذاری بیشتر": "Load more",
    "عملیات با موفقیت انجام شد": "Operation completed successfully",
    "خطایی رخ داد": "Something went wrong",
    "فعال‌سازی رایگان": "Free activation",
    "در انتظار ادمین": "Waiting for admin",
    "پاسخ داده شد": "Answered",
    "بسته": "Closed",
    "پاسخ ادمین آماده است": "Admin reply is ready",
    "در انتظار بررسی پشتیبانی": "Waiting for support review",
    "بازار جهانی": "Global markets",
    "بازار ایران": "Iran market",
    "اطمینان": "Confidence",
    "نوسان": "Volatility",
    "سشن": "Session",
    "افزودن نماد به واچ‌لیست": "Add symbol to watchlist",
    "اعلان دستگاه فعال شد": "Device notifications enabled",
    "مجوز اعلان داده نشد": "Notification permission was not granted",
    "اعلان سیستم در این دستگاه پشتیبانی نمی‌شود": "System notifications are not supported on this device",
    "گرفتم / ثبت ورود": "Take / Record entry",
    "مشاهده همه": "View all",
    "آخرین محتوای کانال": "Latest channel content",
    "لغو TP": "Cancel TP",
    "سر‌به‌سر": "Break even",
    "تغییر SL": "Move SL",
    "لغو معامله": "Cancel trade",
    "ابتدا یک حساب آزمایشی بسازید.": "Create a paper account first.",
    "معاملات و تمام سناریوهای خروج": "Trades and all exit scenarios",
    "مربی رفتار و ریسک متصل به سیگنال‌ها": "Behavior and risk coach connected to signals",
    "ریسک فعال": "Active risk",
    "بدون نقض فعال": "No active breach",
    "نام حساب": "Account name",
    "حساب تمرینی": "Paper account",
    "سرمایه اولیه": "Starting balance",
    "TPها (با ویرگول)": "TPs (comma-separated)",
    "ریسک %": "Risk %",
    "SL جدید": "New SL",
    "ثبت معامله": "Record trade",
    "تیکت": "ticket",
    "دسته": "Category",
    "اولویت": "Priority",
    "شناسه مدیر مسئول": "Assigned admin ID",
    "فقط تیکت‌های عبورکرده از SLA": "Overdue SLA tickets only",
    "اعمال فیلتر": "Apply filters",
    "مدیر مسئول": "Assigned admin",
    "یادداشت‌های داخلی": "Internal notes",
    "مدیر": "Administrator",
    "تخصیص به مدیر": "Assign to admin",
    "تخصیص": "Assign",
    "اولویت و SLA": "Priority and SLA",
    "به‌روزرسانی": "Update",
    "یادداشت داخلی (برای کاربر نمایش داده نمی‌شود)": "Internal note (hidden from user)",
    "ثبت یادداشت": "Save note",
    "بازگشایی": "Reopen",
    "حساب‌ها": "Accounts",
    "همه حساب‌ها": "All accounts",
    "وضعیت": "Status",
    "از تاریخ": "From date",
    "تا تاریخ": "To date",
    "شروع سکوت": "Quiet start",
    "پایان سکوت": "Quiet end",
    "توقف موقت (ساعت)": "Pause for hours",
    "ساعات سکوت فعال": "Quiet hours enabled",
    "بازارها (forex, crypto)": "Markets (Forex, Crypto)",
    "نمادهای خاص": "Specific symbols",
    "اختیاری": "optional",
    "تأیید پرداخت فقط بر اساس رسید و بررسی دستی ادمین است.": "Payment approval is based on the receipt and manual admin review.",
    "ارسال مجدد رایگان؛ رسید لازم نیست ولی تأیید ادمین الزامی است.": "Free resubmission; no receipt is required, but admin approval is required."
});
Object.assign(UI_EN_EXACT, { 'اشتراک شما فعال است': 'Your subscription is active', 'بازار': 'Market', 'موجودی دلار': 'Balance in USD', 'قیمت ورود': 'Entry price', 'اهرم': 'Leverage', 'کارمزد رفت‌وبرگشت %': 'Round-trip fee %', 'محاسبه امن': 'Calculate safely', 'مدیریت SENTINEL': 'SENTINEL Administration', 'فقط ابزارهای مجاز برای این مدیر': 'Only tools authorized for this administrator', '2350 یا 2350,2347': '2350 or 2350,2347', 'قیمت معتبر دریافت نشد.': 'No valid price was received.', 'سیگنال از مسیر امن ربات منتشر و همان لحظه در کانال و مینی‌اپ ثبت می‌شود.': 'The signal is published through the Bot secure path and recorded instantly in the channel and Mini App.', 'هر ارسال تا نتیجه نهایی قابل ردیابی است.': 'Every delivery remains traceable through its final outcome.', 'کل': 'Total', 'زمان‌بندی': 'Scheduled', 'کمپین جدید': 'New campaign', 'مدیریت ریسک': 'Risk management', 'امکانات بیشتر': 'More tools', 'ژورنال معاملاتی': 'Trading journal' });

Object.assign(UI_EN_EXACT, {
    'استاپ': 'Stop',
    'افزودن ادمین جدید': 'Add new administrator',
    'افزودن و سطح دسترسی': 'Add and manage access',
    'افزودن و مدیریت ادمین‌ها': 'Add and manage administrators',
    'این ادمین حذف شود؟': 'Remove this administrator?',
    'این سیگنال برای همیشه حذف شود؟': 'Permanently delete this signal?',
    'بازکردن نتیجه': 'Reset result',
    'بستن بخشی': 'Partial close',
    'بستن دستی': 'Manual close',
    'تأیید مسدودی': 'Confirm ban',
    'تارگت': 'Target',
    'ثبت نتیجه': 'Set result',
    'ثبت نتیجه سیگنال': 'Set signal result',
    'جست‌وجو، VIP و مسدودی': 'Search, VIP and bans',
    'حداقل یک مجوز انتخاب کنید.': 'Select at least one permission.',
    'حذف کامل': 'Delete permanently',
    'رفع مسدودی': 'Unban',
    'ریسک‌فری': 'Break even',
    'مدیریت ادمین‌ها': 'Admin access',
    'مدیریت سیگنال‌ها': 'Manage signals',
    'مدیریت سیگنال‌های منتشرشده': 'Published signal management',
    'مدیریت و کنترل کاربران': 'User management and control',
    'مسدودسازی': 'Ban user',
    'مسدودسازی کاربر': 'Ban user',
    'نتیجه قبلی پاک و سیگنال دوباره باز شود؟': 'Clear the previous result and reopen this signal?',
    'ورود نداده': 'No entry',
    'ویرایش سیگنال': 'Edit signal',
    'ویرایش مجوزهای ادمین': 'Edit administrator permissions',
    'ویرایش، نتیجه و حذف': 'Edit, result and delete',
    'کنترل کاربران': 'User control',
    'کنسل‌شده': 'Cancelled',
    'مربی هوشمند شخصی': 'Personal AI coach',
    'مرکز فرماندهی هوش مصنوعی': 'AI Command Center',
    'مرکز هوش مصنوعی': 'AI Center',
    'مدیریت انسانی پلن‌های VIP': 'Human VIP plan management',
    'مدیریت پلن‌های VIP': 'VIP plan management',
    'ساخت پلن جدید': 'Create new plan',
    'ساخت پلن': 'Create plan',
    'ویرایش پلن': 'Edit plan',
    'ذخیره تغییرات': 'Save changes',
    'فروش': 'Sales',
    'مخاطب': 'Audience',
    'روز': 'days',
    'تأیید انسانی': 'Human approval',
    'رد پیشنهاد': 'Reject proposal',
    'این پیشنهاد فقط پس از تأیید انسانی اجرا شود؟': 'Execute this proposal only after human approval?',
    'پلن بدون سابقه فروش حذف شود؟': 'Delete this plan only if it has no sales history?',
    'AI کاربران: فقط VIP': 'User AI: VIP only',
    'AI کاربران: همه': 'User AI: everyone',
    'برای همه کاربران فعال': 'Available to all users',
    'فقط کاربران VIP': 'VIP users only',
    'بررسی هوشمند حساب': 'Smart account review',
    'تست زنده انجام شد': 'Live test completed',
    'حالت دسترسی کاربران بین فقط VIP و همه تغییر کند؟': 'Switch user AI access between VIP only and everyone?',
    'گزارش روزانه مدیر': 'Daily manager report',
    'اجرای ابزارها با کلید اضطراری متوقف شده است.': 'Tool execution is stopped by the emergency switch.',
    'اجرای دستورات Gemini فعال شود؟': 'Enable Gemini tool execution?',
    'اجرای دستورات Gemini فوراً متوقف شود؟': 'Immediately stop Gemini tool execution?',
    'تأیید ادمین': 'Approve admin',
    'تأیید و اجرا': 'Approve and execute',
    'دستورات ادمین اصلی بدون تأیید اضافه اجرا می‌شوند.': 'Primary-admin commands execute without extra confirmation.',
    'دستورات شما برای تأیید ادمین اصلی ارسال می‌شوند.': 'Your commands are sent to the primary admin for approval.',
    'دلیل رد ادمین:': 'Administrator rejection reason:',
    'دلیل رد دستور:': 'Command rejection reason:',
    'رد درخواست': 'Reject request',
    'رد دستور': 'Reject command',
    '⛔ توقف اجرای AI': '⛔ Stop AI execution',
    '✅ فعال‌کردن اجرای AI': '✅ Enable AI execution',
    'اطلاعات مبلغ پرداخت ناقص است؛ دوباره تلاش کنید.': 'Payment quote data is incomplete; please try again.',
    'تنظیمات پرداخت و پیش‌فرض VIP': 'VIP payment and default settings',
    'ذخیره تنظیمات': 'Save settings',
    'سیگنال بسته شده': 'Signal closed',
    'شماره کارت، نام و قیمت پیش‌فرض': 'Card number, owner name and default price',
    'نمایش مبلغ و اطلاعات پرداخت': 'Show amount and payment information',
    'پلن‌ها و تنظیمات پرداخت VIP': 'VIP plans and payment settings'
});

Object.assign(UI_EN_EXACT, {
    "استاپ لاس": "Stop loss",
    "بریک ایون شد": "Moved to break-even",
    "بستن بخشی انجام شد": "Partial close executed",
    "به‌دلیل بسته‌شدن سیگنال دیگر امکان ثبت «گرفتم / نگرفتم» وجود ندارد.": "Take / skip is disabled because the signal is closed.",
    "تارگت ثبت شد": "Target reached",
    "تمام تارگت‌ها کامل شد": "All targets reached",
    "تی پی ۱": "TP1",
    "تی پی ۱ خورد": "TP1 hit",
    "تی پی ۲": "TP2",
    "تی پی ۲ خورد": "TP2 hit",
    "حد ضرر فعال شد": "Stop loss hit",
    "رخداد": "events",
    "زیان ثبت شد": "Loss recorded",
    "سود کامل ثبت شد": "Full profit booked",
    "سیگنال بسته شده است": "Signal is closed",
    "سیگنال دستی بسته شد": "Signal manually closed",
    "سیگنال لغو شد": "Signal cancelled",
    "سیگنال منقضی شد": "Signal expired",
    "فول تی پی": "Full TP",
    "قالب سیگنال فعال": "Live signal card",
    "نقطه ورود فعال شد": "Entry activated",
    "ورود فعال شد": "Entry hit",
    "ورودی فعال نشد": "No entry",
    "با ثبت معاملات بیشتر، الگوهای رفتاری دقیق‌تر می‌شوند.": "More journal entries will improve behavioral pattern detection."
});

Object.assign(UI_EN_EXACT, {
    "جوایز": "Rewards",
    "پاداش‌ها": "Rewards",
    "جوایز موجود": "Available rewards",
    "جوایز من": "My rewards",
    "تاریخچه امتیاز": "Point history",
    "امتیاز": "Points",
    "دریافتی ثبت‌شده": "Recorded earnings",
    "مصرف ثبت‌شده": "Recorded spending",
    "منبع": "Source",
    "اعتبار": "Validity",
    "شرایط استفاده": "Conditions",
    "مشاهده و دریافت در ربات": "View and claim in bot",
    "دعوت دوستان": "Invite friends",
    "کپی لینک": "Copy link",
    "اشتراک‌گذاری": "Share",
    "دعوت‌ها": "Invitations",
    "خریداران": "Buyers",
    "برای دریافت لینک اختصاصی وارد بخش دعوت ربات شوید.": "Open referrals in the bot to get your personal link.",
    "باز کردن ربات": "Open bot",
    "مأموریت‌ها": "Missions",
    "آموزش": "Education",
    "رتبه‌بندی و باشگاه": "Rankings & club",
    "حساب و تمام خدمات": "Account & all services",
    "همه قابلیت‌ها با حفظ دسترسی‌های قبلی": "All features with existing access preserved",
    "میز معامله‌گری": "Trading workspace",
    "برنامه ریسک": "Risk plan",
    "ژورنال معاملاتی": "Trading journal",
    "تمرین و ابزارها": "Practice & tools",
    "صفحه بعد": "Next page",
    "صفحه قبل": "Previous page",
    "استفاده‌شده": "Used",
    "منقضی": "Expired",
    "قابل استفاده": "Available",
    "در انتظار تحویل": "Awaiting delivery",
    "تحویل‌شده": "Delivered",
    "لغوشده": "Cancelled",
    "تاریخ": "Date",
    "مانده": "Balance",
    "بدون انقضای ثبت‌شده": "No recorded expiry",
    "سقف استفاده هر نفر": "Uses per user",
    "فقط تمدید VIP": "VIP renewal only",
    "پلن‌های مجاز": "Applicable plans",
    "همه پلن‌ها": "All plans",
    "حداقل خرید": "Minimum purchase",
    "کپی شد": "Copied",
    "پشتیبانی": "Support",
    "سؤالات متداول": "FAQ",
    "امروز من": "My today",
    "بررسی هوشمند حساب": "Smart account review",
    "در حال بازیابی اتصال…": "Reconnecting…",
    "اتصال برقرار نشد؛ فرم شما حفظ شده است.": "Connection unavailable. Your form is preserved.",
    "پاسخ‌های ذخیره‌شده بازیابی شدند. فایل‌ها را دوباره انتخاب کنید.": "Saved answers restored. Select attachments again.",
    "نتیجه درخواست قبلی هنوز نامشخص است؛ پیش از ثبت دوباره، تاریخچه یا پشتیبانی را بررسی کنید.": "The previous result is uncertain. Check history or support before submitting again.",
    "روز VIP": "VIP days",
    "٪ تخفیف": "% coupon",
    "معامله‌گری": "Trading"
});
Object.assign(UI_EN_EXACT, {'جوایز':'Rewards','پیگیری':'Reference'});
Object.assign(UI_EN_EXACT, {'کپی کد':'Copy code','عضو عمومی':'Public member'});
Object.assign(I18N.fa,{back:'بازگشت'});Object.assign(I18N.en,{back:'Back'});
Object.assign(UI_EN_EXACT, {'رتبه من':'My rank'});
Object.assign(UI_EN_EXACT, {
  "ابزارهای ربات": "Bot tools",
  "ابزارهای معامله": "Trading tools",
  "اخبار و تقویم": "News & calendar",
  "باشگاه و امتیاز": "Club & points",
  "بررسی هوشمند": "Smart review",
  "جایزه‌های من": "My rewards",
  "جدید": "new",
  "جست‌وجو و خدمات": "Search & services",
  "حساب در ربات": "Bot account",
  "حساب من": "My account",
  "خدمات": "Services",
  "خرید اشتراک": "Buy subscription",
  "رتبه‌بندی": "Rankings",
  "سفارش‌ها و پرداخت": "Orders & payments",
  "قیمت بازار": "Market prices",
  "لینک دعوت من": "My referral link",
  "مأموریت": "Missions",
  "ماشین‌حساب": "Calculator",
  "مدیریت اشتراک": "Manage subscription",
  "مرکز معاملات": "Trading center"
});
Object.assign(UI_EN_EXACT, {'👥 CRM و کاربران':'CRM & users','💳 فروش و اشتراک‌ها':'Sales & subscriptions','📡 ارسال سیگنال':'Signal publishing','📣 تبلیغات و کمپین‌ها':'Advertising & campaigns','🛡 ادمین و امنیت':'Admin & security'});
Object.assign(UI_EN_EXACT, {'بر اساس میانگین ورودی‌های ثبت‌شده': 'Based on the published entry average', 'بر اساس ورود و استاپ ثبت‌شده': 'Based on the published entry and stop'});
const UI_EN_DYNAMIC_PATTERNS = [
    [/^(.+)\s+فارکس\s*·\s*(.+)\s+کریپتو$/u, '$1 Forex · $2 Crypto'],
    [/^(.+)%\s+ظرفیت روزانه$/u, '$1% daily capacity'],
    [/^(.+)\s+معامله باز\s*·\s*(.+)%\s+نرخ برد ژورنال$/u, '$1 open trades · $2% journal win rate'],
    [/^(.+)\s*·\s*فارکس$/u, '$1 · Forex'],
    [/^(.+)\s*·\s*کریپتو$/u, '$1 · Crypto'],
    [/^فارکس\s*·\s*(.+)$/u, 'Forex · $1'],
    [/^کریپتو\s*·\s*(.+)$/u, 'Crypto · $1'],
    [/^(.+)\s+دقیقه$/u, '$1 minutes'],
    [/^(.+)\s+تا خبر$/u, '$1 until event'],
    [/^(.+)\s+از خبر گذشته$/u, '$1 since event'],
    [/^نسخه\s+(.+)$/u, 'Revision $1'],
    [/^(.+)\s+روز معاملاتی$/u, '$1 trading days'],
    [/^(.+)\s+سیگنال$/u, '$1 signals'],
    [/^(.+)\s+تیکت$/u, '$1 tickets'],
    [/^(.+)\s+عملیات واقعی و مجاز$/u, '$1 authorized executable actions'],
    [/^(.+)\s+معامله باز$/u, '$1 open trades']
];
function translateUiText(value) {
    const raw = String(value ?? '');
    if (state.lang !== 'en' || !/[\u0600-\u06ff]/u.test(raw)) return raw;
    const leading = raw.match(/^\s*/u)?.[0] || '';
    const trailing = raw.match(/\s*$/u)?.[0] || '';
    const trimmed = raw.trim();
    const key = Object.keys(I18N.fa).find(k => I18N.fa[k] === trimmed);
    let translated = key ? I18N.en[key] : UI_EN_EXACT[trimmed];
    if (!translated) {
        for (const [pattern, replacement] of UI_EN_DYNAMIC_PATTERNS) {
            if (pattern.test(trimmed)) { translated = trimmed.replace(pattern, replacement); break; }
        }
    }
    return translated ? `${leading}${translated}${trailing}` : raw;
}
const uiOriginalText = new WeakMap();
const uiOriginalAttrs = new WeakMap();
function localizeUiTree(root = document) {
    const target = root?.nodeType ? root : document;
    const walker = document.createTreeWalker(target, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    for (const node of textNodes) {
        const parent = node.parentElement;
        if (!parent || ['SCRIPT', 'STYLE', 'CODE', 'PRE'].includes(parent.tagName) || parent.closest('[data-preserve-language]')) continue;
        if (!uiOriginalText.has(node) && /[\u0600-\u06ff]/.test(node.nodeValue || '')) uiOriginalText.set(node, node.nodeValue);
        if (state.lang === 'en') node.nodeValue = translateUiText(uiOriginalText.get(node) ?? node.nodeValue);
        else if (uiOriginalText.has(node)) node.nodeValue = uiOriginalText.get(node);
    }
    const elements = target.nodeType === Node.ELEMENT_NODE ? [target, ...target.querySelectorAll('*')] : [...document.querySelectorAll('*')];
    for (const el of elements) {
        if (el.closest?.('[data-preserve-language]')) continue;
        let originals = uiOriginalAttrs.get(el);
        for (const attr of ['aria-label', 'placeholder', 'title', 'alt']) {
            if (!el.hasAttribute?.(attr)) continue;
            const value = el.getAttribute(attr) || '';
            if (!originals && /[\u0600-\u06ff]/.test(value)) { originals = {}; uiOriginalAttrs.set(el, originals); }
            if (originals && originals[attr] == null && /[\u0600-\u06ff]/.test(value)) originals[attr] = value;
            if (state.lang === 'en' && originals?.[attr] != null) el.setAttribute(attr, translateUiText(originals[attr]));
            else if (state.lang === 'fa' && originals?.[attr] != null) el.setAttribute(attr, originals[attr]);
        }
    }
}
let uiLocalizationObserver = null;
function ensureUiLocalizationObserver() {
    if (uiLocalizationObserver || !document.body) return;
    uiLocalizationObserver = new MutationObserver(records => {
        if (state.lang !== 'en') return;
        for (const record of records) for (const node of record.addedNodes) if (node.nodeType === Node.ELEMENT_NODE || node.nodeType === Node.TEXT_NODE) localizeUiTree(node);
    });
    uiLocalizationObserver.observe(document.body, { childList: true, subtree: true });
}
const esc = v => String(v ?? '').replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
const num = (v, d = 2) => { const n = Number(v); return Number.isFinite(n) ? new Intl.NumberFormat(state.lang === 'fa' ? 'fa-IR' : 'en-US', { maximumFractionDigits: d }).format(n) : '—'; };
const pct = (v, d = 2) => `${num(v, d)}%`;
const money = (v, c = 'USD') => { const n = Number(v); if (!Number.isFinite(n))
    return '—'; return `${num(n, 2)} ${esc(c)}`; };
const date = v => { if (!v)
    return '—'; const d = new Date(v); return Number.isNaN(d.getTime()) ? '—' : new Intl.DateTimeFormat(state.lang === 'fa' ? 'fa-IR' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' }).format(d); };
const icon = id => `<svg aria-hidden="true"><use href="#i-${id}"/></svg>`;
const unwrap = r => r?.ok && Object.prototype.hasOwnProperty.call(r, 'data') ? r.data : r;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const FEATURE_KEY = { signals: 'signals', risk: 'portal', journal: 'journal', market: 'watchlists', calendar: 'calendar', vip: 'subscriptions', orders: 'subscriptions', support: 'support', notifications: 'notify', track: 'signals', revisions: 'signals' };
function featureEnabled(key) { const module = FEATURE_KEY[key] || key; const row = state.resources.overview?.features?.[module]; return !row || row.enabled !== false; }
function disabledPanel() { return `<div class="panel"><div class="empty">${icon('lock')}<h2>${esc(t('notAvailable'))}</h2><p>${esc(t('maintenance'))}</p></div></div>`; }
function featureDisabledModal() { openModal('FEATURE', t('notAvailable'), disabledPanel(), []); }
function setBusy(on, label = t('loading')) { state.busy += on ? 1 : -1; state.busy = Math.max(0, state.busy); const el = $('#busyOverlay'); el.hidden = !state.busy; if (label)
    $('span', el).textContent = label; }
function toast(message, type = '') { const el = $('#toast'); el.textContent = message; el.className = `toast ${type}`; requestAnimationFrame(() => el.classList.add('show')); clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2600); }
function errorSummary(message) { const el = $('#errorSummary'); el.textContent = message; el.hidden = !message; if (message)
    el.focus(); }
function setConnection(mode, text) { const el = $('#connectionBar'); el.className = `connection-bar ${mode}`; $('span', el).textContent = text || ({ online: t('secure'), offline: t('offline'), loading: t('loading') }[mode]); state.online = mode === 'online'; }
let authRefreshInflight = null;
async function renewAuthenticatedSession() { if (authRefreshInflight)
    return authRefreshInflight; authRefreshInflight = (async () => { try {
        const auth = await request('./api/v1/auth/session', { authRecovery: false }, 6500);
        if (!auth?.csrf_token)
            throw new Error('CSRF_REFRESH_FAILED');
        state.csrf = auth.csrf_token;
        return auth;
    }
    catch {
        const initData = await waitForTelegramInitData(1800);
        if (!initData)
            throw Object.assign(new Error(state.lang === 'fa' ? 'برای تمدید نشست، مینی‌اپ را دوباره از تلگرام باز کنید.' : 'Reopen the Mini App from Telegram to renew your session.'), { code: 'INIT_DATA_MISSING' });
        const auth = await request('./api/v1/auth/bootstrap', { method: 'POST', headers: { 'X-Telegram-Init-Data': initData }, authRecovery: false }, 20000);
        if (!auth?.csrf_token)
            throw new Error('CSRF_REFRESH_FAILED');
        state.csrf = auth.csrf_token;
        return auth;
    } })(); try {
        return await authRefreshInflight;
    }
    finally {
        authRefreshInflight = null;
    } }
async function request(path, options = {}, timeout = 20000) { const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), timeout); const { authRecovery = true, ...fetchOptions } = options; try {
    const headers = { Accept: 'application/json', ...(fetchOptions.headers || {}) };
    if (state.lang)
        headers['Accept-Language'] = state.lang;
    if (options.csrf && state.csrf)
        headers['X-CSRF-Token'] = state.csrf;
    const res = await fetch(path, { credentials: 'include', ...fetchOptions, headers, signal: ctl.signal });
    const text = await res.text();
    let body = {};
    try {
        body = text ? JSON.parse(text) : {};
    }
    catch {
        body = { error: { code: 'INVALID_RESPONSE', message: text.slice(0, 180) } };
    }
    if (!res.ok || body?.ok === false) {
        const err = body?.error || {};
        const tradingErrors = {
            EXECUTION_VOLUME_EXCEEDS_RISK_BUDGET: ['حجم معامله از بودجه ریسک انتخابی بیشتر است؛ حجم را کم کنید.', 'Trade volume exceeds your risk budget. Reduce the volume.'],
            ACCOUNT_CURRENCY_CONVERSION_REQUIRED: ['محاسبه ریسک این معامله به تبدیل ارز معتبر نیاز دارد؛ فعلاً حساب USD یا USDT را انتخاب کنید.', 'This trade requires a verified currency conversion. Use a USD or USDT account for now.'],
            BROKER_ACCOUNT_NOT_AUTHORIZED: ['اتصال بروکر این حساب هنوز توسط مدیریت تأیید نشده است.', 'This account has not been authorized for broker sync by the operator.'],
            BROKER_ACCOUNT_REFERENCE_FORBIDDEN: ['اتصال انتخاب‌شده متعلق به این حساب نیست.', 'The selected broker connection does not belong to this account.'],
            INVALID_CLOSE_FRACTION: ['مقدار خروج باید بیشتر از صفر و حداکثر یک باشد.', 'Close fraction must be greater than zero and at most one.']
        };
        const code = err.code || err.message;
        const friendly = tradingErrors[code];
        const e = new Error(friendly ? friendly[state.lang === 'fa' ? 0 : 1] : err.message || err.code || `HTTP ${res.status}`);
        e.code = err.code || `HTTP_${res.status}`;
        e.httpStatus = res.status;
        e.requestId = err.request_id || res.headers.get('X-Request-ID');
        if(e.requestId) e.message += ` (${state.lang==='fa'?'پیگیری':'Reference'}: ${e.requestId})`;
        throw e;
    }
    setConnection('online');
    return unwrap(body);
}
catch (err) {
    if (err.name === 'AbortError')
        err.message = state.lang === 'fa' ? 'زمان پاسخ سرور تمام شد.' : 'Request timed out.';
    if (authRecovery && !String(path).includes('/api/v1/auth/') && ['UNAUTHORIZED', 'CSRF_INVALID'].includes(String(err?.code || ''))) {
        await renewAuthenticatedSession();
        return request(path, { ...options, authRecovery: false }, timeout);
    }
    if (!navigator.onLine || err.name === 'TypeError' || err.name === 'AbortError')
        setConnection('offline');
    throw err;
}
finally {
    clearTimeout(timer);
} }
async function action(name, payload = {}, showBusy = true) {
    const flightKey = `${name}:${JSON.stringify(payload)}`;
    if (actionInflight.has(flightKey)) return actionInflight.get(flightKey);
    const forms=Array.from(document.querySelectorAll('#modalBody form'));
    if (showBusy) setBusy(true);
    const task=(async()=>{
        const key=await stableActionKey(name,payload);
        try {
            const envelope=await request(`./api/v1/actions/${encodeURIComponent(name)}`, {method:'POST',csrf:true,
                headers:{'Content-Type':'application/json','Idempotency-Key':key.id},body:JSON.stringify({payload,request_id:key.id})},30000);
            completeActionKey(key);
            for (const form of /create|update|submit|reply|purchase|approve|reject|close|accept|delete|import|execute|publish|cancel|claim|pair|revoke|rename|complete/.test(name) ? forms : []) {try {sessionStorage.removeItem(draftKey(form));} catch {} form.dataset.draftCommitted='true';}
            return envelope && typeof envelope==='object' && Object.prototype.hasOwnProperty.call(envelope,'action') && Object.prototype.hasOwnProperty.call(envelope,'data') ? envelope.data : envelope;
        } catch (err) {
            if (err.httpStatus && err.httpStatus<500 && !['IDEMPOTENCY_IN_PROGRESS','IDEMPOTENCY_CONFLICT','ACTION_IN_PROGRESS','REQUEST_IN_PROGRESS'].includes(err.code)) completeActionKey(key);
            throw err;
        }
    })();
    actionInflight.set(flightKey,task);
    try {return await task;} finally {actionInflight.delete(flightKey);if(showBusy)setBusy(false);}
}

function telegramInitDataFromLocation() { for (const raw of [location.hash.slice(1), location.search.slice(1)]) {
    if (!raw)
        continue;
    try {
        const value = new URLSearchParams(raw).get('tgWebAppData');
        if (value && value.includes('hash='))
            return value;
    }
    catch { }
} return ''; }
async function waitForTelegramInitData(timeout = 6000) { const deadline = Date.now() + timeout; do {
    tg = window.Telegram?.WebApp || tg;
    const value = String(tg?.initData || telegramInitDataFromLocation() || '').trim();
    if (value)
        return value;
    await sleep(120);
} while (Date.now() < deadline); return ''; }
async function navigateWorkspaceBack(){
    if(state.pageBackPending)return;
    state.pageBackPending=true;
    try{
        const parent=state.pageHistory.pop()||(['risk','journal'].includes(state.page)?'trading':'home');
        await navigate(parent,false);
    }catch(err){toast(err.message||t('error'),'error');}finally{state.pageBackPending=false;}
}
function handleTelegramBack() {
    const modal=$('#modalLayer');
    if (modal && !modal.hidden) {
        closeModal();
        return;
    }
    if(state.page && state.page!=='home')return navigateWorkspaceBack();
    // Release at the root so Telegram owns its system Back gesture.
    releaseTelegramNavigation(true);
}
function syncTelegramNavigation() {
    tg = window.Telegram?.WebApp || tg;
    try {
        tg?.disableClosingConfirmation?.();
        tg?.enableVerticalSwipes?.();
        const modalOpen = Boolean($('#modalLayer') && !$('#modalLayer').hidden);
        state.telegramBackMode = modalOpen ? 'modal' : 'none';
        const pageOpen=Boolean(state.page && state.page!=='home');
        if(!modalOpen && pageOpen)state.telegramBackMode='page';
        if (modalOpen || pageOpen) {
            if (!state.telegramNavigationInstalled) {
                tg?.BackButton?.offClick?.(handleTelegramBack);
                tg?.BackButton?.onClick?.(handleTelegramBack);
                state.telegramNavigationInstalled = true;
            }
            tg?.BackButton?.show?.();
            if (modalOpen && state.mainButtonHandler) {
                tg?.MainButton?.offClick?.(state.mainButtonHandler);
                tg?.MainButton?.onClick?.(state.mainButtonHandler);
                tg?.MainButton?.show?.();
            }else tg?.MainButton?.hide?.();
        }
        else {
            tg?.BackButton?.offClick?.(handleTelegramBack);
            state.telegramNavigationInstalled = false;
            tg?.BackButton?.hide?.();
            tg?.MainButton?.hide?.();
        }
    }
    catch { }
}
function installTelegramNavigation() {
    tg = window.Telegram?.WebApp || tg;
    if (!tg?.BackButton) return;
    syncTelegramNavigation();
}
function releaseTelegramNavigation(detach = false) {
    tg = window.Telegram?.WebApp || tg;
    try {
        tg?.disableClosingConfirmation?.();
        tg?.enableVerticalSwipes?.();
        tg?.BackButton?.hide?.();
        tg?.MainButton?.hide?.();
        if (state.mainButtonHandler) tg?.MainButton?.offClick?.(state.mainButtonHandler);
        state.telegramBackMode = 'none';
        if (detach) {
            tg?.BackButton?.offClick?.(handleTelegramBack);
            state.telegramNavigationInstalled = false;
        }
    }
    catch { }
}
function prepareTelegramChrome() { tg = window.Telegram?.WebApp || tg; tg?.ready?.(); tg?.expand?.(); try {
    tg?.setHeaderColor?.('#10151d');
    tg?.setBackgroundColor?.('#10151d');
    tg?.setBottomBarColor?.('#151c26');
    tg?.disableClosingConfirmation?.();
    tg?.enableVerticalSwipes?.();
    tg?.BackButton?.hide?.();
    installTelegramNavigation();
}
catch { } }
async function activateAuthenticatedShell(auth) { state.preview = false; state.csrf = auth?.csrf_token || ''; state.loaded.clear(); $('#app')?.classList.remove('auth-required'); $('#previewBanner').hidden = true; errorSummary(''); await loadOverview(true); finishSplash(); renderChrome(); connectEvents(); startLivePricePolling(); await applyDeepLink(); setTimeout(maybeShowOnboarding, 360); setTimeout(async () => { try {
    const feed = await loadResource('feed', true);
    checkFeedUpdates(feed?.items || [], true);
    if (state.page === 'home')
        renderHome();
}
catch { } }, 40); }
async function authenticateWithTelegram(initData) { const auth = await request('./api/v1/auth/bootstrap', { method: 'POST', headers: { 'X-Telegram-Init-Data': initData } }, 20000); await activateAuthenticatedShell(auth); }
async function signedSessionAuth() { return request('./api/v1/auth/session', {}, 6500); }
async function resumeSignedSession() { const auth = await signedSessionAuth(); await activateAuthenticatedShell(auth); }
function isRecoverableTelegramAuthError(err) { return ['INIT_DATA_MISSING', 'INIT_DATA_EXPIRED', 'INIT_DATA_REPLAYED', 'RATE_LIMITED'].includes(String(err?.code || '')); }
function renderAccessGate(err) { state.preview = true; state.online = false; state.eventSource?.close?.(); state.eventSource = null; clearInterval(state.livePriceTimer); const message = err?.message || 'اطلاعات ورود تلگرام دریافت نشد.'; const code = err?.code || 'INIT_DATA_MISSING'; $('#app').classList.add('auth-required'); $('#previewBanner').hidden = true; errorSummary(''); setConnection('offline', 'ورود امن تلگرام تکمیل نشده است'); $('#page-home').innerHTML = `<section class="auth-gate" aria-labelledby="authGateTitle"><div class="auth-gate-icon">${icon('shield')}</div><small>SECURE TELEGRAM ACCESS</small><h1 id="authGateTitle">ورود به SENTINEL تکمیل نشد</h1><p>${esc(message)}</p><ol><li>این صفحه را کامل ببندید.</li><li>به گفت‌وگوی ربات برگردید.</li><li>دکمه <strong>SENTINEL</strong> پایین صفحه یا دکمه Mini App داخل منو را بزنید.</li></ol><div class="auth-gate-actions"><button class="button primary" type="button" data-auth-retry>${icon('refresh')} تلاش دوباره</button>${tg?.close ? `<button class="button secondary" type="button" data-close-app>بستن مینی‌اپ</button>` : ''}</div><details><summary>جزئیات تشخیص</summary><code>${esc(code)}</code><span>${tg ? 'Telegram WebView شناسایی شد؛ اطلاعات امضاشده هنوز نرسیده است.' : 'این صفحه خارج از محیط Web App تلگرام باز شده است.'}</span></details></section>`; $$('.page').forEach(el => el.classList.toggle('active', el.dataset.page === 'home')); finishSplash(); }
async function retryTelegramAuthentication() { setBusy(true, 'در حال دریافت مجوز تلگرام…'); try {
    prepareTelegramChrome();
    const initData = await waitForTelegramInitData(6000);
    if (initData) {
        await authenticateWithTelegram(initData);
        return;
    }
    try {
        await resumeSignedSession();
        return;
    }
    catch { }
    renderAccessGate(Object.assign(new Error('اطلاعات ورود تلگرام هنوز دریافت نشده است؛ صفحه را ببندید و از دکمه پایین ربات دوباره وارد شوید.'), { code: 'INIT_DATA_MISSING' }));
}
catch (err) {
    renderAccessGate(err);
}
finally {
    setBusy(false);
} }
async function bootstrap() { prepareTelegramChrome(); setConnection('loading', 'در حال بررسی ورود امن تلگرام…'); const immediate = String(tg?.initData || telegramInitDataFromLocation() || '').trim(); let recoverableError = null; if (immediate) {
    try {
        await authenticateWithTelegram(immediate);
        return;
    }
    catch (err) {
        if (isRecoverableTelegramAuthError(err)) {
            recoverableError = err;
            try {
                await resumeSignedSession();
                return;
            }
            catch { }
        }
        else {
            renderAccessGate(err);
            return;
        }
    }
} const sessionTask = signedSessionAuth().then(auth => ({ ok: true, auth })).catch(error => ({ ok: false, error })); const initData = await waitForTelegramInitData(); if (initData) {
    try {
        await authenticateWithTelegram(initData);
        return;
    }
    catch (err) {
        if (isRecoverableTelegramAuthError(err)) {
            recoverableError = err;
            try {
                const session = await sessionTask;
                if (session.ok) {
                    await activateAuthenticatedShell(session.auth);
                    return;
                }
            }
            catch { }
        }
        else {
            renderAccessGate(err);
            return;
        }
    }
} const session = await sessionTask; if (session.ok) {
    await activateAuthenticatedShell(session.auth);
    return;
} const lateInit = await waitForTelegramInitData(4000); if (lateInit && lateInit !== immediate) {
    try {
        await authenticateWithTelegram(lateInit);
        return;
    }
    catch (err) {
        if (!isRecoverableTelegramAuthError(err)) {
            renderAccessGate(err);
            return;
        }
        recoverableError = err;
    }
} renderAccessGate(recoverableError || Object.assign(new Error('اطلاعات ورود تلگرام دریافت نشد؛ از دکمه Mini App داخل ربات وارد شوید.'), { code: 'INIT_DATA_MISSING' })); }
const SPLASH_DURATION_MS = 250;
let splashAppReady = false, splashVideoDone = false, splashDeadlineElapsed = false, splashReleased = false, splashDeadlineTimer = null;
function freezeBackgroundVideo() { const video = $('#appBackgroundVideo'); if (!video)
    return; video.dataset.finished = 'true'; video.pause(); if (Number.isFinite(video.duration) && video.duration > .08) {
    try {
        video.currentTime = Math.max(0, video.duration - .06);
    }
    catch { }
} }
function startBackgroundVideo() { if (!document.body.classList.contains("cinematic-mode")) return; const layer = $('#ambientVideoLayer'), video = $('#appBackgroundVideo'); layer?.classList.add('active'); if (!video || video.dataset.finished === 'true')
    return; const source = video.querySelector('source[data-src]'); if (source && !source.src) {
    source.src = source.dataset.src || '';
    video.load();
} video.muted = true; video.defaultMuted = true; video.playsInline = true; video.currentTime = 0; const play = video.play(); if (play?.catch)
    play.catch(() => { freezeBackgroundVideo(); }); }
function resumeBackgroundVideo() { if (!document.body.classList.contains("cinematic-mode")) return; const video = $('#appBackgroundVideo'); if (!video || video.dataset.finished === 'true' || document.hidden)
    return; const remaining = Number.isFinite(video.duration) ? video.duration - video.currentTime : 1; if (remaining > .12) {
    const play = video.play();
    if (play?.catch)
        play.catch(() => { });
}
else
    freezeBackgroundVideo(); }
function maybeReleaseSplash() { if (splashReleased || !splashDeadlineElapsed)
    return; splashReleased = true; clearTimeout(splashDeadlineTimer); const app = $('#app'), splash = $('#splash'); if (app)
    app.hidden = false; startBackgroundVideo(); if (!splash)
    return; splash.classList.add('done'); splash.remove(); }
function markSplashVideoDone() { splashVideoDone = true; }
function prepareMotionExperience() { const intro = $('#loadingVideo'), background = $('#appBackgroundVideo'); background?.addEventListener('ended', freezeBackgroundVideo); background?.addEventListener('error', freezeBackgroundVideo, { once: true }); const startedAt = performance.now(); const releaseAtFourSeconds = () => { const remaining = SPLASH_DURATION_MS - (performance.now() - startedAt); if (remaining > 20) {
        splashDeadlineTimer = setTimeout(releaseAtFourSeconds, remaining);
        return;
    } splashDeadlineElapsed = true; maybeReleaseSplash(); }; splashDeadlineTimer = setTimeout(releaseAtFourSeconds, SPLASH_DURATION_MS); if (!intro)
    return; intro.muted = true; intro.defaultMuted = true; intro.playsInline = true; intro.currentTime = 0; intro.addEventListener('ended', markSplashVideoDone, { once: true }); intro.addEventListener('error', markSplashVideoDone, { once: true }); const play = intro.play(); if (play?.catch)
    play.catch(() => { }); }
function finishSplash() { splashAppReady = true; maybeReleaseSplash(); }
function demoOverview() { return { user: { first_name: 'SENTINEL', language: 'fa' }, account: { active_signals: 4, vip_active: false, points: 120 }, risk: { accounts: [{ id: 1, name: 'Primary Account', currency: 'USD', balance: 10000, equity: 10000, type: 'personal', is_default: true, risk_enabled: true }], default_account: { id: 1, name: 'Primary Account', currency: 'USD', balance: 10000, equity: 10000 }, account_exposure: { open_risk_percent: 1.2, daily_risk_percent: 1.2, remaining_daily_risk_percent: 1.8, open_trades: 1 }, prop: { status: 'safe' }, what_if: { all_stops_loss_amount: -120, worst_case_drawdown_percent: 1.2 }, correlation: { clusters: [] } }, journal_stats: { win_rate: 64.3, closed: 28, pnl_sum: 12.8, max_drawdown: 3.4 }, revision_count: 1, features: {}, today_actions: [{ type: 'revision', priority: 'high', count: 1, target: 'revisions' }], notifications: { signals: true, results: true, news: true, calendar: true, support: true, alerts: true, quiet_enabled: true, quiet_start: '23:00', quiet_end: '07:00', timezone: 'Asia/Tehran', markets: [], symbols: [] }, bot_username: 'SENTINEL_bot', recent_signals: [{ id: 1, display_number: 318, symbol: 'XAUUSD', side: 'buy', entry: '2418–2421', stop: '2409', targets: ['2432', '2444'], risk: '1', status: 'open', risk_reward: '2.4', quote: { price: 2420.4, updated_at: new Date().toISOString() }, entry_state: { missed: false, risk_reward: 2.3 }, choice: {} }], commerce: { plans: [], payment: {} }, rules: { accepted: true }, onboarding: { completed: true, recommendation: { home_mode: 'professional' } }, generated_at: new Date().toISOString() }; }
function renderFatal(err) { $('#page-home').innerHTML = `<div class="panel"><div class="empty">${icon('alert')}<h2>${esc(t('error'))}</h2><p>${esc(err.message)}</p><button class="button" data-reload>${esc(t('retry'))}</button></div></div>`; }
async function loadOverview(force = false) { if (state.preview)
    return state.resources.overview; if (!force && state.loaded.has('overview'))
    return state.resources.overview; if (overviewInflight)
    return overviewInflight; overviewInflight = (async () => { const data = await request('./api/v1/overview'); state.resources.overview = data; const savedLanguage = localStorage.getItem('sentinelLanguage'); state.lang = ['fa', 'en'].includes(savedLanguage) ? savedLanguage : (data.user?.language === 'en' ? 'en' : 'fa'); state.loaded.add('overview'); if (!state.selectedAccount)
    state.selectedAccount = data.risk?.default_account?.id || null; applyLanguage(); return data; })(); try {
    return await overviewInflight;
}
finally {
    overviewInflight = null;
} }
function resourceRoute(key, cursor = '', force = false) { const q = new URLSearchParams({ limit: String(state.pageSize) }); if (cursor)
    q.set('cursor', String(cursor)); if (force && ['signals', 'market'].includes(key))
    q.set('live', '1'); if (key === 'signals') {
    if (state.signalFilter === 'open')
        q.set('status', 'open');
    if (['forex', 'crypto'].includes(state.signalFilter))
        q.set('market', state.signalFilter);
    if (['public', 'vip'].includes(state.signalAccessFilter))
        q.set('scope', state.signalAccessFilter);
    if (state.signalQuery.trim())
        q.set('q', state.signalQuery.trim());
} if (key === 'journal') {
    if (state.journalFilter !== 'all')
        q.set('status', state.journalFilter);
    if (state.journalQuery.trim())
        q.set('q', state.journalQuery.trim());
} if (key === 'orders' && state.orderFilter !== 'all')
    q.set('status', state.orderFilter); if (key === 'tickets' && state.ticketFilter !== 'all')
    q.set('status', state.ticketFilter); const routes = { hub: `./api/v1/user-hub?limit=20&cursor=${typeof pointCursor==='number'?pointCursor:0}`, signals: `./api/v1/signals?${q}`, risk: `./api/v1/risk${state.selectedAccount ? `?account_id=${state.selectedAccount}` : ''}`, journal: `./api/v1/journal?${q}`, feed: './api/v1/feed?limit=60', expansion: './api/v1/expansion', market: `./api/v1/market${force ? '?live=1' : ''}`, calendar: `./api/v1/calendar?${q}`, orders: `./api/v1/orders?${q}`, tickets: `./api/v1/tickets?${q}`, contests: './api/v1/contests', track: `./api/v1/track-record?${q}`, revisions: './api/v1/revisions', adminOps: './api/v1/admin/operations', adminAudit: './api/v1/admin/audit?limit=50', adminExperiments: './api/v1/admin/experiments', adminCampaigns: './api/v1/admin/campaigns?limit=50', adminOrders: './api/v1/admin/orders?limit=50', adminTickets: './api/v1/admin/tickets?limit=50', adminTemplates: './api/v1/admin/signal-templates', adminIntegration: './api/v1/admin/integration', adminPlatform: './api/v1/admin/platform', adminCapabilities: './api/v1/admin/capabilities', adminSignalCycles: './api/v1/admin/signal-cycles?limit=100', adminSignalJobs: './api/v1/admin/signal-jobs?limit=50', adminUsers: './api/v1/admin/users?limit=100', adminAdmins: './api/v1/admin/admins', adminSignals: './api/v1/admin/signals?limit=100', ai: './api/v1/ai?limit=30', adminAI: './api/v1/admin/ai?limit=50', adminVipPlans: './api/v1/admin/vip-plans' }; return routes[key] || ''; }
async function loadResource(key, force = false, append = false) {
    if (state.preview) return state.resources[key];
    const existing = state.resources[key];
    if (append && existing?.next_cursor == null) return existing;
    const cursor = append ? String(existing?.next_cursor || '') : '';
    const route = resourceRoute(key, cursor, force);
    if (!route) return null;
    state.resourceRequests ??= new Map();
    state.resourceEpochs ??= new Map();
    state.resourceRoutes ??= new Map();
    if (!force && !append && state.loaded.has(key) &&
        (!state.resourceRoutes.has(key) || state.resourceRoutes.get(key) === route)) return existing;
    const epoch = state.resourceEpochs.get(key) || 0;
    const flightKey = `${key}:${route}:${append ? 'append' : 'replace'}:${epoch}`;
    const active = state.resourceRequests.get(key);
    if (resourceInflight.has(flightKey) && active?.task === resourceInflight.get(flightKey)) return active.task;
    const token = { route, epoch, task: null };
    state.resourceRequests.set(key, token);
    const task = (async () => {
        const data = await request(route);
        const latest = state.resourceRequests.get(key);
        if (latest !== token) return latest?.task ? await latest.task : state.resources[key];
        // Invalidation or query changes make a response obsolete even when no
        // replacement request has completed yet. Never mark that cache loaded.
        if ((state.resourceEpochs.get(key) || 0) !== epoch || resourceRoute(key, cursor, force) !== route)
            return state.resources[key];
        if (append && existing && Array.isArray(existing.items) && Array.isArray(data.items)) {
            const known = new Set(existing.items.map(x => String(x.id)));
            state.resources[key] = { ...existing, ...data, items: [...existing.items, ...data.items.filter(x => !known.has(String(x.id)))] };
        } else state.resources[key] = data;
        state.resourceRoutes.set(key, route);
        state.loaded.add(key);
        return state.resources[key];
    })();
    token.task = task;
    resourceInflight.set(flightKey, task);
    try { return await task; }
    finally { if (resourceInflight.get(flightKey) === task) resourceInflight.delete(flightKey); }
}
function moreButton(key, data) { return data?.next_cursor != null ? `<div class="pagination-actions"><button class="button secondary" data-load-more="${key}">${state.lang === 'fa' ? 'بارگذاری بیشتر' : 'Load more'} · ${num((data.items || []).length, 0)}/${num(data.total || 0, 0)}</button></div>` : ''; }
async function loadMore(key) { setBusy(true); try {
    await loadResource(key, false, true);
    if (key === 'signals')
        await renderSignals();
    else if (key === 'journal')
        await renderJournal();
    else if (key === 'calendar')
        calendarModal();
    else if (key === 'orders')
        ordersModal();
    else if (key === 'tickets')
        supportModal();
    else if (key === 'track')
        trackModal();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function applyDeepLink() { const params = new URLSearchParams(location.search); const start = (tg?.initDataUnsafe?.start_param || params.get('tgWebAppStartParam') || params.get('startapp') || '').trim(); const explicitPage = params.has('page'), explicitOpen = params.has('open'); let page = params.get('page') || 'home', open = params.get('open') || ''; const bridgePages={referral:['more','referral'],missions:['more','missions'],education:['more','education'],vip:['more','vip'],support:['more','support'],contests:['more','contests'],account:['more',''],settings:['more','settings'],my_rewards:['rewards','']}; const bridge=bridgePages[start]; if(bridge){page=bridge[0];open=bridge[1];} const signal = params.get('signal') || (start.startsWith('signal_') ? start.slice(7) : ''); if (start && ['home', 'signals', 'risk', 'journal', 'more', 'trading', 'rewards'].includes(start))
    page = start; if (!['home', 'signals', 'risk', 'journal', 'more', 'trading', 'rewards'].includes(page))
    page = 'home'; await navigate(page, false); if (signal)
    await openSignal(signal);
else if (open)
    await openMore(open);
else if (!start && !explicitPage && !explicitOpen && state.resources.overview?.onboarding?.completed)
    await openMore('feed'); }
function maybeShowOnboarding() { const o = state.resources.overview || {}; if (!state.preview && !o.onboarding?.completed && o.rules?.accepted !== false && !location.search.includes('signal='))
    onboardingModal(); }
function onboardingModal() { const o = state.resources.overview?.onboarding || {}, a = state.resources.overview?.risk?.default_account || {}; openModal('SENTINEL SETUP', t('onboarding'), `<form id="onboardingForm" novalidate><div class="notice info"><strong>${state.lang === 'fa' ? 'راه‌اندازی یک‌باره حساب' : 'One-time account setup'}</strong><p>${state.lang === 'fa' ? 'این اطلاعات در حساب شما ذخیره می‌شود و در ورودهای بعدی دوباره پرسیده نخواهد شد.' : 'These details are saved to your account and will not be requested again.'}</p></div><div class="form-grid"><div class="field"><label for="onboardAccountName">${state.lang === 'fa' ? 'نام حساب' : 'Account name'}</label><input id="onboardAccountName" required minlength="2" maxlength="80" value="${esc(o.account_name || a.name || (state.lang === 'fa' ? 'حساب 1' : 'Account 1'))}"></div><div class="field"><label for="onboardBalance">${esc(t('balance'))} (USD)</label><input id="onboardBalance" inputmode="decimal" min="1" required value="${esc(o.balance || o.account_size || a.balance || '')}" placeholder="10000"></div><div class="field"><label for="onboardEquity">${esc(t('equity'))} (USD)</label><input id="onboardEquity" inputmode="decimal" min="1" required value="${esc(o.equity || a.equity || o.balance || o.account_size || '')}" placeholder="10000"></div><div class="field"><label for="onboardProfessional">${state.lang === 'fa' ? 'تریدر حرفه‌ای هستید؟' : 'Professional trader?'}</label><select id="onboardProfessional" required><option value="no" ${!o.professional ? 'selected' : ''}>${state.lang === 'fa' ? 'خیر' : 'No'}</option><option value="yes" ${o.professional ? 'selected' : ''}>${state.lang === 'fa' ? 'بله' : 'Yes'}</option></select></div><div class="field"><label for="onboardExperience">${esc(t('experience'))}</label><select id="onboardExperience" required><option value="beginner" ${o.experience === 'beginner' ? 'selected' : ''}>${state.lang === 'fa' ? 'مبتدی' : 'Beginner'}</option><option value="intermediate" ${!o.experience || o.experience === 'intermediate' ? 'selected' : ''}>${state.lang === 'fa' ? 'متوسط' : 'Intermediate'}</option><option value="advanced" ${o.experience === 'advanced' ? 'selected' : ''}>${state.lang === 'fa' ? 'حرفه‌ای' : 'Advanced'}</option><option value="professional" ${o.experience === 'professional' ? 'selected' : ''}>${state.lang === 'fa' ? 'تریدر حرفه‌ای' : 'Professional trader'}</option></select></div><div class="field"><label for="onboardMarket">${esc(t('market'))}</label><select id="onboardMarket"><option value="both" ${!o.market || o.market === 'both' ? 'selected' : ''}>Forex + Crypto</option><option value="forex" ${o.market === 'forex' ? 'selected' : ''}>Forex</option><option value="crypto" ${o.market === 'crypto' ? 'selected' : ''}>Crypto</option></select></div><div class="field"><label for="onboardRisk">${esc(t('riskTolerance'))}</label><select id="onboardRisk"><option value="conservative" ${o.risk_tolerance === 'conservative' ? 'selected' : ''}>${state.lang === 'fa' ? 'محافظه‌کار' : 'Conservative'}</option><option value="balanced" ${!o.risk_tolerance || o.risk_tolerance === 'balanced' ? 'selected' : ''}>${state.lang === 'fa' ? 'متعادل' : 'Balanced'}</option><option value="aggressive" ${o.risk_tolerance === 'aggressive' ? 'selected' : ''}>${state.lang === 'fa' ? 'تهاجمی کنترل‌شده' : 'Controlled aggressive'}</option></select></div><div class="field"><label for="onboardGoal">${esc(t('goal'))}</label><select id="onboardGoal" required><option value="signals" ${!o.goal || o.goal === 'signals' ? 'selected' : ''}>${state.lang === 'fa' ? 'دریافت و مدیریت سیگنال' : 'Signal decisions'}</option><option value="education" ${o.goal === 'education' ? 'selected' : ''}>${state.lang === 'fa' ? 'آموزش' : 'Education'}</option><option value="prop" ${o.goal === 'prop' ? 'selected' : ''}>Prop Firm</option><option value="journal" ${o.goal === 'journal' ? 'selected' : ''}>${state.lang === 'fa' ? 'ژورنال و تحلیل شخصی' : 'Journal & analytics'}</option></select></div></div></form>`, [{ label: t('completeSetup'), kind: 'primary', action: async () => { const f = $('#onboardingForm'); if (!f?.reportValidity())
            return; const balance = Number($('#onboardBalance').value), equity = Number($('#onboardEquity').value); if (!(balance > 0 && equity > 0)) {
            toast(state.lang === 'fa' ? 'موجودی و Equity باید بیشتر از صفر باشند.' : 'Balance and equity must be greater than zero.', 'error');
            return;
        } setBusy(true); try {
            const result = await action('onboarding_update', { account_name: $('#onboardAccountName').value.trim(), balance, equity, account_size: balance, professional: $('#onboardProfessional').value === 'yes', experience: $('#onboardProfessional').value === 'yes' ? 'professional' : $('#onboardExperience').value, market: $('#onboardMarket').value, risk_tolerance: $('#onboardRisk').value, goal: $('#onboardGoal').value, currency: 'USD' }, false);
            state.resources.overview = { ...(state.resources.overview || {}), onboarding: { ...(result.onboarding || {}), completed: true }, risk: { ...(state.resources.overview?.risk || {}), default_account: result.account, accounts: [result.account] } };
            state.selectedAccount = result.account?.id || state.selectedAccount;
            closeModal();
            invalidate('overview', 'risk');
            await loadOverview(true);
            renderChrome();
            renderHome();
            toast(t('success'));
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function actionTarget(item) { const target = item?.target || ''; if (['risk', 'signals', 'journal', 'home', 'more','trading','rewards'].includes(target))
    return `data-page-target="${target}"`; return `data-open="${esc(target)}"`; }
function todayActionsHtml(items = []) { if (!items.length)
    return ''; const labels = { onboarding: state.lang === 'fa' ? 'پروفایل معامله‌گری خود را تکمیل کنید' : 'Complete your trading profile', revision: state.lang === 'fa' ? 'تغییر مهم سیگنال نیاز به تأیید دارد' : 'A signal revision needs acknowledgement', risk_exhausted: state.lang === 'fa' ? 'ظرفیت ریسک حساب تمام شده است' : 'Account risk capacity is exhausted', risk_low: state.lang === 'fa' ? 'ظرفیت ریسک روزانه رو به پایان است' : 'Daily risk capacity is running low', prop_breach: state.lang === 'fa' ? 'هشدار نقض قوانین پراپ' : 'Prop rule breach warning', pending_order: state.lang === 'fa' ? 'سفارش در حال بررسی' : 'Order under review', open_ticket: state.lang === 'fa' ? 'تیکت پشتیبانی باز' : 'Open support ticket' }; return `<section class="panel action-center"><div class="panel-head"><div><small class="eyebrow">TODAY</small><h2>${esc(t('todayActions'))}</h2></div></div><div class="panel-body action-list">${items.map(item => `<button class="action-item ${esc(item.priority || 'normal')}" ${actionTarget(item)}>${icon(item.priority === 'critical' ? 'alert' : 'bell')}<span><strong>${esc(labels[item.type] || item.type)}</strong><small>${item.count ? num(item.count, 0) : item.remaining != null ? pct(item.remaining) : ''}</small></span>${icon('chevron')}</button>`).join('')}</div></section>`; }
function renderChrome() { const o = state.resources.overview || {}; $('#greeting').textContent = t('welcome'); $('#displayName').textContent = o.user?.first_name || t('member'); $('#languageButton').textContent = state.lang === 'fa' ? 'EN' : 'FA'; const count = Number(o.account?.active_signals || 0); $('#signalNavBadge').hidden = !count; $('#signalNavBadge').textContent = num(count, 0); const rev = Number(o.revision_count || 0); $('#revisionBadge').hidden = !rev; $('#revisionBadge').textContent = num(rev, 0); $('#moreNavBadge').hidden = !rev; $('#moreNavBadge').textContent = num(rev, 0); $$('[data-i18n]').forEach(el => el.textContent = t(el.dataset.i18n)); const labels = state.lang === 'fa' ? { profile: 'حساب کاربری', revisions: 'تغییرات مهم سیگنال‌ها', refresh: 'تازه‌سازی', language: 'تغییر زبان', main: 'ناوبری اصلی', home: 'خانه', signals: 'سیگنال‌ها', risk: 'مدیریت ریسک', journal: 'ژورنال معاملاتی', more: 'امکانات بیشتر', close: 'بستن' } : { profile: 'User account', revisions: 'Important signal revisions', refresh: 'Refresh', language: 'Change language', main: 'Main navigation', home: 'Home', signals: 'Signals', risk: 'Risk management', journal: 'Trading journal', more: 'More tools', close: 'Close' }; $('#profileButton')?.setAttribute('aria-label', labels.profile); $('#revisionButton')?.setAttribute('aria-label', labels.revisions); $('#refreshButton')?.setAttribute('aria-label', labels.refresh); $('#languageButton')?.setAttribute('aria-label', labels.language); $('.bottom-nav')?.setAttribute('aria-label', labels.main); $('#page-home')?.setAttribute('aria-label', labels.home); $('#page-signals')?.setAttribute('aria-label', labels.signals); $('#page-risk')?.setAttribute('aria-label', labels.risk); $('#page-journal')?.setAttribute('aria-label', labels.journal); $('#page-more')?.setAttribute('aria-label', labels.more); $('[data-close-modal]')?.setAttribute('aria-label', labels.close); if (state.lang === 'en') localizeUiTree(document); }
function pageHead(eyebrow, title, desc, action = '') { return `<div class="page-header"><div><span class="eyebrow">${esc(eyebrow)}</span><h1>${esc(title)}</h1><p>${esc(desc)}</p></div>${action}</div>`; }
function skeleton(count = 3) { return `<div class="signal-list">${Array.from({ length: count }, () => '<div class="skeleton"></div>').join('')}</div>`; }
function empty(message = t('noData')) { return `<div class="empty">${icon('chart')}<p>${esc(message)}</p></div>`; }
function metric(label, value, sub = '', tone = '') { return `<div class="metric ${tone}"><span>${esc(label)}</span><strong>${value}</strong>${sub ? `<small>${esc(sub)}</small>` : ''}</div>`; }
function renderHome() {
    const o = state.resources.overview || demoOverview(), r = o.risk || {}, ex = r.account_exposure || {}, j = o.journal_stats || {};
    $('#page-home').innerHTML = `
 <article class="hero"><img class="hero-image" src="./assets/brand/sentinel-signals.8dd7e47f85.webp" alt="" loading="eager"><div class="hero-copy"><span class="eyebrow">SENTINEL TRADING OS</span><h1>${esc(t('decisionCenter'))}</h1><p>${state.lang === 'fa' ? 'سیگنال را فقط نبین؛ اثر آن بر ریسک حساب، قیمت فعلی، اخبار و ژورنال شخصی‌ات را قبل از ورود بررسی کن.' : 'Do not just view a signal. Validate its live price, account risk, news context and personal journal impact before execution.'}</p><div class="hero-actions"><button class="button" data-page-target="signals">${icon('signal')}${esc(t('viewAll'))}</button><button class="button secondary" data-page-target="risk">${icon('shield')}${esc(t('riskOS'))}</button><button class="button ghost" data-open="search">${icon('search')}${esc(t('globalSearch'))}</button></div></div></article>
 ${todayActionsHtml(o.today_actions || [])}<div class="metric-grid">${metric(t('activeSignals'), num(o.account?.active_signals || 0, 0), '', 'info')}${metric(t('openRisk'), pct(ex.open_risk_percent || 0), '', 'warn')}${metric(t('dailyRisk'), pct(ex.daily_risk_percent || 0), '', 'info')}${metric(t('journalWin'), pct(j.win_rate || 0), '', 'good')}</div>
 <section class="panel"><div class="panel-head"><div><small class="eyebrow">WORKFLOW</small><h2>${esc(state.lang === 'fa' ? 'تصمیم‌گیری یکپارچه' : 'Integrated decision flow')}</h2></div></div><div class="panel-body"><div class="quick-grid">
 ${quick('signal', t('decisionCenter'), state.lang === 'fa' ? 'تحلیل، ورود و ثبت Taken' : 'Analyze, execute and track', 'signals')}
 ${quick('shield', t('riskOS'), state.lang === 'fa' ? 'چند حساب، پراپ و سناریو' : 'Multi-account, prop and scenarios', 'risk')}
 ${quick('journal', t('tradeJournal'), state.lang === 'fa' ? 'نتایج واقعی و رفتار معاملاتی' : 'Actual results and behavior', 'journal')}
 ${quick('chart', t('trust'), state.lang === 'fa' ? 'آمار شفاف و تاریخچه ویرایش' : 'Transparent performance and revisions', 'track')}
 </div></div></section>
 <section class="panel"><div class="panel-head"><div><small class="eyebrow">RECENT</small><h2>${esc(t('signals'))}</h2></div><button class="button ghost small" data-page-target="signals">${esc(t('viewAll'))}</button></div><div class="panel-body signal-list">${(o.recent_signals || []).map(signalCard).join('') || empty()}</div></section>
 ${channelFeedPanel(state.resources.feed?.items || [])}`;
}
function quick(iconName, title, desc, target) { return `<button class="quick-card touch" data-${target === 'track' ? 'open' : 'page-target'}="${target}">${icon(iconName)}<span><strong>${esc(title)}</strong><small>${esc(desc)}</small></span></button>`; }
function signalTargetRHtml(s) { const rows = s.target_rr || s.entry_state?.target_rr || []; return rows.length ? `<div class="signal-rr-row">${rows.map(x => `<span class="tag">${esc(x.label)} · ${x.r == null ? '—' : `${num(x.r, 2)}R`}</span>`).join('')}</div>` : ''; }
function signalDecisionLabel(choice) { return choice === 'taken' ? (state.lang === 'fa' ? 'گرفته شد · در ژورنال' : 'Taken · journaled') : (state.lang === 'fa' ? 'نگرفتم' : 'Skipped'); }
function signalCard(s) { const sell = ['sell', 'short'].includes(String(s.side).toLowerCase()), q = s.quote || {}, entryState = s.entry_state || {}, choice = s.choice?.choice || '', locked = Boolean(s.decision_locked || choice), highest = Number(s.highest_target_hit || 0), status = String(s.status || 'open'), final = Boolean(s.is_final || ['closed','win','loss','sl','stop','stopped','tp','tp1','tp2','tp3','be','cancelled','canceled'].includes(status.toLowerCase())), statusLabel = highest ? `TP${highest} · ${status}` : status, activation = state.lang === 'fa' ? entryState.activation_text_fa : entryState.activation_text_en; return `<article class="signal-card ${sell ? 'sell' : ''}" data-signal-row="${esc(s.id)}"><div class="signal-top"><div class="signal-symbol"><span class="side-badge ${sell ? 'sell' : ''}">${esc(String(s.side || '').toUpperCase())}</span><strong>${esc(s.symbol)}</strong></div><span class="status-badge ${final ? (status === 'win' ? 'good' : 'bad') : 'good'}">#${num(s.display_number, 0)} · ${esc(statusLabel)}</span></div><div class="signal-levels"><div><span>${esc(t('currentPrice'))}</span><b>${num(q.price, 7)}</b></div><div><span>${esc(t('entry'))}</span><b>${esc(s.entry || entryState.entry_reference || '—')}</b></div><div><span>SL</span><b>${esc(s.stop || s.stop_loss || '—')}</b></div></div><div class="notice ${entryState.inside_entry_zone ? 'good' : 'info'}"><strong>${esc(activation || (state.lang === 'fa' ? 'قیمت لحظه‌ای در دسترس نیست' : 'Live price unavailable'))}</strong>${q.provider ? `<small>${esc(q.provider)} · ${date(q.updated_at || s.updated_at)}</small>` : ''}</div>${signalTargetRHtml(s)}<div class="signal-meta">${choice ? `<span class="status-badge ${choice === 'taken' ? 'good' : 'muted'}">${esc(signalDecisionLabel(choice))}</span>` : ''}</div><div class="card-actions"><button class="button small" data-signal-detail="${s.id}">${esc(t('details'))}</button>${final && !locked ? `<button class="button primary small" data-signal-retro="${s.id}" data-retro-choice="taken">${state.lang === 'fa' ? 'گرفتم' : 'Taken'}</button><button class="button ghost small" data-signal-retro="${s.id}" data-retro-choice="skipped">${state.lang === 'fa' ? 'نگرفتم' : 'Skipped'}</button>` : (!final && !locked ? `<button class="button primary small" data-signal-take="${s.id}">${state.lang === 'fa' ? 'بگیرش' : 'Take it'}</button><button class="button ghost small" data-signal-skip="${s.id}">${state.lang === 'fa' ? 'نمی‌گیرم' : 'Skip'}</button>` : '')}<button class="button secondary small" data-copy-signal="${s.id}">${icon('copy')}${esc(t('copy'))}</button></div></article>`; }
async function renderSignals(force = false) { const page = $('#page-signals'); if (!featureEnabled('signals')) {
    page.innerHTML = pageHead('SIGNALS', t('decisionCenter'), '') + disabledPanel();
    return;
} page.innerHTML = pageHead('SIGNALS', t('decisionCenter'), state.lang === 'fa' ? 'هر سیگنال را با وضعیت لحظه‌ای و اثر آن روی حساب بررسی کن.' : 'Evaluate every signal against live market context and your selected account.') + skeleton(4); try {
    const data = await loadResource('signals', force), rows = data?.items || [];
    page.innerHTML = pageHead('SIGNALS', t('decisionCenter'), state.lang === 'fa' ? 'هر سیگنال را با وضعیت لحظه‌ای و اثر آن روی حساب بررسی کن.' : 'Evaluate every signal against live market context and your selected account.') + `<div class="search-box">${icon('search')}<label class="sr-only" for="signalSearch">${esc(t('searchSignals'))}</label><input id="signalSearch" value="${esc(state.signalQuery)}" placeholder="${esc(t('searchSignals'))}"></div><div class="filters"><button class="filter-chip ${state.signalFilter === 'all' ? 'active' : ''}" data-signal-filter="all">${esc(t('all'))}</button><button class="filter-chip ${state.signalFilter === 'open' ? 'active' : ''}" data-signal-filter="open">${esc(t('open'))}</button><button class="filter-chip ${state.signalFilter === 'forex' ? 'active' : ''}" data-signal-filter="forex">${esc(t('forex'))}</button><button class="filter-chip ${state.signalFilter === 'crypto' ? 'active' : ''}" data-signal-filter="crypto">${esc(t('crypto'))}</button></div><div class="signal-list" style="margin-top:12px">${rows.map(signalCard).join('') || empty(t('noSignals'))}</div>${moreButton('signals', data)}`;
}
catch (err) {
    page.innerHTML = errorPanel(err, 'signals');
} }
function filteredSignals(rows) { return rows; }
async function openSignal(id) { setBusy(true); try {
    const q = new URLSearchParams({ live: '1' });
    if (state.selectedAccount)
        q.set('account_id', state.selectedAccount);
    const s = await request(`./api/v1/signals/${id}?${q}`);
    state.resources[`signal:${id}`] = s;
    showSignalModal(s);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function refreshSignalCardsDom(data) { const rows = data?.items || []; for (const signal of rows) {
    const current = document.querySelector(`[data-signal-row="${CSS.escape(String(signal.id))}"]`);
    if (current)
        current.outerHTML = signalCard(signal);
} }
function gateReasonLabel(code = '') { const labels = { TRADING_ACCOUNT_REQUIRED: { fa: 'برای محاسبه دقیق ریسک، ابتدا یک حساب معاملاتی انتخاب یا ایجاد کنید.', en: 'Select or create a trading account for full risk calculations.' }, ALL_RISK_CHECKS_PASSED: { fa: 'همه کنترل‌های فعال ریسک با موفقیت پاس شدند.', en: 'All enabled risk checks passed successfully.' }, DAILY_LOSS_LIMIT: { fa: 'محدودیت زیان روزانه اجازه ورود نمی‌دهد.', en: 'The daily loss limit blocks this entry.' }, TOTAL_DRAWDOWN_LIMIT: { fa: 'محدودیت افت کل حساب اجازه ورود نمی‌دهد.', en: 'The total drawdown limit blocks this entry.' }, MAX_OPEN_RISK: { fa: 'ریسک باز حساب از سقف مجاز عبور می‌کند.', en: 'Open account risk would exceed the limit.' }, MAX_OPEN_TRADES: { fa: 'تعداد معاملات باز به سقف مجاز رسیده است.', en: 'The maximum number of open trades has been reached.' }, STALE_ACCOUNT_DATA: { fa: 'اطلاعات حساب قدیمی است و باید تازه‌سازی شود.', en: 'Account data is stale and must be refreshed.' }, LOW_DATA_CONFIDENCE: { fa: 'اعتماد داده‌های حساب برای تصمیم قطعی کافی نیست.', en: 'Account data confidence is too low for a definitive decision.' } }; const row = labels[String(code || '').toUpperCase()]; return row ? (state.lang === 'fa' ? row.fa : row.en) : String(code || '').replaceAll('_', ' '); }
function gateHtml(g = {}) { const hard = Array.isArray(g.hard_blocks) ? g.hard_blocks : [], warnings = Array.isArray(g.warnings) ? g.warnings : [], raw = Array.isArray(g.reasons) && g.reasons.length ? g.reasons : [...hard.map(x => ({ ...x, severity: 'block' })), ...warnings.map(x => ({ ...x, severity: 'warning' }))], status = ['green', 'yellow', 'red'].includes(g.status) ? g.status : (hard.length ? 'red' : warnings.length ? 'yellow' : g.can_execute === false ? 'yellow' : 'green'), reasons = (raw.length ? raw : [{ code: 'ALL_RISK_CHECKS_PASSED', params: {}, severity: 'safe' }]).map(r => `<li class="${esc(r.severity || '')}"><strong>${esc(gateReasonLabel(r.code || r.rule || r.reason))}</strong>${r.params && Object.keys(r.params).length ? `<small>${esc(Object.entries(r.params).map(([k, v]) => `${k}: ${v}`).join(' · '))}</small>` : ''}</li>`).join(''), metrics = g.metrics && Object.keys(g.metrics).length ? `<div class="gate-metrics">${Object.entries(g.metrics).slice(0, 6).map(([k, v]) => `<span><b>${esc(String(k).replaceAll('_', ' '))}</b><em>${esc(typeof v === 'number' ? num(v, 3) : v)}</em></span>`).join('')}</div>` : ''; return `<div class="gate ${status}"><h3>${icon(status === 'green' ? 'check' : 'alert')}${esc(t('safetyGate'))} · ${esc(t(status))}</h3><ul>${reasons}</ul>${metrics}</div>`; }

function signalLifecycleLabel(event) { const key = String(event || '').toLowerCase(); const labels = { open: state.lang === 'fa' ? 'ثبت اولیه سیگنال' : 'Signal created', entry_hit: state.lang === 'fa' ? 'نقطه ورود فعال شد' : 'Entry activated', entry: state.lang === 'fa' ? 'نقطه ورود فعال شد' : 'Entry activated', tp1: state.lang === 'fa' ? 'تی پی ۱ خورد' : 'TP1 hit', tp2: state.lang === 'fa' ? 'تی پی ۲ خورد' : 'TP2 hit', tp3: state.lang === 'fa' ? 'تمام تارگت‌ها کامل شد' : 'All targets reached', target: state.lang === 'fa' ? 'تارگت ثبت شد' : 'Target reached', target_complete: state.lang === 'fa' ? 'تمام تارگت‌ها کامل شد' : 'All targets reached', win: state.lang === 'fa' ? 'سود کامل ثبت شد' : 'Full profit booked', stop: state.lang === 'fa' ? 'حد ضرر فعال شد' : 'Stop loss hit', stopped: state.lang === 'fa' ? 'حد ضرر فعال شد' : 'Stop loss hit', sl: state.lang === 'fa' ? 'حد ضرر فعال شد' : 'Stop loss hit', loss: state.lang === 'fa' ? 'زیان ثبت شد' : 'Loss recorded', be: state.lang === 'fa' ? 'بریک ایون شد' : 'Moved to break-even', breakeven: state.lang === 'fa' ? 'بریک ایون شد' : 'Moved to break-even', partial_close: state.lang === 'fa' ? 'بستن بخشی انجام شد' : 'Partial close executed', manual_close: state.lang === 'fa' ? 'سیگنال دستی بسته شد' : 'Manually closed', cancelled: state.lang === 'fa' ? 'سیگنال لغو شد' : 'Signal cancelled', expired: state.lang === 'fa' ? 'سیگنال منقضی شد' : 'Signal expired', no_entry: state.lang === 'fa' ? 'ورودی فعال نشد' : 'No entry' }; return labels[key] || key.replaceAll('_', ' '); }
function signalLifecycleTone(event) { const key = String(event || '').toLowerCase(); if (['stop','stopped','sl','loss'].includes(key)) return 'bad'; if (['tp1','tp2','tp3','target','target_complete','win','entry_hit','entry','breakeven'].includes(key)) return 'good'; return 'info'; }
function timeOnly(v) { if (!v) return '—'; const d = new Date(v); return Number.isNaN(d.getTime()) ? '—' : new Intl.DateTimeFormat(state.lang === 'fa' ? 'fa-IR' : 'en-GB', { hour: '2-digit', minute: '2-digit' }).format(d); }
function signalVisualStage(s) { const history = (s.lifecycle_report || s.lifecycle_history || []).filter(Boolean); const last = history.length ? history[history.length - 1] : null; const key = String(last?.event || s.media?.status_key || s.status || 'open').toLowerCase(); const map = { entry_hit: { key: 'entry-hit', src: './assets/status/entry-hit.png', label: state.lang === 'fa' ? 'ورود فعال شد' : 'Entry hit' }, entry: { key: 'entry-hit', src: './assets/status/entry-hit.png', label: state.lang === 'fa' ? 'ورود فعال شد' : 'Entry hit' }, tp1: { key: 'tp1-hit', src: './assets/status/tp1-hit.png', label: state.lang === 'fa' ? 'تی پی ۱' : 'TP1 hit' }, tp2: { key: 'tp2-hit', src: './assets/status/tp2-hit.png', label: state.lang === 'fa' ? 'تی پی ۲' : 'TP2 hit' }, tp3: { key: 'full-tp', src: './assets/status/full-tp.png', label: state.lang === 'fa' ? 'فول تی پی' : 'Full TP' }, target: { key: 'full-tp', src: './assets/status/full-tp.png', label: state.lang === 'fa' ? 'فول تی پی' : 'Full TP' }, target_complete: { key: 'full-tp', src: './assets/status/full-tp.png', label: state.lang === 'fa' ? 'فول تی پی' : 'Full TP' }, win: { key: 'full-tp', src: './assets/status/full-tp.png', label: state.lang === 'fa' ? 'فول تی پی' : 'Full TP' }, stop: { key: 'stop-loss', src: './assets/status/stop-loss.png', label: state.lang === 'fa' ? 'استاپ لاس' : 'Stop loss' }, stopped: { key: 'stop-loss', src: './assets/status/stop-loss.png', label: state.lang === 'fa' ? 'استاپ لاس' : 'Stop loss' }, sl: { key: 'stop-loss', src: './assets/status/stop-loss.png', label: state.lang === 'fa' ? 'استاپ لاس' : 'Stop loss' }, loss: { key: 'stop-loss', src: './assets/status/stop-loss.png', label: state.lang === 'fa' ? 'استاپ لاس' : 'Stop loss' } }; return map[key] || { key: 'live', src: '', label: state.lang === 'fa' ? 'قالب سیگنال فعال' : 'Live signal card' }; }
function signalVisualCard(s) { const stage = signalVisualStage(s), targets = Array.isArray(s.targets || s.take_profits) ? (s.targets || s.take_profits) : []; const actualTargets = targets.filter(v => v !== null && v !== undefined && String(v).trim() !== ''); const updated = (s.lifecycle_report || s.lifecycle_history || []).filter(Boolean).slice(-1)[0] || null; const statusStamp = updated ? `${signalLifecycleLabel(updated.event || updated.to)} · ${timeOnly(updated.at || updated.created_at)}` : `${state.lang === 'fa' ? 'آخرین وضعیت' : 'Latest status'} · ${timeOnly(s.updated_at)}`; const meta = `<div class="signal-visual-meta"><span><b>${esc(t('entry'))}</b><strong>${esc(s.entry || s.entry_state?.entry_reference || '—')}</strong></span><span><b>SL</b><strong>${esc(s.stop || s.stop_loss || '—')}</strong></span>${actualTargets.slice(0, 3).map((target, idx) => `<span><b>TP${idx + 1}</b><strong>${esc(target)}</strong></span>`).join('')}</div>`; if (stage.src) return `<article class="signal-visual-card poster-stage ${esc(stage.key)}"><div class="signal-poster-shell"><img class="signal-poster-image" src="${stage.src}" alt="${esc(stage.label)}" loading="lazy"></div><div class="signal-poster-caption"><div><small>${esc(stage.label)}</small><strong>${esc(s.symbol)} · #${num(s.display_number, 0)}</strong></div><span class="status-badge ${signalLifecycleTone(updated?.event || s.status)}">${esc(statusStamp)}</span></div>${meta}</article>`; const side = String(s.side || '').toUpperCase(); return `<article class="signal-visual-card live-stage ${side === 'SELL' ? 'sell' : ''}"><div class="signal-live-shell"><div class="signal-live-brand"><img src="./assets/brand/sentinel-miniapp-logo.2febef7c25.webp" alt="SENTINEL"><div><small>SENTINEL SIGNALS</small><strong>${esc(side)} · ${esc(s.symbol)}</strong></div></div><div class="signal-live-status"><span class="status-badge good">#${num(s.display_number, 0)}</span><span class="status-badge info">${esc(statusStamp)}</span></div><div class="signal-live-grid"><div><span>${esc(t('entry'))}</span><b>${esc(s.entry || s.entry_state?.entry_reference || '—')}</b></div><div><span>SL</span><b>${esc(s.stop || s.stop_loss || '—')}</b></div>${actualTargets.slice(0, 3).map((target, idx) => `<div><span>TP${idx + 1}</span><b>${esc(target)}</b></div>`).join('')}</div></div>${meta}</article>`; }
function signalMediaSection(s) { const slides = [`<div class="signal-media-slide">${signalVisualCard(s)}</div>`]; if (s.media?.result_chart_available && s.media?.result_chart_url) slides.push(`<div class="signal-media-slide chart result-chart"><figure class="signal-chart-figure"><img src="${esc(s.media.result_chart_url)}" alt="${state.lang === 'fa' ? 'چارت نتیجه نهایی سیگنال' : 'Final signal result chart'}" loading="eager"><figcaption><strong>${state.lang === 'fa' ? 'مدرک تصویری نتیجه نهایی' : 'Final result evidence'}</strong>${s.media.result_chart_caption ? `<span>${esc(s.media.result_chart_caption)}</span>` : ''}${s.media.result_chart_added_at ? `<small>${date(s.media.result_chart_added_at)}</small>` : ''}</figcaption></figure></div>`); if (s.media?.chart_available && s.media?.chart_url) slides.push(`<div class="signal-media-slide chart"><figure class="signal-chart-figure"><img src="${esc(s.media.chart_url)}" alt="${state.lang === 'fa' ? 'چارت تحلیل' : 'Analysis chart'}" loading="lazy"><figcaption>${state.lang === 'fa' ? 'عکس تحلیل / چارت ارسالی ادمین' : 'Admin analysis chart'}</figcaption></figure></div>`); return `<section class="panel signal-media-panel"><div class="panel-head"><div><h3>${state.lang === 'fa' ? 'جزئیات تصویری سیگنال' : 'Signal visuals'}</h3><small>${state.lang === 'fa' ? 'وضعیت، مدرک نتیجه و چارت تحلیل در اسلایدهای جداگانه' : 'Status, result evidence and analysis chart in separate slides'}</small></div></div><div class="panel-body"><div class="signal-media-gallery">${slides.join('')}</div></div></section>`; }
function signalActivityItems(s) { const rows = (s.lifecycle_report || s.lifecycle_history || []).filter(item => item && (item.event || item.to || item.at || item.created_at)); if (!rows.length) return `<div class="timeline-item"><strong>${state.lang === 'fa' ? 'ثبت اولیه سیگنال' : 'Signal created'}</strong><p>${state.lang === 'fa' ? 'گزارش ویرایشی برای این سیگنال ثبت نشده است.' : 'No edit log recorded for this signal yet.'}</p><small>${date(s.created_at || s.updated_at)}</small></div>`; return rows.slice().reverse().map(row => { const event = row.event || row.to || row.status; const notes = []; if (row.price != null && row.price !== '') notes.push(`${state.lang === 'fa' ? 'قیمت' : 'Price'}: ${row.price}`); if (row.rr != null && row.rr !== '') notes.push(`R/R: ${num(row.rr, 2)}`); if (row.note) notes.push(String(row.note)); return `<div class="timeline-item activity-item ${signalLifecycleTone(event)}"><div class="activity-head"><strong>${esc(signalLifecycleLabel(event))}</strong><span class="status-badge ${signalLifecycleTone(event)}">${esc(timeOnly(row.at || row.created_at))}</span></div><p>${notes.length ? esc(notes.join(' • ')) : esc(state.lang === 'fa' ? 'به‌روزرسانی وضعیت ثبت شد.' : 'Status update recorded.')}</p><small>${date(row.at || row.created_at)}</small></div>`; }).join(''); }
function signalRevisionItems(s) { const history = s.trust_passport?.revisions || []; return history.length ? history.slice().reverse().map(h => `<div class="timeline-item"><strong>${state.lang === 'fa' ? 'نسخه' : 'Revision'} ${esc(h.revision || h.version || 1)}</strong><p>${esc((h.changed_fields || []).join(', ') || h.reason || (state.lang === 'fa' ? 'ثبت اولیه سیگنال' : 'Initial signal'))}</p><small>${date(h.created_at)}</small></div>`).join('') : `<div class="timeline-item"><strong>${state.lang === 'fa' ? 'نسخه ۱' : 'Revision 1'}</strong><p>${state.lang === 'fa' ? 'ثبت اولیه سیگنال' : 'Initial signal'}</p><small>${date(s.created_at || s.updated_at)}</small></div>`; }
function signalRiskRewardMetric(entryState = {}) {
    const rr = entryState.risk_reward;
    if (rr == null || !Number.isFinite(Number(rr)) || Number(rr) <= 0) return '';
    const basis = entryState.rr_basis === 'average_entries'
        ? (state.lang === 'fa' ? 'بر اساس میانگین ورودی‌های ثبت‌شده' : 'Based on the published entry average')
        : (state.lang === 'fa' ? 'بر اساس ورود و استاپ ثبت‌شده' : 'Based on the published entry and stop');
    return metric('TP1 R/R', `${num(rr, 2)}R`, basis, 'good');
}
function showSignalModal(s) { const q = s.quote || {}, entryState = s.entry_state || {}, gate = s.pretrade_gate || {}, news = s.nearby_news || [], newsMeta = s.nearby_news_meta || {}, actualEntry = s.entry || entryState.entry_reference || '', actualStop = s.stop || s.stop_loss || '', status = String(s.status || 'open').toLowerCase(), final = Boolean(s.is_final || ['closed','win','loss','sl','stop','stopped','tp','tp1','tp2','tp3','be','cancelled','canceled','target_complete','manual_close','no_entry'].includes(status)), choice = s.choice?.choice || '', locked = Boolean(s.decision_locked || choice), activation = state.lang === 'fa' ? entryState.activation_text_fa : entryState.activation_text_en, targets = `<div class="metric-grid">${(s.target_rr || []).map(target => metric(target.label || 'TP', target.price ? esc(target.price) : '—', target.r == null ? '' : `${num(target.r, 2)}R`, Number(target.r || 0) > 0 ? 'good' : '')).join('')}</div>`, account = state.resources.risk?.accounts?.find(a => String(a.id) === String(state.selectedAccount)) || state.resources.risk?.accounts?.[0], plan = gate.execution_plan || {}, historyBadge = (s.lifecycle_report || s.lifecycle_history || []).length, accountPanel = account ? `<form id="executionForm" class="form-grid"><div class="field"><label>${esc(t('account'))}</label><select id="execAccount">${(state.resources.risk?.accounts || []).map(a => `<option value="${a.id}" ${a.id === account.id ? 'selected' : ''}>${esc(a.name)} · ${esc(a.kind || '')}</option>`).join('')}</select></div><div class="field"><label for="execEntry">${esc(t('entry'))}</label><input id="execEntry" inputmode="decimal" value="${esc(actualEntry)}" required></div><div class="field"><label for="execStop">${esc(t('stop'))}</label><input id="execStop" inputmode="decimal" value="${esc(actualStop)}" required></div><div class="field"><label for="execRisk">${esc(t('riskPercent'))}</label><input id="execRisk" inputmode="decimal" value="${esc(plan.allowed_risk_percent || account.default_risk_percent || s.risk || 1)}" required></div><div class="field"><label for="execVolume">${esc(t('volume'))} <small>(${state.lang === 'fa' ? 'اختیاری' : 'optional'})</small></label><input id="execVolume" inputmode="decimal" value="${esc(plan.planned_volume || '')}"><span class="field-help">${state.lang === 'fa' ? 'خالی بماند، سیستم با ریسک حساب محاسبه می‌کند.' : 'Leave empty for automatic risk-based sizing.'}</span></div></div><label class="check-row"><input id="execConfirm" type="checkbox" required> <span>${state.lang === 'fa' ? 'این سیگنال را می‌گیرم و فقط یک‌بار در ژورنال همین حساب ثبت شود.' : 'Take this signal and journal it once for this account.'}</span></label></form>` : `<div class="notice danger"><strong>${state.lang === 'fa' ? 'حساب معاملاتی ندارید' : 'No trading account'}</strong><p>${state.lang === 'fa' ? 'ابتدا راه‌اندازی حساب را تکمیل کنید.' : 'Complete account setup first.'}</p></div>`; openModal('SIGNAL TRACKER', `${s.symbol} · #${s.display_number}`, `<div class="row-between"><div><span class="side-badge ${String(s.side).toLowerCase() === 'sell' ? 'sell' : ''}">${esc(String(s.side).toUpperCase())}</span> <span class="status-badge ${final ? 'warn' : 'good'}">${esc(signalLifecycleLabel(status))}</span></div><div class="inline-actions"><button class="button ghost small" data-signal-replay="${s.id}">${icon('history')}${esc(t('replay'))}</button><button class="button ghost small" data-copy-signal="${s.id}">${icon('copy')}${esc(t('copy'))}</button></div></div>${signalMediaSection(s)}<div class="metric-grid">${metric(t('currentPrice'), num(q.price, 7), q.provider || '', 'info')}${metric(t('entry'), num(entryState.entry_reference || actualEntry, 7), activation || '', '')}${metric(t('distance'), entryState.distance_from_entry_percent == null ? '—' : pct(entryState.distance_from_entry_percent, 3), entryState.inside_entry_zone ? (state.lang === 'fa' ? 'فعال' : 'active') : '', 'info')}${signalRiskRewardMetric(entryState)}</div>${targets}<section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'گزارش ویرایش و وضعیت' : 'Edit & status log'}</h3><small>${historyBadge ? `${num(historyBadge, 0)} ${state.lang === 'fa' ? 'رخداد' : 'events'}` : ''}</small></div><div class="panel-body timeline">${signalActivityItems(s)}</div></section><div class="panel" style="margin-top:12px"><div class="panel-head"><h3>${locked ? esc(signalDecisionLabel(choice || 'taken')) : (final ? (state.lang === 'fa' ? 'ثبت نتیجه شخصی' : 'Record your outcome') : esc(t('execute')))}</h3></div><div class="panel-body">${locked ? `<div class="notice good"><strong>${esc(signalDecisionLabel(choice))}</strong><p>${state.lang === 'fa' ? 'این تصمیم قفل شده و رکورد تکراری ایجاد نمی‌شود.' : 'This decision is locked and will not be duplicated.'}</p></div>` : (final ? `<div class="notice info"><strong>${state.lang === 'fa' ? 'این سیگنال بسته شده است' : 'This signal is closed'}</strong><p>${state.lang === 'fa' ? 'فقط مشخص کنید آن را گرفته بودید یا نگرفته بودید؛ معامله جدیدی باز نمی‌شود.' : 'Record whether you took it; no new position will be opened.'}</p></div>` : accountPanel)}</div></div>${gateHtml(gate)}<section class="panel"><div class="panel-head"><h3>${esc(t('nearbyNews'))}</h3><small>${newsMeta.window_hours ? `${num(newsMeta.window_hours, 0)}h` : ''}</small></div><div class="panel-body">${news.length ? news.map(n => `<div class="notice ${String(n.importance).toLowerCase().includes('high') ? 'warning' : ''}"><strong>${esc((n.currency ? `${n.currency} · ` : '') + n.title)}</strong><br><small>${date(n.datetime)} · ${Number(n.minutes_from_now) >= 0 ? (state.lang === 'fa' ? 'تا خبر' : 'until') : (state.lang === 'fa' ? 'از خبر گذشته' : 'since')} ${num(Math.abs(Number(n.minutes_from_now || 0)), 0)} ${state.lang === 'fa' ? 'دقیقه' : 'min'}</small></div>`).join('') : `<div class="notice good"><strong>${esc(newsMeta.status === 'calendar_not_synced' ? (state.lang === 'fa' ? 'تقویم اقتصادی هنوز همگام نشده است.' : 'Economic calendar is not synced yet.') : (state.lang === 'fa' ? 'خبر مهم مرتبطی در بازه نزدیک این سیگنال وجود ندارد.' : 'No relevant high-impact event is near this signal.'))}</strong>${newsMeta.calendar_updated_at ? `<small>${state.lang === 'fa' ? 'آخرین همگام‌سازی' : 'Last sync'}: ${date(newsMeta.calendar_updated_at)}</small>` : ''}</div>`}</div></section><section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'سوابق نسخه‌ها و شفافیت' : 'Revision history & transparency'}</h3><small>${esc(s.trust_passport?.revision_chain_valid === false ? 'CHAIN ALERT' : 'VERIFIED')}</small></div><div class="panel-body timeline">${signalRevisionItems(s)}</div>${s.trust_passport?.evidence_hash ? `<div class="notice mono"><strong>${esc(t('evidenceHash'))}</strong><small>${esc(s.trust_passport.evidence_hash)}</small></div>` : ''}</section>`, locked ? [] : (final ? [{ label: state.lang === 'fa' ? 'نگرفتم' : 'Skipped', kind: 'secondary', action: () => setSignalChoice(s.id, 'skipped', true) }, { label: state.lang === 'fa' ? 'گرفتم' : 'Taken', kind: 'primary', action: () => setSignalChoice(s.id, 'taken', true) }] : [{ label: state.lang === 'fa' ? 'نمی‌گیرم' : 'Skip', kind: 'secondary', action: () => setSignalChoice(s.id, 'skipped') }, { label: state.lang === 'fa' ? 'بگیرش و ثبت کن' : 'Take & journal', kind: 'primary', action: () => submitExecution(s) }])); }
async function signalReplayModal(id) { setBusy(true); try {
    const r = await request(`./api/v1/signals/${id}/replay`);
    openModal('SIGNAL REPLAY', `${r.symbol} · #${r.display_number}`, `<div class="metric-grid">${metric(t('marketRegime'), esc(String(r.regime?.regime || 'balanced').replaceAll('_', ' ')), pct(Number(r.regime?.confidence || 0) * 100, 0), 'info')}${metric('Outcome', `${num(r.outcome?.net_r || 0, 2)}R`, esc(r.outcome?.bucket || ''), Number(r.outcome?.net_r || 0) >= 0 ? 'good' : 'bad')}${metric('Chain', r.revision_chain_valid ? 'VALID' : 'INVALID', '', '')}${metric(t('status'), esc(r.status), '', '')}</div><div class="timeline">${(r.timeline || []).map(x => `<div class="timeline-item"><strong>${esc(x.title || x.type)}</strong><p>${esc((x.changed_fields || []).join(', ') || x.reason || '')}</p><small>${date(x.at)}</small></div>`).join('') || empty()}</div>${r.analyst_lesson ? `<div class="notice"><strong>${state.lang === 'fa' ? 'نکته آموزشی تحلیل‌گر' : 'Analyst lesson'}</strong><p>${esc(r.analyst_lesson)}</p></div>` : ''}<div class="notice mono">${esc(r.evidence_hash || '')}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function shareSignalCard(id) { setBusy(true); try {
    const card = await request(`./api/v1/signals/${id}/share-card`);
    const blob = new Blob([card.svg], { type: card.mime_type || 'image/svg+xml' }), file = new File([blob], card.filename || `sentinel-${id}.svg`, { type: blob.type });
    if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({ title: `SENTINEL ${card.symbol}`, text: `${card.net_r >= 0 ? '+' : ''}${num(card.net_r, 2)}R · verified result`, files: [file] });
    }
    else {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = file.name;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    }
    toast(t('success'));
}
catch (err) {
    if (err.name !== 'AbortError')
        toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function applySignalChoiceLocal(id, choice) { const patch = row => String(row?.id) === String(id) ? { ...row, choice: { ...(row.choice || {}), choice }, decision_locked: true } : row; for (const key of ['signals']) {
    const resource = state.resources[key];
    if (resource?.items)
        resource.items = resource.items.map(patch);
} const recent = state.resources.overview?.recent_signals; if (Array.isArray(recent))
    state.resources.overview.recent_signals = recent.map(patch); }
function refreshSignalSurfaces() { Promise.allSettled([loadOverview(true), loadResource('signals', true), loadResource('risk', true), loadResource('journal', true)]).then(() => { renderChrome(); if (state.page === 'signals')
    renderSignals();
else if (state.page === 'risk')
    renderRisk();
else if (state.page === 'journal')
    renderJournal();
else if (state.page === 'home')
    renderHome(); }); }
async function submitExecution(s) { const f = $('#executionForm'); if (!f?.reportValidity())
    return; const volume = Number($('#execVolume').value || 0), payload = { signal_id: s.id, choice: 'taken', execution: { account_id: $('#execAccount').value, actual_entry: Number($('#execEntry').value), actual_stop: Number($('#execStop').value), risk_percent: Number($('#execRisk').value), volume, current_price: Number(s.quote?.price || $('#execEntry').value), confirmation: $('#execConfirm').checked, data_source: 'miniapp' } }; setBusy(true); try {
    await action('signal_choice_update', payload, false);
    applySignalChoiceLocal(s.id, 'taken');
    closeModal();
    toast(t('positionOpened'));
    invalidate('signals', 'risk', 'journal', 'overview', 'feed');
    refreshSignalSurfaces();
}
catch (err) {
    toast(err.message === 'SIGNAL_DECISION_LOCKED' ? (state.lang === 'fa' ? 'برای این سیگنال قبلاً تصمیم ثبت شده است.' : 'A decision is already recorded for this signal.') : err.message, 'error');
}
finally {
    setBusy(false);
} }
async function setSignalChoice(id, choice, retrospective = false) { setBusy(true); try {
    await action('signal_choice_update', { signal_id: id, choice, retrospective }, false);
    applySignalChoiceLocal(id, choice);
    closeModal();
    toast(t('success'));
    invalidate('signals', 'risk', 'journal', 'overview', 'expansion', 'feed');
    if (state.page === 'signals')
        renderSignals();
    else if (state.page === 'home')
        renderHome();
    refreshSignalSurfaces();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function renderRiskLegacy(force = false) {
    const page = $('#page-risk');
    if (!featureEnabled('risk')) {
        page.innerHTML = pageHead('RISK OS', t('riskOS'), '') + disabledPanel();
        return;
    }
    page.innerHTML = pageHead('RISK OS', t('riskOS'), state.lang === 'fa' ? 'ریسک واقعی پوزیشن‌ها، قوانین پراپ و بدترین سناریو در یک نما.' : 'Actual position risk, prop rules and worst-case scenarios in one view.') + skeleton(4);
    try {
        const r = await loadResource('risk', force), a = r.selected_account || r.default_account || {}, e = r.exposure || {}, p = r.prop || {}, w = r.what_if || {}, corr = r.correlation || {}, confidence = r.data_confidence || {};
        page.innerHTML = pageHead('RISK OS', t('riskOS'), state.lang === 'fa' ? 'ریسک واقعی پوزیشن‌ها، قوانین پراپ و بدترین سناریو در یک نما.' : 'Actual position risk, prop rules and worst-case scenarios in one view.', `<button class="button small" data-account-edit="new">${icon('plus')}${esc(t('addAccount'))}</button>`) + `
 <div class="filters account-filters">${(r.accounts || []).map(x => `<button class="filter-chip ${String(x.id) === String(a.id) ? 'active' : ''}" data-account-select="${x.id}">${esc(x.name)}</button>`).join('')}</div>
 <section class="panel"><div class="panel-head"><div><small class="eyebrow">${esc(a.type || 'personal')}</small><h2>${esc(a.name || t('account'))}</h2></div><div class="card-actions">${a.broker_sync_available ? `<button class="button secondary small" data-broker-sync="${esc(a.id)}">${icon('refresh')}${state.lang === 'fa' ? 'همگام‌سازی فقط‌خواندنی' : 'Read-only sync'}</button>` : ''}<button class="button ghost small" data-account-edit="${a.id}">${icon('edit')}${esc(t('editAccount'))}</button></div></div><div class="panel-body"><div class="metric-grid">${metric(t('balance'), money(a.balance, a.currency), '', 'info')}${metric(t('equity'), money(a.equity, a.currency), '', '')}${metric(t('openRisk'), pct(e.open_risk_percent || 0), `${num(e.open_trades || 0, 0)} trade`, 'warn')}${metric(t('dailyRisk'), pct(e.daily_risk_percent || 0), `${pct(e.remaining_daily_risk_percent || 0)} remaining`, 'info')}</div><div class="progress"><i style="width:${Math.min(100, Number(e.open_risk_percent || 0) / Math.max(Number(a.max_open_risk_percent || 5), .01) * 100)}%"></i></div></div></section>
 <section class="panel"><div class="panel-head"><h2>${esc(t('whatIf'))}</h2></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'زیان در برخورد همه SLها' : 'All stops loss', money(w.all_stops_loss_amount, a.currency), '', 'bad')}${metric(state.lang === 'fa' ? 'اکویتی بدترین حالت' : 'Worst equity', money(w.worst_case_equity, a.currency), '', 'warn')}${metric(state.lang === 'fa' ? 'دراودان بدترین حالت' : 'Worst drawdown', pct(w.worst_case_drawdown_percent || 0), '', w.would_breach_total_loss ? 'bad' : 'good')}${metric(state.lang === 'fa' ? 'بزرگ‌ترین خوشه' : 'Largest cluster', esc(w.largest_correlation_cluster || '—'), money(w.largest_cluster_loss_amount, a.currency), '')}</div></div></section>
 <section class="panel"><div class="panel-head"><h2>Prop Firm Mode</h2><span class="status-badge ${p.status === 'safe' ? 'good' : 'bad'}">${esc(p.status || 'safe')}</span></div><div class="panel-body"><div class="metric-grid">${metric(t('dailyLoss'), pct(p.daily_loss_used_percent || 0), `${pct(p.daily_loss_remaining_percent || 0)} remaining`, p.daily_loss_remaining_percent < 1 ? 'bad' : 'warn')}${metric(t('totalLoss'), pct(p.total_drawdown_percent || 0), `${pct(p.total_loss_remaining_percent || 0)} remaining`, p.total_loss_remaining_percent < 1 ? 'bad' : 'warn')}${metric(t('profitTarget'), pct(p.profit_progress_percent || 0), 'progress', 'good')}${metric(state.lang === 'fa' ? 'روز معاملاتی' : 'Trading days', `${num(p.trading_days || 0, 0)}/${num(p.min_trading_days || 0, 0)}`, '', 'info')}</div></div></section>
 <section class="panel"><div class="panel-head"><h2>${esc(t('correlation'))}</h2></div><div class="panel-body">${correlationHtml(corr)}</div></section>
 <section class="panel"><div class="panel-head"><h2>${state.lang === 'fa' ? 'اعتماد و تازگی داده' : 'Data confidence & freshness'}</h2></div><div class="panel-body">${confidenceHtml(confidence)}</div></section>
 <section class="panel"><div class="panel-head"><h2>${esc(t('positions'))}</h2></div><div class="panel-body journal-list">${(r.positions || []).map(positionCard).join('') || empty()}</div></section>`;
    }
    catch (err) {
        page.innerHTML = errorPanel(err, 'risk');
    }
}
function correlationHtml(c) { const clusters = c.clusters || c.cluster_summary || []; if (clusters.length)
    return clusters.map(x => `<div class="account-card"><div class="row-between"><strong>${esc(x.cluster || x.name || 'other')}</strong><span>${pct(x.risk_percent || x.open_risk_percent || 0)}</span></div><div class="progress"><i style="width:${Math.min(100, Number(x.risk_percent || x.open_risk_percent || 0) * 20)}%"></i></div><p>${num(x.positions || x.count || 0, 0)} positions</p></div>`).join(''); const matrix = c.windows?.['60']?.matrix || c.windows?.['20']?.matrix || {}, pairs = []; Object.keys(matrix).forEach(left => Object.keys(matrix[left] || {}).forEach(right => { if (left < right && matrix[left][right] != null)
    pairs.push({ left, right, value: Number(matrix[left][right]) }); })); if (!pairs.length)
    return empty(); return pairs.sort((a, b) => Math.abs(b.value) - Math.abs(a.value)).slice(0, 8).map(x => `<div class="account-card"><div class="row-between"><strong>${esc(x.left)} ↔ ${esc(x.right)}</strong><span>${num(x.value, 3)}</span></div><div class="progress"><i style="width:${Math.min(100, Math.abs(x.value) * 100)}%"></i></div></div>`).join(''); }
function confidenceHtml(values) { const rows = Object.entries(values).filter(([, x]) => x); if (!rows.length)
    return empty(); return rows.map(([field, x]) => `<div class="account-card"><div class="row-between"><strong>${esc(field)}</strong><span class="status-badge ${x.stale ? 'bad' : Number(x.confidence || 0) >= .8 ? 'good' : 'warn'}">${x.stale ? (state.lang === 'fa' ? 'قدیمی' : 'stale') : num(Number(x.confidence || 0) * 100, 0) + '%'}</span></div><p>${esc(x.source || 'unknown')} · ${num(x.age_seconds || 0, 0)}s</p></div>`).join(''); }
function positionCard(p) { return `<article class="journal-card"><div class="row-between"><h3>${esc(p.symbol)} · ${esc(p.side)}</h3><span class="status-badge ${p.status === 'open' ? 'good' : 'warn'}">${esc(p.status)}</span></div><p>${t('entry')}: ${num(p.actual_entry, 7)} · SL: ${num(p.actual_stop, 7)} · ${t('volume')}: ${num(p.actual_volume, 6)}</p><p>${t('openRisk')}: ${pct(p.remaining_risk_percent ?? p.actual_risk_percent ?? p.risk_percent ?? 0)} · ${money(p.remaining_risk_money ?? p.risk_money ?? 0)}</p><div class="card-actions"><button class="button secondary small" data-position-close="${p.id}">${esc(t('closeTrade'))}</button></div></article>`; }
function accountRuleTemplates(resource) { const rows = Array.isArray(resource?.prop_templates) ? resource.prop_templates.filter(x => x?.id) : []; return rows.length ? rows : [{ id: 'personal-standard', provider: 'SENTINEL', name: 'Personal Standard', version: 1 }, { id: 'prop-static-5-10', provider: 'Generic', name: 'Static 5/10', version: 1 }, { id: 'prop-trailing-4', provider: 'Generic', name: 'Trailing 4%', version: 1 }]; }
function accountModal(id) { const r = state.resources.risk || {}, templates = accountRuleTemplates(r), existing = id === 'new' ? {} : (r.accounts || []).find(a => String(a.id) === String(id)) || {}; openModal('RISK ACCOUNT', id === 'new' ? t('addAccount') : t('editAccount'), `<form id="accountForm" novalidate><div class="form-grid"><div class="field"><label for="accName">${esc(t('name'))}</label><input id="accName" value="${esc(existing.name || '')}" required minlength="2"></div><div class="field"><label for="accType">${esc(t('accountType'))}</label><select id="accType"><option value="personal">${esc(t('personal'))}</option><option value="prop_challenge">${esc(t('propChallenge'))}</option><option value="prop_funded">${esc(t('propFunded'))}</option><option value="demo">${esc(t('demo'))}</option></select></div><div class="field"><label for="accRuleTemplate">${state.lang === 'fa' ? 'قالب قوانین' : 'Rule template'}</label><select id="accRuleTemplate" required>${templates.map(x => `<option value="${esc(x.id)}" ${String(existing.rule_template_id || 'personal-standard') === String(x.id) ? 'selected' : ''}>${esc(x.provider)} · ${esc(x.name)} v${num(x.version, 0)}</option>`).join('')}</select><small class="field-help" id="accRuleHelp">${state.lang === 'fa' ? 'قالب متناسب با نوع حساب به‌صورت خودکار انتخاب می‌شود و قابل تغییر است.' : 'A suitable template is selected automatically and remains editable.'}</small></div><div class="field"><label for="accBalance">${esc(t('balance'))}</label><input id="accBalance" inputmode="decimal" value="${esc(existing.balance ?? '')}" required></div><div class="field"><label for="accEquity">${esc(t('equity'))}</label><input id="accEquity" inputmode="decimal" value="${esc(existing.equity ?? existing.balance ?? '')}" required></div><div class="field"><label for="accCurrency">Currency</label><select id="accCurrency">${['USD', 'USDT', 'EUR', 'GBP', 'AED', 'IRR'].map(c => `<option ${existing.currency === c ? 'selected' : ''}>${c}</option>`).join('')}</select></div><div class="field"><label for="accTimezone">${esc(t('timezone'))}</label><input id="accTimezone" value="${esc(existing.timezone || 'UTC')}" required></div><div class="field"><label for="accBrokerProvider">${state.lang === 'fa' ? 'ارائه‌دهنده اتصال فقط‌خواندنی' : 'Read-only provider'}</label><input id="accBrokerProvider" value="${esc(existing.provider || existing.broker_provider || '')}" placeholder="MT5 Bridge"></div><div class="field"><label for="accBrokerReference">${state.lang === 'fa' ? 'شناسه بروکر (تنظیم‌شده توسط مدیریت)' : 'Broker account reference'}</label><input id="accBrokerReference" readonly value="${esc(existing.broker_account_reference || '')}" autocomplete="off"></div><div class="field"><label for="accDefaultRisk">${esc(t('riskPercent'))}</label><input id="accDefaultRisk" inputmode="decimal" value="${esc(existing.default_risk_percent ?? 1)}"></div><div class="field"><label for="accDailyRisk">${esc(t('maxDailyRisk'))}</label><input id="accDailyRisk" inputmode="decimal" value="${esc(existing.max_daily_risk_percent ?? 3)}"></div><div class="field"><label for="accOpenRisk">${esc(t('maxOpenRisk'))}</label><input id="accOpenRisk" inputmode="decimal" value="${esc(existing.max_open_risk_percent ?? 5)}"></div><div class="field"><label for="accDailyLoss">${esc(t('dailyLoss'))}</label><input id="accDailyLoss" inputmode="decimal" value="${esc(existing.max_daily_loss_percent ?? 5)}"></div><div class="field"><label for="accTotalLoss">${esc(t('totalLoss'))}</label><input id="accTotalLoss" inputmode="decimal" value="${esc(existing.max_total_loss_percent ?? 10)}"></div><div class="field"><label for="accTarget">${esc(t('profitTarget'))}</label><input id="accTarget" inputmode="decimal" value="${esc(existing.profit_target_percent ?? 8)}"></div></div><label class="check-row"><input id="accEnabled" type="checkbox" ${existing.risk_enabled !== false ? 'checked' : ''}> <span>${esc(t('riskEnabled'))}</span></label></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const f = $('#accountForm'); if (!f.reportValidity())
            return; const payload = { account_id: existing.id, name: $('#accName').value, type: $('#accType').value, phase: $('#accType').value.startsWith('prop') ? (existing.phase || 'phase_1') : $('#accType').value === 'demo' ? 'demo' : 'personal', balance: Number($('#accBalance').value), equity: Number($('#accEquity').value), starting_balance: Number(existing.starting_balance || $('#accBalance').value), high_water_mark: Number(existing.high_water_mark || $('#accEquity').value), currency: $('#accCurrency').value, timezone: $('#accTimezone').value, default_risk_percent: Number($('#accDefaultRisk').value), max_daily_risk_percent: Number($('#accDailyRisk').value), max_open_risk_percent: Number($('#accOpenRisk').value), max_daily_loss_percent: Number($('#accDailyLoss').value), max_total_loss_percent: Number($('#accTotalLoss').value), profit_target_percent: Number($('#accTarget').value), rule_template_id: $('#accRuleTemplate').value, provider: $('#accBrokerProvider').value.trim(), risk_enabled: $('#accEnabled').checked, enabled: true }; setBusy(true); try {
            const res = await action('account_upsert', payload, false);
            state.selectedAccount = res.id;
            closeModal();
            invalidate('risk', 'overview');
            await Promise.all([loadOverview(true), loadResource('risk', true)]);
            renderChrome();
            renderRisk();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); setTimeout(() => { const type = $('#accType'), rules = $('#accRuleTemplate'); type.value = existing.type || 'personal'; const syncRuleTemplate = () => { const prop = type.value === 'prop_challenge' || type.value === 'prop_funded'; const current = String(rules.value || ''); if (prop && (!current || current === 'personal-standard')) {
            const preferred = templates.find(x => String(x.id) === 'prop-static-5-10') || templates.find(x => String(x.id) !== 'personal-standard');
            if (preferred)
                rules.value = String(preferred.id);
        }
        else if (!prop && !existing.rule_template_id && templates.some(x => String(x.id) === 'personal-standard'))
            rules.value = 'personal-standard'; }; type.addEventListener('change', syncRuleTemplate); syncRuleTemplate(); }, 0); }
function closePositionModal(id) { openModal('POSITION', t('closeTrade'), `<form id="closePositionForm"><div class="form-grid"><div class="field"><label for="posExit">${esc(t('exitPrice'))}</label><input id="posExit" inputmode="decimal" required></div><div class="field"><label for="posFraction">Close fraction (0–1)</label><input id="posFraction" inputmode="decimal" value="1" min="0.01" max="1" required></div><div class="field"><label for="posPnlAmount">${esc(t('pnlAmount'))}</label><input id="posPnlAmount" inputmode="decimal"></div><div class="field"><label for="posPnlPercent">${esc(t('pnlPercent'))} (${state.lang === 'fa' ? 'از اکویتی هنگام ورود؛ مبلغ اولویت دارد' : 'of equity at entry; amount takes precedence'})</label><input id="posPnlPercent" inputmode="decimal"></div><div class="field"><label for="posFees">${esc(t('fees'))}</label><input id="posFees" inputmode="decimal" value="0"></div><div class="field"><label for="posCommission">${esc(t('commission'))}</label><input id="posCommission" inputmode="decimal" value="0"></div><div class="field"><label for="posSwap">${esc(t('swap'))}</label><input id="posSwap" inputmode="decimal" value="0"></div></div></form>`, [{ label: t('closeTrade'), kind: 'primary', action: async () => { const f = $('#closePositionForm'); if (!f.reportValidity())
            return; setBusy(true); try {
            await action('position_close', { position_id: id, exit_price: Number($('#posExit').value), close_fraction: Number($('#posFraction').value), pnl_amount: $('#posPnlAmount').value === '' ? null : Number($('#posPnlAmount').value), pnl_percent: $('#posPnlPercent').value === '' ? null : Number($('#posPnlPercent').value), fees: Number($('#posFees').value || 0), commission: Number($('#posCommission').value || 0), swap: Number($('#posSwap').value || 0) }, false);
            closeModal();
            invalidate('risk', 'journal', 'overview');
            await Promise.all([loadOverview(true), loadResource('risk', true), loadResource('journal', true)]);
            renderRisk();
            renderChrome();
            toast(t('success'));
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function renderJournal(force = false) {
    const page = $('#page-journal');
    if (!featureEnabled('journal')) {
        page.innerHTML = pageHead('JOURNAL', t('tradeJournal'), '') + disabledPanel();
        return;
    }
    page.innerHTML = pageHead('JOURNAL', t('tradeJournal'), state.lang === 'fa' ? 'ژورنال مشترک ربات و مینی‌اپ با نتیجه R و دلیل ورود.' : 'Shared bot/Mini App journal with R results and entry reasons.') + skeleton(4);
    try {
        const j = await loadResource('journal', force), st = j.stats || {}, b = j.behavioral_review || {}, c = j.trading_coach || {};
        page.innerHTML = pageHead('JOURNAL', t('tradeJournal'), state.lang === 'fa' ? 'معامله‌های شخصی و سیگنال‌های کانال در یک ژورنال مشترک.' : 'Personal trades and channel signals in one shared journal.', `<button class="button small" data-journal-new>${icon('plus')}${esc(t('newTrade'))}</button>`) + `
  <div class="metric-grid">${metric(state.lang === 'fa' ? 'خالص R' : 'Net R', `${num(st.r_net || 0, 2)}R`, `${num(st.r_count || 0, 0)} trade`, (st.r_net || 0) >= 0 ? 'good' : 'bad')}${metric(state.lang === 'fa' ? 'R سود' : 'R won', `+${num(st.r_won || 0, 2)}R`, '', 'good')}${metric(state.lang === 'fa' ? 'R زیان' : 'R lost', `-${num(st.r_lost || 0, 2)}R`, '', 'bad')}${metric(t('journalWin'), pct(st.win_rate || 0), `${num(st.closed || 0, 0)} closed`, 'info')}</div>
  <section class="panel"><div class="panel-head"><h2>${state.lang === 'fa' ? 'منبع معاملات' : 'Trade sources'}</h2></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'سیگنال کانال' : 'Channel signals', num(st.channel_signal_entries || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'معامله شخصی' : 'Personal trades', num(st.personal_entries || 0, 0), '', '')}${metric(t('costs'), money(st.costs || 0), '', 'warn')}${metric('Max DD', pct(st.max_drawdown || 0), '', 'bad')}</div></div></section>
  <section class="panel"><div class="panel-head"><h2>${esc(t('behavior'))}</h2></div><div class="panel-body"><div class="metric-grid">${metric(t('lateLossRate'), pct(b.late_entry_loss_rate || 0), '', 'warn')}${metric(t('slippage'), pct(b.average_entry_slippage_percent || 0, 4), '', 'info')}${metric(state.lang === 'fa' ? 'عبورهای ریسک' : 'Risk overrides', num(b.risk_overrides || 0, 0), '', 'bad')}${metric(state.lang === 'fa' ? 'معاملات بسته' : 'Closed trades', num(b.closed_trades || 0, 0), '', '')}</div></div></section>
  <section class="panel"><div class="panel-head"><h2>${state.lang === 'fa' ? 'مربی معاملاتی' : 'Trading coach'}</h2></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'نمونه تحلیل' : 'Sample', num(c.sample_size || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'بهترین ساعت‌ها' : 'Best hours', num((c.best_hours || []).length, 0), '', 'good')}${metric(state.lang === 'fa' ? 'بهترین ستاپ‌ها' : 'Best setups', num((c.best_setups || []).length, 0), '', 'good')}</div><div class="journal-list">${(c.findings || []).map(x => `<article class="journal-card"><p>${esc(x)}</p></article>`).join('') || `<p class="field-help">${state.lang === 'fa' ? 'با ثبت معاملات بیشتر، الگوهای رفتاری دقیق‌تر می‌شوند.' : 'More journal entries will improve behavioral pattern detection.'}</p>`}</div><p class="field-help">${esc(c.disclaimer || '')}</p></div></section>
  <section class="panel"><div class="panel-head"><h2>${esc(t('tradeJournal'))}</h2><div><button class="button ghost small" data-journal-pdf>${icon('download')}PDF</button> <button class="button ghost small" data-journal-export>${icon('download')}${esc(t('exportCsv'))}</button> <button class="button ghost small" data-journal-import>${esc(t('importCsv'))}</button> <button class="button ghost small" data-broker-import>${esc(t('brokerImport'))}</button></div></div><div class="panel-body"><div class="search-box">${icon('search')}<label class="sr-only" for="journalSearch">${esc(t('globalSearch'))}</label><input id="journalSearch" value="${esc(state.journalQuery)}" placeholder="${state.lang === 'fa' ? 'نماد، دلیل ورود یا یادداشت' : 'Symbol, entry reason or note'}"></div><div class="filters">${['all', 'open', 'partial', 'closed', 'voided'].map(x => `<button class="filter-chip ${state.journalFilter === x ? 'active' : ''}" data-journal-filter="${x}">${esc(x === 'all' ? t('all') : x)}</button>`).join('')}</div><div class="journal-list" style="margin-top:12px">${(j.items || []).map(journalCard).join('') || empty()}</div></div>${moreButton('journal', j)}</section>`;
    }
    catch (err) {
        page.innerHTML = errorPanel(err, 'journal');
    }
}
function journalCard(x) { const r = x.result_r == null ? null : Number(x.result_r), reasonType = x.entry_reason_type || ((x.source === 'channel_signal' || x.source === 'signal_taken') ? 'channel_signal' : 'personal_analysis'), reasonLabel = reasonType === 'channel_signal' ? (state.lang === 'fa' ? 'سیگنال کانال' : 'Channel signal') : (reasonType === 'other' ? (state.lang === 'fa' ? 'سایر' : 'Other') : (state.lang === 'fa' ? 'تحلیل شخصی' : 'Personal analysis')); return `<article class="journal-card"><div class="row-between"><h3>${esc(x.symbol)} · ${esc(x.side)}</h3><span class="status-badge ${x.status === 'closed' ? (Number(r || 0) >= 0 ? 'good' : 'bad') : 'warn'}">${esc(x.status)}</span></div><p>${t('entry')}: ${num(x.entry_price, 7)} · SL: ${num(x.actual_stop || x.stop_loss, 7)}${x.exit_price ? ` · ${t('exitPrice')}: ${num(x.exit_price, 7)}` : ''}</p><div class="notice info"><strong>${esc(reasonLabel)}</strong><p>${esc(x.entry_reason || x.setup || '—')}</p></div>${x.status === 'closed' ? `<p class="${Number(r || 0) >= 0 ? 'text-good' : 'text-bad'}"><strong>${r == null ? '—' : `${num(r, 2)}R`}</strong></p>` : ''}${x.note ? `<p>${esc(x.note)}</p>` : ''}<div class="card-actions">${['open', 'partial'].includes(x.status) ? `<button class="button small" data-journal-close="${x.id}">${esc(t('closeTrade'))}</button>` : ''}<button class="button danger small" data-journal-archive="${x.id}">${esc(t('archived'))}</button></div></article>`; }
function journalNewModal() { const accounts = state.resources.overview?.risk?.accounts || []; openModal('JOURNAL', t('newTrade'), `<form id="journalNewForm" novalidate><div class="form-grid"><div class="field"><label for="jSymbol">Symbol</label><input id="jSymbol" required maxlength="20"></div><div class="field"><label for="jSide">Side</label><select id="jSide"><option>BUY</option><option>SELL</option></select></div><div class="field"><label for="jAccount">${esc(t('account'))}</label><select id="jAccount" required>${accounts.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select></div><div class="field"><label for="jEntry">${esc(t('entry'))}</label><input id="jEntry" inputmode="decimal" required></div><div class="field"><label for="jStop">${esc(t('stop'))}</label><input id="jStop" inputmode="decimal" required></div><div class="field"><label for="jReasonType">${state.lang === 'fa' ? 'دلیل ورود' : 'Entry source'}</label><select id="jReasonType"><option value="personal_analysis">${state.lang === 'fa' ? 'تحلیل شخصی' : 'Personal analysis'}</option><option value="channel_signal">${state.lang === 'fa' ? 'سیگنال کانال' : 'Channel signal'}</option><option value="other">${state.lang === 'fa' ? 'سایر' : 'Other'}</option></select></div></div><div class="field"><label for="jReason">${state.lang === 'fa' ? 'توضیح کوتاه دلیل ورود' : 'Short entry reason'}</label><input id="jReason" maxlength="500" required></div><div class="field"><label for="jNote">${state.lang === 'fa' ? 'سایر / یادداشت اختیاری' : 'Other / optional note'}</label><textarea id="jNote" maxlength="2000"></textarea></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const f = $('#journalNewForm'); if (!f?.reportValidity())
            return; const reasonType = $('#jReasonType').value; setBusy(true); try {
            await action('journal_add', { symbol: $('#jSymbol').value, side: $('#jSide').value, account_id: $('#jAccount').value, entry_price: Number($('#jEntry').value), actual_stop: Number($('#jStop').value), stop_loss: Number($('#jStop').value), source: reasonType === 'channel_signal' ? 'channel_signal' : 'manual', entry_reason_type: reasonType, entry_reason: $('#jReason').value, note: $('#jNote').value }, false);
            closeModal();
            invalidate('journal');
            await loadResource('journal', true);
            renderJournal();
            toast(t('success'));
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function journalCloseModal(id) { openModal('JOURNAL', t('closeTrade'), `<form id="jCloseForm" novalidate><div class="form-grid"><div class="field"><label for="jcExit">${esc(t('exitPrice'))}</label><input id="jcExit" inputmode="decimal" required></div><div class="field"><label for="jcResultR">${state.lang === 'fa' ? 'نتیجه معامله برحسب R' : 'Trade result in R'}</label><input id="jcResultR" inputmode="decimal" required placeholder="2 یا -1"></div></div><div class="field"><label for="jcNote">${state.lang === 'fa' ? 'سایر / یادداشت اختیاری' : 'Other / optional note'}</label><textarea id="jcNote" maxlength="2000"></textarea></div></form>`, [{ label: t('closeTrade'), kind: 'primary', action: async () => { const f = $('#jCloseForm'); if (!f?.reportValidity())
            return; setBusy(true); try {
            await action('journal_result_update', { id, exit_price: Number($('#jcExit').value), result_r: Number($('#jcResultR').value), note: $('#jcNote').value }, false);
            closeModal();
            invalidate('journal', 'risk', 'overview');
            await loadResource('journal', true);
            renderJournal();
            toast(t('success'));
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }

function mt5ConnectorPanel(r, a) {
    const rows = r.mt5_connectors || [], current = rows.find(x => String(x.account_id) === String(a.id)) || rows[0];
    const status = current?.status || 'offline', tone = status === 'online' ? 'good' : status === 'stale' ? 'warn' : 'bad';
    return `<section class="panel mt5-connector"><div class="panel-head"><div><small class="eyebrow">SENTINEL CONNECTOR</small><h2>${state.lang === 'fa' ? 'اتصال فقط‌خواندنی MetaTrader 5' : 'Read-only MetaTrader 5 connection'}</h2></div><span class="status-badge ${tone}">${esc(status)}</span></div><div class="panel-body">${current ? `<div class="metric-grid">${metric(state.lang === 'fa' ? 'حساب' : 'Account', esc(current.account_login_masked || '—'), esc(current.account_name || ''), 'info')}${metric(state.lang === 'fa' ? 'بروکر' : 'Broker', esc(current.broker || '—'), esc(current.server_name || ''), '')}${metric(state.lang === 'fa' ? 'آخرین همگام‌سازی' : 'Last sync', date(current.last_snapshot_at), `${num(current.age_seconds || 0, 0)}s`, tone)}${metric(state.lang === 'fa' ? 'حالت' : 'Mode', current.readonly_mode ? (state.lang === 'fa' ? 'فقط‌خواندنی' : 'Read only') : '—', '', 'good')}</div><div class="card-actions"><button class="button secondary small" data-mt5-pair="${esc(a.id)}">${icon('refresh')}${state.lang === 'fa' ? 'کد اتصال جدید' : 'New pairing code'}</button><button class="button ghost small" data-mt5-revoke="${esc(current.id)}">${state.lang === 'fa' ? 'قطع اتصال' : 'Revoke'}</button></div>` : `<div class="notice warning"><strong>${state.lang === 'fa' ? 'این حساب هنوز به MT5 متصل نیست.' : 'This account is not connected to MT5 yet.'}</strong><p>${state.lang === 'fa' ? 'اتصال کاملاً فقط‌خواندنی است و رمز حساب دریافت نمی‌شود.' : 'The connector is read-only and never asks for your account password.'}</p></div><div class="card-actions"><button class="button primary" data-mt5-pair="${esc(a.id)}">${icon('plus')}${state.lang === 'fa' ? 'اتصال MT5' : 'Connect MT5'}</button><a class="button secondary" href="./downloads/Sentinel_MT5_Connector_Source.zip" target="_blank" rel="noopener">${state.lang === 'fa' ? 'دانلود بسته' : 'Download package'}</a></div>`}</div></section>`;
}
function propGuardianPanel(r) {
    const g = r.prop_guardian || {}, cap = g.capacity || {}, bp = g.broker_positions || {}, alerts = g.alerts || [];
    const tone = g.status === 'safe' || g.status === 'passed' ? 'good' : g.status === 'warning' ? 'warn' : 'bad';
    const capCard = (label, x={}) => metric(label, pct(x.actual || 0), `${pct(x.remaining || 0)} ${state.lang === 'fa' ? 'باقی‌مانده' : 'remaining'}`, x.level === 'danger' ? 'bad' : x.level === 'warning' || x.level === 'watch' ? 'warn' : 'good');
    return `<section class="panel prop-guardian-live"><div class="panel-head"><div><small class="eyebrow">PROP GUARDIAN</small><h2>${state.lang === 'fa' ? 'نگهبان زنده حساب پراپ' : 'Live prop account guardian'}</h2></div><span class="status-badge ${tone}">${esc(g.status || 'unconfigured')}</span></div><div class="panel-body"><div class="metric-grid">${capCard(state.lang === 'fa' ? 'افت روزانه' : 'Daily loss', cap.daily_loss)}${capCard(state.lang === 'fa' ? 'افت کل' : 'Total drawdown', cap.total_drawdown)}${capCard(state.lang === 'fa' ? 'ریسک باز' : 'Open risk', cap.open_risk)}${metric(state.lang === 'fa' ? 'معامله بدون SL' : 'Missing stop', num(bp.missing_stop_count || 0, 0), `${num(bp.open_count || 0, 0)} ${state.lang === 'fa' ? 'باز' : 'open'}`, Number(bp.missing_stop_count || 0) ? 'bad' : 'good')}</div>${alerts.length ? `<div class="journal-list risk-alert-list">${alerts.slice(0, 10).map(x => `<div class="notice ${x.severity === 'critical' ? 'danger' : 'warning'}"><strong>${esc(x.title_fa || x.title_en || x.code || 'هشدار')}</strong><p>${esc(x.message_fa || x.message_en || x.code || '')}</p></div>`).join('')}</div>` : `<div class="notice good"><strong>${state.lang === 'fa' ? 'در حال حاضر هشدار فعالی وجود ندارد.' : 'No active risk alerts.'}</strong></div>`}<div class="metric-grid">${metric(state.lang === 'fa' ? 'اگر همه SLها بخورند' : 'If all stops hit', money(g.what_if?.all_stops_loss_amount || 0, g.account?.currency || 'USD'), '', 'bad')}${metric(state.lang === 'fa' ? 'اکویتی پس از سناریو' : 'Projected equity', money(g.what_if?.equity_after_all_stops || 0, g.account?.currency || 'USD'), '', 'warn')}</div></div></section>`;
}
function riskCoachPanel(r, a) {
    const c = r.risk_coach || {}, plan = r.daily_plan || c.daily_plan || {}, behavior = c.behavior || c.behavioral_details || {}, findings = c.findings || [], score = Number(c.discipline_score || c.score || 0), tone = score >= 80 ? 'good' : score >= 60 ? 'warn' : 'bad';
    return `<section class="panel risk-coach-live"><div class="panel-head"><div><small class="eyebrow">RISK COACH</small><h2>${state.lang === 'fa' ? 'مربی شخصی ریسک' : 'Personal risk coach'}</h2></div><span class="status-badge ${tone}">${num(score, 0)}/100</span></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'ریسک هر معامله' : 'Risk per trade', pct(plan.max_risk_per_trade_percent || 0), '', 'info')}${metric(state.lang === 'fa' ? 'ریسک روزانه' : 'Daily risk', pct(plan.max_daily_risk_percent || 0), '', 'warn')}${metric(state.lang === 'fa' ? 'حداکثر معاملات' : 'Max trades', num(plan.max_trades || 0, 0), '', '')}${metric(state.lang === 'fa' ? 'توقف بعد از ضرر' : 'Stop after losses', num(plan.stop_after_losses || 0, 0), '', 'bad')}</div><div class="card-actions"><button class="button secondary small" data-risk-plan="${esc(a.id)}">${state.lang === 'fa' ? 'ویرایش برنامه امروز' : 'Edit today plan'}</button>${plan.status !== 'accepted' ? `<button class="button primary small" data-risk-plan-accept="${esc(a.id)}">${state.lang === 'fa' ? 'تأیید برنامه' : 'Accept plan'}</button>` : ''}<button class="button ghost small" data-risk-checkin="${esc(a.id)}">${state.lang === 'fa' ? 'ثبت وضعیت روانی' : 'Risk check-in'}</button></div>${findings.length ? `<div class="journal-list">${findings.slice(0, 8).map(x => `<div class="account-card"><div class="row-between"><strong>${esc(x.title_fa || x.title_en || x.code || 'تحلیل')}</strong><span class="status-badge ${x.severity === 'critical' ? 'bad' : 'warn'}">${esc(x.severity || 'info')}</span></div><p>${esc(x.message_fa || x.message_en || x.detail || '')}</p></div>`).join('')}</div>` : ''}</div></section>`;
}
function mt5PairModal(accountId) {
    openModal('MT5 CONNECTOR', state.lang === 'fa' ? 'ساخت کد اتصال یک‌بارمصرف' : 'Create one-time pairing code', `<div class="notice warning"><strong>${state.lang === 'fa' ? 'ابتدا بسته اتصال‌دهنده را دانلود و سورس را در MetaEditor با F7 کامپایل کنید.' : 'Download the connector source and compile it with F7 in MetaEditor.'}</strong></div><p>${state.lang === 'fa' ? 'این اتصال فقط‌خواندنی است. رمز معاملاتی یا Investor Password وارد نکنید.' : 'This connection is read-only. Do not enter any trading password.'}</p>`, [{label: state.lang === 'fa' ? 'ساخت کد' : 'Generate code', kind: 'primary', action: async () => { setBusy(true); try { const data = await action('mt5_pairing_create', {account_id: accountId}, false); openModal('MT5 CONNECTOR', state.lang === 'fa' ? 'کد اتصال آماده است' : 'Pairing code ready', `<div class="account-card"><small>${state.lang === 'fa' ? 'کد یک‌بارمصرف' : 'One-time code'}</small><h2 data-preserve-language>${esc(data.code)}</h2><p>${state.lang === 'fa' ? 'اعتبار' : 'Expires in'}: ${num((data.ttl_seconds || 0)/60, 0)} min</p></div><div class="card-actions"><a class="button primary" href="${esc(data.download_package_url || './downloads/Sentinel_MT5_Connector_Source.zip')}" target="_blank" rel="noopener">${state.lang === 'fa' ? 'دانلود بسته اتصال‌دهنده' : 'Download connector'}</a><a class="button secondary" href="${esc(data.installation_guide_url || './downloads/Sentinel_MT5_Installation_FA.txt')}" target="_blank" rel="noopener">${state.lang === 'fa' ? 'راهنمای نصب' : 'Installation guide'}</a></div><p>${state.lang === 'fa' ? 'آدرس WebRequest مجاز' : 'Allowed WebRequest URL'}:</p><code data-preserve-language>${esc(data.api_url || location.origin)}</code>`, []); } catch(err) { toast(err.message, 'error'); } finally { setBusy(false); }}}]);
}
function riskPlanModal(accountId) {
    const r=state.resources.risk || {}, p=r.daily_plan || r.risk_coach?.daily_plan || {};
    openModal('RISK COACH', state.lang === 'fa' ? 'برنامه ریسک امروز' : 'Today risk plan', `<form id="riskPlanForm"><div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'ریسک هر معامله' : 'Risk per trade'} (%)</label><input id="rpTrade" inputmode="decimal" value="${esc(p.max_risk_per_trade_percent ?? 0.5)}"></div><div class="field"><label>${state.lang === 'fa' ? 'ریسک کل روز' : 'Daily total risk'} (%)</label><input id="rpDaily" inputmode="decimal" value="${esc(p.max_daily_risk_percent ?? 1.5)}"></div><div class="field"><label>${state.lang === 'fa' ? 'حداکثر معامله' : 'Max trades'}</label><input id="rpTrades" inputmode="numeric" value="${esc(p.max_trades ?? 3)}"></div><div class="field"><label>${state.lang === 'fa' ? 'توقف پس از ضرر' : 'Stop after losses'}</label><input id="rpLosses" inputmode="numeric" value="${esc(p.stop_after_losses ?? 2)}"></div><div class="field"><label>${state.lang === 'fa' ? 'حداقل R:R' : 'Minimum R:R'}</label><input id="rpRR" inputmode="decimal" value="${esc(p.minimum_rr ?? 2)}"></div></div></form>`, [{label: state.lang === 'fa' ? 'ذخیره و تأیید' : 'Save and accept', kind:'primary', action: async()=>{ const values={max_risk_per_trade_percent:Number($('#rpTrade').value),max_daily_risk_percent:Number($('#rpDaily').value),max_trades:Number($('#rpTrades').value),stop_after_losses:Number($('#rpLosses').value),minimum_rr:Number($('#rpRR').value)}; await action('risk_daily_plan_update',{account_id:accountId,values,accept:true}); closeModal(); invalidate('risk','expansion'); await renderRisk(true); toast(t('success')); }}]);
}
function riskCheckinModal(accountId) {
    openModal('RISK COACH', state.lang === 'fa' ? 'ثبت وضعیت قبل از معامله' : 'Pre-trade check-in', `<form id="riskCheckinForm"><div class="field"><label>${state.lang === 'fa' ? 'حالت فعلی' : 'Current emotion'}</label><select id="rcEmotion"><option value="calm">${state.lang === 'fa' ? 'آرام' : 'Calm'}</option><option value="focused">${state.lang === 'fa' ? 'متمرکز' : 'Focused'}</option><option value="fearful">${state.lang === 'fa' ? 'نگران' : 'Fearful'}</option><option value="angry">${state.lang === 'fa' ? 'عصبانی' : 'Angry'}</option><option value="revenge">${state.lang === 'fa' ? 'تمایل به انتقام' : 'Revenge urge'}</option></select></div><div class="field"><label>${state.lang === 'fa' ? 'اعتماد به پلن از ۱۰' : 'Plan confidence /10'}</label><input id="rcConfidence" inputmode="numeric" value="7"></div><div class="field"><label>${state.lang === 'fa' ? 'یادداشت' : 'Note'}</label><textarea id="rcNote" maxlength="1000"></textarea></div></form>`, [{label:t('save'),kind:'primary',action:async()=>{await action('risk_checkin_create',{account_id:accountId,checkin_type:'pretrade',emotion:$('#rcEmotion').value,confidence:Number($('#rcConfidence').value),followed_plan:true,note:$('#rcNote').value});closeModal();toast(t('success'));}}]);
}
/* v8.5 simplified risk workspace: weekly budget first, advanced prop data collapsed. */
async function renderRisk(force = false) {
    const page = $('#page-risk');
    if (!featureEnabled('risk')) {
        page.innerHTML = pageHead('RISK OS', t('riskOS'), '') + disabledPanel();
        return;
    }
    page.innerHTML = pageHead('RISK OS', t('riskOS'), state.lang === 'fa' ? 'اول ظرفیت ریسک این هفته را ببین؛ جزئیات پیشرفته فقط در صورت نیاز باز می‌شوند.' : 'See this week’s risk capacity first. Advanced details stay optional.') + skeleton(4);
    try {
        const r = await loadResource('risk', force), a = r.selected_account || r.default_account || {}, e = r.exposure || {}, w = r.what_if || {}, p = r.prop || {}, weekly = r.weekly_risk || {}, positions = r.positions || [];
        if (!a?.id) {
            page.innerHTML = pageHead('RISK OS', t('riskOS'), '', `<button class="button small" data-account-edit="new">${icon('plus')}${esc(t('addAccount'))}</button>`) + `<div class="panel">${empty(state.lang === 'fa' ? 'برای شروع یک حساب معاملاتی اضافه کنید.' : 'Add a trading account to begin.')}</div>`;
            return;
        }
        const weeklyTone = weekly.level === 'stop' ? 'bad' : weekly.level === 'caution' ? 'warn' : 'good', guidance = state.lang === 'fa' ? weekly.guidance_fa : weekly.guidance_en, isProp = String(a.type || '').startsWith('prop');
        page.innerHTML = pageHead('RISK OS', t('riskOS'), state.lang === 'fa' ? 'خلاصه روشن ریسک، معاملات گرفته‌شده و ظرفیت باقی‌مانده.' : 'A clear summary of taken trades and remaining capacity.', `<button class="button small" data-account-edit="new">${icon('plus')}${esc(t('addAccount'))}</button>`) + `
  <div class="filters account-filters">${(r.accounts || []).map(x => `<button class="filter-chip ${String(x.id) === String(a.id) ? 'active' : ''}" data-account-select="${x.id}">${esc(x.name)}</button>`).join('')}</div>
  <section class="panel weekly-risk ${weeklyTone}"><div class="panel-head"><div><small class="eyebrow">WEEKLY RISK COACH</small><h2>${state.lang === 'fa' ? 'بودجه ریسک این هفته' : 'This week risk budget'}</h2></div><span class="status-badge ${weeklyTone}">${weekly.can_trade === false ? (state.lang === 'fa' ? 'توقف معامله' : 'STOP') : (weekly.level === 'caution' ? (state.lang === 'fa' ? 'احتیاط' : 'CAUTION') : (state.lang === 'fa' ? 'مجاز' : 'OK'))}</span></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'ریسک مصرف‌شده' : 'Used risk', pct(weekly.used_percent || 0), `${num(weekly.taken_count || 0, 0)} ${state.lang === 'fa' ? 'سیگنال گرفته‌شده' : 'taken signals'}`, weeklyTone)}${metric(state.lang === 'fa' ? 'ظرفیت باقی‌مانده' : 'Remaining', pct(weekly.remaining_percent || 0), `${pct(weekly.limit_percent || 0)} ${state.lang === 'fa' ? 'سقف هفتگی' : 'weekly limit'}`, weeklyTone)}${metric(state.lang === 'fa' ? 'ریسک معاملات فعال' : 'Active trade risk', pct(weekly.active_risk_percent || 0), '', 'warn')}${metric(state.lang === 'fa' ? 'درصد استفاده' : 'Usage', pct(weekly.usage_percent || 0), '', weeklyTone)}</div><div class="progress"><i style="width:${Math.min(100, Number(weekly.usage_percent || 0))}%"></i></div><div class="notice ${weeklyTone === 'bad' ? 'danger' : weeklyTone === 'warn' ? 'warning' : 'good'}"><strong>${esc(guidance || '—')}</strong></div>${(weekly.items || []).length ? `<details><summary>${state.lang === 'fa' ? 'سیگنال‌های محاسبه‌شده' : 'Counted signals'}</summary><div class="journal-list">${weekly.items.map(x => `<div class="account-card"><div class="row-between"><strong>${esc(x.symbol || x.signal_id)}</strong><span>${pct(x.risk_percent || 0)}</span></div><p>${esc(x.status || '')} · ${date(x.selected_at)}</p></div>`).join('')}</div></details>` : ''}</div></section>
  <section class="panel"><div class="panel-head"><div><small class="eyebrow">${esc(a.type || 'personal')}</small><h2>${esc(a.name || t('account'))}</h2></div><div class="card-actions">${a.broker_sync_available ? `<button class="button secondary small" data-broker-sync="${esc(a.id)}">${icon('refresh')}${state.lang === 'fa' ? 'همگام‌سازی' : 'Sync'}</button>` : ''}<button class="button ghost small" data-account-edit="${a.id}">${icon('edit')}${esc(t('editAccount'))}</button></div></div><div class="panel-body"><div class="metric-grid">${metric(t('balance'), money(a.balance, a.currency), '', 'info')}${metric(t('equity'), money(a.equity, a.currency), '', '')}${metric(t('openRisk'), pct(e.open_risk_percent || 0), `${num(e.open_trades || 0, 0)} trade`, 'warn')}${metric(state.lang === 'fa' ? 'ظرفیت روزانه' : 'Daily remaining', pct(e.remaining_daily_risk_percent || 0), '', 'info')}</div></div></section>
  ${mt5ConnectorPanel(r, a)}
  ${propGuardianPanel(r)}
  ${riskCoachPanel(r, a)}
  <section class="panel"><div class="panel-head"><h2>${esc(t('whatIf'))}</h2></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'اگر همه استاپ شوند' : 'If all stops hit', money(w.all_stops_loss_amount || 0, a.currency), '', 'bad')}${metric(state.lang === 'fa' ? 'اکویتی بعد از استاپ‌ها' : 'Equity after stops', money(w.worst_case_equity || w.equity_after_all_stops || a.equity, a.currency), '', 'warn')}${metric(state.lang === 'fa' ? 'افت احتمالی' : 'Potential drawdown', pct(w.worst_case_drawdown_percent || 0), '', w.would_breach_total_loss ? 'bad' : 'good')}</div></div></section>
  ${isProp ? `<details class="panel"><summary class="panel-head"><h2>${state.lang === 'fa' ? 'قوانین حساب پراپ' : 'Prop account rules'}</h2><span class="status-badge ${p.status === 'safe' ? 'good' : p.status === 'warning' ? 'warn' : 'bad'}">${esc(p.status || 'safe')}</span></summary><div class="panel-body"><div class="metric-grid">${metric(t('dailyLoss'), pct(p.daily_loss_used_percent || 0), `${pct(p.daily_loss_remaining_percent || 0)} remaining`, p.daily_loss_remaining_percent < 1 ? 'bad' : 'warn')}${metric(t('totalLoss'), pct(p.total_drawdown_percent || 0), `${pct(p.total_loss_remaining_percent || 0)} remaining`, p.total_loss_remaining_percent < 1 ? 'bad' : 'warn')}${metric(t('profitTarget'), pct(p.profit_progress_percent || 0), '', 'good')}${metric(state.lang === 'fa' ? 'روزهای معامله' : 'Trading days', `${num(p.trading_days || 0, 0)}/${num(p.min_trading_days || 0, 0)}`, '', 'info')}</div>${(p.hard_blocks || []).length ? `<div class="notice danger">${(p.hard_blocks || []).map(x => esc(x.code || x)).join(' · ')}</div>` : ''}</div></details>` : ''}
  <section class="panel"><div class="panel-head"><h2>${esc(t('positions'))}</h2><span class="status-badge info">${num(positions.length, 0)}</span></div><div class="panel-body journal-list">${positions.map(positionCard).join('') || empty()}</div></section>
  <details class="panel"><summary class="panel-head"><h2>${state.lang === 'fa' ? 'تحلیل پیشرفته' : 'Advanced analysis'}</h2></summary><div class="panel-body"><h3>${esc(t('correlation'))}</h3>${correlationHtml(r.correlation || {})}<h3>${state.lang === 'fa' ? 'تازگی داده' : 'Data freshness'}</h3>${confidenceHtml(r.data_confidence || {})}</div></details>`;
    }
    catch (err) {
        page.innerHTML = errorPanel(err, 'risk');
    }
}
async function renderMoreLegacy(force = false) { const page = $('#page-more'), o = state.resources.overview || {}; page.innerHTML = pageHead('EXPLORE', t('more'), state.lang === 'fa' ? 'بازار، شفافیت، اعلان، اشتراک و پشتیبانی در یک مرکز.' : 'Market, transparency, notifications, subscription and support in one center.') + `<div class="feature-grid">${feature('search', t('globalSearch'), state.lang === 'fa' ? 'جست‌وجو در تمام داده‌های شخصی' : 'Search all personal data', 'search')}${feature('market', t('market'), state.lang === 'fa' ? 'قیمت‌ها و واچ‌لیست' : 'Quotes and watchlist', 'market')}${feature('calendar', t('calendar'), state.lang === 'fa' ? 'خبرهای مهم هفته' : 'Important events', 'calendar')}${feature('chart', t('trackRecord'), state.lang === 'fa' ? 'آمار واقعی و هش شواهد' : 'Verified performance', 'track')}${feature('bell', t('revisions'), state.lang === 'fa' ? 'تغییرات پوزیشن‌های Taken' : 'Changes to taken signals', 'revisions', o.revision_count || 0)}${feature('bell', t('notifications'), state.lang === 'fa' ? 'فیلتر بازار، ساعات سکوت و خلاصه‌ها' : 'Market filters, quiet hours and digests', 'notifications')}${feature('crown', t('vip'), state.lang === 'fa' ? 'پلن‌ها و پرداخت امن' : 'Plans and secure checkout', 'vip')}${feature('wallet', t('orders'), state.lang === 'fa' ? 'پیگیری، لغو و ارسال مجدد' : 'Track, cancel, resubmit', 'orders')}${feature('support', t('support'), state.lang === 'fa' ? 'تیکت و پاسخ‌ها' : 'Tickets and replies', 'support')}${feature('user', t('settings'), state.lang === 'fa' ? 'زبان، قوانین و نشست' : 'Language, rules, session', 'settings')}${o.admin_available ? feature('shield', t('adminConsole'), state.lang === 'fa' ? 'تحویل شیفت، گزارش روزانه و آزمایش‌های رشد' : 'Handoffs, daily brief and growth experiments', 'admin') : ''}</div>`; }
function searchModal() { openModal('SEARCH', t('globalSearch'), `<div class="search-box">${icon('search')}<label class="sr-only" for="globalSearchInput">${esc(t('globalSearch'))}</label><input id="globalSearchInput" autocomplete="off" placeholder="${esc(t('searchPlaceholder'))}"></div><div id="globalSearchResults" class="search-results">${empty()}</div>`, []); setTimeout(() => $('#globalSearchInput')?.focus(), 50); }
async function runGlobalSearch(query) { const box = $('#globalSearchResults'); if (!box)
    return; if (query.trim().length < 2) {
    box.innerHTML = empty();
    return;
} box.innerHTML = skeleton(2); try {
    const data = await request(`./api/v1/search?q=${encodeURIComponent(query.trim())}&limit=50`);
    box.innerHTML = (data.items || []).map(x => `<button class="search-result" data-search-target="${esc(x.target)}"><span class="status-badge info">${esc(x.type)}</span><span><strong>${esc(x.title)}</strong><small>${esc(x.subtitle || '')}</small></span>${icon('chevron')}</button>`).join('') || empty();
}
catch (err) {
    box.innerHTML = errorPanel(err, 'search');
} }
function notificationModal() { const n = state.resources.overview?.notifications || {}; const keys = [['signals', state.lang === 'fa' ? 'سیگنال‌ها' : 'Signals'], ['results', state.lang === 'fa' ? 'نتایج سیگنال' : 'Signal results'], ['news', state.lang === 'fa' ? 'اخبار مهم' : 'Important news'], ['calendar', t('calendar')], ['support', t('support')], ['alerts', state.lang === 'fa' ? 'هشدار قیمت' : 'Price alerts'], ['daily_digest', state.lang === 'fa' ? 'خلاصه روزانه' : 'Daily digest'], ['weekly_digest', state.lang === 'fa' ? 'خلاصه هفتگی' : 'Weekly digest']]; openModal('NOTIFICATIONS', t('notifications'), `<form id="notificationForm"><div class="toggle-list">${keys.map(([k, label]) => `<label class="toggle-row" for="notify_${k}"><span>${esc(label)}</span><input id="notify_${k}" type="checkbox" ${n[k] !== false ? 'checked' : ''}></label>`).join('')}</div><div class="form-grid"><div class="field"><label for="notifyMarkets">${state.lang === 'fa' ? 'بازارها (forex, crypto)' : 'Markets (forex, crypto)'}</label><input id="notifyMarkets" value="${esc((n.markets || []).join(', '))}"></div><div class="field"><label for="notifySymbols">${state.lang === 'fa' ? 'نمادهای خاص' : 'Specific symbols'}</label><input id="notifySymbols" value="${esc((n.symbols || []).join(', '))}"></div><div class="field"><label for="notifyTimezone">${esc(t('timezone'))}</label><input id="notifyTimezone" value="${esc(n.timezone || 'Asia/Tehran')}"></div><div class="field"><label for="notifyQuietStart">${state.lang === 'fa' ? 'شروع سکوت' : 'Quiet start'}</label><input id="notifyQuietStart" type="time" value="${esc(n.quiet_start || '23:00')}"></div><div class="field"><label for="notifyQuietEnd">${state.lang === 'fa' ? 'پایان سکوت' : 'Quiet end'}</label><input id="notifyQuietEnd" type="time" value="${esc(n.quiet_end || '07:00')}"></div><div class="field"><label for="notifyPause">${state.lang === 'fa' ? 'توقف موقت (ساعت)' : 'Pause for hours'}</label><input id="notifyPause" type="number" min="0" max="8760" value="0"></div></div><label class="check-row" for="notifyQuiet"><input id="notifyQuiet" type="checkbox" ${n.quiet_enabled !== false ? 'checked' : ''}><span>${state.lang === 'fa' ? 'ساعات سکوت فعال' : 'Quiet hours enabled'}</span></label></form>`, [{ label: t('save'), kind: 'primary', action: saveNotifications }]); }
async function saveNotifications() { const form = $('#notificationForm'); if (!form?.reportValidity())
    return; const payload = { markets: $('#notifyMarkets').value.split(',').map(x => x.trim()).filter(Boolean), symbols: $('#notifySymbols').value.split(',').map(x => x.trim()).filter(Boolean), timezone: $('#notifyTimezone').value, quiet_start: $('#notifyQuietStart').value, quiet_end: $('#notifyQuietEnd').value, quiet_enabled: $('#notifyQuiet').checked, pause_hours: Number($('#notifyPause').value || 0) }; ['signals', 'results', 'news', 'calendar', 'support', 'alerts', 'daily_digest', 'weekly_digest'].forEach(k => payload[k] = $(`#notify_${k}`).checked); setBusy(true); try {
    const result = await action('notification_preferences_update', payload, false);
    state.resources.overview.notifications = result;
    toast(t('success'));
    closeModal();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function feature(ic, title, desc, target, badge = 0) { const enabled = !FEATURE_KEY[target] || featureEnabled(target); return `<button class="feature-tile touch ${enabled ? '' : 'disabled'}" ${enabled ? `data-open="${target}"` : 'data-feature-disabled'} aria-disabled="${enabled ? 'false' : 'true'}">${icon(enabled ? ic : 'lock')}<strong>${esc(title)}</strong><small>${esc(enabled ? desc : t('maintenance'))}</small>${badge ? `<em>${num(badge, 0)}</em>` : ''}</button>`; }
async function openMoreLegacy(target) { if (target === 'settings')
    return settingsModal(); if (target === 'search')
    return searchModal(); if (target === 'notifications')
    return notificationModal(); if (target === 'onboarding')
    return onboardingModal(); if (target === 'admin')
    return adminWorkspace(); if (FEATURE_KEY[target] && !featureEnabled(target))
    return featureDisabledModal(); setBusy(true); try {
    const key = target === 'vip' ? 'overview' : target === 'support' ? 'tickets' : target;
    await loadResource(key);
    ({ market: marketModal, calendar: calendarModal, track: trackModal, revisions: revisionsModal, vip: vipModal, orders: ordersModal, support: supportModal }[target] || (() => { }))();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function marketQuoteCard(q, watchSymbols = new Set(), allowWatch = true) { const symbol = String(q.symbol || '').toUpperCase(), watched = watchSymbols.has(symbol), change = Number(q.change_percent || 0), stale = Boolean(q.stale || q.delayed), providers = Number(q.provider_count || 1), confidence = Number(q.confidence || 0); return `<div class="account-card" data-market-row="${esc(symbol)}"><div class="row-between"><div><strong>${esc(q.title || q.symbol)}</strong><small class="mono">${esc(q.symbol || '')}</small></div><div><b data-market-price>${num(q.price, 7)} ${esc(q.unit || '')}</b>${stale ? `<span class="status-badge warn">${state.lang === 'fa' ? 'آخرین قیمت معتبر' : 'Last known'}</span>` : ''}</div></div><p data-market-meta>${esc(q.provider || q.source || '')} · ${date(q.updated_at)}${providers > 1 ? ` · ${providers} API · ${pct(confidence * 100, 0)} confidence` : ''}${Number.isFinite(change) && change !== 0 ? ` · <span class="${change >= 0 ? 'text-good' : 'text-bad'}">${change >= 0 ? '+' : ''}${pct(change, 2)}</span>` : ''}</p><div class="card-actions">${watched ? `<span class="status-badge good">Watchlist</span><button class="button danger small" data-watch-remove="${esc(q.symbol)}">${state.lang === 'fa' ? 'حذف' : 'Remove'}</button>` : allowWatch ? `<button class="button secondary small" data-watch-quick="${esc(q.symbol)}">${icon('plus')} Watchlist</button>` : ''}</div></div>`; }
function marketModal() { const d = state.resources.market || {}, quotes = d.quotes || [], iran = d.iran_quotes || d.iran || [], watch = d.watchlist || [], reg = d.regime || {}, current = reg.current || {}, watchSymbols = new Set(watch.map(w => String(w.symbol || '').toUpperCase())), failed = d.failed_quotes || []; openModal('MARKET', t('market'), `<div class="row-between"><span id="marketLiveBadge" class="status-badge ${d.live ? 'good' : 'warn'}">${d.live ? 'LIVE · MULTI API' : 'CACHE'}</span><button class="button secondary small" data-market-refresh>${icon('refresh')}${esc(t('updated'))}</button></div><section class="panel regime-card"><div class="panel-head"><div><small class="eyebrow">MARKET INTELLIGENCE</small><h3>${esc(t('marketRegime'))}</h3></div><span class="status-badge info">${esc(String(current.regime || 'balanced').replaceAll('_', ' '))}</span></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'اطمینان' : 'Confidence', pct(Number(current.confidence || 0) * 100, 0), '', 'info')}${metric(state.lang === 'fa' ? 'نوسان' : 'Volatility', esc(current.volatility || 'unknown'), '', '')}${metric(state.lang === 'fa' ? 'سشن' : 'Session', esc(current.session || '—'), '', '')}</div><p class="field-help">${esc((current.reasons || []).join(' · '))}</p></div></section><div class="field"><label for="watchSymbol">${state.lang === 'fa' ? 'افزودن نماد به واچ‌لیست' : 'Add symbol to watchlist'}</label><div style="display:flex;gap:8px"><input id="watchSymbol" maxlength="20" class="ltr" placeholder="XAUUSD / BTCUSD"><button class="button" data-watch-add>${icon('plus')}</button></div></div>${watch.length ? `<section class="panel"><div class="panel-head"><h3>Watchlist</h3><span class="status-badge info">${num(watch.length, 0)}</span></div><div class="panel-body signal-list">${watch.map(w => { const row = w.quote || [...quotes, ...iran].find(q => String(q.symbol).toUpperCase() === String(w.symbol).toUpperCase()) || w; return marketQuoteCard(row, watchSymbols, false); }).join('')}</div></section>` : ''}<section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'بازار جهانی' : 'Global markets'}</h3><span class="status-badge ${failed.length ? 'warn' : 'good'}">${num(quotes.length, 0)} / ${num(quotes.length + failed.length, 0)}</span></div><div class="panel-body signal-list">${quotes.length ? quotes.map(q => marketQuoteCard(q, watchSymbols)).join('') : empty()}</div></section><section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'بازار ایران' : 'Iran market'}</h3><span class="status-badge ${d.iran_error ? 'warn' : 'good'}">${num(iran.length, 0)}</span></div><div class="panel-body">${d.iran_error ? `<div class="notice warning">${esc(d.iran_error)}</div>` : ''}<div class="signal-list">${iran.length ? iran.map(q => marketQuoteCard(q, watchSymbols)).join('') : empty()}</div></div></section>${failed.length ? `<details class="notice warning"><summary>${state.lang === 'fa' ? 'نمادهای موقتاً ناموفق' : 'Temporarily unavailable symbols'}</summary><p>${failed.map(x => esc(x.symbol)).join(' · ')}</p></details>` : ''}`, []); }
function refreshMarketDom(data) { if (!data)
    return; const rows = [...(data.quotes || []), ...(data.iran_quotes || data.iran || [])]; for (const q of rows) {
    const row = document.querySelector(`[data-market-row="${CSS.escape(String(q.symbol || '').toUpperCase())}"]`);
    if (!row)
        continue;
    const price = $('[data-market-price]', row), meta = $('[data-market-meta]', row);
    if (price)
        price.textContent = `${num(q.price, 7)} ${q.unit || ''}`.trim();
    if (meta)
        meta.textContent = `${q.provider || q.source || ''} · ${date(q.updated_at)}${Number(q.provider_count || 1) > 1 ? ` · ${Number(q.provider_count)} API` : ''}`;
} const badge = $('#marketLiveBadge'); if (badge) {
    badge.textContent = data.live ? 'LIVE · MULTI API' : 'CACHE';
    badge.className = `status-badge ${data.live ? 'good' : 'warn'}`;
} }
function calendarModal() { const d = state.resources.calendar || {}, p = d.preferences || {}; openModal('CALENDAR', t('calendar'), `<div class="row-between modal-toolbar"><div><strong>${esc((p.currencies || []).join(' · ') || '—')}</strong><p>${esc(t('minImpact'))}: ${esc(p.min_impact || 'high')} · ${esc(t('reminderMinutes'))}: ${num(p.reminder_minutes || 30, 0)} min</p></div><button class="button secondary small" data-calendar-settings>${icon('settings')}<span>${esc(t('calendarSettings'))}</span></button></div><div class="signal-list">${(d.items || []).map(e => `<div class="account-card"><div class="row-between"><strong>${esc(e.currency || e.country || '')} · ${esc(e.title || e.event || '')}</strong><span class="status-badge ${String(e.importance || e.impact).toLowerCase().includes('high') ? 'bad' : 'warn'}">${esc(e.importance || e.impact || '')}</span></div><p>${date(e.datetime || e.date || e.time)} · Actual ${esc(e.actual ?? '—')} / Forecast ${esc(e.forecast ?? '—')}</p></div>`).join('') || empty()}</div>${moreButton('calendar', d)}`, []); }
function calendarPreferencesModal() { const p = state.resources.calendar?.preferences || {}, currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'NZD', 'CHF', 'CNY'], selected = new Set(p.currencies || []); openModal('CALENDAR SETTINGS', t('calendarSettings'), `<form id="calendarPreferencesForm"><div class="toggle-row"><label for="calendarEnabled"><span>${esc(t('calendarAlerts'))}</span><input id="calendarEnabled" type="checkbox" ${p.enabled !== false ? 'checked' : ''}></label></div><div class="toggle-row"><label for="calendarActualAlerts"><span>${esc(t('actualAlerts'))}</span><input id="calendarActualAlerts" type="checkbox" ${p.actual_alerts !== false ? 'checked' : ''}></label></div><fieldset class="field"><legend>${esc(t('currencies'))}</legend><div class="choice-grid">${currencies.map(c => `<label class="choice-chip"><input type="checkbox" name="calendarCurrency" value="${c}" ${selected.has(c) ? 'checked' : ''}><span>${c}</span></label>`).join('')}</div></fieldset><div class="form-grid"><div class="field"><label for="calendarImpact">${esc(t('minImpact'))}</label><select id="calendarImpact"><option value="high" ${p.min_impact === 'high' ? 'selected' : ''}>High</option><option value="medium" ${p.min_impact === 'medium' ? 'selected' : ''}>Medium</option><option value="low" ${p.min_impact === 'low' ? 'selected' : ''}>Low</option></select></div><div class="field"><label for="calendarReminder">${esc(t('reminderMinutes'))}</label><select id="calendarReminder">${[5, 15, 30, 60, 120].map(v => `<option value="${v}" ${Number(p.reminder_minutes || 30) === v ? 'selected' : ''}>${v} min</option>`).join('')}</select></div><div class="field"><label for="calendarTimezone">${esc(t('timezone'))}</label><select id="calendarTimezone">${['Asia/Tehran', 'Asia/Baku', 'UTC'].map(v => `<option value="${v}" ${String(p.timezone || 'UTC') === v ? 'selected' : ''}>${v}</option>`).join('')}</select></div></div><div id="calendarFormError" class="form-error" role="alert" hidden></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const currencies = $$('input[name="calendarCurrency"]:checked').map(el => el.value), error = $('#calendarFormError'); if (!currencies.length) {
            error.hidden = false;
            error.textContent = state.lang === 'fa' ? 'حداقل یک ارز را انتخاب کنید.' : 'Select at least one currency.';
            return;
        } setBusy(true); try {
            await action('calendar_preferences_update', { enabled: $('#calendarEnabled').checked, actual_alerts: $('#calendarActualAlerts').checked, currencies, min_impact: $('#calendarImpact').value, reminder_minutes: Number($('#calendarReminder').value), timezone: $('#calendarTimezone').value }, false);
            invalidate('calendar');
            await loadResource('calendar', true);
            calendarModal();
            toast(t('success'));
        }
        catch (err) {
            error.hidden = false;
            error.textContent = err.message;
        }
        finally {
            setBusy(false);
        } } }]); }
function trackModal() { const d = state.resources.track || {}, s = d.summary || {}; openModal('TRUST', t('trackRecord'), `<div class="metric-grid">${metric('Sample', num(s.sample_size || 0, 0), '', 'info')}${metric('Win rate', pct(s.win_rate || 0), '', 'good')}${metric('Average R', num(s.average_r || 0, 3), '', '')}${metric('Max DD (R)', num(s.maximum_drawdown_r || 0, 3), '', 'bad')}</div><div class="signal-list">${(d.items || []).map(x => `<div class="account-card"><div class="row-between"><strong>${esc(x.symbol)} · #${num(x.display_number, 0)}</strong><span class="status-badge ${Number(x.outcome?.net_r) >= 0 ? 'good' : 'bad'}">${num(x.outcome?.net_r, 2)}R</span></div><p>${date(x.created_at)} · rev ${num(x.revision, 0)} · chain ${x.revision_chain_valid ? '✓' : '✕'}</p><small class="mono">${esc(x.evidence_hash || '')}</small></div>`).join('') || empty()}</div>${moreButton('track', d)}`, []); }
function revisionsModal() { const d = state.resources.revisions || {}; openModal('REVISION INBOX', t('revisions'), `<div class="revision-list">${(d.items || []).map(x => `<div class="revision-card"><div class="row-between"><strong>${esc(x.symbol)} · #${num(x.display_number, 0)}</strong><span class="status-badge warn">R${num(x.revision, 0)}</span></div><p>${esc((x.changed_fields || []).join(', '))} · ${date(x.created_at)}</p><button class="button small" data-revision-ack="${x.signal_id}" data-revision="${x.revision}">${esc(t('ack'))}</button></div>`).join('') || empty()}</div>`, []); }
function vipModal() { const d = state.resources.overview?.commerce || {}, plans = d.plans || []; openModal('VIP', t('vip'), `<div class="signal-list">${plans.map(p => `<article class="account-card"><div class="row-between"><h3>${esc(state.lang === 'en' && p.name_en ? p.name_en : p.name)}</h3><strong class="quote-price">${num(p.price, 0)} T</strong></div><p>${esc(state.lang === 'en' && p.description_en ? p.description_en : p.description)}</p><div class="card-actions"><button class="button" data-plan-checkout="${p.id}">${esc(t('selectPlan'))}</button></div></article>`).join('') || empty()}</div>`, []); }
function checkoutRequestId(prefix = 'quote') { return `${prefix}:${Date.now()}:${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}`; }
function checkoutActionData(value) { if (!value || typeof value !== 'object') return value; if (value.action && value.data && typeof value.data === 'object') { const data = value.data; return data.result && typeof data.result === 'object' ? data.result : data; } return value; }
function checkoutModal(planId) { const d = state.resources.overview?.commerce || {}, p = (d.plans || []).find(x => Number(x.id) === Number(planId)); if (!p)
    return; openModal('SECURE CHECKOUT', p.name, `<div class="quote-box"><small>${state.lang === 'fa' ? 'قیمت پلن قبل از تخفیف' : 'Plan price before discount'}</small><div class="quote-price">${num(p.price, 0)} Toman</div></div><form id="quoteForm"><div class="field"><label for="payMethod">${esc(t('paymentMethod'))}</label><select id="payMethod">${d.payment?.card?.enabled ? '<option value="card">Card to card</option>' : ''}${d.payment?.usdt?.enabled ? '<option value="usdt">USDT</option>' : ''}</select></div><label class="checkbox-row"><input id="hasCoupon" type="checkbox"><span>${state.lang === 'fa' ? 'کد تخفیف دارم' : 'I have a coupon'}</span></label><div class="field" id="couponField" hidden><label for="couponCode">${esc(t('coupon'))}</label><input id="couponCode" maxlength="40" autocomplete="off"></div></form><div id="quoteResult"></div>`, [{ label: state.lang === 'fa' ? 'نمایش مبلغ و اطلاعات پرداخت' : t('getQuote'), kind: 'primary', action: () => getCheckoutQuote(planId) }]); const toggle = $('#hasCoupon'), field = $('#couponField'); if (toggle && field) toggle.addEventListener('change', () => { field.hidden = !toggle.checked; if (!toggle.checked && $('#couponCode')) $('#couponCode').value = ''; }); }
async function getCheckoutQuote(planId) { setBusy(true); try {
    const requestId = checkoutRequestId('checkout-quote'), coupon = $('#hasCoupon')?.checked ? ($('#couponCode')?.value || '').trim() : '';
    const rawQuote = await request('./api/v1/checkout/quote', { method: 'POST', csrf: true, headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId }, body: JSON.stringify({ plan_id: planId, payment_method: $('#payMethod').value, coupon, request_id: requestId }) });
    const q = checkoutActionData(rawQuote);
    if (!q || !q.quote_id || !Number.isFinite(Number(q.payable_toman))) throw new Error(state.lang === 'fa' ? 'اطلاعات مبلغ پرداخت ناقص است؛ دوباره تلاش کنید.' : 'Checkout quote is incomplete; try again.');
    state.resources.checkoutQuote = q;
    const free = Number(q.payable_toman) <= 0, payment = free ? `<div class="notice good"><strong>${state.lang === 'fa' ? 'فعال‌سازی رایگان' : 'Free activation'}</strong><p>${state.lang === 'fa' ? 'این سفارش بدون رسید ثبت می‌شود، اما فعال‌سازی فقط پس از تأیید دستی ادمین انجام می‌شود.' : 'This order needs no receipt, but still requires manual admin approval.'}</p></div>` : (q.payment_method === 'usdt' ? `<p class="ltr">${esc(q.payment_amount_usdt)} USDT · ${esc(q.payment_network)}</p><p class="mono ltr">${esc(q.payment_wallet)}</p>` : `<p class="ltr mono">${esc(q.payment_card_number)}</p><p>${esc(q.payment_card_owner)}</p>`);
    const receipt = free ? '' : `<div class="field"><label for="receiptFile">${state.lang === 'fa' ? 'عکس فیش پرداخت' : esc(t('uploadReceipt'))}</label><input id="receiptFile" type="file" accept="image/jpeg,image/png,image/webp" required><small class="field-help">${state.lang === 'fa' ? 'پس از انتخاب، پیش‌نمایش فیش نمایش داده می‌شود و برای ادمین ارسال خواهد شد.' : 'The receipt preview will be shown and sent to an admin.'}</small><img id="receiptLocalPreview" class="receipt-preview" hidden alt="receipt preview"></div>`;
    const txid = !free && q.payment_method === 'usdt' ? `<div class="field"><label for="orderTxid">${esc(t('transactionHash'))} (${state.lang === 'fa' ? 'اختیاری' : 'optional'})</label><input id="orderTxid" class="ltr" maxlength="128"><small class="field-help">${state.lang === 'fa' ? 'تأیید پرداخت فقط بر اساس رسید و بررسی دستی ادمین است.' : 'Approval is based on the receipt and manual admin review.'}</small></div>` : '';
    $('#quoteResult').innerHTML = `<div class="quote-box"><small>${esc(t('payable'))}</small><div class="quote-price">${num(q.payable_toman, 0)} Toman</div>${payment}<p>${esc(t('expires'))}: ${date(q.expires_at)}</p></div><form id="orderForm" style="margin-top:14px">${receipt}${txid}<button class="button primary wide" type="button" data-order-submit>${state.lang === 'fa' ? 'ثبت سفارش و ارسال فیش' : esc(t('submit'))}</button></form>`;
    const receiptInput = $('#receiptFile'), receiptPreview = $('#receiptLocalPreview'); if (receiptInput && receiptPreview) receiptInput.addEventListener('change', () => { const file = receiptInput.files?.[0]; if (!file) { receiptPreview.hidden = true; receiptPreview.removeAttribute('src'); return; } receiptPreview.src = URL.createObjectURL(file); receiptPreview.hidden = false; });
    setModalFooter([]);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function submitOrder() { const q = state.resources.checkoutQuote; if (!q)
    return; const free = Number(q.payable_toman || 0) <= 0, file = $('#receiptFile')?.files?.[0]; if (!free && !file) {
    toast(state.lang === 'fa' ? 'رسید را انتخاب کنید.' : 'Select a receipt.', 'error');
    return;
} setBusy(true); try {
    let receiptId = '';
    if (!free) {
        const fd = new FormData();
        fd.append('file', file);
        const receipt = await request('./api/v1/checkout/receipt', { method: 'POST', csrf: true, body: fd }, 40000);
        receiptId = receipt.receipt_id;
    }
    await action('vip_order_submit', { quote_id: q.quote_id, receipt_id: receiptId, transaction_hash: $('#orderTxid')?.value || '' }, false);
    toast(t('success'));
    closeModal();
    invalidate('orders', 'overview');
    await loadOverview(true);
    renderChrome();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function ordersModal() { const d = state.resources.orders || {}; openModal('ORDERS', t('orders'), `<div class="filters">${['all', 'pending', 'approved', 'rejected', 'cancelled'].map(x => `<button class="filter-chip ${state.orderFilter === x ? 'active' : ''}" data-order-filter="${x}">${esc(x === 'all' ? t('all') : x)}</button>`).join('')}</div><div class="order-list" style="margin-top:12px">${(d.items || []).map(o => `<article class="order-card"><div class="row-between"><h3>${esc(o.plan_name)}</h3><span class="status-badge ${o.status === 'approved' ? 'good' : o.status === 'rejected' ? 'bad' : 'warn'}">${esc(o.status)}</span></div><p>${esc(o.order_id)} · ${num(o.price, 0)} T · ${date(o.created_at)}</p>${o.rejection_reason ? `<div class="notice danger">${esc(o.rejection_reason)}</div>` : ''}<div class="card-actions"><button class="button secondary small" data-order-detail="${o.order_id}">${esc(t('orderDetails'))}</button>${['pending', 'approving'].includes(o.status) ? `<button class="button danger small" data-order-cancel="${o.order_id}">${esc(t('cancel'))}</button>` : ''}${['rejected', 'cancelled', 'expired'].includes(o.status) ? `<button class="button small" data-order-resubmit="${o.order_id}">${esc(t('resubmit'))}</button>` : ''}</div></article>`).join('') || empty()}</div>${moreButton('orders', d)}`, []); }
async function orderDetailModal(orderId) { setBusy(true); try {
    const o = await request(`./api/v1/orders/${encodeURIComponent(orderId)}`);
    const receiptPreview = o.receipt_attached || o.receipt_id || o.receipt_key ? `<div class="account-card"><strong>${state.lang === 'fa' ? 'رسید ثبت‌شده' : 'Submitted receipt'}</strong><img class="receipt-preview" src="./api/v1/orders/${encodeURIComponent(orderId)}/receipt" alt="receipt" loading="lazy"></div>` : '';
    openModal('ORDER', `${t('orderDetails')} · ${o.order_id}`, `<div class="metric-grid">${metric(t('status'), esc(o.status), '', 'info')}${metric(t('payable'), `${num(o.price, 0)} T`, '', '')}${metric(t('paymentMethod'), esc(o.payment_method || '—'), '', '')}${metric(t('updated'), date(o.updated_at || o.created_at), '', '')}</div>${receiptPreview}${o.rejection_reason ? `<div class="notice danger"><strong>${esc(t('reason'))}</strong><p>${esc(o.rejection_reason)}</p></div>` : ''}<div class="timeline">${(o.timeline || o.history || []).map(x => `<div class="timeline-item"><strong>${esc(x.status || x.event || 'update')}</strong><p>${esc(x.note || x.reason || '')}</p><small>${date(x.created_at)}</small></div>`).join('') || `<div class="timeline-item"><strong>${esc(o.status)}</strong><small>${date(o.updated_at || o.created_at)}</small></div>`}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function orderResubmitModal(orderId) { setBusy(true); try {
    const o = await request(`./api/v1/orders/${encodeURIComponent(orderId)}`), requestId = checkoutRequestId('checkout-resubmit'), rawQuote = await request('./api/v1/checkout/quote', { method: 'POST', csrf: true, headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId }, body: JSON.stringify({ plan_id: o.plan_id, payment_method: o.payment_method, coupon: o.coupon || '', request_id: requestId }) });
    const q = checkoutActionData(rawQuote); if (!q || !q.quote_id || !Number.isFinite(Number(q.payable_toman))) throw new Error('CHECKOUT_QUOTE_INVALID');
    state.resources.resubmitQuote = q;
    const free = Number(q.payable_toman || 0) <= 0, payment = free ? `<div class="notice good">${state.lang === 'fa' ? 'ارسال مجدد رایگان؛ رسید لازم نیست ولی تأیید ادمین الزامی است.' : 'Free resubmission; no receipt is required, but admin approval is.'}</div>` : (q.payment_method === 'usdt' ? `<p class="ltr">${esc(q.payment_amount_usdt)} USDT · ${esc(q.payment_network)}</p><p class="mono ltr">${esc(q.payment_wallet)}</p>` : `<p class="ltr mono">${esc(q.payment_card_number)}</p><p>${esc(q.payment_card_owner)}</p>`);
    openModal('ORDER', t('resubmit'), `<div class="quote-box"><small>${esc(t('payable'))}</small><div class="quote-price">${num(q.payable_toman, 0)} Toman</div>${payment}<p>${esc(t('expires'))}: ${date(q.expires_at)}</p></div><form id="orderResubmitForm" style="margin-top:14px">${free ? '' : `<div class="field"><label for="resubmitReceipt">${esc(t('uploadReceipt'))}</label><input id="resubmitReceipt" type="file" accept="image/jpeg,image/png,image/webp" required></div>`}${!free && q.payment_method === 'usdt' ? `<div class="field"><label for="resubmitTxid">${esc(t('transactionHash'))}</label><input id="resubmitTxid" class="ltr" maxlength="128"></div>` : ''}</form>`, [{ label: t('resubmit'), kind: 'primary', action: async () => { const f = $('#orderResubmitForm'), file = $('#resubmitReceipt')?.files?.[0]; if (!f.reportValidity() || (!free && !file))
                return; setBusy(true); try {
                let receiptId = '';
                if (!free) {
                    const fd = new FormData();
                    fd.append('file', file);
                    const receipt = await request('./api/v1/checkout/receipt', { method: 'POST', csrf: true, body: fd }, 40000);
                    receiptId = receipt.receipt_id;
                }
                await action('vip_order_resubmit', { order_id: orderId, quote_id: q.quote_id, receipt_id: receiptId, transaction_hash: $('#resubmitTxid')?.value.trim() || '' }, false);
                closeModal();
                invalidate('orders', 'overview');
                await loadResource('orders', true);
                ordersModal();
                toast(t('success'));
            }
            catch (err) {
                toast(err.message, 'error');
            }
            finally {
                setBusy(false);
            } } }]);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function ticketStatusClass(status) { return status === 'closed' ? 'bad' : status === 'answered' ? 'good' : status === 'pending' ? 'warn' : 'info'; }
function ticketStatusLabel(status) { const labelsFa = { open: 'باز', pending: 'در انتظار ادمین', answered: 'پاسخ داده شد', closed: 'بسته' }, labelsEn = { open: 'Open', pending: 'Waiting for admin', answered: 'Answered', closed: 'Closed' }; return (state.lang === 'fa' ? labelsFa : labelsEn)[status] || status; }
function supportModal() { const d = state.resources.tickets || {}, items = d.items || [], counts = items.reduce((a, x) => (a[x.status] = (a[x.status] || 0) + 1, a), {}); openModal('SUPPORT', t('support'), `<div class="notice info"><strong>${state.lang === 'fa' ? 'پشتیبانی یکپارچه ربات و مینی‌اپ' : 'Unified Bot & Mini App support'}</strong><p>${state.lang === 'fa' ? 'تمام پاسخ‌ها در هر دو محیط هم‌زمان ثبت و اطلاع‌رسانی می‌شوند.' : 'Every message is synchronized and notified in both environments.'}</p></div><div class="row-between"><button class="button" data-ticket-new>${icon('plus')}${esc(t('createTicket'))}</button><span class="status-badge info">${num(d.total || items.length, 0)} ${state.lang === 'fa' ? 'تیکت' : 'tickets'}</span></div><div class="filters" style="margin-top:13px">${['all', 'open', 'pending', 'answered', 'closed'].map(x => `<button class="filter-chip ${state.ticketFilter === x ? 'active' : ''}" data-ticket-filter="${x}">${esc(x === 'all' ? t('all') : ticketStatusLabel(x))}${x !== 'all' && counts[x] ? ` · ${num(counts[x], 0)}` : ''}</button>`).join('')}</div><div class="ticket-list" style="margin-top:13px">${items.map(x => { const messages = x.messages || [], last = messages[messages.length - 1] || {}; return `<article class="ticket-card"><div class="row-between"><h3>#${num(x.id, 0)} · ${esc(x.subject)}</h3><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${esc(x.category || 'general')} · ${esc(x.priority || 'normal')} · ${date(x.updated_at || x.created_at)}</p><div class="notice ${x.waiting_for === 'user' ? 'good' : 'info'}"><strong>${x.waiting_for === 'user' ? (state.lang === 'fa' ? 'پاسخ ادمین آماده است' : 'Admin reply available') : (state.lang === 'fa' ? 'در انتظار بررسی پشتیبانی' : 'Waiting for support')}</strong>${last.text ? `<small>${esc(String(last.text).slice(0, 160))}</small>` : ''}</div><div class="card-actions"><button class="button secondary small" data-ticket-detail="${x.id}">${esc(t('details'))} · ${num(messages.length, 0)}</button></div></article>`; }).join('') || empty()}</div>${moreButton('tickets', d)}`, []); }
function ticketNewModal() { openModal('SUPPORT', t('createTicket'), `<form id="ticketForm"><div class="form-grid"><div class="field"><label for="ticketSubject">${esc(t('ticketSubject'))}</label><input id="ticketSubject" required maxlength="200"></div><div class="field"><label for="ticketCategory">${state.lang === 'fa' ? 'دسته' : 'Category'}</label><select id="ticketCategory"><option value="general">General</option><option value="account">Account</option><option value="payment">Payment</option><option value="signal">Signal</option><option value="education">Education</option><option value="technical">Technical</option></select></div><div class="field"><label for="ticketPriority">${esc(t('priority'))}</label><select id="ticketPriority"><option value="low">Low</option><option value="normal" selected>Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></div></div><div class="field"><label for="ticketMessage">${esc(t('message'))}</label><textarea id="ticketMessage" required minlength="4" maxlength="4000"></textarea></div></form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#ticketForm'); if (!f.reportValidity())
            return; setBusy(true); try {
            const row = await action('ticket_create', { subject: $('#ticketSubject').value, priority: $('#ticketPriority').value, text: $('#ticketMessage').value, category: $('#ticketCategory').value }, false);
            invalidate('tickets', 'overview');
            await Promise.all([loadResource('tickets', true), loadOverview(true)]);
            closeModal();
            await ticketDetail(row.id);
            toast(t('success'));
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function ticketDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/tickets/${id}`), closed = x.status === 'closed';
    openModal('TICKET', `#${x.id} · ${x.subject}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'منتظر پاسخ' : 'Waiting for', esc(x.waiting_for || 'admin'), '', 'info')}${metric(state.lang === 'fa' ? 'پیام‌ها' : 'Messages', num((x.messages || []).length, 0), '', '')}</div><div class="timeline">${(x.messages || []).map(m => `<div class="timeline-item ${m.sender === 'admin' ? 'admin-message' : 'user-message'}"><strong>${m.sender === 'admin' ? (state.lang === 'fa' ? 'پشتیبانی SENTINEL' : 'SENTINEL Support') : (state.lang === 'fa' ? 'شما' : 'You')}</strong><p>${esc(m.text)}</p><small>${date(m.created_at)}</small></div>`).join('') || empty()}</div>${!closed ? `<form id="ticketReplyForm"><div class="field"><label for="ticketReply">${esc(t('message'))}</label><textarea id="ticketReply" required maxlength="4000"></textarea></div><div class="card-actions"><button type="button" class="button" data-ticket-reply="${x.id}">${esc(t('submit'))}</button><button type="button" class="button danger" data-ticket-status="${x.id}" data-status="closed">${state.lang === 'fa' ? 'بستن تیکت' : 'Close ticket'}</button></div></form>` : `<div class="notice warning"><strong>${state.lang === 'fa' ? 'تیکت بسته است' : 'Ticket is closed'}</strong><button class="button secondary small" data-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button></div>`}`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function settingsModal() { const o = state.resources.overview || {}; openModal('SETTINGS', t('settings'), `<div class="account-card"><div class="row-between"><strong>${esc(t('onboarding'))}</strong><span class="status-badge ${o.onboarding?.completed ? 'good' : 'warn'}">${esc(o.onboarding?.completed ? t('accepted') : t('pending'))}</span></div><p>${state.lang === 'fa' ? 'سطح تجربه، بازار، اندازه حساب، تحمل ریسک و هدف خود را ویرایش کنید.' : 'Edit experience, market, account size, risk tolerance and primary goal.'}</p><button class="button secondary small" data-open="onboarding">${esc(t('onboarding'))}</button></div><div class="account-card"><div class="row-between"><strong>${esc(t('language'))}</strong><button class="button secondary small" data-language-toggle>${state.lang === 'fa' ? 'English' : 'Persian'}</button></div></div><div class="account-card"><div class="row-between"><strong>${esc(t('rules'))}</strong><span class="status-badge ${o.rules?.accepted ? 'good' : 'warn'}">${esc(o.rules?.accepted ? t('accepted') : t('pending'))}</span></div><p>${esc(o.rules?.summary || o.rules?.title || '')}</p>${o.rules?.accepted ? '' : `<button class="button small" data-rules-accept>${esc(t('acceptRules'))}</button>`}</div><div class="account-card"><div class="row-between"><strong>${esc(t('appVersion'))}</strong><span class="mono">${esc(APP_VERSION)}</span></div><p>${state.lang === 'fa' ? 'کش برنامه نسخه‌دار است و Hotfixها بدون انتظار ۲۴ ساعته دریافت می‌شوند.' : 'Versioned assets receive hotfixes without a 24-hour stale cache.'}</p><button class="button secondary small" data-app-reload>${esc(t('reloadApp'))}</button></div><button class="button danger" data-logout>${esc(t('logout'))}</button>`, []); }
/* v8.3.9 role-separated navigation. Server permissions remain authoritative. */
async function renderMore(force = false) {
    const page = $('#page-more'), o = state.resources.overview || {}, admin = o.admin || { available: Boolean(o.admin_available), role: 'user' };
    const userTools = `<section class="panel"><div class="panel-head"><div><small class="eyebrow">USER CENTER</small><h2>مرکز کاربر</h2></div><span class="status-badge info">${esc(o.user?.role || 'user')}</span></div><div class="panel-body"><div class="feature-grid">
 ${feature('bell', 'فید کانال', 'سیگنال، خبر و اعلان زنده', 'feed')}
 ${feature('shield', 'مرکز تمرین و ریسک', 'Paper Trading، Prop و مربی رفتار', 'tradeCenter')}
 ${feature('chart', 'بررسی هوشمند حساب', 'تحلیل ژورنال، ریسک و حساب‌های خودت با یک دکمه', 'ai')}
 ${feature('search', t('globalSearch'), 'جست‌وجو در تمام داده‌های شخصی', 'search')}
 ${feature('market', t('market'), 'قیمت‌ها و واچ‌لیست', 'market')}
 ${feature('calendar', t('calendar'), 'خبرهای مهم هفته', 'calendar')}
 ${feature('chart', t('trackRecord'), 'عملکرد قابل راستی‌آزمایی', 'track')}
 ${feature('bell', t('revisions'), 'تغییرات سیگنال‌های گرفته‌شده', 'revisions', o.revision_count || 0)}
 ${feature('user', t('settings'), 'زبان، قوانین و نشست', 'settings')}
 ${feature('support', t('support'), 'تیکت و پاسخ‌ها', 'support')}
 </div></div></section>`;
    const adminPerms = new Set(admin.permissions || []), canAI = admin.role === 'owner' || adminPerms.has('ai_command_center'); const adminTools = admin.available ? `<section class="panel admin-zone"><div class="panel-head"><div><small class="eyebrow">ADMIN ONLY</small><h2>مرکز اختصاصی ادمین</h2></div><span class="status-badge warn">${esc(admin.role || 'admin')}</span></div><div class="panel-body"><p class="field-help">این بخش فقط با نقش و مجوز ادمین از سمت سرور باز می‌شود.</p><div class="feature-grid">${feature('shield', t('adminConsole'), 'عملیات، Audit، شیفت و کنترل سامانه', 'admin')}${canAI ? feature('chart', 'مرکز فرماندهی Gemini', 'CRM، کانال، کاربران و سلامت سیستم', 'adminAI') : ''}</div></div></section>` : '';
    page.innerHTML = pageHead('EXPLORE', t('more'), 'دسترسی‌های کاربر و ادمین کاملاً از هم جدا شده‌اند.') + userTools + adminTools;
}
async function openMore(target) {
    if (target === 'settings')
        return settingsModal();
    if (target === 'search')
        return searchModal();
    if (target === 'notifications')
        return notificationModal();
    if (target === 'onboarding')
        return onboardingModal();
    if (target === 'admin')
        return adminWorkspace();
    if (target === 'feed')
        return feedModal();
    if (target === 'tradeCenter')
        return tradeCenterModal();
    if (target === 'ai')
        return userAiCenter();
    if (target === 'adminAI')
        return adminAiCenter();
    if (FEATURE_KEY[target] && !featureEnabled(target))
        return featureDisabledModal();
    setBusy(true);
    try {
        const key = target === 'vip' ? 'overview' : target === 'support' ? 'tickets' : target;
        await loadResource(key);
        ({ market: marketModal, calendar: calendarModal, track: trackModal, revisions: revisionsModal, vip: vipModal, orders: ordersModal, support: supportModal }[target] || (() => { }))();
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function contestKindMeta(kind) {
    const fa = state.lang === 'fa';
    const rows = {
        price: { icon: 'market', title: fa ? 'پیش‌بینی قیمت' : 'Price prediction', desc: fa ? 'نزدیک‌ترین قیمت برنده است' : 'Closest price wins' },
        chart: { icon: 'chart', title: fa ? 'مسابقه چارت' : 'Chart challenge', desc: fa ? 'جهت بعدی بازار را انتخاب کنید' : 'Choose the next market direction' },
        candle: { icon: 'signal', title: fa ? 'مسابقه کندل' : 'Candle challenge', desc: fa ? 'قیمت بسته‌شدن کندل را حدس بزنید' : 'Predict the candle close' },
        news_direction: { icon: 'calendar', title: fa ? 'جهت بازار بعد از خبر' : 'News direction', desc: fa ? 'حرکت بازار بعد از خبر را پیش‌بینی کنید' : 'Predict the post-news move' },
    };
    return rows[kind] || { icon: 'trophy', title: fa ? 'مسابقه' : 'Contest', desc: '' };
}
function contestChoiceLabel(kind, value) {
    const key = String(value ?? '').toUpperCase(), fa = state.lang === 'fa';
    const labels = {
        UP: fa ? 'صعودی' : 'Bullish',
        DOWN: fa ? 'نزولی' : 'Bearish',
        FLAT: fa ? 'خنثی' : 'Flat',
        RANGE: fa ? 'رنج' : 'Range',
    };
    return labels[key] || String(value ?? '—');
}
function contestRewardText(row) {
    if(row.prize_by_rank && Object.keys(row.prize_by_rank).length) return Object.entries(row.prize_by_rank).map(([rank,prize])=>`#${rank}: ${clientPrizeLabel(prize)}`).join(" · ");
    if (row.kind === 'candle') {
        const r = row.reward_by_rank || {};
        return state.lang === 'fa'
            ? `رتبه ۱: ${num(r['1'] || 10, 0)} · رتبه ۲: ${num(r['2'] || 7, 0)} · رتبه ۳: ${num(r['3'] || 5, 0)} امتیاز`
            : `1st: ${num(r['1'] || 10, 0)} · 2nd: ${num(r['2'] || 7, 0)} · 3rd: ${num(r['3'] || 5, 0)} pts`;
    }
    return state.lang === 'fa' ? `${num(row.reward_points || 0, 0)} امتیاز جایزه` : `${num(row.reward_points || 0, 0)} reward points`;
}
function contestAnswerControls(row) {
    if (row.participated) {
        const shown = row.kind === 'price' || row.kind === 'candle' ? num(row.my_answer, 8) : contestChoiceLabel(row.kind, row.my_answer);
        return `<div class="contest-submitted">${icon('check')}<div><strong>${state.lang === 'fa' ? 'پاسخ شما ثبت شده' : 'Your answer is registered'}</strong><small>${esc(shown)}${row.submitted_at ? ` · ${date(row.submitted_at)}` : ''}</small></div></div>`;
    }
    if (row.kind === 'price' || row.kind === 'candle') {
        return `<div class="contest-entry"><input id="contest-answer-${esc(row.kind)}" inputmode="decimal" autocomplete="off" placeholder="${row.kind === 'price' ? (state.lang === 'fa' ? 'قیمت پیش‌بینی‌شده' : 'Predicted price') : (state.lang === 'fa' ? 'قیمت بسته‌شدن' : 'Closing price')}"><button class="button primary" data-contest-submit="${esc(row.kind)}">${state.lang === 'fa' ? 'ثبت پاسخ' : 'Submit'}</button></div>`;
    }
    const choices = row.kind === 'news_direction' ? ['UP', 'DOWN', 'RANGE'] : ['UP', 'DOWN', 'FLAT'];
    return `<div class="contest-choices">${choices.map(choice => `<button class="button secondary" data-contest-submit="${esc(row.kind)}" data-contest-answer="${choice}">${choice === 'UP' ? '📈' : choice === 'DOWN' ? '📉' : '↔️'} ${esc(contestChoiceLabel(row.kind, choice))}</button>`).join('')}</div>`;
}
function contestCard(row) {
    const meta = contestKindMeta(row.kind), title = row.question || row.news_name || meta.desc;
    return `<article class="contest-card ${row.participated ? 'joined' : ''}">
      <div class="contest-card-head"><span class="contest-icon">${icon(meta.icon)}</span><div><h3>${esc(meta.title)}</h3><p>${esc(meta.desc)}</p></div><span class="status-badge good">${state.lang === 'fa' ? 'فعال' : 'Active'}</span></div>
      ${row.image_available ? `<img class="contest-image" src="${esc(row.image_url)}" alt="${esc(meta.title)}" loading="lazy">` : ''}
      <div class="contest-question">${row.symbol ? `<span class="contest-symbol">${esc(row.symbol)}</span>` : ''}<strong>${esc(title)}</strong></div>
      <div class="contest-meta"><span>${icon('history')}${state.lang === 'fa' ? 'پایان' : 'Ends'}: ${date(row.ends_at)}</span><span>${icon('crown')}${esc(contestRewardText(row))}</span><span>${icon('user')}${num(row.participants_count || 0, 0)} ${state.lang === 'fa' ? 'شرکت‌کننده' : 'entries'}</span></div>
      ${contestAnswerControls(row)}
    </article>`;
}
function contestResultCard(row) {
    const meta = contestKindMeta(row.kind), answer = row.kind === 'price' || row.kind === 'candle' ? num(row.my_answer, 8) : contestChoiceLabel(row.kind, row.my_answer);
    const outcome = row.won ? (state.lang === 'fa' ? 'برنده' : 'Winner') : (state.lang === 'fa' ? 'پایان‌یافته' : 'Completed');
    return `<article class="contest-result ${row.won ? 'winner' : ''}"><span class="contest-icon">${icon(row.won ? 'crown' : meta.icon)}</span><div><strong>${esc(meta.title)}</strong><p>${state.lang === 'fa' ? 'پاسخ شما' : 'Your answer'}: ${esc(answer)}${row.rank ? ` · ${state.lang === 'fa' ? 'رتبه' : 'Rank'} ${num(row.rank, 0)}` : ''}</p><small>${date(row.closed_at)}</small></div><span class="status-badge ${row.won ? 'good' : 'info'}">${esc(outcome)}${row.prize && Object.keys(row.prize).length ? ` · ${esc(clientPrizeLabel(row.prize))}` : row.points ? ` · +${num(row.points, 0)}` : ''}</span></article>`;
}
async function contestsModal(force = false) {
    setBusy(true);
    try {
        const d = await loadResource('contests', force), rows = d?.items || [], history = d?.recent_results || [];
        const body = `<div class="contest-hero"><div>${icon('trophy')}<div><strong>${state.lang === 'fa' ? 'مسابقه‌های SENTINEL' : 'SENTINEL Contests'}</strong><p>${state.lang === 'fa' ? 'بدون خروج از مینی‌اپ در مسابقه فعال شرکت کنید؛ پاسخ دقیقاً در همان سیستم مسابقات ربات ثبت می‌شود.' : 'Join active contests without leaving the Mini App. Your entry is saved in the same contest system as the bot.'}</p></div></div><button class="icon-button" data-contest-refresh aria-label="refresh">${icon('refresh')}</button></div>
          <div class="contest-grid">${rows.map(contestCard).join('') || empty(state.lang === 'fa' ? 'در حال حاضر مسابقه فعالی وجود ندارد.' : 'There are no active contests right now.')}</div>
          ${history.length ? `<div class="contest-history"><div class="panel-head"><div><h3>${state.lang === 'fa' ? 'نتایج اخیر من' : 'My recent results'}</h3><p>${state.lang === 'fa' ? 'فقط مسابقه‌هایی که در آن‌ها شرکت کرده‌اید' : 'Only contests you joined'}</p></div></div>${history.map(contestResultCard).join('')}</div>` : ''}`;
        openModal('CONTESTS', state.lang === 'fa' ? 'مسابقه‌ها' : 'Contests', body, []);
    }
    catch (err) {
        toast(translateUiText(err.message || t('error')), 'error');
    }
    finally { setBusy(false); }
}
async function submitContestEntry(kind, answer) {
    if (answer == null || String(answer).trim() === '') {
        toast(state.lang === 'fa' ? 'پاسخ را وارد کنید.' : 'Enter your answer.', 'error');
        return;
    }
    setBusy(true);
    try {
        const result = await action('contest_submit', { kind, answer }, false);
        if (result?.result === 'OK') toast(state.lang === 'fa' ? 'پاسخ مسابقه با موفقیت ثبت شد.' : 'Contest entry submitted.', 'success');
        else if (result?.result === 'ALREADY') toast(state.lang === 'fa' ? 'قبلاً در این مسابقه پاسخ ثبت کرده‌اید.' : 'You already entered this contest.', 'info');
        else if (result?.result === 'NO_ACTIVE') toast(state.lang === 'fa' ? 'زمان مسابقه تمام شده یا دیگر فعال نیست.' : 'This contest is no longer active.', 'error');
        else toast(state.lang === 'fa' ? 'ثبت پاسخ انجام نشد.' : 'Could not submit the entry.', 'error');
        invalidate('contests', 'overview');
        await contestsModal(true);
    }
    catch (err) {
        const message = String(err?.message || '');
        toast(message.includes('CONTEST_ANSWER_INVALID') ? (state.lang === 'fa' ? 'پاسخ واردشده معتبر نیست.' : 'The submitted answer is invalid.') : translateUiText(message || t('error')), 'error');
    }
    finally { setBusy(false); }
}
document.addEventListener('click', async event => {
    const el = event.target.closest('[data-contest-submit],[data-contest-refresh]');
    if (!el) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (el.dataset.contestRefresh !== undefined) {
        invalidate('contests');
        return contestsModal(true);
    }
    const kind = String(el.dataset.contestSubmit || ''), answer = el.dataset.contestAnswer !== undefined ? el.dataset.contestAnswer : $(`#contest-answer-${kind}`)?.value;
    await submitContestEntry(kind, answer);
});
function feedItem(row) {
    const labels = { signal: 'سیگنال', announcement: 'اعلان', news: 'خبر', market: 'گزارش بازار', publication: 'انتشار' };
    const signal = row.type === 'signal';
    const decision = signal && row.choice?.choice;
    const signalStatus = String(row.status || row.signal_status || '').toLowerCase();
    const signalFinal = Boolean(row.is_final || ['closed','win','loss','sl','stop','stopped','tp','tp1','tp2','tp3','be','cancelled','canceled'].includes(signalStatus));
    const decisionLabel = decision === 'taken' ? 'این سیگنال را گرفته‌اید' : decision === 'skipped' ? 'این سیگنال را رد کرده‌اید' : '';
    return `<article class="journal-card feed-item ${signal ? 'feed-signal' : ''}">
  <div class="row-between"><strong>${esc(row.title || labels[row.type] || row.type)}</strong><span class="status-badge ${row.priority === 'high' ? 'warn' : 'info'}">${esc(labels[row.type] || row.type)}</span></div>
  ${row.summary ? `<p>${esc(row.summary)}</p>` : ''}<small>${date(row.created_at)} · ${esc(row.destination || 'public')}</small>
  ${signal ? `<div class="card-actions">${signalFinal ? `<span class="status-badge warn">سیگنال بسته شده</span>` : (decision ? `<span class="status-badge ${decision === 'taken' ? 'ok' : 'muted'}">${esc(decisionLabel)}</span>` : `<button class="button small" data-signal-take="${esc(row.signal_id)}">گرفتم / ثبت ورود</button><button class="button secondary small" data-signal-skip="${esc(row.signal_id)}">نگرفتم</button>`)}<button class="button ghost small" data-signal-detail="${esc(row.signal_id)}">جزئیات</button></div>` : ''}
 </article>`;
}
function channelFeedPanel(rows = []) {
    return `<section class="panel channel-feed"><div class="panel-head"><div><small class="eyebrow">CHANNEL LIVE</small><h2>${state.lang === 'fa' ? 'آخرین محتوای کانال' : 'Channel timeline'}</h2></div><button class="button ghost small" data-open="feed">${state.lang === 'fa' ? 'مشاهده همه' : 'View all'}</button></div><div class="panel-body journal-list">${rows.slice(0, 6).map(feedItem).join('') || empty()}</div></section>`;
}
function checkFeedUpdates(rows = [], initial = false) {
    const newest = rows[0], key = 'sentinelFeedLastSeen', last = localStorage.getItem(key) || '';
    if (!newest)
        return;
    if (!initial && last && last !== String(newest.id)) {
        const message = newest.type === 'signal' ? (state.lang === 'fa' ? `سیگنال جدید ${newest.title}` : `New signal ${newest.title}`) : (newest.title || 'SENTINEL update');
        toast(message, 'info');
        tg?.HapticFeedback?.notificationOccurred?.('success');
        if (window.Notification?.permission === 'granted')
            try {
                new window.Notification('SENTINEL', { body: message, tag: String(newest.id) });
            }
            catch { }
    }
    localStorage.setItem(key, String(newest.id));
}
async function refreshFeed(notify = true) {
    const data = await loadResource('feed', true);
    if (notify)
        checkFeedUpdates(data?.items || [], false);
    return data;
}
async function feedModal() {
    const data = await refreshFeed(false);
    openModal('CHANNEL LIVE', state.lang === 'fa' ? 'مرکز اطلاع‌رسانی کانال' : 'Channel feed', `<div class="row-between"><p class="field-help">${state.lang === 'fa' ? 'سیگنال، خبر، اعلان و گزارش منتشرشده در کانال با رعایت دسترسی VIP.' : 'Signals, news, announcements and published channel reports.'}</p><button class="button secondary small" data-notification-enable>اعلان دستگاه</button></div><div class="journal-list">${(data?.items || []).map(feedItem).join('') || empty()}</div>`, []);
}
async function enableDeviceNotifications() {
    if (!('Notification' in window)) {
        toast('اعلان سیستم در این دستگاه پشتیبانی نمی‌شود', 'error');
        return;
    }
    const permission = await Notification.requestPermission();
    toast(permission === 'granted' ? 'اعلان دستگاه فعال شد' : 'مجوز اعلان داده نشد', permission === 'granted' ? 'success' : 'error');
}
function tradeActions(trade) {
    const targets = trade.targets || [trade.target].filter(Boolean), hits = new Set(trade.target_hits || []), cancelled = new Set(trade.cancelled_targets || []);
    const tp = targets.map((price, index) => { const n = index + 1; return `<button class="button small" data-paper-action="tp${n}" data-trade-id="${trade.id}" ${hits.has(n) || cancelled.has(n) ? 'disabled' : ''}>TP${n} · ${esc(price)}</button><button class="button ghost small" data-paper-cancel-target="${n}" data-trade-id="${trade.id}" ${hits.has(n) || cancelled.has(n) ? 'disabled' : ''}>لغو TP${n}</button>`; }).join('');
    return `<div class="card-actions">${tp}<button class="button secondary small" data-paper-action="breakeven" data-trade-id="${trade.id}">سر‌به‌سر</button><button class="button secondary small" data-paper-move-stop="${trade.id}">تغییر SL</button><button class="button secondary small" data-paper-action="sl" data-trade-id="${trade.id}">Stop Loss</button><button class="button ghost small" data-paper-action="cancel" data-trade-id="${trade.id}">لغو معامله</button></div>`;
}
function tradeCenterBody(data) {
    const paper = data.paper_arena || {}, accounts = paper.accounts || [], trades = (paper.trades || []).slice().reverse(), coach = data.risk_coach || {}, prop = data.prop_guardian?.accounts || [];
    return `<div class="admin-workspace">
 <section class="panel"><div class="panel-head"><div><small class="eyebrow">PAPER + PROP</small><h3>مرکز تمرین معامله و مدیریت ریسک</h3></div><button class="button small" data-paper-account-new>ساخت حساب</button></div><div class="panel-body"><div class="metric-grid">${metric('حساب', num(accounts.length, 0), '', 'info')}${metric('باز', num(paper.summary?.open || 0, 0), '', 'warn')}${metric('بسته', num(paper.summary?.closed || 0, 0), '', 'good')}${metric('لغوشده', num(paper.summary?.cancelled || 0, 0), '', '')}</div>${accounts.length ? `<button class="button primary" data-paper-trade-new>ثبت معامله آزمایشی</button>` : '<p>ابتدا یک حساب آزمایشی بسازید.</p>'}</div></section>
 <section class="panel"><div class="panel-head"><h3>معاملات و تمام سناریوهای خروج</h3></div><div class="panel-body journal-list">${trades.map(trade => `<article class="journal-card"><div class="row-between"><strong>#${trade.id} · ${esc(trade.symbol)} · ${esc(String(trade.side).toUpperCase())}</strong><span class="status-badge ${trade.status === 'open' ? 'good' : trade.status === 'cancelled' ? 'warn' : 'info'}">${esc(trade.status)}</span></div><p>Entry ${esc(trade.entry)} · SL ${esc(trade.stop)} · باقی‌مانده ${pct(Number(trade.remaining_fraction ?? 1) * 100, 0)}</p><small>${date(trade.opened_at)} · ${num(trade.realized_r || trade.result_r || 0, 2)}R · ${money(trade.realized_pnl || trade.pnl_amount || 0, 'USD')}</small>${trade.status === 'open' ? tradeActions(trade) : ''}</article>`).join('') || empty()}</div></section>
 <section class="panel"><div class="panel-head"><h3>نگهبان Prop</h3></div><div class="panel-body journal-list">${prop.map(row => `<article class="journal-card"><div class="row-between"><strong>${esc(row.title || `Account ${row.account_id}`)}</strong><span class="status-badge ${row.status === 'safe' || row.status === 'passed' ? 'good' : row.status === 'blocked' ? 'bad' : 'warn'}">${esc(row.status)}</span></div>${row.status === 'unconfigured' ? `<button class="button small" data-prop-standard="${row.account_id}">فعال‌کردن قوانین استاندارد</button>` : `<p>زیان روزانه: ${pct(row.metrics?.daily_loss_percent || 0)} · افت کل: ${pct(row.metrics?.total_drawdown_percent || 0)} · پیشرفت سود: ${pct(row.metrics?.profit_progress_percent || 0)}</p><small>${(row.hard_blocks || []).join('، ') || ((row.warnings || []).join('، ') || 'بدون نقض فعال')}</small>`}</article>`).join('') || empty()}</div></section>
 <section class="panel"><div class="panel-head"><h3>مربی رفتار و ریسک متصل به سیگنال‌ها</h3><button class="button secondary small" data-risk-coach-refresh>تحلیل مجدد</button></div><div class="panel-body"><div class="metric-grid">${metric('انضباط', `${num(coach.discipline_score || 0, 1)}/100`, '', 'good')}${metric('سیگنال گرفته‌شده', num(coach.signal_risk?.taken_count || 0, 0), '', 'info')}${metric('ریسک فعال', pct(coach.signal_risk?.active_risk_percent || 0), '', 'warn')}${metric('Net R', `${num(coach.net_r || 0, 2)}R`, '', '')}</div><div class="journal-list">${(coach.findings || []).map(x => `<div class="notice ${x.severity === 'high' ? 'warning' : ''}"><strong>${esc(x.title || x.code)}</strong><br><small>${num(x.count || 0, 0)}</small></div>`).join('') || '<div class="notice">الگوی پرخطر واضحی دیده نشد.</div>'}${(coach.recommendations || []).map(x => `<p>• ${esc(x)}</p>`).join('')}</div></div></section>
 </div>`;
}
async function tradeCenterModal() {
    setBusy(true);
    try {
        const data = await loadResource('expansion', true);
        openModal('TRADING & RISK', state.lang === 'fa' ? 'مرکز تمرین معامله و مدیریت ریسک' : 'Trading practice & risk center', tradeCenterBody(data), []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function paperAccountModal() {
    openModal('PAPER ACCOUNT', 'ساخت حساب آزمایشی', `<form id="paperAccountForm"><div class="field"><label>نام حساب</label><input id="paperAccountTitle" value="حساب تمرینی" required></div><div class="field"><label>سرمایه اولیه</label><input id="paperAccountBalance" type="number" min="100" value="10000" required></div></form>`, [{ label: 'ساخت حساب', kind: 'primary', action: async () => { const f = $('#paperAccountForm'); if (!f.reportValidity())
                return; await action('paper_account_create', { title: $('#paperAccountTitle').value, starting_balance: Number($('#paperAccountBalance').value) }, false); closeModal(); invalidate('expansion'); await tradeCenterModal(); toast('حساب ساخته شد'); } }]);
}
function paperTradeModal() {
    const accounts = state.resources.expansion?.paper_arena?.accounts || [];
    openModal('PAPER TRADE', 'ثبت معامله آزمایشی', `<form id="paperTradeForm"><div class="form-grid"><div class="field"><label>حساب</label><select id="paperAccount">${accounts.map(x => `<option value="${x.id}">${esc(x.title)}</option>`).join('')}</select></div><div class="field"><label>نماد</label><input id="paperSymbol" required placeholder="XAUUSD"></div><div class="field"><label>جهت</label><select id="paperSide"><option value="buy">BUY</option><option value="sell">SELL</option></select></div><div class="field"><label>Entry</label><input id="paperEntry" type="number" step="any" required></div><div class="field"><label>SL</label><input id="paperStop" type="number" step="any" required></div><div class="field"><label>TPها (با ویرگول)</label><input id="paperTargets" required placeholder="2350,2360,2375"></div><div class="field"><label>ریسک %</label><input id="paperRisk" type="number" min=".1" max="5" step=".1" value="1" required></div></div></form>`, [{ label: 'ثبت معامله', kind: 'primary', action: async () => { const f = $('#paperTradeForm'); if (!f.reportValidity())
                return; const targets = $('#paperTargets').value.split(',').map(Number).filter(Number.isFinite); await action('paper_trade_open', { account_id: $('#paperAccount').value, symbol: $('#paperSymbol').value, side: $('#paperSide').value, entry: Number($('#paperEntry').value), stop: Number($('#paperStop').value), targets, risk_percent: Number($('#paperRisk').value) }, false); closeModal(); invalidate('expansion'); await tradeCenterModal(); toast('معامله ثبت شد'); } }]);
}
function paperMoveStopModal(id) {
    openModal('MOVE STOP', 'تغییر حد ضرر', `<form id="moveStopForm"><div class="field"><label>SL جدید</label><input id="paperNewStop" type="number" step="any" required></div><div class="field"><label>دلیل</label><input id="paperStopReason" maxlength="300"></div></form>`, [{ label: 'ذخیره', kind: 'primary', action: async () => { if (!$('#moveStopForm').reportValidity())
                return; await managePaper(id, 'move_sl', { new_stop: Number($('#paperNewStop').value), reason: $('#paperStopReason').value }); } }]);
}
async function managePaper(id, trade_action, extra = {}) {
    setBusy(true);
    try {
        await action('paper_trade_action', { trade_id: id, trade_action, ...extra }, false);
        closeModal();
        invalidate('expansion');
        await tradeCenterModal();
        toast('وضعیت معامله به‌روزرسانی شد');
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
async function standardProp(accountId) {
    await action('prop_challenge_configure', { account_id: accountId, rules: { daily_loss_limit_percent: 5, total_loss_limit_percent: 10, profit_target_percent: 8, min_trading_days: 5, max_risk_per_trade_percent: 2, news_trading_allowed: true, weekend_holding_allowed: false } }, false);
    closeModal();
    invalidate('expansion');
    await tradeCenterModal();
    toast('نگهبان Prop فعال شد');
}
document.addEventListener('click', async (event) => {
    const el = event.target.closest('[data-signal-take],[data-signal-skip],[data-signal-retro],[data-notification-enable],[data-paper-account-new],[data-paper-trade-new],[data-paper-action],[data-paper-cancel-target],[data-paper-move-stop],[data-prop-standard],[data-risk-coach-refresh]');
    if (!el)
        return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (el.dataset.signalTake)
        return openSignal(el.dataset.signalTake);
    if (el.dataset.signalSkip)
        return setSignalChoice(el.dataset.signalSkip, 'skipped');
    if (el.dataset.signalRetro)
        return setSignalChoice(el.dataset.signalRetro, el.dataset.retroChoice, true);
    if (el.dataset.notificationEnable !== undefined)
        return enableDeviceNotifications();
    if (el.dataset.paperAccountNew !== undefined)
        return paperAccountModal();
    if (el.dataset.paperTradeNew !== undefined)
        return paperTradeModal();
    if (el.dataset.paperMoveStop)
        return paperMoveStopModal(el.dataset.paperMoveStop);
    if (el.dataset.paperAction)
        return managePaper(el.dataset.tradeId, el.dataset.paperAction);
    if (el.dataset.paperCancelTarget)
        return managePaper(el.dataset.tradeId, 'cancel_target', { target_index: Number(el.dataset.paperCancelTarget) });
    if (el.dataset.propStandard)
        return standardProp(el.dataset.propStandard);
    if (el.dataset.riskCoachRefresh !== undefined) {
        await action('risk_coach_refresh', {}, false);
        invalidate('expansion');
        closeModal();
        return tradeCenterModal();
    }
}, true);
/* SENTINEL Sovereign Experience — server-authoritative public/VIP/admin UX. */
const sentinelLegacyOpenMore = openMore;
const sentinelLegacyRenderChrome = renderChrome;
function sentinelTier() {
    const o = state.resources.overview || {}, role = String(o.user?.role || 'user');
    if (['owner', 'admin'].includes(role))
        return { key: 'admin', label: role === 'owner' ? 'مالک سیستم' : 'مدیر', icon: 'shield' };
    if (o.account?.vip_active)
        return { key: 'vip', label: 'عضو VIP', icon: 'crown' };
    return { key: 'public', label: 'عضو عمومی', icon: 'user' };
}
function sentinelMarketLabel(value) { return String(value || 'forex').toLowerCase() === 'crypto' ? 'کریپتو' : 'فارکس'; }
function sentinelAccessLabel(value) { return String(value || 'public').toLowerCase() === 'vip' ? 'VIP' : 'عمومی'; }
function sentinelRing(value, label, tone = 'cyan') {
    const safe = Math.max(0, Math.min(100, Number(value) || 0));
    return `<div class="sentinel-ring ${tone}" style="--ring:${safe}"><div><strong>${num(safe, 0)}%</strong><span>${esc(label)}</span></div></div>`;
}
function sentinelBars(values = []) {
    const rows = values;
    const max = Math.max(1, ...rows.map(Number));
    return `<div class="micro-chart" aria-label="نمودار خلاصه">${rows.map((value, index) => `<i style="--bar:${Math.max(8, Math.round(Number(value) / max * 100))}" title="${esc(value)}"><span>${index + 1}</span></i>`).join('')}</div>`;
}
function sentinelSection(title, subtitle, body, action = '') {
    return `<section class="panel sentinel-section"><div class="panel-head"><div><h2>${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div>${action}</div><div class="panel-body">${body}</div></section>`;
}
function sentinelService(ic, title, desc, target, badge = 0, tone = '') {
    return `<button class="service-card ${tone}" data-open="${esc(target)}">${icon(ic)}<span><strong>${esc(title)}</strong><small>${esc(desc)}</small></span>${badge ? `<em>${num(badge, 0)}</em>` : ''}${icon('chevron')}</button>`;
}
renderChrome = function () {
    sentinelLegacyRenderChrome();
    const tier = sentinelTier(), topbar = $('.topbar'), copy = $('.topbar-copy');
    topbar?.classList.toggle('vip-shell', tier.key === 'vip');
    topbar?.classList.toggle('admin-shell', tier.key === 'admin');
    let badge = $('#accountTier');
    if (!badge && copy) {
        badge = document.createElement('button');
        badge.id = 'accountTier';
        badge.type = 'button';
        badge.dataset.open = tier.key === 'public' ? 'vip' : 'settings';
        copy.appendChild(badge);
    }
    if (badge) {
        badge.className = `account-tier ${tier.key}`;
        badge.innerHTML = `${icon(tier.icon)}<span>${esc(tier.label)}</span>`;
        badge.dataset.open = tier.key === 'public' ? 'vip' : 'settings';
    }
};
renderHome = function () {
    const o = state.resources.overview || demoOverview(), r = o.risk || {}, ex = r.account_exposure || {}, j = o.journal_stats || {}, tier = sentinelTier();
    const signals = Number(o.account?.active_signals || 0), forex = Number(o.account?.active_forex_signals || 0), crypto = Number(o.account?.active_crypto_signals || 0);
    const exposure = Math.max(0, Number(ex.open_risk_percent || 0)), remaining = Math.max(0, Number(ex.remaining_daily_risk_percent || 0));
    const journalSeries = (j.equity_curve || j.series || []).map(x => Number(x.value ?? x.pnl ?? x)).filter(Number.isFinite).slice(-12);
    $('#page-home').innerHTML = `
 <article class="sentinel-command ${tier.key}">
  <img src="./assets/brand/sentinel-miniapp-logo.2febef7c25.webp" alt="" width="82" height="82">
  <div class="command-copy"><span class="eyebrow">SENTINEL PROTECTION NETWORK</span><h1>مرکز فرمان معامله‌گری</h1><p>سیگنال، بازار، ریسک و ژورنال شما در یک نمای زنده و محافظت‌شده.</p>
   <div class="command-actions"><button class="button primary" data-page-target="signals">${icon('signal')} مشاهده سیگنال‌ها</button><button class="button secondary" data-open="tradeCenter">${icon('shield')} مرکز معامله</button></div>
  </div><div class="protection-orbit">${icon('shield')}<span>محافظ فعال</span></div>
 </article>
 <div class="market-lanes">
  <button data-signal-scope-home="public"><span>${icon('market')} سیگنال عمومی</span><strong>${num(signals, 0)}</strong><small>${num(forex, 0)} فارکس · ${num(crypto, 0)} کریپتو</small></button>
  <button class="vip-lane" data-signal-scope-home="vip"><span>${icon('crown')} اتاق VIP</span><strong>${o.account?.vip_active ? num((state.resources.feed?.groups?.vip || 0), 0) : 'قفل'}</strong><small>${o.account?.vip_active ? 'سیگنال‌های اختصاصی زنده' : 'برای دسترسی اشتراک تهیه کنید'}</small></button>
 </div>
 <section class="sentinel-dashboard">
  <div class="dashboard-chart panel"><div class="panel-head"><div><small class="eyebrow">ACCOUNT SHIELD</small><h2>وضعیت محافظت حساب</h2></div><span class="status-badge ${r.prop?.status === 'blocked' ? 'bad' : 'good'}">${esc(r.prop?.status || 'محافظت‌شده')}</span></div>
   <div class="dashboard-chart-body">${sentinelRing(Math.min(100, exposure * 20), 'ریسک باز', exposure > 3 ? 'red' : 'cyan')}<div class="chart-copy"><strong>${pct(remaining)} ظرفیت روزانه</strong>${sentinelBars(journalSeries)}<small>${num(ex.open_trades || 0, 0)} معامله باز · ${pct(j.win_rate || 0)} نرخ برد ژورنال</small></div></div>
  </div>
  <div class="quick-grid">
   <button data-open="market">${icon('market')}<strong>بازار زنده</strong><small>قیمت و واچ‌لیست</small></button>
   <button data-open="calculator">${icon('chart')}<strong>محاسبه حجم</strong><small>فارکس و کریپتو</small></button>
   <button data-page-target="journal">${icon('journal')}<strong>معاملات من</strong><small>ژورنال و نتیجه</small></button>
   <button data-open="notifications">${icon('bell')}<strong>اعلان‌ها</strong><small>کنترل بدون مزاحمت</small></button>
  </div>
 </section>
 ${sentinelSection('سیگنال‌های تازه', 'عمومی و VIP بر اساس دسترسی حساب', (o.recent_signals || []).map(signalCard).join('') || empty(), `<button class="button ghost small" data-page-target="signals">مشاهده همه</button>`)}
 ${channelFeedPanel(state.resources.feed?.items || [])}`;
};
signalCard = function (s) {
    const sell = ['sell', 'short'].includes(String(s.side).toLowerCase()), vip = String(s.access_tier || 'public') === 'vip', market = s.market_category || 'forex', choice = s.choice?.choice || '', status = String(s.status || 'open').toLowerCase(), final = Boolean(s.is_final || ['closed','win','loss','sl','stop','stopped','target_complete','manual_close','no_entry','expired','cancelled','canceled'].includes(status));
    const targets = Array.isArray(s.targets) ? s.targets : [];
    return `<article class="signal-card signal-card-v2 ${sell ? 'sell' : ''} ${vip ? 'vip' : ''}">
  <div class="signal-ribbon">${vip ? icon('crown') : icon('shield')}<span>${sentinelAccessLabel(s.access_tier)}</span><span>${sentinelMarketLabel(market)}</span></div>
  <div class="signal-top"><div class="signal-symbol"><span class="side-badge ${sell ? 'sell' : ''}">${esc(String(s.side || '').toUpperCase())}</span><div><strong>${esc(s.symbol)}</strong><small>#${num(s.display_number, 0)} · ${date(s.created_at)}</small></div></div><span class="live-dot">${esc(s.status || 'open')}</span></div>
  <div class="signal-levels"><div><span>ENTRY</span><b>${esc(s.entry)}</b></div><div><span>STOP</span><b>${esc(s.stop)}</b></div><div><span>R/R</span><b>${esc(s.risk_reward || '—')}</b></div></div>
  ${targets.length ? `<div class="target-rail">${targets.slice(0, 5).map((x, i) => `<span>TP${i + 1}<b>${esc(x)}</b></span>`).join('')}</div>` : ''}
  <div class="signal-meta"><span>${icon('market')} ${num(s.quote?.price, 6)}</span><span>${choice ? `انتخاب: ${esc(choice)}` : 'منتظر تصمیم شما'}</span></div>
  <div class="card-actions"><button class="button small" data-signal-detail="${s.id}">${icon('signal')} جزئیات</button>${!choice ? (final ? `<button class="button primary small" data-signal-retro="${s.id}" data-retro-choice="taken">گرفتم</button><button class="button ghost small" data-signal-retro="${s.id}" data-retro-choice="skipped">نگرفتم</button>` : `<button class="button primary small pulse-action" data-signal-take="${s.id}">بگیرش</button><button class="button ghost small" data-signal-skip="${s.id}">نمی‌گیرم</button>`) : ''}<button class="button secondary small" data-copy-signal="${s.id}">${icon('copy')}</button></div>
 </article>`;
};
renderSignals = async function (force = false) {
    const page = $('#page-signals');
    if (!featureEnabled('signals')) {
        page.innerHTML = pageHead('SIGNALS', t('decisionCenter'), '') + disabledPanel();
        return;
    }
    page.innerHTML = pageHead('SIGNALS', 'مرکز سیگنال SENTINEL', 'تفکیک عمومی، VIP، فارکس و کریپتو؛ هر تصمیم مستقیم به ژورنال و مربی ریسک متصل است.') + skeleton(4);
    try {
        const data = await loadResource('signals', force), rows = data?.items || [], access = data?.access || {}, groups = data?.groups || {};
        const accessFilters = `<div class="access-switch"><button class="${state.signalAccessFilter === 'all' ? 'active' : ''}" data-signal-access="all">${icon('signal')} همه <b>${num(data.total || rows.length, 0)}</b></button><button class="${state.signalAccessFilter === 'public' ? 'active' : ''}" data-signal-access="public">${icon('shield')} عمومی <b>${num(groups.public || 0, 0)}</b></button><button class="${state.signalAccessFilter === 'vip' ? 'active' : ''}" data-signal-access="vip" ${!access.vip_active ? 'data-vip-locked' : ''}>${icon('crown')} VIP <b>${access.vip_active ? num(groups.vip || 0, 0) : 'قفل'}</b></button></div>`;
        const marketFilters = `<div class="filters compact"><button class="filter-chip ${state.signalFilter === 'all' ? 'active' : ''}" data-signal-filter="all">همه بازارها</button><button class="filter-chip ${state.signalFilter === 'open' ? 'active' : ''}" data-signal-filter="open">باز</button><button class="filter-chip ${state.signalFilter === 'forex' ? 'active' : ''}" data-signal-filter="forex">فارکس · ${num(groups.forex || 0, 0)}</button><button class="filter-chip ${state.signalFilter === 'crypto' ? 'active' : ''}" data-signal-filter="crypto">کریپتو · ${num(groups.crypto || 0, 0)}</button></div>`;
        const vipNotice = state.signalAccessFilter === 'vip' && !access.vip_active ? `<section class="vip-gate">${icon('crown')}<h2>اتاق سیگنال VIP</h2><p>این بخش فقط برای اشتراک فعال باز می‌شود و سیگنال خصوصی را هم‌زمان با کانال دریافت می‌کند.</p><button class="button primary" data-open="vip">مشاهده پلن‌ها</button></section>` : '';
        page.innerHTML = pageHead('SIGNALS', 'مرکز سیگنال SENTINEL', 'عمومی و VIP، با تصمیم‌گیری مستقیم و ثبت خودکار در ژورنال.') + accessFilters + `<div class="search-box">${icon('search')}<input id="signalSearch" value="${esc(state.signalQuery)}" placeholder="نماد یا شماره سیگنال"></div>` + marketFilters + vipNotice + (!vipNotice ? `<div class="signal-list signal-catalog">${rows.map(signalCard).join('') || empty(t('noSignals'))}</div>${moreButton('signals', data)}` : '');
    }
    catch (err) {
        page.innerHTML = errorPanel(err, 'signals');
    }
};
feedItem = function (row) {
    const signal = row.type === 'signal', vip = row.access_tier === 'vip', decision = row.choice?.choice || '', status = String(row.status || row.signal_status || '').toLowerCase(), final = Boolean(row.is_final || ['closed','win','loss','sl','stop','stopped','target_complete','manual_close','no_entry','expired','cancelled','canceled'].includes(status)), labels = { signal: 'سیگنال', announcement: 'اعلان', news: 'خبر', market: 'تحلیل بازار', publication: 'انتشار' };
    return `<article class="feed-card ${signal ? 'signal' : ''} ${vip ? 'vip' : ''}">
  <div class="feed-icon">${icon(signal ? 'signal' : row.type === 'news' ? 'market' : 'bell')}</div><div class="feed-content">
   <div class="row-between"><strong>${esc(row.title || labels[row.type] || 'به‌روزرسانی')}</strong><div><span class="status-badge ${vip ? 'vip' : 'info'}">${vip ? 'VIP' : esc(labels[row.type] || row.type)}</span></div></div>
   ${row.summary ? `<p>${esc(row.summary)}</p>` : ''}<small>${date(row.created_at)} · ${sentinelMarketLabel(row.market_category)}</small>
   ${signal ? `<div class="card-actions">${decision ? `<span class="status-badge good">${decision === 'taken' ? (row.choice?.retrospective ? 'گرفتم' : 'گرفته شد و در ژورنال ثبت شد') : 'نگرفتم'}</span>` : (final ? `<button class="button primary small" data-signal-retro="${esc(row.signal_id)}" data-retro-choice="taken">گرفتم</button><button class="button ghost small" data-signal-retro="${esc(row.signal_id)}" data-retro-choice="skipped">نگرفتم</button>` : `<button class="button primary small pulse-action" data-signal-take="${esc(row.signal_id)}">بگیرش</button><button class="button ghost small" data-signal-skip="${esc(row.signal_id)}">نمی‌گیرم</button>`)}<button class="button secondary small" data-signal-detail="${esc(row.signal_id)}">بررسی</button></div>` : ''}
  </div></article>`;
};
channelFeedPanel = function (rows = []) {
    const visible = rows.slice(0, 7), vip = visible.filter(x => x.access_tier === 'vip').length;
    return sentinelSection('نبض زنده کانال', 'سیگنال، خبر و اعلان هم‌زمان با تلگرام', `<div class="feed-summary"><span>${icon('signal')} ${num(visible.filter(x => x.type === 'signal').length, 0)} سیگنال</span><span>${icon('crown')} ${num(vip, 0)} VIP</span><span class="live-pill"><i></i> زنده</span></div><div class="feed-list">${visible.map(feedItem).join('') || empty()}</div>`, `<button class="button ghost small" data-open="feed">مشاهده همه</button>`);
};
feedModal = async function () {
    const data = await refreshFeed(false), rows = data?.items || [], filters = [['all', 'همه'], ['signal', 'سیگنال'], ['news', 'خبر و بازار'], ['announcement', 'اعلان'], ['vip', 'VIP']];
    const visible = rows.filter(row => state.feedFilter === 'all' || (state.feedFilter === 'news' ? ['news', 'market'].includes(row.type) : state.feedFilter === 'vip' ? row.access_tier === 'vip' : state.feedFilter === row.type));
    openModal('CHANNEL LIVE', 'نبض زنده کانال', `<div class="feed-toolbar"><div class="filters compact">${filters.map(([key, label]) => `<button class="filter-chip ${state.feedFilter === key ? 'active' : ''}" data-feed-filter="${key}">${label}</button>`).join('')}</div><button class="button secondary small" data-notification-enable>${icon('bell')} اعلان دستگاه</button></div><div class="feed-list">${visible.map(feedItem).join('') || empty()}</div>`, []);
};
tradeCenterBody = function (data) {
    const paper = data.paper_arena || {}, accounts = paper.accounts || [], trades = (paper.trades || []).slice().reverse(), coach = data.risk_coach || {}, prop = data.prop_guardian?.accounts || [], tab = state.tradeHubTab;
    const nav = `<div class="trade-tabs"><button class="${tab === 'overview' ? 'active' : ''}" data-trade-tab="overview">نمای کلی</button><button class="${tab === 'paper' ? 'active' : ''}" data-trade-tab="paper">تمرین معامله</button><button class="${tab === 'prop' ? 'active' : ''}" data-trade-tab="prop">نگهبان Prop</button><button class="${tab === 'coach' ? 'active' : ''}" data-trade-tab="coach">مربی ریسک</button></div>`;
    const overview = `<div class="trade-overview"><div class="trade-hero">${icon('shield')}<div><small>SENTINEL TRADE SHIELD</small><h3>مرکز معامله و محافظت</h3><p>حساب آزمایشی، قوانین Prop و رفتار معاملاتی در سه بخش روشن و مستقل.</p></div></div><div class="metric-grid">${metric('حساب تمرینی', num(accounts.length, 0), '', 'info')}${metric('معامله باز', num(paper.summary?.open || 0, 0), '', 'warn')}${metric('انضباط', `${num(coach.discipline_score || 0, 0)}/100`, '', 'good')}${metric('ریسک سیگنال', pct(coach.signal_risk?.active_risk_percent || 0), '', '')}</div><div class="quick-grid compact"><button data-trade-tab="paper">${icon('signal')}<strong>تمرین معامله</strong><small>ثبت و مدیریت تمام TPها</small></button><button data-trade-tab="prop">${icon('shield')}<strong>نگهبان Prop</strong><small>کنترل نقض قوانین</small></button><button data-trade-tab="coach">${icon('chart')}<strong>مربی ریسک</strong><small>تحلیل سیگنال‌های گرفته‌شده</small></button><button data-open="calculator">${icon('market')}<strong>محاسبه حجم</strong><small>قبل از ورود</small></button></div></div>`;
    const paperView = `<section class="panel flat"><div class="panel-head"><div><h3>تمرین معامله</h3><p>حساب آزمایشی و همه سناریوهای خروج در یکجا</p></div><div class="card-actions"><button class="button secondary small" data-paper-account-new>حساب جدید</button>${accounts.length ? '<button class="button primary small" data-paper-trade-new>معامله جدید</button>' : ''}</div></div><div class="panel-body"><div class="metric-grid">${metric('باز', num(paper.summary?.open || 0, 0), '', 'warn')}${metric('بسته', num(paper.summary?.closed || 0, 0), '', 'good')}${metric('لغو', num(paper.summary?.cancelled || 0, 0), '', '')}</div><div class="journal-list">${trades.map(trade => `<article class="journal-card"><div class="row-between"><strong>${esc(trade.symbol)} · ${esc(String(trade.side).toUpperCase())}</strong><span class="status-badge ${trade.status === 'open' ? 'good' : 'info'}">${esc(trade.status)}</span></div><p>Entry ${esc(trade.entry)} · SL ${esc(trade.stop)} · باقی‌مانده ${pct(Number(trade.remaining_fraction ?? 1) * 100, 0)}</p><small>${date(trade.opened_at)} · ${num(trade.realized_r || trade.result_r || 0, 2)}R</small>${trade.status === 'open' ? tradeActions(trade) : ''}</article>`).join('') || empty()}</div></div></section>`;
    const propView = `<section class="panel flat"><div class="panel-head"><div><h3>نگهبان Prop</h3><p>فاصله تا نقض قانون و آمادگی چالش</p></div></div><div class="panel-body journal-list">${prop.map(row => `<article class="prop-card"><div class="row-between"><strong>${esc(row.title || `Account ${row.account_id}`)}</strong><span class="status-badge ${['safe', 'passed'].includes(row.status) ? 'good' : row.status === 'blocked' ? 'bad' : 'warn'}">${esc(row.status)}</span></div>${row.status === 'unconfigured' ? `<p>قوانین این حساب هنوز تنظیم نشده است.</p><button class="button small" data-prop-standard="${row.account_id}">فعال‌کردن الگوی استاندارد</button>` : `<div class="prop-rings">${sentinelRing(row.metrics?.daily_loss_percent || 0, 'ضرر روزانه', Number(row.metrics?.daily_loss_percent || 0) > 4 ? 'red' : 'cyan')}${sentinelRing(row.metrics?.total_drawdown_percent || 0, 'افت کل', Number(row.metrics?.total_drawdown_percent || 0) > 8 ? 'red' : 'gold')}${sentinelRing(row.metrics?.profit_progress_percent || 0, 'هدف سود', 'green')}</div><div class="notice ${row.hard_blocks?.length ? 'danger' : ''}">${(row.hard_blocks || []).join('، ') || ((row.warnings || []).join('، ') || 'هیچ نقض فعالی ثبت نشده است.')}</div>`}</article>`).join('') || empty()}</div></section>`;
    const coachView = `<section class="panel flat"><div class="panel-head"><div><h3>مربی رفتار و ریسک</h3><p>متصل به سیگنال‌های گرفته‌شده و ژورنال واقعی شما</p></div><button class="button secondary small" data-risk-coach-refresh>تحلیل مجدد</button></div><div class="panel-body"><div class="coach-score">${sentinelRing(coach.discipline_score || 0, 'انضباط', 'green')}<div><strong>${num(coach.signal_risk?.taken_count || 0, 0)} سیگنال گرفته‌شده</strong><p>${pct(coach.signal_risk?.active_risk_percent || 0)} ریسک فعال · ${num(coach.net_r || 0, 2)}R خالص</p></div></div><div class="journal-list">${(coach.findings || []).map(x => `<div class="notice ${x.severity === 'high' ? 'danger' : x.severity === 'medium' ? 'warning' : ''}"><strong>${esc(x.title || x.code)}</strong><small>${num(x.count || 0, 0)} بار مشاهده</small></div>`).join('') || '<div class="notice good">الگوی پرخطر واضحی دیده نشد.</div>'}${(coach.recommendations || []).map(x => `<p class="coach-tip">${icon('shield')} ${esc(x)}</p>`).join('')}</div></div></section>`;
    return `<div class="trade-center-v2">${nav}${tab === 'paper' ? paperView : tab === 'prop' ? propView : tab === 'coach' ? coachView : overview}</div>`;
};
function calculatorModal() {
    const account = state.resources.overview?.risk?.default_account || {}, balance = Number(account.equity || account.balance || 10000), leverage = Number(account.leverage || 100);
    openModal('RISK CALCULATOR', 'محاسبه‌گر دقیق حجم و مارجین SENTINEL', `<form id="riskCalculatorForm"><div class="notice info"><strong>محاسبه هم‌زمان محدودیت ریسک و مارجین</strong><p>حجم نهایی از بین حجم مجاز ریسک، ظرفیت مارجین، گام حجم و حداقل سفارش انتخاب می‌شود.</p></div><div class="form-grid"><div class="field"><label>بازار</label><select id="calcMarket"><option value="forex">فارکس / CFD</option><option value="crypto">کریپتو اسپات / فیوچرز</option></select></div><div class="field"><label>نماد</label><input id="calcSymbol" value="XAUUSD" required></div><div class="field"><label>موجودی / Equity دلار</label><input id="calcBalance" type="number" min="1" step="any" value="${esc(balance)}" required></div><div class="field"><label>مارجین آزاد دلار</label><input id="calcAvailableMargin" type="number" min=".01" step="any" value="${esc(balance)}" required><small class="field-help">اگر مارجین آزاد کمتر از موجودی است، مقدار واقعی را وارد کنید.</small></div><div class="field"><label>ریسک درصدی</label><input id="calcRisk" type="number" min=".01" max="20" step=".01" value="1" required></div><div class="field"><label>قیمت ورود</label><input id="calcEntry" type="number" min=".00000001" step="any" required></div><div class="field"><label>حد ضرر</label><input id="calcStop" type="number" min=".00000001" step="any" required></div><div class="field"><label>اهرم</label><input id="calcLeverage" type="number" min="1" max="1000" value="${esc(leverage)}" required></div><div class="field"><label>کارمزد رفت‌وبرگشت %</label><input id="calcFee" type="number" min="0" max="10" step=".001" value="0"><small class="field-help">برای کریپتو؛ مجموع کارمزد ورود و خروج.</small></div><div class="field"><label>نرخ تبدیل ارز مظنه به USD</label><input id="calcCrossRate" type="number" min=".00000001" step="any" placeholder="فقط جفت‌های Cross"></div></div><details class="details-block"><summary>مشخصات پیشرفته بروکر / صرافی</summary><div class="form-grid"><div class="field"><label>Contract Size فارکس</label><input id="calcContractSize" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>حداقل لات</label><input id="calcMinLot" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>گام لات</label><input id="calcLotStep" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>حداکثر لات</label><input id="calcMaxLot" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>Quantity Step کریپتو</label><input id="calcQuantityStep" type="number" min=".000000000001" step="any" placeholder="0.00000001"></div><div class="field"><label>حداقل Quantity</label><input id="calcMinQuantity" type="number" min=".000000000001" step="any" placeholder="برابر گام مقدار"></div><div class="field"><label>حداقل Notional</label><input id="calcMinNotional" type="number" min="0" step="any" placeholder="مثلاً 5 USDT"></div></div></details><button class="button primary wide" type="button" data-risk-calculate>${icon('shield')} محاسبه دقیق و امن</button></form><div id="calculatorResult"></div>`, []);
}
function optionalNumber(id) { const value = $(id)?.value?.trim(); return value === '' || value == null ? null : Number(value); }
async function runRiskCalculator() {
    const form = $('#riskCalculatorForm');
    if (!form?.reportValidity()) return;
    setBusy(true);
    try {
        const payload = { market: $('#calcMarket').value, symbol: $('#calcSymbol').value, balance: Number($('#calcBalance').value), available_margin: Number($('#calcAvailableMargin').value), risk_percent: Number($('#calcRisk').value), entry: Number($('#calcEntry').value), stop: Number($('#calcStop').value), leverage: Number($('#calcLeverage').value), fee_percent: Number($('#calcFee').value), cross_rate: optionalNumber('#calcCrossRate'), contract_size: optionalNumber('#calcContractSize'), min_lot: optionalNumber('#calcMinLot'), lot_step: optionalNumber('#calcLotStep'), max_lot: optionalNumber('#calcMaxLot'), quantity_step: optionalNumber('#calcQuantityStep'), min_quantity: optionalNumber('#calcMinQuantity'), min_notional: optionalNumber('#calcMinNotional') };
        const data = await action('risk_calculate', payload, false), r = data.result || {}, forex = r.mode === 'forex', size = r.lot ?? r.quantity ?? r.units, unit = forex ? 'LOT' : 'UNIT', constraint = r.capped_by_margin ? 'ظرفیت مارجین' : 'بودجه ریسک';
        const advanced = forex ? `<div class="metric-grid">${metric('حجم خام', num(r.raw_lot, 6), 'Lot', 'info')}${metric('حد ریسک', num(r.risk_limited_lot, 6), 'Lot', '')}${metric('حد مارجین', num(r.margin_limited_lot, 6), 'Lot', r.capped_by_margin ? 'warn' : '')}${metric('فاصله استاپ', `${num(r.pip_distance, 2)} pip`, `${num(r.stop_percent, 4)}%`, '')}${metric('ارزش هر پیپ', money(r.pip_value_per_lot, 'USD'), 'برای ۱ لات', '')}${metric('Contract Size', num(r.contract_size, 4), '', '')}</div>` : `<div class="metric-grid">${metric('مقدار خام', num(r.raw_quantity, 10), '', 'info')}${metric('حد ریسک', num(r.risk_limited_quantity, 10), '', '')}${metric('حد قابل خرید', num(r.max_affordable_quantity, 10), '', r.capped_by_margin ? 'warn' : '')}${metric('فاصله استاپ', `${num(r.stop_percent, 4)}%`, '', '')}${metric('ریسک هر واحد', money(r.loss_per_unit, 'USD'), '', '')}${metric('حداقل Notional', money(r.min_notional, 'USD'), '', '')}</div>`;
        $('#calculatorResult').innerHTML = `<section class="panel calculator-audit"><div class="panel-head"><div><small class="eyebrow">POSITION AUDIT</small><h3>نتیجه محاسبه دقیق</h3></div><span class="status-badge ${r.capped_by_margin ? 'warn' : 'good'}">${esc(constraint)}</span></div><div class="panel-body"><section class="calculator-result"><div class="result-shield">${icon('shield')}</div><div><small>حجم اجرایی پیشنهادی</small><strong>${num(size, forex ? 4 : 10)} ${unit}</strong><p>ریسک واقعی: ${money(r.effective_risk || 0, 'USD')} (${num(r.effective_risk_percent, 4)}%)</p><span>حجم به پایین گرد شده تا ریسک از سقف تعیین‌شده عبور نکند.</span></div></section><div class="metric-grid">${metric('بودجه ریسک', money(r.risk_amount || 0, 'USD'), `${num(r.risk_budget_usage_percent, 2)}% مصرف`, 'info')}${metric('ارزش پوزیشن', money(r.notional || 0, 'USD'), '', '')}${metric('مارجین لازم', money(r.estimated_margin || 0, 'USD'), `${num(r.margin_usage_percent, 2)}% مارجین آزاد`, r.margin_usage_percent > 90 ? 'warn' : '')}${metric('مارجین آزاد', money(r.available_margin || payload.available_margin, 'USD'), '', '')}</div>${advanced}${r.below_minimum || r.below_min_notional ? `<div class="notice danger"><strong>حجم زیر حداقل بروکر / صرافی است</strong><p>مشخصات Contract، گام حجم و حداقل Notional را با نماد واقعی تطبیق دهید.</p></div>` : ''}${r.capped_by_margin ? `<div class="notice warning"><strong>حجم به‌دلیل محدودیت مارجین کاهش یافت</strong><p>حجم مبتنی بر ریسک بیشتر بود، اما با مارجین آزاد و اهرم فعلی قابل اجرا نبود.</p></div>` : `<div class="notice good"><strong>حجم با بودجه ریسک محدود شده است</strong><p>مارجین فعلی برای حجم محاسبه‌شده کافی است.</p></div>`}<div class="notice info"><small>پیش از سفارش، Contract Size، Tick/Pip Value، حداقل حجم و گام سفارش را از مشخصات زنده بروکر یا صرافی بررسی کنید.</small></div></div></section>`;
    } catch (err) { toast(err.message, 'error'); } finally { setBusy(false); }
}
async function campaignsModal() {
    setBusy(true);
    try {
        const data = await loadResource('adminCampaigns', true), rows = data?.items || [], summary = data?.summary || {};
        openModal('CAMPAIGN CONTROL', 'مرکز دقیق کمپین‌ها', `<div class="campaign-head"><div class="metric-grid">${metric('کل', num(summary.total || rows.length, 0), '', 'info')}${metric('فعال', num(summary.active || 0, 0), '', 'good')}${metric('زمان‌بندی', num(summary.scheduled || 0, 0), '', 'warn')}${metric('تکمیل', num(summary.completed || 0, 0), '', '')}</div><button class="button primary" data-campaign-new>${icon('plus')} کمپین جدید</button></div><div class="campaign-list">${rows.map(row => `<article class="campaign-card"><div class="row-between"><div><small>${esc(row.category || 'CAMPAIGN')}</small><h3>${esc(row.name)}</h3></div><span class="status-badge ${row.status === 'active' ? 'good' : row.status === 'draft' ? 'warn' : 'info'}">${esc(row.status)}</span></div><div class="campaign-funnel"><span style="--funnel:100">مخاطب <b>${num(row.metrics?.audience_size || 0, 0)}</b></span><span style="--funnel:${Math.max(10, row.metrics?.delivery_success_rate || 0)}">تحویل <b>${num(row.metrics?.sent || 0, 0)}</b></span><span style="--funnel:${Math.max(10, row.metrics?.conversion_rate || 0)}">تبدیل <b>${num(row.metrics?.approved_orders || 0, 0)}</b></span></div><div class="row-between"><small>کیفیت داده: ${esc(row.measurement?.quality || 'unknown')}</small><button class="button secondary small" data-campaign-detail="${esc(row.id)}">گزارش دقیق</button></div></article>`).join('') || empty()}</div>`, []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function campaignCreateModal() {
    openModal('CAMPAIGN BUILDER', 'ساخت کمپین قابل‌اندازه‌گیری', `<form id="campaignForm"><div class="form-grid"><div class="field"><label>نام کمپین</label><input id="campaignName" maxlength="100" required></div><div class="field"><label>دسته</label><select id="campaignCategory"><option value="retention">نگهداشت</option><option value="conversion">فروش و تبدیل</option><option value="activation">فعال‌سازی</option><option value="winback">بازگشت کاربر</option><option value="vip_upgrade">ارتقای VIP</option><option value="announcement">اطلاع‌رسانی</option></select></div><div class="field"><label>مخاطب</label><select id="campaignAudience"><option value="all">همه کاربران</option><option value="vip_active">VIP فعال</option><option value="never_vip">بدون سابقه VIP</option><option value="inactive_user">غیرفعال</option><option value="renewal_due">نزدیک تمدید</option><option value="abandoned_checkout">خرید نیمه‌تمام</option></select></div><div class="field"><label>مسیر ارسال</label><select id="campaignDelivery"><option value="link_bot">لینک اختصاصی ربات</option><option value="link_channel">لینک اختصاصی کانال</option><option value="link_both">ربات و کانال</option><option value="direct">پیام مستقیم ربات</option><option value="public">کانال عمومی</option><option value="private">کانال VIP</option></select></div><div class="field full"><label>هدف قابل‌اندازه‌گیری</label><input id="campaignObjective" maxlength="240" placeholder="مثلاً تبدیل کاربران عمومی به VIP"></div><div class="field full"><label>متن کمپین</label><textarea id="campaignMessage" maxlength="3500" required></textarea></div></div></form>`, [{ label: 'ذخیره پیش‌نویس', kind: 'primary', action: async () => { const form = $('#campaignForm'); if (!form.reportValidity())
                return; await action('campaign_create', { name: $('#campaignName').value, category: $('#campaignCategory').value, audience: $('#campaignAudience').value, delivery: $('#campaignDelivery').value, objective: $('#campaignObjective').value, message: $('#campaignMessage').value, tracking: { source: 'miniapp', created_version: APP_VERSION } }, false); invalidate('adminCampaigns'); closeModal(); await campaignsModal(); toast('کمپین ایجاد شد'); } }]);
}
async function campaignDetailModal(id) {
    setBusy(true);
    try {
        const row = await request(`./api/v1/admin/campaigns/${encodeURIComponent(id)}`), m = row.metrics || {}, measure = row.measurement || m.measurement || {}, anomalies = measure.anomalies || [];
        openModal('CAMPAIGN REPORT', row.name || id, `<div class="metric-grid">${metric('مخاطب', num(m.audience_size || 0, 0), '', 'info')}${metric('تحویل موفق', pct(m.delivery_success_rate || 0), '', 'good')}${metric('تبدیل', pct(m.conversion_rate || 0), '', 'warn')}${metric('درآمد', money(m.revenue || 0, 'T'), '', '')}</div><div class="campaign-quality ${measure.quality === 'high' ? 'good' : 'warn'}">${icon(measure.quality === 'high' ? 'check' : 'alert')}<div><strong>کیفیت اندازه‌گیری: ${esc(measure.quality || 'unknown')}</strong><p>${esc(measure.attribution_model || '')}</p></div></div>${anomalies.length ? `<div class="notice warning">${anomalies.map(esc).join(' · ')}</div>` : ''}<pre class="campaign-message">${esc(row.message || '')}</pre><div class="card-actions">${['draft', 'active', 'paused', 'failed'].includes(row.status) ? `<button class="button primary" data-campaign-schedule="${esc(id)}">انتشار امن</button>` : ''}${row.status === 'draft' ? `<button class="button secondary" data-campaign-status="${esc(id)}" data-status="active">فعال‌کردن</button>` : ''}${row.status === 'active' ? `<button class="button secondary" data-campaign-status="${esc(id)}" data-status="paused">توقف</button>` : ''}</div>`, []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function adminSignalValues(id) { return ($(id)?.value || '').split(/[,،؛]+/).map(x => Number(String(x).trim())).filter(Number.isFinite); }
function adminSignalQuoteHtml(q) { const current = Number(q?.price), entries = adminSignalValues('#asEntries'), targets = adminSignalValues('#asTargets'), stop = Number($('#asStop')?.value), side = String($('#asSide')?.value || 'buy'), entry = entries.length ? entries.reduce((a, b) => a + b, 0) / entries.length : NaN; if (!Number.isFinite(current))
    return '<div class="notice warning">قیمت معتبر دریافت نشد.</div>'; const low = entries.length ? Math.min(...entries) : NaN, high = entries.length ? Math.max(...entries) : NaN, inside = Number.isFinite(low) && current >= low && current <= high, entryDistance = Number.isFinite(low) ? (inside ? 0 : Math.min(Math.abs(current - low), Math.abs(current - high)) / current * 100) : NaN, risk = Number.isFinite(entry) && Number.isFinite(stop) ? Math.abs(entry - stop) : NaN; const nearest = targets.map((v, i) => ({ v, i, d: Math.abs(v - current) / current * 100, reached: side === 'buy' ? current >= v : current <= v })).sort((a, b) => a.d - b.d)[0]; const targetRows = targets.map((v, i) => { const rr = Number.isFinite(risk) && risk > 0 ? Math.abs(v - entry) / risk : NaN, d = Math.abs(v - current) / current * 100, reached = side === 'buy' ? current >= v : current <= v; return `<div class="account-card"><div class="row-between"><strong>TP${i + 1} · ${num(v, 7)}</strong><span class="status-badge ${reached ? 'good' : 'info'}">${reached ? 'رسیده' : `${pct(d, 3)} فاصله`}</span></div><p>${Number.isFinite(rr) ? `${num(rr, 2)}R` : 'R نامشخص'}</p></div>`; }).join(''); return `<section class="panel"><div class="panel-head"><div><small class="eyebrow">LIVE CONSENSUS TRACKER</small><h3>${esc(q.symbol || '')}</h3></div><span class="status-badge ${q.stale ? 'warn' : 'good'}">${q.consensus ? 'CONSENSUS' : 'LIVE'} · ${num(q.provider_count || 1, 0)} API</span></div><div class="panel-body"><div class="metric-grid">${metric('قیمت فعلی', num(current, 7), '', 'good')}${metric('فاصله تا Entry', Number.isFinite(entryDistance) ? pct(entryDistance, 3) : '—', '', inside ? 'good' : 'info')}${metric('نزدیک‌ترین تارگت', nearest ? `TP${nearest.i + 1} · ${pct(nearest.d, 3)}` : '—', '', '')}</div><div class="notice ${inside ? 'good' : 'info'}"><strong>${inside ? 'قیمت داخل محدوده ورود است' : Number.isFinite(entryDistance) ? `${pct(entryDistance, 3)} تا محدوده ورود باقی مانده` : 'سطوح Entry را وارد کنید'}</strong><small>${esc(q.source || q.provider || '')} · ${date(q.updated_at)} · confidence ${pct(Number(q.confidence || 0) * 100, 0)}</small></div>${targetRows}</div></section>`; }
async function refreshAdminSignalQuote(silent = false) { const form = $('#adminSignalForm'), box = $('#adminSignalQuote'); if (!form || !box)
    return; const symbol = String($('#asSymbol')?.value || '').trim(); if (symbol.length < 2) {
    box.innerHTML = '<div class="notice info">نماد را وارد کنید تا ردیاب چندمنبعی فعال شود.</div>';
    return;
} if (!silent)
    box.innerHTML = '<div class="notice info">در حال دریافت بهترین قیمت از APIهای فعال…</div>'; try {
    const q = await request(`./api/v1/market/quote?symbol=${encodeURIComponent(symbol)}&live=1`, {}, 16000);
    state.adminSignalQuote = q;
    box.innerHTML = adminSignalQuoteHtml(q);
}
catch (err) {
    box.innerHTML = `<div class="notice warning">${esc(err.message)}</div>`;
} }
function adminSignalComposer() {
    openModal('SIGNAL DESK', 'ارسال سیگنال با ردیاب زنده', `<form id="adminSignalForm"><div class="form-grid"><div class="field"><label>نماد</label><input id="asSymbol" required maxlength="20" value="XAUUSD" placeholder="XAUUSD"></div><div class="field"><label>جهت</label><select id="asSide"><option value="buy">BUY</option><option value="sell">SELL</option></select></div><div class="field"><label>ورودها</label><input id="asEntries" required placeholder="2350 یا 2350,2347"></div><div class="field"><label>تارگت‌ها</label><input id="asTargets" required placeholder="2360,2370,2380"></div><div class="field"><label>حد ضرر</label><input id="asStop" required inputmode="decimal"></div><div class="field"><label>ریسک درصدی</label><input id="asRisk" required inputmode="decimal" value="1"></div><div class="field"><label>مقصد</label><select id="asTarget"><option value="public">کانال عمومی</option><option value="private">کانال VIP</option><option value="both">هر دو کانال</option></select></div><div class="field"><label>تایم‌فریم</label><input id="asTimeframe" value="1H" maxlength="20"></div></div><div class="card-actions"><button type="button" class="button secondary" data-admin-quote-refresh>${icon('refresh')} دریافت قیمت و محاسبه فاصله‌ها</button></div><div id="adminSignalQuote"><div class="notice info">نماد و سطوح را وارد کنید؛ قیمت اجماعی، فاصله Entry، نزدیک‌ترین TP و R/R محاسبه می‌شود.</div></div><div class="field"><label>یادداشت/تحلیل</label><textarea id="asNote" maxlength="2000"></textarea></div><div class="notice info">سیگنال از مسیر امن ربات منتشر و همان لحظه در کانال و مینی‌اپ ثبت می‌شود.</div></form>`, [{ label: 'اعتبارسنجی و انتشار', kind: 'primary', action: async () => { const f = $('#adminSignalForm'); if (!f.reportValidity())
                return; const split = id => $(id).value.split(/[,،؛]+/).map(x => x.trim()).filter(Boolean); setBusy(true); try {
                const result = await action('miniapp_signal_publish', { symbol: $('#asSymbol').value, side: $('#asSide').value, entries: split('#asEntries'), targets: split('#asTargets'), stop: $('#asStop').value, risk: $('#asRisk').value, target: $('#asTarget').value, timeframe: $('#asTimeframe').value, note: $('#asNote').value }, false);
                closeModal();
                invalidate('signals', 'feed', 'overview', 'adminSignalJobs');
                toast(`سیگنال Q-${result.queue_id || '—'} برای انتشار در ربات، کانال و مینی‌اپ ثبت شد`);
                if (result.queue_id)
                    await adminSignalJobDetail(result.queue_id, { poll: true });
            }
            catch (err) {
                toast(err.message, 'error');
            }
            finally {
                setBusy(false);
            } } }]);
    setTimeout(() => refreshAdminSignalQuote(true), 80);
}
function adminAnnouncementComposer() {
    openModal('ANNOUNCEMENT DESK', 'انتشار اعلان کانال', `<form id="adminAnnouncementForm"><div class="form-grid"><div class="field"><label>عنوان</label><input id="aaTitle" required minlength="3" maxlength="100"></div><div class="field"><label>مقصد</label><select id="aaDelivery"><option value="public">کانال عمومی</option><option value="private">کانال VIP</option></select></div></div><div class="field"><label>متن اعلان</label><textarea id="aaMessage" required maxlength="3500" rows="8"></textarea></div><div class="notice info">اعلان از صف پایدار کمپین منتشر می‌شود تا ارسال دوباره، قطع سرویس یا کلیک تکراری باعث انتشار چندباره نشود.</div></form>`, [{ label: 'ثبت و انتشار', kind: 'primary', action: async () => { const f = $('#adminAnnouncementForm'); if (!f.reportValidity())
                return; setBusy(true); try {
                await action('miniapp_announcement_publish', { title: $('#aaTitle').value, message: $('#aaMessage').value, delivery: $('#aaDelivery').value }, false);
                closeModal();
                invalidate('adminCampaigns', 'feed');
                toast('اعلان در صف پایدار انتشار قرار گرفت');
            }
            catch (err) {
                toast(err.message, 'error');
            }
            finally {
                setBusy(false);
            } } }]);
}
function signalJobTone(status) { return status === 'sent' ? 'good' : status === 'dead' || status === 'failed' ? 'bad' : status === 'processing' || status === 'retrying' ? 'warn' : status === 'cancelled' ? 'muted' : 'info'; }
function signalJobStatusLabel(status) { const fa = { pending: 'در انتظار', processing: 'در حال انتشار', retrying: 'در انتظار تلاش مجدد', sent: 'ارسال‌شده', dead: 'شکست دائمی', cancelled: 'لغوشده', failed: 'ناموفق' }; return state.lang === 'fa' ? (fa[status] || status) : status; }
function signalJobHtml(job) { const status = String(job?.status || 'pending'), delivered = (job?.delivered_channels || []).length, deliveryRows = (job?.deliveries || []).map(x => `<div class="health-card"><strong>${esc(x.channel || 'channel')}</strong><span class="status-badge good">#${esc(x.message_id || '—')}</span><small>${esc(String(x.chat_id || ''))}</small></div>`).join(''); return `<section class="panel"><div class="panel-head"><div><small class="eyebrow">SIGNAL DELIVERY Q-${esc(job?.id || '—')}</small><h3>${esc(job?.symbol || '—')} · ${esc(job?.side || '—')}</h3></div><span class="status-badge ${signalJobTone(status)}">${esc(signalJobStatusLabel(status))}</span></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'مقصد' : 'Target', esc(job?.target || '—'), '', 'info')}${metric(state.lang === 'fa' ? 'شناسه سیگنال' : 'Signal ID', job?.signal_id ? `#${esc(job.signal_id)}` : '—', '', '')}${metric(state.lang === 'fa' ? 'تلاش‌ها' : 'Attempts', `${num(job?.attempts || 0, 0)}/${num(job?.max_attempts || 3, 0)}`, '', '')}${metric(state.lang === 'fa' ? 'تحویل‌ها' : 'Delivered', num(delivered, 0), 'channel', 'good')}</div><p>${state.lang === 'fa' ? 'ورود' : 'Entry'}: ${esc((job?.entries || []).join(' / ') || '—')} · SL: ${esc(job?.stop ?? '—')}</p><p>TP: ${esc((job?.targets || []).join(' / ') || '—')}</p>${deliveryRows ? `<div class="health-grid">${deliveryRows}</div>` : ''}${job?.last_error ? `<div class="notice danger"><strong>${state.lang === 'fa' ? 'خطای انتشار' : 'Delivery error'}</strong><p>${esc(job.last_error)}</p></div>` : `<div class="notice ${status === 'sent' ? 'good' : 'info'}"><strong>${status === 'sent' ? (state.lang === 'fa' ? 'سیگنال در کانال و مینی‌اپ ثبت شد.' : 'Signal is live in channel and Mini App.') : (state.lang === 'fa' ? 'انتشار از صف امن ربات در حال انجام است…' : 'Publishing through the bot delivery queue…')}</strong></div>`}<div class="card-actions">${job?.can_retry ? `<button class="button primary small" data-signal-job-retry="${esc(job.id)}">${state.lang === 'fa' ? 'تلاش مجدد' : 'Retry'}</button>` : ''}${job?.can_edit ? `<button class="button secondary small" data-signal-job-edit="${esc(job.id)}">${state.lang === 'fa' ? 'ویرایش صف' : 'Edit queue'}</button>` : ''}${job?.can_cancel ? `<button class="button danger small" data-signal-job-cancel="${esc(job.id)}">${state.lang === 'fa' ? 'لغو' : 'Cancel'}</button>` : ''}</div></div></section>`; }
async function adminSignalJobDetail(id, { poll = true } = {}) { openModal('SIGNAL DELIVERY', `Q-${id}`, `<div id="signalJobStatus">${skeleton(2)}</div>`, []); const box = () => $('#signalJobStatus'); let attempts = 0; while (attempts < 24) {
    try {
        const job = await request(`./api/v1/admin/signal-jobs/${encodeURIComponent(id)}`, {}, 12000);
        if (box())
            box().innerHTML = signalJobHtml(job);
        if (['sent', 'dead', 'cancelled'].includes(job.status)) {
            if (job.status === 'sent') {
                invalidate('signals', 'feed', 'overview', 'adminSignalJobs');
                await Promise.allSettled([loadOverview(true), loadResource('signals', true), refreshFeed(true)]);
                renderChrome();
                if (state.page === 'home')
                    renderHome();
            }
            return job;
        }
    }
    catch (err) {
        if (box())
            box().innerHTML = `<div class="notice danger">${esc(err.message)}</div>`;
        if (!poll)
            throw err;
    }
    if (!poll)
        return null;
    attempts++;
    await new Promise(resolve => setTimeout(resolve, 2000));
} if (box())
    box().insertAdjacentHTML('beforeend', `<div class="notice warning">${state.lang === 'fa' ? 'انتشار هنوز در صف است؛ این صفحه را بعداً دوباره باز کنید.' : 'Delivery is still queued; reopen this page shortly.'}</div>`); return null; }
async function adminSignalJobsCenter() { setBusy(true); try {
    const d = await loadResource('adminSignalJobs', true), rows = d?.items || [];
    openModal('SIGNAL DELIVERY', 'وضعیت انتشار سیگنال‌ها', `<div class="notice info"><strong>BOT ↔ CHANNEL ↔ MINI APP</strong><p>هر ارسال تا نتیجه نهایی قابل ردیابی است.</p></div><div class="journal-list">${rows.map(x => `<article class="journal-card"><div class="row-between"><strong>Q-${esc(x.id)} · ${esc(x.symbol)} ${esc(x.side)}</strong><span class="status-badge ${signalJobTone(x.status)}">${esc(x.status)}</span></div><p>${esc(x.target)} · ${date(x.created_at || x.run_at)}</p>${x.last_error ? `<small class="text-bad">${esc(x.last_error)}</small>` : ''}<div class="card-actions"><button class="button secondary small" data-admin-signal-job="${esc(x.id)}">${esc(t('details'))}</button></div></article>`).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function adminTicketCenter() { setBusy(true); try {
    const d = await loadResource('adminTickets', true), rows = d?.items || [];
    openModal('ADMIN SUPPORT', 'مدیریت تیکت‌های ربات و مینی‌اپ', `<div class="notice info"><strong>LIVE TWO-WAY SUPPORT</strong><p>پاسخ ادمین در مینی‌اپ و ربات کاربر هم‌زمان اطلاع‌رسانی می‌شود.</p></div><div class="journal-list">${rows.map(x => `<article class="journal-card"><div class="row-between"><strong>#${num(x.id, 0)} · ${esc(x.subject || 'Support')}</strong><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>User ${esc(x.user_id)} · ${esc(x.priority || 'normal')} · ${esc(x.waiting_for || 'admin')}</p><small>${date(x.updated_at || x.created_at)} · ${num((x.messages || []).length, 0)} message</small><div class="card-actions"><button class="button primary small" data-admin-ticket="${x.id}">${state.lang === 'fa' ? 'بازکردن و پاسخ' : 'Open & reply'}</button></div></article>`).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function adminPlatformCenter() { return adminModuleControlCenter(); }
renderMore = async function () {
    const page = $('#page-more'), o = state.resources.overview || {}, admin = Boolean(o.admin_available), adminInfo = o.admin || {}, permissions = new Set(adminInfo.permissions || []), owner = String(adminInfo.role || '').toLowerCase() === 'owner', can = permission => owner || permissions.has(permission);
    const adminHeading = title => `<h3 class="admin-domain-title">${esc(title)}</h3>`;
    const adminServices = [
        admin && (can('signals') || can('signal_edit') || can('signal_results') || can('signal_delete') || can('signal_templates')) ? adminHeading('📡 ارسال سیگنال') : '',
        admin && can('signals') ? sentinelService('signal', 'ارسال سیگنال', 'انتشار در کانال، ربات و مینی‌اپ', 'admin-signal') : '',
        admin && can('signals') ? sentinelService('history', 'پیگیری ارسال سیگنال', 'صف، تحویل و خطاها', 'admin-signal-jobs') : '',
        admin && (can('signals') || can('signal_edit') || can('signal_results') || can('signal_delete')) ? sentinelService('chart', 'مدیریت سیگنال‌ها', 'ویرایش، نتیجه و حذف', 'admin-signals') : '',
        admin && can('signal_templates') ? sentinelService('chart', 'قالب‌های سیگنال', 'پس‌زمینه و چیدمان', 'admin') : '',
        admin && (can('users') || can('tickets')) ? adminHeading('👥 CRM و کاربران') : '',
        admin && can('users') ? sentinelService('account', 'کنترل کاربران', 'جست‌وجو، VIP و مسدودی', 'admin-users') : '',
        admin && can('tickets') ? sentinelService('support', 'تیکت‌های پشتیبانی', 'مشاهده و پاسخ دوطرفه', 'admin-tickets', o.account?.open_tickets || 0) : '',
        admin && can('payments') ? adminHeading('💳 فروش و اشتراک‌ها') : '',
        admin && can('payments') ? sentinelService('wallet', 'پرداخت و رسید VIP', 'تأیید یا رد از مینی‌اپ', 'admin') : '',
        admin && (can('announcements') || can('campaigns')) ? adminHeading('📣 تبلیغات و کمپین‌ها') : '',
        admin && can('announcements') ? sentinelService('bell', 'میز اعلان', 'انتشار امن اطلاعیه', 'admin-announcement') : '',
        admin && can('campaigns') ? sentinelService('market', 'مرکز کمپین', 'ساخت، ارسال و آمار دقیق', 'campaigns') : '',
        admin ? adminHeading('🛡 ادمین و امنیت') : '',
        admin ? sentinelService('shield', 'کنسول عملیات', 'حاکمیت، شیفت و سلامت', 'admin') : '',
        admin && can('admin_management') ? sentinelService('shield', 'مدیریت ادمین‌ها', 'افزودن و سطح دسترسی', 'admin-admins') : '',
        admin && can('system_control') ? sentinelService('settings', 'وضعیت تمام ماژول‌ها', 'دسترسی، اتصال و زیرسامانه‌ها', 'admin-platform') : ''
    ].filter(Boolean).join('');
    page.innerHTML = pageHead('SENTINEL HUB', 'تمام خدمات', 'ابزارها بر اساس کاری که می‌خواهید انجام دهید دسته‌بندی شده‌اند.') +
        `<div class="service-groups">
  <section><div class="service-title">${icon('signal')}<div><h2>معامله و تصمیم</h2><p>از سیگنال تا ثبت نتیجه</p></div></div><div class="service-list">${sentinelService('shield', 'مرکز معامله', 'تمرین، Prop و مربی ریسک', 'tradeCenter')}${sentinelService('chart', 'محاسبه‌گر حجم', 'فارکس و کریپتو', 'calculator')}${sentinelService('journal', 'ژورنال و معاملات', 'ورود، خروج و تحلیل', 'journal-route')}${sentinelService('market', 'قیمت و بازار', 'واچ‌لیست و رژیم بازار', 'market')}</div></section>
  <section><div class="service-title">${icon('crown')}<div><h2>اشتراک و دسترسی</h2><p>VIP، سفارش و پرداخت</p></div></div><div class="service-list">${sentinelService('crown', 'اشتراک VIP', o.account?.vip_active ? 'اشتراک شما فعال است' : 'مشاهده پلن‌ها و خرید', 'vip', 0, o.account?.vip_active ? 'vip' : '')}${sentinelService('wallet', 'سفارش‌ها', 'رسید و وضعیت پرداخت', 'orders', o.account?.pending_orders || 0)}${sentinelService('signal', 'نبض کانال', 'سیگنال، خبر و اعلان', 'feed')}</div></section>
  <section><div class="service-title">${icon('bell')}<div><h2>اطلاعات و ارتباط</h2><p>اعلان، تقویم و پشتیبانی</p></div></div><div class="service-list">${sentinelService('trophy', 'مسابقه‌ها', 'شرکت مستقیم و مشاهده نتیجه', 'contests')}${sentinelService('bell', 'مرکز اعلان', 'فیلتر و ساعات سکوت', 'notifications')}${sentinelService('calendar', 'تقویم اقتصادی', 'خبرهای مهم بازار', 'calendar')}${sentinelService('support', 'پشتیبانی', 'تیکت و پاسخ', 'support', o.account?.open_tickets || 0)}${sentinelService('search', 'جست‌وجوی سراسری', 'تمام اطلاعات حساب', 'search')}</div></section>
  <section><div class="service-title">${icon('shield')}<div><h2>اعتماد و حساب</h2><p>شفافیت، قوانین و تنظیمات</p></div></div><div class="service-list">${sentinelService('chart', 'عملکرد تأییدشده', 'Track Record و شواهد', 'track')}${sentinelService('history', 'تغییرات سیگنال', 'نسخه‌ها و اصلاحیه‌ها', 'revisions', o.revision_count || 0)}${sentinelService('settings', 'تنظیمات حساب', 'زبان، قوانین و نشست', 'settings')}</div></section>
  ${adminServices ? `<section class="admin-service-group"><div class="service-title">${icon('shield')}<div><h2>مدیریت SENTINEL</h2><p>فقط ابزارهای مجاز برای این مدیر</p></div></div><div class="service-list">${adminServices}</div></section>` : ''}
 </div>`;
};
openMore = async function (target) {
    if (target === 'calculator')
        return calculatorModal();
    if (target === 'tradeCenter')
        return tradeCenterModal();
    if (target === 'feed')
        return feedModal();
    if (target === 'campaigns')
        return campaignsModal();
    if (target === 'contests')
        return contestsModal();
    if (target === 'admin-signal')
        return adminSignalComposer();
    if (target === 'admin-signal-jobs')
        return adminSignalJobsCenter();
    if (target === 'admin-signals')
        return adminSignalsCenter();
    if (target === 'admin-users')
        return adminUsersCenter();
    if (target === 'admin-admins')
        return adminAdminsCenter();
    if (target === 'admin-tickets')
        return adminTicketCenter();
    if (target === 'admin-platform')
        return adminPlatformCenter();
    if (target === 'admin-announcement')
        return adminAnnouncementComposer();
    if (target === 'journal-route') {
        closeModal();
        return navigate('journal');
    }
    return sentinelLegacyOpenMore(target);
};
document.addEventListener('click', async (event) => {
    const el = event.target.closest('[data-signal-access],[data-vip-locked],[data-signal-scope-home],[data-feed-filter],[data-trade-tab],[data-risk-calculate],[data-campaign-new],[data-campaign-detail],[data-campaign-status],[data-campaign-schedule],[data-admin-quote-refresh],[data-admin-signal-job],[data-signal-job-retry],[data-signal-job-cancel],[data-signal-job-edit]');
    if (!el)
        return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (el.dataset.vipLocked !== undefined && !state.resources.overview?.account?.vip_active)
        return openMore('vip');
    if (el.dataset.signalAccess) {
        state.signalAccessFilter = el.dataset.signalAccess;
        invalidate('signals');
        return renderSignals(true);
    }
    if (el.dataset.signalScopeHome) {
        state.signalAccessFilter = el.dataset.signalScopeHome;
        if (state.signalAccessFilter === 'vip' && !state.resources.overview?.account?.vip_active)
            return openMore('vip');
        return navigate('signals');
    }
    if (el.dataset.feedFilter) {
        state.feedFilter = el.dataset.feedFilter;
        return feedModal();
    }
    if (el.dataset.tradeTab) {
        state.tradeHubTab = el.dataset.tradeTab;
        const data = state.resources.expansion || await loadResource('expansion', true);
        const body = $('#modalBody');
        if (body)
            body.innerHTML = tradeCenterBody(data);
        return;
    }
    if (el.dataset.riskCalculate !== undefined)
        return runRiskCalculator();
    if (el.dataset.adminQuoteRefresh !== undefined)
        return refreshAdminSignalQuote(false);
    if (el.dataset.adminSignalJob)
        return adminSignalJobDetail(el.dataset.adminSignalJob, { poll: true });
    if (el.dataset.signalJobRetry) {
        await action('signal_job_retry', { job_id: el.dataset.signalJobRetry }, false);
        invalidate('adminSignalJobs');
        toast(state.lang === 'fa' ? 'سیگنال دوباره وارد صف شد.' : 'Signal requeued.');
        return adminSignalJobDetail(el.dataset.signalJobRetry, { poll: true });
    }
    if (el.dataset.signalJobCancel) {
        await action('signal_job_cancel', { job_id: el.dataset.signalJobCancel, reason: 'لغو از پنل ادمین مینی‌اپ' }, false);
        invalidate('adminSignalJobs');
        toast(state.lang === 'fa' ? 'انتشار لغو شد.' : 'Delivery cancelled.');
        return adminSignalJobDetail(el.dataset.signalJobCancel, { poll: false });
    }
    if (el.dataset.signalJobEdit) {
        const id = el.dataset.signalJobEdit;
        openModal('SIGNAL QUEUE', state.lang === 'fa' ? 'ویرایش مقصد و زمان انتشار' : 'Edit queued signal', `<form id="signalJobEditForm"><div class="field"><label>مقصد</label><select id="signalJobTarget"><option value="public">عمومی</option><option value="private">VIP</option><option value="both">هر دو</option></select></div><div class="field"><label>زمان ISO (اختیاری)</label><input id="signalJobRunAt" placeholder="2026-07-25T18:30:00+00:00"></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { await action('signal_job_update', { job_id: id, target: $('#signalJobTarget').value, run_at: $('#signalJobRunAt').value || undefined }, false); invalidate('adminSignalJobs'); closeModal(); toast(t('success')); adminSignalJobDetail(id, { poll: false }); } }]);
        return;
    }
    if (el.dataset.campaignNew !== undefined)
        return campaignCreateModal();
    if (el.dataset.campaignDetail)
        return campaignDetailModal(el.dataset.campaignDetail);
    if (el.dataset.campaignSchedule) {
        await action('campaign_schedule', { campaign_id: el.dataset.campaignSchedule, scheduled_for: new Date(Date.now() + 45000).toISOString(), priority: 1 }, false);
        invalidate('adminCampaigns');
        closeModal();
        toast('کمپین در صف پایدار انتشار قرار گرفت');
        return campaignsModal();
    }
    if (el.dataset.campaignStatus) {
        await action('campaign_status_update', { campaign_id: el.dataset.campaignStatus, status: el.dataset.status }, false);
        invalidate('adminCampaigns');
        closeModal();
        return campaignsModal();
    }
}, true);
function openModal(eyebrow, title, body, actions = []) { state.modalGeneration=(state.modalGeneration||0)+1; saveVisibleDrafts(); trapModal(false); state.modalDraftContext = `${eyebrow}:${title}`; state.modalReturn = document.activeElement; $('#modalEyebrow').textContent = translateUiText(eyebrow); $('#modalTitle').textContent = translateUiText(title); $('#modalBody').innerHTML = body; restoreFormDrafts(); setModalFooter(actions); localizeUiTree($('#modal')); $('#modalLayer').hidden = false; document.body.style.overflow = 'hidden'; $('#main')?.setAttribute('inert', ''); $('#modal').focus(); installTelegramNavigation(); syncTelegramNavigation(); trapModal(true); }
function setModalFooter(actions = []) { const foot = $('#modalFooter'); foot.innerHTML = actions.map((a, i) => `<button class="button ${a.kind === 'secondary' ? 'secondary' : a.kind === 'danger' ? 'danger' : ''}" data-modal-action="${i}">${esc(a.label)}</button>`).join(''); foot.hidden = !actions.length; state.modalActions = actions; if (state.mainButtonHandler)
    tg?.MainButton?.offClick?.(state.mainButtonHandler); state.mainButtonHandler = null; const primaryIndex = actions.findIndex(a => a.kind === 'primary'); if (primaryIndex >= 0 && tg?.MainButton) {
    state.mainButtonHandler = () => actions[primaryIndex]?.action?.();
    tg.MainButton.setParams?.({ text: String(actions[primaryIndex].label || t('submit')), is_visible: true, is_active: true });
    tg.MainButton.onClick?.(state.mainButtonHandler);
}
else
    tg?.MainButton?.hide?.(); }
function closeModal() { state.modalGeneration=(state.modalGeneration||0)+1; if ($('#modalLayer').hidden)
    return; saveVisibleDrafts(); $('#modalLayer').hidden = true; document.body.style.overflow = ''; $('#main')?.removeAttribute('inert'); if (state.mainButtonHandler)
    tg?.MainButton?.offClick?.(state.mainButtonHandler); state.mainButtonHandler = null; setModalFooter([]); tg?.MainButton?.hide?.(); syncTelegramNavigation(); trapModal(false); state.modalReturn?.focus?.(); state.modalReturn = null; }
function trapModal(active) { if (active) {
    state.trapHandler = e => { if (e.key === 'Escape') {
        closeModal();
        return;
    } if (e.key !== 'Tab')
        return; const focusable = $$('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])', $('#modal')); if (!focusable.length)
        return; const first = focusable[0], last = focusable.at(-1); if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
    }
    else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
    } };
    document.addEventListener('keydown', state.trapHandler);
}
else if (state.trapHandler) {
    document.removeEventListener('keydown', state.trapHandler);
    state.trapHandler = null;
} }
function errorPanel(err, key) { return `<div class="panel"><div class="empty">${icon('alert')}<h2>${esc(t('error'))}</h2><p>${esc(err.message)}</p><button class="button" data-retry="${key}">${esc(t('retry'))}</button></div></div>`; }
function invalidate(...keys) { state.resourceEpochs ??= new Map(); keys.forEach(k => { state.loaded.delete(k); state.resourceEpochs.set(k,(state.resourceEpochs.get(k)||0)+1); }); }
async function navigate(page, scroll = true) { if (!['home','signals','risk','journal','more','trading','rewards'].includes(page)) page='home'; if(scroll && page!==state.page) {state.pageHistory.push(state.page);if(state.pageHistory.length>20)state.pageHistory.shift();} if(page==='home')state.pageHistory=[]; state.page = page; syncTelegramNavigation(); try { const routeNav=$('#pageNavigation');if(routeNav)routeNav.hidden=page==='home'; $$('.page').forEach(el => el.classList.toggle('active', el.dataset.page === page)); $$('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.pageTarget === page)); if (scroll)
    window.scrollTo({ top: 0, behavior: 'smooth' }); if (page === 'home')
    renderHome(); if (page === 'signals')
    await renderSignals(); if (page === 'risk')
    await renderRisk(); if (page === 'journal')
    await renderJournal(); if (page === 'more')
    await renderMore(); if (page === 'trading') renderTradingWorkspace(); if (page === 'rewards') await renderRewardsWorkspace(); if (state.lang === 'en') localizeUiTree(document); } finally { syncTelegramNavigation(); } }
function applyLanguage() { document.documentElement.lang = state.lang; document.documentElement.dir = state.lang === 'fa' ? 'rtl' : 'ltr'; document.title = state.lang === 'fa' ? 'SENTINEL | سیستم مدیریت معامله' : 'SENTINEL | Trading Risk OS'; const description = document.querySelector('meta[name="description"]'); if (description) description.content = state.lang === 'fa' ? 'SENTINEL — سیستم‌عامل مستقل مدیریت سیگنال، ریسک، ژورنال و شفافیت عملکرد' : 'SENTINEL — independent signal, risk, journal and verified-performance operating system'; renderChrome(); localizeUiTree(document); ensureUiLocalizationObserver(); }
async function toggleLanguage() { const previous = state.lang; state.lang = state.lang === 'fa' ? 'en' : 'fa'; localStorage.setItem('sentinelLanguage', state.lang); if (state.resources.overview?.user) state.resources.overview.user.language = state.lang; closeModal(); applyLanguage(); await navigate(state.page, false); localizeUiTree(document); if (!state.preview) { try { await action('language_update', { language: state.lang }, false); } catch (err) { state.lang = previous; localStorage.setItem('sentinelLanguage', previous); applyLanguage(); await navigate(state.page, false); toast(translateUiText(err.message || t('error')), 'error'); } } }
function copySignal(id) { const all = [...(state.resources.signals?.items || []), ...(state.resources.overview?.recent_signals || [])], s = all.find(x => Number(x.id) === Number(id)) || state.resources[`signal:${id}`]; if (!s)
    return; const text = [`${s.symbol} ${String(s.side).toUpperCase()}`, `Entry: ${s.entry}`, ...(s.targets || []).map((x, i) => `TP${i + 1}: ${x}`), `SL: ${s.stop}`, `Risk: ${s.risk}%`].join('\n'); navigator.clipboard.writeText(text).then(() => toast(t('copyDone'))); }
function exportJournal() { const rows = state.resources.journal?.items || [], fields = ['id', 'signal_id', 'source', 'entry_reason_type', 'entry_reason', 'symbol', 'side', 'entry_price', 'actual_stop', 'exit_price', 'volume', 'result_r', 'pnl_percent', 'pnl_amount', 'fees', 'commission', 'swap', 'status', 'note', 'created_at', 'closed_at']; const csv = [fields.join(','), ...rows.map(r => fields.map(k => `"${String(r[k] ?? '').replaceAll('"', '""')}"`).join(','))].join('\n'); const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'sentinel-journal.csv'; a.click(); URL.revokeObjectURL(a.href); }
async function downloadJournalPdf() { setBusy(true); try {
    const response = await fetch(`./api/v1/journal/export.pdf?lang=${encodeURIComponent(state.lang)}`, { credentials: 'include', headers: { 'Accept': 'application/pdf' } });
    if (!response.ok) {
        let message = 'PDF_EXPORT_FAILED';
        try {
            const body = await response.json();
            message = body?.error?.message || body?.detail || message;
        }
        catch { }
        throw new Error(message);
    }
    const blob = await response.blob();
    if (!blob.size)
        throw new Error('PDF_EXPORT_EMPTY');
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url;
    a.download = `sentinel-journal-${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    toast(state.lang === 'fa' ? 'گزارش PDF ژورنال آماده شد.' : 'Journal PDF downloaded.');
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function importJournal() { openModal('JOURNAL', t('importCsv'), `<div class="field"><label for="journalCsvFile">${esc(t('file'))}</label><input id="journalCsvFile" type="file" accept=".csv,text/csv" required></div>`, [{ label: t('importCsv'), kind: 'primary', action: async () => { const file = $('#journalCsvFile').files?.[0]; if (!file)
            return; setBusy(true); try {
            const content = await file.text();
            const result = await action('journal_import_csv', { content }, false);
            toast(`${t('success')}: ${num(result.imported, 0)}`);
            closeModal();
            invalidate('journal');
            await loadResource('journal', true);
            renderJournal();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function importBroker() { const accounts = state.resources.overview?.risk?.accounts || []; openModal('BROKER IMPORT', t('brokerImport'), `<form id="brokerImportForm"><div class="form-grid"><div class="field"><label for="brokerName">Broker / Platform</label><select id="brokerName"><option>MT5</option><option>MT4</option><option>cTrader</option><option>Generic CSV</option></select></div><div class="field"><label for="brokerAccount">${esc(t('account'))}</label><select id="brokerAccount">${accounts.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select></div></div><div class="field"><label for="brokerFile">${esc(t('file'))}</label><input id="brokerFile" type="file" accept=".csv,.html,.htm,text/csv,text/html" required aria-describedby="brokerHint"><small id="brokerHint" class="field-help">${state.lang === 'fa' ? 'گزارش معاملات MT4/MT5 یا CSV بروکر؛ رکورد تکراری با Ticket دوباره وارد نمی‌شود.' : 'MT4/MT5 statement or broker CSV; duplicate ticket IDs are skipped.'}</small></div></form>`, [{ label: t('brokerImport'), kind: 'primary', action: async () => { const f = $('#brokerImportForm'), file = $('#brokerFile').files?.[0]; if (!f.reportValidity() || !file)
            return; setBusy(true); try {
            const result = await action('broker_import', { content: await file.text(), filename: file.name, broker: $('#brokerName').value, account_id: $('#brokerAccount').value }, false);
            toast(`${t('success')}: ${num(result.imported, 0)} / ${num(result.parsed, 0)}`);
            closeModal();
            invalidate('journal');
            await loadResource('journal', true);
            renderJournal();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function adminWorkspace() {
    setBusy(true);
    try {
        const overview = state.resources.overview || await loadOverview(), admin = overview.admin || {}, perms = new Set(admin.permissions || []), owner = admin.role === 'owner', can = p => owner || perms.has(p), canAny = (...names) => owner || names.some(name => perms.has(name)),
            canPayment = canAny('payments','payment_dashboard_view','payment_transactions_view','payment_receipts_view','payment_receipt_approve','payment_receipt_reject','payment_manual_review'),
            canAi = can('ai_command_center'),
            canVipPlan = canAny('vip_settings','vip_plan_view','vip_plan_create','vip_plan_edit','vip_plan_activate','vip_plan_archive','vip_plan_delete'),
            canTickets = canAny('tickets','tickets_view','tickets_reply','tickets_assign','tickets_status_manage','tickets_priority_manage','ticket_attachments_view','ticket_internal_notes'),
            canTicketReply = canAny('tickets','tickets_reply'),
            canSignals = canAny('signals','signals_view','signal_edit','signal_results','signal_status_manage','signal_metrics_edit','signal_delete','signal_schedule','signal_board_manage','signal_publish_now'),
            canSignalQueue = canAny('signals','signal_schedule'),
            canSignalCycles = canAny('signals','signal_board_manage'),
            canUsers = canAny('users','users_view','user_ban_manage','user_vip_assign','user_sensitive_data_view'),
            canIntegrationView = canAny('system_control','integration_health_view'),
            canIntegrationManage = can('system_control'),
            canRuntime = canAny('runtime_safety','maintenance_mode_manage'),
            canSystemHealth = canAny('system_control','system_health_view','integration_health_view'),
            canAudit = canAny('audit_logs','system_health_view'),
            safe = async (key, allowed = true) => { if (!allowed)
            return null; try {
            return await loadResource(key, true);
        }
        catch (err) {
            state.adminLoadErrors = state.adminLoadErrors || {};
            state.adminLoadErrors[key] = err.message;
            return null;
        } };
        const [ops, experiments, orders, tickets, templates, integration, signalJobs, signalCycles, capabilities, aiCenter, vipPlans] = await Promise.all([
            safe('adminOps', true), safe('adminExperiments', can('campaigns')), safe('adminOrders', canPayment), safe('adminTickets', canTickets), safe('adminTemplates', can('signal_templates')), safe('adminIntegration', canIntegrationView), safe('adminSignalJobs', canSignalQueue), safe('adminSignalCycles', canSignalCycles), safe('adminCapabilities', true), safe('adminAI', canAi), safe('adminVipPlans', canVipPlan)
        ]);
        const brief = ops?.brief || {}, counts = brief.counts || {}, health = ops?.system_health || {}, intel = ops?.operations_intelligence || {}, runtime = overview.miniapp_runtime || { enabled: true }, orderRows = orders?.items || [], ticketRows = tickets?.items || [], signalRows = signalJobs?.items || [], cycleRows = signalCycles?.items || [], currentCycle = signalCycles?.current || cycleRows[0] || {}, handoffs = ops?.handoffs || [], experimentRows = experiments?.experiments || [];
        const fa = state.lang === 'fa', role = owner ? (fa ? 'مالک' : 'Owner') : (admin.role || 'admin'), pendingOrders = orderRows.filter(x => ['pending','approving'].includes(String(x.status))).length, waitingTickets = ticketRows.filter(x => x.status !== 'closed' && x.waiting_for === 'admin').length;
        const summary = `<section class="panel"><div class="panel-head"><div><small class="eyebrow">SENTINEL ADMIN</small><h3>${fa ? 'مرکز مدیریت ساده و عملیاتی' : 'Simple operations center'}</h3></div><span class="status-badge good">${esc(role)}</span></div><div class="panel-body"><div class="metric-grid">${metric(fa ? 'پرداخت منتظر' : 'Pending payments', num(pendingOrders, 0), '', 'warn')}${metric(fa ? 'تیکت نیازمند پاسخ' : 'Tickets waiting', num(waitingTickets, 0), '', 'warn')}${metric(fa ? 'سیگنال در صف' : 'Signal jobs', num(signalRows.length, 0), '', 'info')}${metric(fa ? 'دسترسی فعال' : 'Permissions', owner ? 'ALL' : num(perms.size, 0), '', 'good')}</div><p class="field-help">${fa ? 'کارهای روزمره در همین صفحه قرار دارند. تمام دسترسی‌های تخصصی بدون حذف، داخل «همه ابزارهای ادمین» باقی مانده‌اند.' : 'Daily actions stay on this page. Every advanced permission remains available in “All admin tools”.'}</p><div class="card-actions"><button class="button primary wide" data-admin-command-center>${fa ? 'همه ابزارهای ادمین' : 'All admin tools'}</button>${canPayment ? `<button class="button primary" data-admin-payments>${fa ? 'مدیریت رسیدها و پرداخت‌ها' : 'Receipts & payments'}</button>` : ''}${canSignals ? `<button class="button secondary" data-admin-signals>${fa ? 'مدیریت سیگنال‌ها' : 'Manage signals'}</button>` : ''}${canSignalQueue ? `<button class="button secondary" data-open="admin-signal-jobs">${fa ? 'صف ارسال سیگنال' : 'Signal delivery queue'}</button>` : ''}${canUsers ? `<button class="button secondary" data-admin-users>${fa ? 'کنترل کاربران' : 'User control'}</button>` : ''}${can('admin_management') ? `<button class="button secondary" data-admin-admins>${fa ? 'مدیریت ادمین‌ها' : 'Admin access'}</button>` : ''}${canAi ? `<button class="button secondary" data-admin-ai-center>${fa ? 'مرکز هوش مصنوعی' : 'AI Command Center'}</button>` : ''}${canVipPlan ? `<button class="button secondary" data-admin-vip-plans>${fa ? 'پلن‌ها و تنظیمات پرداخت VIP' : 'VIP plans & payment settings'}</button>` : ''}${canAudit ? `<button class="button secondary" data-admin-audit>${fa ? 'گزارش ممیزی' : 'Audit log'}</button>` : ''}</div></div></section>`;
        const runtimeSection = canRuntime ? `<section class="panel compact-panel"><div class="panel-head"><div><small class="eyebrow">MINI APP</small><h3>${fa ? 'دسترسی کاربران' : 'User availability'}</h3></div><span class="status-badge ${runtime.enabled !== false ? 'good' : 'bad'}">${runtime.enabled !== false ? 'ON' : 'OFF'}</span></div><div class="panel-body"><p>${runtime.enabled !== false ? (fa ? 'مینی‌اپ برای کاربران روشن است.' : 'Mini App is available to users.') : (fa ? 'مینی‌اپ برای کاربران خاموش است؛ دسترسی ادمین حفظ شده.' : 'Mini App is hidden from users; admin access remains.')}</p><button class="button ${runtime.enabled !== false ? 'danger' : 'primary'}" data-miniapp-toggle="${runtime.enabled !== false ? 'off' : 'on'}">${runtime.enabled !== false ? (fa ? 'خاموش‌کردن' : 'Disable') : (fa ? 'روشن‌کردن' : 'Enable')}</button></div></section>` : '';
        const integrationSection = canIntegrationView ? `<section class="panel compact-panel"><div class="panel-head"><div><small class="eyebrow">BOT ↔ MINI APP</small><h3>${fa ? 'همگام‌سازی اطلاعات' : 'Data synchronization'}</h3></div><span class="status-badge ${integration?.status === 'connected' ? 'good' : 'warn'}">${integration?.status === 'connected' ? 'CONNECTED' : 'CHECK'}</span></div><div class="panel-body"><p class="field-help">${fa ? 'سیگنال، اشتراک، واچ‌لیست و دسترسی‌ها بین ربات و مینی‌اپ تطبیق داده می‌شوند.' : 'Signals, subscriptions, watchlists and permissions are reconciled across both clients.'}</p>${canIntegrationManage ? `<button class="button primary" data-integration-reconcile>${icon('refresh')}${fa ? 'تطبیق دوباره' : 'Reconcile now'}</button>` : `<div class="notice info"><strong>${fa ? 'دسترسی فقط‌خواندنی' : 'Read-only access'}</strong><p>${fa ? 'وضعیت اتصال قابل مشاهده است؛ اجرای تطبیق نیازمند کنترل کامل سیستم است.' : 'Integration health is visible; reconciliation requires full system control.'}</p></div>`}</div></section>` : '';
        const cycleStats = currentCycle?.stats || {};
        const cycleSection = canSignalCycles ? `<section class="panel"><div class="panel-head"><div><small class="eyebrow">SIGNAL PERIODS</small><h3>${fa ? 'دوره‌های نام‌دار سیگنال' : 'Named signal periods'}</h3></div><span class="status-badge ${currentCycle?.status === 'closed' ? 'warn' : 'good'}">${currentCycle?.status === 'closed' ? (fa ? 'بسته' : 'CLOSED') : (fa ? 'فعال' : 'ACTIVE')}</span></div><div class="panel-body"><div class="row-between"><div><strong>#${num(currentCycle?.id || 1, 0)} · ${esc(currentCycle?.name || (fa ? 'دوره فعلی' : 'Current period'))}</strong><p class="field-help">${fa ? 'با بستن دوره، تاریخچه و سیگنال‌ها حذف نمی‌شوند.' : 'Closing preserves every signal and report.'}</p></div></div><div class="metric-grid">${metric(fa ? 'کل سیگنال' : 'Signals', num(cycleStats.total || 0, 0), '', 'info')}${metric(fa ? 'برد' : 'Wins', num(cycleStats.wins || 0, 0), '', 'good')}${metric(fa ? 'باخت' : 'Losses', num(cycleStats.losses || 0, 0), '', 'warn')}${metric(fa ? 'نرخ برد' : 'Win rate', `${num(cycleStats.win_rate || 0, 1)}%`, '', 'info')}</div><div class="card-actions"><button class="button primary" data-admin-signal-cycles>${fa ? 'آرشیو و گزارش دوره‌ها' : 'Period archive & reports'}</button>${currentCycle?.status === 'closed' ? `<button class="button" data-signal-cycle-name="start">${fa ? 'شروع دوره جدید' : 'Start new period'}</button>` : `<button class="button" data-signal-cycle-name="rollover">${fa ? 'بستن و شروع دوره جدید' : 'Close & start new'}</button><button class="button danger" data-signal-cycle-close>${fa ? 'فقط بستن دوره' : 'Close only'}</button>`}</div></div></section>` : '';
        const ordersSection = canPayment ? `<section class="panel"><div class="panel-head"><div><h3>${fa ? 'رسیدهای منتظر بررسی' : 'Receipts awaiting review'}</h3><small>${fa ? 'همگام با ربات و خرید Mini App' : 'Synced with Bot and Mini App checkout'}</small></div><span class="status-badge warn">${num(pendingOrders, 0)}</span></div><div class="panel-body journal-list">${orderRows.filter(x => ['pending','approving'].includes(String(x.status))).slice(0, 8).map(x => `<article class="journal-card"><div class="row-between"><strong>${esc(x.plan_name || x.plan_id || x.id)}</strong><span class="status-badge ${x.status === 'approving' ? 'info' : 'warn'}">${esc(x.status)}</span></div><p>${fa ? 'کاربر' : 'User'} ${esc(x.user_id)} · ${money(x.amount_toman || 0, 'T')}</p><div class="row-between"><small>${x.receipt_attached ? (fa ? '✅ رسید پیوست شده' : '✅ Receipt attached') : (fa ? '⚠️ بدون رسید' : '⚠️ No receipt')}</small><small>${date(x.updated_at || x.created_at)}</small></div><div class="card-actions"><button class="button primary small" data-admin-order="${esc(x.id)}">${fa ? 'مشاهده و بررسی' : 'Open & review'}</button></div></article>`).join('') || empty()}<div class="card-actions"><button class="button secondary wide" data-admin-payments>${fa ? 'مشاهده همه پرداخت‌ها' : 'View all payments'}</button></div></div></section>` : '';
        const ticketsSection = canTickets ? `<section class="panel"><div class="panel-head"><h3>${fa ? 'تیکت‌های نیازمند پاسخ' : 'Tickets needing reply'}</h3><span class="status-badge warn">${num(waitingTickets, 0)}</span></div><div class="panel-body journal-list">${ticketRows.filter(x => x.status !== 'closed' && x.waiting_for === 'admin').slice(0, 6).map(x => `<article class="journal-card"><div class="row-between"><strong>#${num(x.id, 0)} · ${esc(x.subject || 'Support')}</strong><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${fa ? 'کاربر' : 'User'} ${esc(x.user_id)} · ${esc(x.priority || 'normal')}</p><div class="card-actions"><button class="button primary small" data-admin-ticket="${x.id}">${canTicketReply ? (fa ? 'بازکردن و پاسخ' : 'Open & reply') : (fa ? 'مشاهده تیکت' : 'View ticket')}</button></div></article>`).join('') || empty()}</div></section>` : '';
        const advanced = `<details class="details-block"><summary>${fa ? 'ابزارها و جزئیات پیشرفته' : 'Advanced tools and details'}</summary><div class="admin-workspace">${canSystemHealth ? `<section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'سلامت سیستم' : 'System health'}</h3><span class="status-badge ${health.database?.persistent ? 'good' : 'warn'}">${esc(health.release || APP_VERSION)}</span></div><div class="panel-body"><div class="health-grid"><div class="health-card"><strong>Database</strong><span class="status-badge ${health.database?.persistent ? 'good' : 'bad'}">${health.database?.persistent ? 'Persistent' : 'Check'}</span><small>${esc(health.database?.reason || '')}</small></div><div class="health-card"><strong>Receipts</strong><span class="status-badge ${health.receipt_storage?.persistent && health.receipt_storage?.healthy ? 'good' : 'bad'}">${esc(health.receipt_storage?.backend || 'unknown')}</span><small>${esc(health.receipt_storage?.detail || '')}</small></div><div class="health-card"><strong>Memory</strong><span class="status-badge ${intel.memory?.state === 'healthy' ? 'good' : intel.memory?.state === 'critical' ? 'bad' : 'warn'}">${intel.memory?.percent == null ? 'unknown' : `${num(intel.memory.percent, 1)}%`}</span><small>${num(intel.memory?.rss_mb || 0, 1)} MB</small></div><div class="health-card"><strong>Self-healing</strong><span class="status-badge ${intel.self_healing?.enabled ? 'good' : 'warn'}">${intel.self_healing?.enabled ? 'ON' : 'OFF'}</span><small>${esc(intel.self_healing?.last_status || 'never')}</small></div></div></div></section>` : ''}${can('signal_templates') ? `<section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'قالب سیگنال' : 'Signal templates'}</h3></div><div class="panel-body">${['buy', 'sell'].map(side => { const row = templates?.[side]?.background || {}; return `<div class="account-card"><div class="row-between"><strong>${side.toUpperCase()}</strong><span class="status-badge ${row.custom ? 'good' : 'info'}">${row.custom ? 'CUSTOM' : 'DEFAULT'}</span></div><div class="field"><input id="adminTemplate${side}" type="file" accept="image/jpeg,image/png,image/webp"></div><div class="card-actions"><button class="button small" data-template-upload="${side}">${fa ? 'بارگذاری' : 'Upload'}</button>${row.custom ? `<button class="button danger small" data-template-reset="${side}">${fa ? 'قالب اصلی' : 'Default'}</button>` : ''}</div></div>`; }).join('')}</div></section>` : ''}${handoffs.length ? `<section class="panel compact-panel"><div class="panel-head"><h3>${esc(t('shiftHandoff'))}</h3><button class="button small" data-admin-handoff-new>${icon('plus')}${esc(t('newHandoff'))}</button></div><div class="panel-body journal-list">${handoffs.slice(0, 5).map(x => `<article class="journal-card"><strong>#${num(x.id, 0)} · ${esc(x.from_admin_id)} → ${esc(x.to_admin_id)}</strong><p>${esc(x.summary)}</p></article>`).join('')}</div></section>` : ''}${can('campaigns') ? `<section class="panel compact-panel"><div class="panel-head"><h3>${esc(t('experimentLab'))}</h3><button class="button small" data-experiment-new>${icon('plus')}${esc(t('newExperiment'))}</button></div><div class="panel-body journal-list">${experimentRows.slice(0, 5).map(x => `<article class="journal-card"><strong>${esc(x.name)}</strong><p>${esc(x.primary_metric || '')}</p></article>`).join('') || empty()}</div></section>` : ''}</div></details>`;
        openModal('ADMIN', t('adminConsole'), `<div class="admin-workspace">${summary}<div class="form-grid">${runtimeSection}${integrationSection}</div>${cycleSection}${ordersSection}${ticketsSection}${advanced}</div>`, []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function signalCycleStatusLabel(status) { const closed = String(status || 'active') === 'closed'; return state.lang === 'fa' ? (closed ? 'بسته' : 'فعال') : (closed ? 'Closed' : 'Active'); }
function signalCycleCard(row) { const stats = row?.stats || {}, closed = String(row?.status || 'active') === 'closed'; return `<article class="journal-card"><div class="row-between"><div><strong>#${num(row?.id || 0, 0)} · ${esc(row?.name || '—')}</strong><p>${esc(signalCycleStatusLabel(row?.status))} · ${num(stats.total || row?.signal_count || 0, 0)} ${state.lang === 'fa' ? 'سیگنال' : 'signals'}</p></div><span class="status-badge ${closed ? 'info' : 'good'}">${esc(signalCycleStatusLabel(row?.status))}</span></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'برد' : 'Wins', num(stats.wins || 0, 0), '', 'good')}${metric(state.lang === 'fa' ? 'باخت' : 'Losses', num(stats.losses || 0, 0), '', 'warn')}${metric(state.lang === 'fa' ? 'نرخ برد' : 'Win rate', `${num(stats.win_rate || 0, 1)}%`, '', 'info')}${metric(state.lang === 'fa' ? 'سود/زیان' : 'P/L', `${Number(stats.profit_percent_sum || 0) >= 0 ? '+' : ''}${num(stats.profit_percent_sum || 0, 2)}%`, '', Number(stats.profit_percent_sum || 0) >= 0 ? 'good' : 'warn')}</div><div class="card-actions"><button class="button primary small" data-signal-cycle-detail="${esc(row?.id)}">${state.lang === 'fa' ? 'مشاهده سیگنال‌ها' : 'View signals'}</button><button class="button small" data-signal-cycle-pdf="${esc(row?.id)}">PDF</button><button class="button secondary small" data-signal-cycle-rename="${esc(row?.id)}">${state.lang === 'fa' ? 'تغییر نام' : 'Rename'}</button></div></article>`; }
async function adminSignalCyclesModal() { setBusy(true); try {
    const d = await loadResource('adminSignalCycles', true), rows = d?.items || [], current = d?.current || rows[0] || {}, closed = String(current?.status || 'active') === 'closed';
    state.resources.adminSignalCycles = d;
    openModal('SIGNAL PERIODS', state.lang === 'fa' ? 'دوره‌های سیگنال و گزارش عملکرد' : 'Signal periods and performance', `<div class="notice info"><strong>${state.lang === 'fa' ? 'تاریخچه دائمی دوره‌ها' : 'Permanent period history'}</strong><p>${state.lang === 'fa' ? 'بستن دوره فقط آن را آرشیو می‌کند؛ سیگنال‌ها، نتایج و PDF آن باقی می‌مانند.' : 'Closing archives the period; signals, results and PDF remain available.'}</p></div><div class="card-actions"><button class="button primary" data-signal-cycle-name="${closed ? 'start' : 'rollover'}">${closed ? (state.lang === 'fa' ? 'شروع دوره جدید' : 'Start new period') : (state.lang === 'fa' ? 'بستن و شروع دوره جدید' : 'Close & start new')}</button>${!closed ? `<button class="button danger" data-signal-cycle-close>${state.lang === 'fa' ? 'فقط بستن دوره فعلی' : 'Close current only'}</button>` : ''}</div><div class="journal-list">${rows.map(signalCycleCard).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
function signalCycleNameModal(mode = 'rollover', cycleId = '') { const d = state.resources.adminSignalCycles || {}, current = d.current || {}, rename = mode === 'rename', start = mode === 'start', title = rename ? (state.lang === 'fa' ? 'تغییر نام دوره' : 'Rename period') : (start ? (state.lang === 'fa' ? 'شروع دوره جدید' : 'Start new period') : (state.lang === 'fa' ? 'بستن دوره فعلی و شروع دوره جدید' : 'Close current and start new')); const existing = rename ? (d.items || []).find(x => String(x.id) === String(cycleId))?.name || '' : ''; openModal('SIGNAL PERIOD', title, `<form id="signalCycleNameForm"><div class="notice ${mode === 'rollover' ? 'warning' : 'info'}"><p>${mode === 'rollover' ? (state.lang === 'fa' ? 'دوره فعلی بدون حذف تاریخچه بسته می‌شود و دوره جدید با شماره‌گذاری #1 آغاز خواهد شد.' : 'Current period will be preserved and a new #1 sequence starts.') : (rename ? (state.lang === 'fa' ? 'فقط نام دوره تغییر می‌کند و سیگنال‌ها دست‌نخورده می‌مانند.' : 'Only the name changes; signals remain untouched.') : (state.lang === 'fa' ? 'نام دوره جدید را مشخص کنید.' : 'Choose a name for the new period.'))}</p></div><div class="field"><label for="signalCycleName">${state.lang === 'fa' ? 'نام دوره' : 'Period name'}</label><input id="signalCycleName" required minlength="2" maxlength="120" value="${esc(existing)}" placeholder="${state.lang === 'fa' ? 'کمپین تبدیل ۱۰۰ به ۱۰۰۰' : '100 to 1000 campaign'}"></div></form>`, [{ label: rename ? (state.lang === 'fa' ? 'ذخیره نام' : 'Save name') : (state.lang === 'fa' ? 'ثبت و اجرا' : 'Confirm'), kind: 'primary', action: async () => { const form = $('#signalCycleNameForm'), name = $('#signalCycleName')?.value.trim(); if (!form?.reportValidity() || !name)
            return; if (mode === 'rollover' && !confirm(state.lang === 'fa' ? 'دوره فعلی بسته و دوره جدید آغاز شود؟' : 'Close current period and start a new one?'))
            return; setBusy(true); try {
            const actionName = rename ? 'signal_cycle_rename' : start ? 'signal_cycle_start' : 'signal_cycle_rollover', payload = rename ? { cycle_id: Number(cycleId), name } : { name };
            await action(actionName, payload, false);
            invalidate('adminSignalCycles', 'signals', 'overview', 'adminSignalJobs');
            await loadResource('adminSignalCycles', true);
            closeModal();
            await adminSignalCyclesModal();
            toast(state.lang === 'fa' ? 'دوره با موفقیت به‌روزرسانی شد.' : 'Period updated successfully.');
        }
        catch (err) {
            toast(err?.message || String(err), 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function closeSignalCycleFromMiniApp() { if (!confirm(state.lang === 'fa' ? 'دوره فعلی بسته شود؟ هیچ سیگنالی حذف نخواهد شد.' : 'Close current period? No signal will be deleted.'))
    return; setBusy(true); try {
    await action('signal_cycle_close', {}, false);
    invalidate('adminSignalCycles', 'signals', 'overview', 'adminSignalJobs');
    await loadResource('adminSignalCycles', true);
    closeModal();
    await adminSignalCyclesModal();
    toast(state.lang === 'fa' ? 'دوره بسته و در آرشیو نگهداری شد.' : 'Period closed and preserved.');
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
async function adminSignalCycleDetail(id) { setBusy(true); try {
    const d = await request(`./api/v1/admin/signal-cycles/${encodeURIComponent(id)}?limit=500`), row = d?.cycle || {}, items = d?.items || [], stats = row?.stats || {};
    openModal('SIGNAL PERIOD', `#${num(row.id || id, 0)} · ${row.name || '—'}`, `<div class="metric-grid">${metric(state.lang === 'fa' ? 'کل سیگنال' : 'Signals', num(stats.total || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'برد' : 'Wins', num(stats.wins || 0, 0), '', 'good')}${metric(state.lang === 'fa' ? 'باخت' : 'Losses', num(stats.losses || 0, 0), '', 'warn')}${metric(state.lang === 'fa' ? 'نرخ برد' : 'Win rate', `${num(stats.win_rate || 0, 1)}%`, '', 'info')}${metric(state.lang === 'fa' ? 'سود/زیان تجمعی' : 'Cumulative P/L', `${Number(stats.profit_percent_sum || 0) >= 0 ? '+' : ''}${num(stats.profit_percent_sum || 0, 2)}%`, '', Number(stats.profit_percent_sum || 0) >= 0 ? 'good' : 'warn')}</div><div class="card-actions"><button class="button primary" data-signal-cycle-pdf="${esc(id)}">${state.lang === 'fa' ? 'دریافت PDF کامل' : 'Download full PDF'}</button><button class="button secondary" data-signal-cycle-rename="${esc(id)}">${state.lang === 'fa' ? 'تغییر نام دوره' : 'Rename period'}</button><button class="button" data-admin-signal-cycles>${state.lang === 'fa' ? 'بازگشت به دوره‌ها' : 'Back to periods'}</button></div><div class="journal-list">${items.map(x => `<article class="journal-card"><div class="row-between"><strong>#${num(x.display_number || x.id || 0, 0)} · ${esc(x.symbol || '—')}</strong><span class="status-badge ${String(x.status || 'open').includes('stop') ? 'bad' : 'info'}">${esc(x.status || 'open')}</span></div><p>${esc(String(x.side || '').toUpperCase())} · ${state.lang === 'fa' ? 'سود/زیان' : 'P/L'} ${Number(x.profit_percent || 0) >= 0 ? '+' : ''}${num(x.profit_percent || 0, 2)}%</p></article>`).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
async function downloadSignalCyclePdf(id) { setBusy(true); try {
    const response = await fetch(`./api/v1/admin/signal-cycles/${encodeURIComponent(id)}/export.pdf?lang=${encodeURIComponent(state.lang)}`, { credentials: 'include', headers: { Accept: 'application/pdf' } });
    if (!response.ok) {
        let message = 'SIGNAL_PERIOD_PDF_FAILED';
        try {
            const body = await response.json();
            message = body?.error?.message || body?.detail || message;
        }
        catch { }
        throw new Error(message);
    }
    const blob = await response.blob();
    if (!blob.size)
        throw new Error('SIGNAL_PERIOD_PDF_EMPTY');
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url;
    a.download = `sentinel-signal-period-${id}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    toast(state.lang === 'fa' ? 'گزارش PDF دوره آماده شد.' : 'Period PDF downloaded.');
}
catch (err) {
    toast(err?.message || String(err), 'error');
}
finally {
    setBusy(false);
} }
function adminPaymentTone(status) { return status === 'approved' ? 'good' : status === 'rejected' || status === 'cancelled' ? 'bad' : status === 'approving' ? 'info' : 'warn'; }
function adminPaymentLabel(status) { const fa = state.lang === 'fa', labels = fa ? { pending:'منتظر بررسی', approving:'در حال تأیید', approved:'تأییدشده', rejected:'ردشده', cancelled:'لغوشده', expired:'منقضی' } : { pending:'Pending review', approving:'Approving', approved:'Approved', rejected:'Rejected', cancelled:'Cancelled', expired:'Expired' }; return labels[String(status)] || String(status || 'unknown'); }
async function adminPaymentsModal(force = true) { setBusy(true); try {
    const data = await loadResource('adminOrders', force), rows = data?.items || [], filter = state.adminPaymentFilter || 'pending', visible = filter === 'all' ? rows : filter === 'pending' ? rows.filter(row => ['pending','approving'].includes(String(row.status))) : rows.filter(row => String(row.status) === filter), counts = rows.reduce((out,row) => (out[row.status] = (out[row.status] || 0) + 1, out), {});
    openModal('PAYMENT REVIEW', state.lang === 'fa' ? 'رسیدها و پرداخت‌های VIP' : 'VIP receipts and payments', `<div class="notice info"><strong>${state.lang === 'fa' ? 'ارتباط مستقیم ربات و Mini App' : 'Direct Bot ↔ Mini App sync'}</strong><p>${state.lang === 'fa' ? 'رسید ارسالی کاربر در همین صفحه دیده می‌شود؛ تأیید یا رد، همان سفارش را در ربات و Mini App به‌روزرسانی می‌کند.' : 'User receipts are reviewed here; approve/reject updates the same order in Bot and Mini App.'}</p></div><div class="filters">${['pending','approved','rejected','all'].map(key => `<button class="filter-chip ${filter === key ? 'active' : ''}" data-admin-payment-filter="${key}">${esc(key === 'all' ? (state.lang === 'fa' ? 'همه' : 'All') : adminPaymentLabel(key))}${key !== 'all' ? ` · ${num(key === 'pending' ? Number(counts.pending || 0) + Number(counts.approving || 0) : counts[key] || 0, 0)}` : ` · ${num(rows.length,0)}`}</button>`).join('')}</div><div class="journal-list" style="margin-top:12px">${visible.map(row => `<article class="journal-card"><div class="row-between"><div><strong>${esc(row.plan_name || row.plan_id || row.id)}</strong><p>#${esc(row.id)} · ${state.lang === 'fa' ? 'کاربر' : 'User'} ${esc(row.user_id)}</p></div><span class="status-badge ${adminPaymentTone(row.status)}">${esc(adminPaymentLabel(row.status))}</span></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'مبلغ' : 'Amount', money(row.amount_toman || 0, 'T'), '', 'warn')}${metric(state.lang === 'fa' ? 'رسید' : 'Receipt', row.receipt_attached ? (state.lang === 'fa' ? 'پیوست‌شده' : 'Attached') : (state.lang === 'fa' ? 'ندارد' : 'Missing'), '', row.receipt_attached ? 'good' : 'bad')}</div><small>${date(row.updated_at || row.created_at)}</small><div class="card-actions"><button class="button primary small" data-admin-order="${esc(row.id)}">${state.lang === 'fa' ? 'بازکردن رسید و بررسی' : 'Open receipt & review'}</button></div></article>`).join('') || empty()}</div>`, []);
} catch (err) { toast(err.message, 'error'); } finally { setBusy(false); } }

async function adminOrderDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/admin/orders/${encodeURIComponent(id)}`), receipt = x.receipt ? `<div class="receipt-preview"><img src="${esc(x.receipt.view_url)}" alt="Payment receipt" loading="lazy"></div>` : `<div class="notice warning">${state.lang === 'fa' ? 'رسیدی متصل نیست.' : 'No receipt attached.'}</div>`;
    openModal('VIP PAYMENT', `${x.plan_name || x.plan_id || x.id}`, `<div class="metric-grid">${metric(t('status'), esc(x.status), '', 'info')}${metric(state.lang === 'fa' ? 'کاربر' : 'User', esc(x.user_id), '', '')}${metric(t('payable'), money(x.amount_toman || 0, 'T'), '', 'warn')}${metric(t('paymentMethod'), esc(x.payment_method || '—'), '', '')}</div>${receipt}${x.transaction_hash ? `<div class="notice mono ltr">${esc(x.transaction_hash)}</div>` : ''}${x.rejection_reason ? `<div class="notice danger">${esc(x.rejection_reason)}</div>` : ''}<div class="notice ${x.receipt ? 'good' : 'danger'}"><strong>${x.receipt ? (state.lang === 'fa' ? 'رسید آماده بررسی است' : 'Receipt ready for review') : (state.lang === 'fa' ? 'رسیدی برای این سفارش ثبت نشده است' : 'No receipt is attached')}</strong>${x.receipt ? `<small>${date(x.receipt.created_at)} · ${num(x.receipt.size_bytes || 0,0)} bytes</small>` : ''}</div><div class="card-actions">${x.status === 'pending' && x.permissions?.approve ? `<button class="button primary" data-admin-order-approve="${esc(x.id)}">${state.lang === 'fa' ? 'تأیید دستی و ارسال لینک' : 'Manual approve & send link'}</button>` : ''}${x.status === 'pending' && x.permissions?.reject ? `<button class="button danger" data-admin-order-reject="${esc(x.id)}">${state.lang === 'fa' ? 'رد پرداخت' : 'Reject payment'}</button>` : ''}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function adminOrderRejectModal(id) { openModal('VIP PAYMENT', state.lang === 'fa' ? 'دلیل رد پرداخت' : 'Rejection reason', `<form id="adminRejectForm"><div class="field"><label for="adminRejectReason">${esc(t('reason'))}</label><textarea id="adminRejectReason" required minlength="3"></textarea></div></form>`, [{ label: state.lang === 'fa' ? 'رد پرداخت' : 'Reject', kind: 'danger', action: async () => { const f = $('#adminRejectForm'); if (!f.reportValidity())
            return; await action('payment_reject', { order_id: id, reason: $('#adminRejectReason').value }, false); invalidate('adminOrders', 'orders', 'overview'); closeModal(); await adminPaymentsModal(true); toast(t('success')); } }]); }
async function adminTicketDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/admin/tickets/${encodeURIComponent(id)}`), closed = x.status === 'closed', canReply = adminCan('tickets') || adminCan('tickets_reply'), canStatus = adminCan('tickets') || adminCan('tickets_status_manage');
    const replyForm = !closed && canReply ? `<form id="adminTicketReplyForm"><div class="field"><label for="adminTicketReply">${esc(t('message'))}</label><textarea id="adminTicketReply" required minlength="1" maxlength="4000"></textarea></div></form>` : '';
    const controls = `${!closed && canReply ? `<button class="button primary" data-admin-ticket-reply="${x.id}">${state.lang === 'fa' ? 'ارسال پاسخ' : 'Send reply'}</button>` : ''}${canStatus ? (!closed ? `<button class="button secondary" data-admin-ticket-status="${x.id}" data-status="pending">${state.lang === 'fa' ? 'در انتظار بررسی' : 'Mark pending'}</button><button class="button secondary" data-admin-ticket-status="${x.id}" data-status="answered">${state.lang === 'fa' ? 'پاسخ داده شد' : 'Mark answered'}</button><button class="button danger" data-admin-ticket-status="${x.id}" data-status="closed">${esc(t('close'))}</button>` : `<button class="button secondary" data-admin-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button>`) : ''}`;
    openModal('SUPPORT ADMIN', `#${x.id} · ${x.subject || 'Support'}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric('User', esc(x.user_id), '', 'info')}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'منتظر پاسخ' : 'Waiting for', esc(x.waiting_for || 'admin'), '', 'warn')}</div><div class="timeline">${(x.messages || []).map(m => `<div class="timeline-item ${m.sender === 'admin' ? 'admin-message' : 'user-message'}"><strong>${m.sender === 'admin' ? (state.lang === 'fa' ? 'ادمین SENTINEL' : 'SENTINEL Admin') : (state.lang === 'fa' ? 'کاربر' : 'User')}</strong><p>${esc(m.text)}</p><small>${date(m.created_at)}</small></div>`).join('') || empty()}</div>${replyForm}${controls ? `<div class="card-actions">${controls}</div>` : `<div class="notice info"><strong>${state.lang === 'fa' ? 'دسترسی فقط‌خواندنی' : 'Read-only access'}</strong></div>`}`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function uploadSignalTemplate(side) { const file = $(`#adminTemplate${side}`)?.files?.[0]; if (!file) {
    toast(state.lang === 'fa' ? 'ابتدا تصویر را انتخاب کنید.' : 'Choose an image first.', 'error');
    return;
} setBusy(true); try {
    const fd = new FormData();
    fd.append('file', file);
    await request(`./api/v1/admin/signal-templates/background?side=${encodeURIComponent(side)}`, { method: 'POST', csrf: true, body: fd }, 50000);
    invalidate('adminTemplates');
    closeModal();
    await adminWorkspace();
    toast(t('success'));
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function resetSignalTemplate(side) { setBusy(true); try {
    await request(`./api/v1/admin/signal-templates/background?side=${encodeURIComponent(side)}`, { method: 'DELETE', csrf: true }, 30000);
    invalidate('adminTemplates');
    closeModal();
    await adminWorkspace();
    toast(t('success'));
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function adminAuditModal() { setBusy(true); try {
    const d = await loadResource('adminAudit', true);
    openModal('AUDIT LOG', state.lang === 'fa' ? 'گزارش ممیزی قابل جست‌وجو' : 'Searchable audit log', `<div class="search-box">${icon('search')}<label class="sr-only" for="auditSearch">Search</label><input id="auditSearch" placeholder="action / admin / detail"></div><div id="auditRows" class="timeline" style="margin-top:12px">${(d.items || []).map(x => `<div class="timeline-item"><strong>${esc(x.action || 'event')}</strong><p>${esc(x.details || '')}</p><small>${esc(x.admin_id || '')} · ${date(x.created_at)}</small></div>`).join('') || empty()}</div>`, []);
    const input = $('#auditSearch');
    input?.addEventListener('input', () => { const q = input.value.trim().toLowerCase(); $$('.timeline-item', $('#auditRows')).forEach(row => row.hidden = q && !row.textContent.toLowerCase().includes(q)); });
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function handoffCreateModal() { openModal('SHIFT HANDOFF', t('newHandoff'), `<form id="handoffForm"><div class="field"><label for="handoffTo">${state.lang === 'fa' ? 'آیدی ادمین تحویل‌گیرنده' : 'Receiving admin ID'}</label><input id="handoffTo" inputmode="numeric" required></div><div class="field"><label for="handoffSummary">${state.lang === 'fa' ? 'خلاصه وضعیت' : 'Status summary'}</label><textarea id="handoffSummary" rows="4" required minlength="5"></textarea></div><div class="field"><label for="handoffPending">${state.lang === 'fa' ? 'موارد باز؛ هر خط یک مورد' : 'Pending items; one per line'}</label><textarea id="handoffPending" rows="4"></textarea></div><div class="field"><label for="handoffRisks">${state.lang === 'fa' ? 'ریسک‌ها؛ هر خط یک مورد' : 'Risks; one per line'}</label><textarea id="handoffRisks" rows="3"></textarea></div></form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#handoffForm'); if (!f.reportValidity())
            return; const list = id => $(id).value.split(/\n+/).map(x => x.trim()).filter(Boolean); setBusy(true); try {
            await action('shift_handoff_create', { to_admin_id: $('#handoffTo').value, summary: $('#handoffSummary').value, pending_items: list('#handoffPending'), risks: list('#handoffRisks') }, false);
            closeModal();
            invalidate('adminOps');
            toast(t('success'));
            await adminWorkspace();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function propTemplateCreateModal() { openModal('PROP RULE ENGINE', state.lang === 'fa' ? 'ساخت قالب قوانین پراپ' : 'Create prop rule template', `<form id="propTemplateForm"><div class="form-grid"><div class="field"><label for="propProvider">${state.lang === 'fa' ? 'شرکت پراپ' : 'Provider'}</label><input id="propProvider" required minlength="2" maxlength="80" placeholder="FTMO / FundedNext / Custom"></div><div class="field"><label for="propName">${esc(t('name'))}</label><input id="propName" required minlength="3" maxlength="120"></div><div class="field"><label for="propVersion">Version</label><input id="propVersion" type="number" min="1" value="1" required></div><div class="field"><label for="propTimezone">${esc(t('timezone'))}</label><input id="propTimezone" value="UTC" required></div><div class="field"><label for="propResetHour">${state.lang === 'fa' ? 'ساعت ریست روزانه' : 'Daily reset hour'}</label><input id="propResetHour" type="number" min="0" max="23" value="0" required></div><div class="field"><label for="propDailyLoss">${esc(t('dailyLoss'))} %</label><input id="propDailyLoss" inputmode="decimal" type="number" min="0.1" max="100" step="0.1" value="5" required></div><div class="field"><label for="propTotalLoss">${esc(t('totalLoss'))} %</label><input id="propTotalLoss" inputmode="decimal" type="number" min="0.1" max="100" step="0.1" value="10" required></div><div class="field"><label for="propDrawdownMode">${state.lang === 'fa' ? 'نوع افت سرمایه' : 'Drawdown mode'}</label><select id="propDrawdownMode"><option value="static">Static</option><option value="trailing">Trailing</option></select></div><div class="field"><label for="propDailyBasis">${state.lang === 'fa' ? 'مبنای ضرر روزانه' : 'Daily loss basis'}</label><select id="propDailyBasis"><option value="balance">Balance</option><option value="equity">Equity</option></select></div><div class="field"><label for="propOpenRisk">${esc(t('maxOpenRisk'))} %</label><input id="propOpenRisk" type="number" min="0.1" max="100" step="0.1" value="5" required></div><div class="field"><label for="propOpenTrades">${state.lang === 'fa' ? 'حداکثر معاملات باز' : 'Max open trades'}</label><input id="propOpenTrades" type="number" min="1" max="100" value="5" required></div><div class="field"><label for="propMinDays">${state.lang === 'fa' ? 'حداقل روز معاملاتی' : 'Minimum trading days'}</label><input id="propMinDays" type="number" min="0" max="365" value="0" required></div><div class="field"><label for="propNewsFreeze">${state.lang === 'fa' ? 'محدودیت خبر (دقیقه)' : 'News freeze (minutes)'}</label><input id="propNewsFreeze" type="number" min="0" max="240" value="0" required></div></div><label class="check-row"><input id="propFloating" type="checkbox" checked> <span>${state.lang === 'fa' ? 'زیان شناور در حد روزانه محاسبه شود' : 'Include floating loss in daily limit'}</span></label><label class="check-row"><input id="propWeekend" type="checkbox"> <span>${state.lang === 'fa' ? 'نگهداری آخر هفته مجاز باشد' : 'Allow weekend holding'}</span></label></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const f = $('#propTemplateForm'); if (!f.reportValidity())
            return; const rules = { daily_loss_percent: Number($('#propDailyLoss').value), total_loss_percent: Number($('#propTotalLoss').value), total_drawdown_mode: $('#propDrawdownMode').value, daily_loss_basis: $('#propDailyBasis').value, daily_reset_timezone: $('#propTimezone').value.trim(), daily_reset_hour: Number($('#propResetHour').value), include_floating_in_daily_loss: $('#propFloating').checked, max_open_risk_percent: Number($('#propOpenRisk').value), max_open_trades: Number($('#propOpenTrades').value), min_trading_days: Number($('#propMinDays').value), news_freeze_minutes: Number($('#propNewsFreeze').value), allow_weekend_holding: $('#propWeekend').checked }; setBusy(true); try {
            await action('prop_template_create', { provider: $('#propProvider').value.trim(), name: $('#propName').value.trim(), version: Number($('#propVersion').value), rules }, false);
            closeModal();
            invalidate('risk');
            toast(t('success'));
            await adminWorkspace();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function experimentCreateModal() { openModal('EXPERIMENT LAB', t('newExperiment'), `<form id="experimentForm"><div class="field"><label for="expName">${esc(t('name'))}</label><input id="expName" required minlength="3"></div><div class="field"><label for="expHypothesis">${esc(t('hypothesis'))}</label><textarea id="expHypothesis" rows="3" required minlength="5"></textarea></div><div class="form-grid"><div class="field"><label for="expMetric">${esc(t('primaryMetric'))}</label><select id="expMetric"><option value="purchase">Purchase</option><option value="checkout_started">Checkout started</option><option value="renewal">Renewal</option></select></div><div class="field"><label for="expSample">${esc(t('minimumSample'))}</label><input id="expSample" inputmode="numeric" value="100" min="10"></div><div class="field"><label for="expHoldout">Holdout %</label><input id="expHoldout" inputmode="decimal" value="10" min="0" max="50"></div><div class="field"><label for="expStop">Stop-loss %</label><input id="expStop" inputmode="decimal" value="25" min="0" max="100"></div></div><div class="field"><label for="expControl">Control label</label><input id="expControl" value="Control" required></div><div class="field"><label for="expVariant">Variant label</label><input id="expVariant" value="Variant A" required></div></form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#experimentForm'); if (!f.reportValidity())
            return; setBusy(true); try {
            await action('experiment_create', { name: $('#expName').value, hypothesis: $('#expHypothesis').value, primary_metric: $('#expMetric').value, min_sample_per_variant: Number($('#expSample').value), holdout_percent: Number($('#expHoldout').value), stop_loss_percent: Number($('#expStop').value), variants: [{ key: 'control', label: $('#expControl').value, weight: 1, is_control: true }, { key: 'variant_a', label: $('#expVariant').value, weight: 1, is_control: false }] }, false);
            closeModal();
            invalidate('adminExperiments');
            toast(t('success'));
            await adminWorkspace();
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function syncActiveView() { if (document.hidden || state.preview) return; if (state.page === 'home') { await Promise.all([loadOverview(true), refreshFeed(true)]); renderChrome(); renderHome(); return; } if (['signals', 'risk', 'journal'].includes(state.page)) await Promise.all([loadOverview(true), loadResource(state.page, true)]); else await loadOverview(true); if(state.page==='rewards' || !$('#modalLayer')?.hidden && ['REWARDS','REFERRAL','MISSIONS'].includes($('#modalEyebrow')?.textContent)) await loadResource('hub',true); renderChrome(); if (state.page === 'signals') await renderSignals(); else if (state.page === 'risk') await renderRisk(); else if (state.page === 'journal') await renderJournal(); else await navigate(state.page, false); }
function connectEvents() { if (state.preview || !window.EventSource)
    return; clearTimeout(state.eventReconnectTimer); state.eventSource?.close(); const suffix = state.lastEventId ? `?last_id=${state.lastEventId}` : '', es = new EventSource(`./api/v1/events${suffix}`, { withCredentials: true }); state.eventSource = es; const accept = async (event, keys, refresh) => { const id = Number(event.lastEventId || 0), resync = event.type === 'stream.resync_required'; if (!resync && id && id <= state.lastEventId)
    return; if (id && id > state.lastEventId) {
    state.lastEventId = id;
    sessionStorage.setItem('sentinelLastEventId', String(id));
} invalidate(...keys); try {
    if (refresh === 'feed') {
        await refreshFeed(true);
        await loadOverview(true);
        renderChrome();
        if (state.page === 'home')
            renderHome();
        return;
    }
    if (resync) {
        await Promise.all([loadOverview(true), refreshFeed(false)]);
        renderChrome();
        if (state.page !== 'home')
            await loadResource(state.page, true);
        await navigate(state.page, false);
        return;
    }
    if (state.page === 'home') {
        await loadOverview(true);
        renderChrome();
        renderHome();
        return;
    }
    if (refresh === 'signals' && state.page === 'signals') {
        await loadResource('signals', true);
        await renderSignals();
    }
    else if (refresh === 'risk' && state.page === 'risk') {
        await loadResource('risk', true);
        await renderRisk();
    }
    else if (refresh === 'journal' && state.page === 'journal') {
        await loadResource('journal', true);
        await renderJournal();
    }
    else if (refresh === 'rewards') {
        await loadResource('hub',true);
        if(state.page==='rewards')await renderRewardsWorkspace();
    }
    else if (refresh === 'orders') {
        if (state.page === 'more' && state.resources.orders) await loadResource('orders', true);
        const paymentReviewOpen = !$('#modalLayer')?.hidden && $('#modalEyebrow')?.textContent === 'PAYMENT REVIEW';
        if (paymentReviewOpen) await adminPaymentsModal(true);
    }
    else if (refresh === 'tickets' && state.page === 'more' && state.resources.tickets) {
        await loadResource('tickets', true);
    }
}
catch { } }; const bind = (names, keys, refresh) => names.forEach(name => es.addEventListener(name, event => accept(event, keys, refresh))); bind(['signal.created', 'channel.announcement', 'channel.news', 'channel.publication'], ['feed', 'signals', 'overview', 'adminSignalJobs'], 'feed'); bind(['signal.updated', 'signal.revised', 'signal.closed', 'signal.choice_updated', 'signal.lifecycle_updated', 'signal.result_updated', 'signal.result_reset', 'signal.partial_closed', 'signal.metrics_updated', 'signal.edited'], ['signals', 'revisions', 'overview', 'adminSignals'], 'signals'); bind(['signal.deleted'], ['signals', 'revisions', 'overview', 'adminSignals'], 'signals'); bind(['admin.user_updated'], ['adminUsers', 'overview'], 'home'); bind(['admin.access_updated'], ['adminAdmins', 'adminCapabilities', 'overview'], 'home'); bind(['admin.control_updated', 'admin.governance_updated'], ['adminPlatform', 'adminCapabilities', 'overview'], 'home'); bind(['signal.cycle_changed'], ['adminSignalCycles', 'signals', 'overview', 'adminSignalJobs'], 'signals'); bind(['position.opened', 'position.closed', 'position.risk_changed', 'position.voided', 'account.updated', 'account.archived'], ['risk', 'overview', 'expansion'], 'risk'); bind(['journal.updated'], ['journal', 'overview', 'expansion'], 'journal'); bind(['order.status_changed', 'miniapp.vip_order_submit', 'miniapp.vip_order_cancel', 'miniapp.vip_order_resubmit'], ['orders', 'adminOrders', 'overview'], 'orders'); bind(['ticket.message_added', 'ticket.status_changed', 'miniapp.ticket_create', 'miniapp.ticket_reply', 'miniapp.ticket_status_update'], ['tickets', 'adminTickets', 'overview'], 'tickets'); bind(['rewards.updated','missions.updated','referral.updated','miniapp.reward_claim'], ['hub','overview'], 'rewards'); bind(['preferences.updated'], ['overview'], 'home'); bind(['stream.resync_required'], ['overview', 'signals', 'risk', 'journal', 'orders', 'tickets', 'revisions', 'feed', 'expansion', 'adminSignals', 'adminUsers', 'adminAdmins', 'adminCapabilities'], 'home'); es.onopen = () => { state.eventFailureCount = 0; clearInterval(state.pollTimer); }; const reconnect = (renew = false) => {
    if (state.eventSource !== es) return;
    es.close(); state.eventSource = null;
    state.eventFailureCount = renew ? Math.max(2, state.eventFailureCount + 1) : state.eventFailureCount + 1;
    startPolling(); clearTimeout(state.eventReconnectTimer);
    const delay = Math.min(30000, 2000 * 2 ** Math.min(4, state.eventFailureCount - 1));
    state.eventReconnectTimer = setTimeout(async () => {
        if (state.eventFailureCount >= 2) {
            try { await renewAuthenticatedSession(); state.eventFailureCount = 0; }
            catch { /* Existing polling and bounded reconnect delay retain recovery. */ }
        }
        connectEvents();
    }, delay);
};
es.addEventListener('stream.auth_required', () => reconnect(true));
es.addEventListener('stream.rotate', () => {
    if (state.eventSource !== es) return;
    es.close(); state.eventSource = null;
    clearTimeout(state.eventReconnectTimer);
    state.eventReconnectTimer = setTimeout(connectEvents, 250);
});
es.onerror = () => reconnect(); }

function startPolling() { clearInterval(state.pollTimer); const tick = async () => { if (document.hidden || state.preview) return; try { await syncActiveView(); } catch { } }; tick(); state.pollTimer = setInterval(tick, 8000); }
function startLivePricePolling() { clearInterval(state.livePriceTimer); const tick = async () => { if (document.hidden || state.preview || !state.online || state.busy)
    return; try {
    await refreshVisibleHub();
    if (state.page === 'signals' && $('#page-signals')?.classList.contains('active')) {
        const data = await loadResource('signals', true);
        refreshSignalCardsDom(data);
    }
    if ($('[data-market-refresh]')) {
        const data = await loadResource('market', true);
        refreshMarketDom(data);
    }
    if ($('#adminSignalForm'))
        await refreshAdminSignalQuote(true);
}
catch { } }; state.livePriceTimer = setInterval(tick, 15000); setTimeout(tick, 5000); }
// Legacy contract marker: LIVE MODULE REGISTRY (replaced by the localized dynamic operations center).

// Legacy source-contract marker retained for release tests: x.status==='pending'?`<button
function adminFieldMarkup(field, index) {
    const name = String(field?.name || `field_${index}`), id = `adminAction_${index}_${name.replace(/[^a-z0-9_]/gi, '_')}`, label = state.lang === 'fa' ? (field?.label_fa || field?.label_en || name) : (field?.label_en || field?.label_fa || name), required = field?.required ? 'required' : '', placeholder = esc(state.lang === 'fa' ? (field?.placeholder || '') : (field?.placeholder_en || field?.placeholder || '')), value = field?.default;
    const helpText = state.lang === 'fa' ? field?.help_fa : (field?.help_en || field?.help_fa);
    const help = helpText ? `<small class="field-help">${esc(helpText)}</small>` : '';
    if (field?.type === 'checkbox')
        return `<label class="check-row"><input id="${id}" data-admin-field="${esc(name)}" data-kind="checkbox" type="checkbox" ${value ? 'checked' : ''}> <span>${esc(label)}</span></label>${help}`;
    if (field?.type === 'select')
        return `<div class="field"><label for="${id}">${esc(label)}</label><select id="${id}" data-admin-field="${esc(name)}" data-kind="select" ${required}>${(field.options || []).map(x => `<option value="${esc(x.value)}" ${String(value ?? '') === String(x.value) ? 'selected' : ''}>${esc(state.lang === 'fa' ? (x.label_fa || x.label) : (x.label_en || x.label))}</option>`).join('')}</select>${help}</div>`;
    if (field?.type === 'textarea' || field?.type === 'json')
        return `<div class="field field-span"><label for="${id}">${esc(label)}</label><textarea id="${id}" data-admin-field="${esc(name)}" data-kind="${esc(field.type)}" rows="${field.type === 'json' ? 7 : 4}" placeholder="${placeholder}" ${required}>${esc(field.type === 'json' ? JSON.stringify(value ?? {}, null, 2) : (value ?? ''))}</textarea>${help}</div>`;
    const type = field?.type === 'password' ? 'password' : field?.type === 'number' ? 'number' : field?.type === 'datetime' ? 'datetime-local' : 'text';
    return `<div class="field"><label for="${id}">${esc(label)}</label><input id="${id}" data-admin-field="${esc(name)}" data-kind="${esc(field?.type || 'text')}" type="${type}" value="${esc(value ?? '')}" placeholder="${placeholder}" ${required}>${help}</div>`;
}
function collectAdminActionPayload(form) { const payload = {}; $$('[data-admin-field]', form).forEach(el => { const name = el.dataset.adminField, kind = el.dataset.kind || 'text'; let value = kind === 'checkbox' ? el.checked : el.value; if (kind === 'number' && value !== '')
    value = Number(value); if (kind === 'csv')
    value = String(value).split(/[,،\n]+/).map(x => x.trim()).filter(Boolean); if (kind === 'json') {
    try {
        value = JSON.parse(String(value || '{}'));
    }
    catch {
        throw new Error(state.lang === 'fa' ? `JSON فیلد «${name}» معتبر نیست.` : `Invalid JSON in ${name}`);
    }
} if (value !== '' && value !== undefined)
    payload[name] = value; }); return payload; }
function adminResultMarkup(result) { const data = result?.result ?? result; return `<div class="notice success"><strong>${state.lang === 'fa' ? 'عملیات با موفقیت انجام شد' : 'Operation completed'}</strong></div><pre class="code-block" dir="ltr">${esc(JSON.stringify(data ?? {}, null, 2))}</pre>`; }
function nativeAdminAction(row) { const name = row.action; if (name === 'miniapp_signal_publish') {
    closeModal();
    adminSignalComposer();
    return true;
} if (name === 'ticket_admin_reply' || name === 'ticket_admin_status_update') {
    closeModal();
    adminTicketCenter();
    return true;
} if (name === 'miniapp_announcement_publish') {
    closeModal();
    announcementPublishModal?.();
    return true;
} if (name === 'experiment_create') {
    closeModal();
    experimentCreateModal();
    return true;
} if (name === 'prop_template_create') {
    closeModal();
    propTemplateCreateModal();
    return true;
} return false; }
function openAdminCapability(row) {
    if (!row)
        return;
    if (row.ui_mode === 'native' && nativeAdminAction(row))
        return;
    const fields = Array.isArray(row.fields) ? row.fields : [];
    const rawFallback = !fields.length && row.ui_mode !== 'inspect' && row.ui_mode !== 'confirm';
    const rowLabel = state.lang === 'fa' ? (row.label_fa || row.action) : (row.label_en || row.label_fa || row.action), rowDescription = state.lang === 'fa' ? (row.description_fa || '') : (row.description_en || row.description_fa || '');
    const body = `<div class="notice info"><strong>${esc(rowLabel)}</strong><p>${esc(rowDescription)}</p><small>${state.lang === 'fa' ? 'دسترسی موردنیاز' : 'Required permission'}: ${esc(state.lang === 'fa' ? (row.permission_label || row.permission || 'مدیر') : (row.permission_label_en || row.permission_label || row.permission || 'Administrator'))}</small></div><form id="adminGenericActionForm"><div class="form-grid">${fields.map(adminFieldMarkup).join('')}${rawFallback ? adminFieldMarkup({ name: '__raw_payload', label_fa: 'داده ورودی JSON', label_en: 'JSON payload', type: 'json', default: {} }, 999) : ''}</div></form><div id="adminActionResult"></div>`;
    const run = async () => { const form = $('#adminGenericActionForm'); if (!form?.reportValidity())
        return; let payload = {}; try {
        payload = collectAdminActionPayload(form);
        if (payload.__raw_payload && typeof payload.__raw_payload === 'object')
            payload = payload.__raw_payload;
    }
    catch (err) {
        toast(localizedError(err), 'error');
        return;
    } const confirmation = state.lang === 'fa' ? row.confirmation_fa : (row.confirmation_en || row.confirmation_fa); if (confirmation && !confirm(confirmation))
        return; setBusy(true); try {
        const result = await action(row.action, payload, false);
        $('#adminActionResult').innerHTML = adminResultMarkup(result);
        (row.refresh || []).forEach(k => invalidate(k));
        toast(state.lang === 'fa' ? 'عملیات با موفقیت انجام شد.' : 'Operation completed');
    }
    catch (err) {
        $('#adminActionResult').innerHTML = `<div class="notice danger"><strong>${state.lang === 'fa' ? 'عملیات ناموفق بود' : 'Operation failed'}</strong><p>${esc(localizedError(err))}</p></div>`;
        toast(localizedError(err), 'error');
    }
    finally {
        setBusy(false);
    } };
    const actions = row.ui_mode === 'inspect' || row.ui_mode === 'confirm' ? [{ label: row.ui_mode === 'inspect' ? (state.lang === 'fa' ? 'دریافت اطلاعات' : 'Load') : (state.lang === 'fa' ? 'اجرا' : 'Run'), kind: 'primary', action: run }] : [{ label: state.lang === 'fa' ? 'ثبت و اجرا' : 'Submit', kind: 'primary', action: run }];
    openModal('ADMIN COMMAND', rowLabel, body, actions);
}
async function adminCommandCenter() { setBusy(true); try {
    const d = await loadResource('adminCapabilities', true), rows = d?.actions || [];
    const groupKey = x => state.lang === 'fa' ? (x.group || x.permission_label || 'سایر') : (x.group_en || x.group || x.permission_label_en || x.permission_label || 'Other');
    const groups = [...new Set(rows.map(groupKey))];
    openModal('SENTINEL ADMIN', state.lang === 'fa' ? 'مرکز کامل عملیات ادمین' : 'Full admin command center', `<div class="notice info"><strong>${num(rows.length, 0)} ${state.lang === 'fa' ? 'عملیات واقعی و مجاز' : 'authorized executable actions'}</strong><p>${state.lang === 'fa' ? 'هر گزینه مستقیماً از رجیستری مشترک ربات و مینی‌اپ اجرا می‌شود.' : 'Every option executes through the shared bot/Mini App registry.'}</p></div><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجوی عملیات' : 'Search actions'}</label><input data-admin-action-search placeholder="${state.lang === 'fa' ? 'نام ماژول یا عملیات...' : 'Module or action...'}"></div><div id="adminActionGroups">${groups.map(group => `<section class="panel compact-panel" data-admin-action-group><div class="panel-head"><h3>${esc(group)}</h3><span class="status-badge info">${rows.filter(x => groupKey(x) === group).length}</span></div><div class="panel-body permission-grid">${rows.filter(x => groupKey(x) === group).map(x => { const label = state.lang === 'fa' ? (x.label_fa || x.action) : (x.label_en || x.label_fa || x.action), description = state.lang === 'fa' ? (x.description_fa || x.action) : (x.description_en || x.description_fa || x.action); return `<button class="permission-chip enabled admin-action-button" data-admin-capability="${esc(x.action)}" data-search="${esc(`${x.label_fa || ''} ${x.label_en || ''} ${x.description_fa || ''} ${x.description_en || ''} ${x.action} ${group}`.toLowerCase())}"><strong>${esc(label)}</strong><small>${esc(description)}</small></button>`; }).join('')}</div></section>`).join('')}</div>`, []);
    state.adminCapabilities = Object.fromEntries(rows.map(x => [x.action, x]));
}
catch (err) {
    openModal('ADMIN ERROR', state.lang === 'fa' ? 'بارگذاری پنل ادمین ناموفق بود' : 'Admin panel failed', `<div class="notice danger"><strong>${esc(localizedError(err))}</strong><p>${state.lang === 'fa' ? 'اتصال، دسترسی یا وضعیت سرور را بررسی کنید.' : 'Check connectivity, permission, and server health.'}</p></div>`, [{ label: t('retry'), kind: 'primary', action: adminCommandCenter }]);
}
finally {
    setBusy(false);
} }
document.addEventListener('click', event => { const center = event.target.closest('[data-admin-command-center]'); if (center) {
    event.preventDefault();
    event.stopImmediatePropagation();
    adminCommandCenter();
    return;
} const button = event.target.closest('[data-admin-capability]'); if (button) {
    event.preventDefault();
    event.stopImmediatePropagation();
    const row = state.adminCapabilities?.[button.dataset.adminCapability] || (state.resources.adminCapabilities?.actions || []).find(x => x.action === button.dataset.adminCapability);
    openAdminCapability(row);
    return;
} }, true);
document.addEventListener('input', event => { if (!event.target.matches('[data-admin-action-search]'))
    return; const q = event.target.value.trim().toLowerCase(); $$('[data-admin-action-group]').forEach(group => { let visible = 0; $$('[data-admin-capability]', group).forEach(button => { const show = !q || (button.dataset.search || '').includes(q); button.hidden = !show; if (show)
    visible++; }); group.hidden = !visible; }); }, true);
document.addEventListener('click', event => { const periods = event.target.closest('[data-admin-signal-cycles]'); if (periods) {
    event.preventDefault();
    event.stopImmediatePropagation();
    adminSignalCyclesModal();
    return;
} const name = event.target.closest('[data-signal-cycle-name]'); if (name) {
    event.preventDefault();
    event.stopImmediatePropagation();
    signalCycleNameModal(name.dataset.signalCycleName || 'rollover');
    return;
} const close = event.target.closest('[data-signal-cycle-close]'); if (close) {
    event.preventDefault();
    event.stopImmediatePropagation();
    closeSignalCycleFromMiniApp();
    return;
} const detail = event.target.closest('[data-signal-cycle-detail]'); if (detail) {
    event.preventDefault();
    event.stopImmediatePropagation();
    adminSignalCycleDetail(detail.dataset.signalCycleDetail);
    return;
} const pdf = event.target.closest('[data-signal-cycle-pdf]'); if (pdf) {
    event.preventDefault();
    event.stopImmediatePropagation();
    downloadSignalCyclePdf(pdf.dataset.signalCyclePdf);
    return;
} const rename = event.target.closest('[data-signal-cycle-rename]'); if (rename) {
    event.preventDefault();
    event.stopImmediatePropagation();
    signalCycleNameModal('rename', rename.dataset.signalCycleRename);
    return;
} }, true);


function adminPermissionSet() {
    const admin = state.resources.overview?.admin || {};
    return { owner: String(admin.role || '').toLowerCase() === 'owner', values: new Set(admin.permissions || []) };
}
function adminCan(permission) { const p = adminPermissionSet(); return p.owner || p.values.has(permission); }
function adminUserCard(row) {
    const name = [row.first_name, row.last_name].filter(Boolean).join(' ') || row.username || row.user_id;
    return `<article class="journal-card" data-admin-user-row="${esc(row.user_id)}"><div class="row-between"><div><strong>${esc(name)}</strong><p><code>${esc(row.user_id)}</code>${row.username ? ` · @${esc(row.username)}` : ''}</p></div><span class="status-badge ${row.banned ? 'bad' : row.vip_active ? 'good' : 'info'}">${row.banned ? (state.lang === 'fa' ? 'مسدود' : 'BANNED') : row.vip_active ? 'VIP' : (state.lang === 'fa' ? 'فعال' : 'ACTIVE')}</span></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'امتیاز' : 'Points', num(row.points || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'آخرین حضور' : 'Last seen', row.last_seen_at ? date(row.last_seen_at) : '—', '', '')}</div><div class="card-actions"><button class="button primary small" data-admin-user-detail="${esc(row.user_id)}">${state.lang === 'fa' ? 'کنترل کاربر' : 'Manage user'}</button></div></article>`;
}
async function adminUsersCenter() {
    setBusy(true);
    try {
        const data = await loadResource('adminUsers', true), rows = data?.items || [];
        openModal('USER CONTROL', state.lang === 'fa' ? 'مدیریت و کنترل کاربران' : 'User management', `<div class="notice info"><strong>${num(data?.total || rows.length, 0)} ${state.lang === 'fa' ? 'کاربر ثبت‌شده' : 'registered users'}</strong><p>${state.lang === 'fa' ? 'وضعیت کاربر، VIP و مسدودی از دیتابیس مشترک ربات و مینی‌اپ خوانده می‌شود.' : 'User, VIP and ban state comes from the shared bot/Mini App database.'}</p></div><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجو' : 'Search'}</label><input data-admin-user-search placeholder="ID / @username / name"></div><div id="adminUsersList" class="journal-list">${rows.map(adminUserCard).join('') || empty()}</div>`, []);
        const input = $('[data-admin-user-search]');
        input?.addEventListener('input', () => { const q = String(input.value || '').trim().toLowerCase(); $$('#adminUsersList [data-admin-user-row]').forEach(card => { card.hidden = Boolean(q) && !card.textContent.toLowerCase().includes(q); }); });
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
async function adminUserDetail(userId) {
    setBusy(true);
    try {
        const row = await request(`./api/v1/admin/users/${encodeURIComponent(userId)}`), name = [row.first_name, row.last_name].filter(Boolean).join(' ') || row.username || row.user_id;
        const body = `<div class="notice ${row.banned ? 'danger' : 'success'}"><strong>${esc(name)}</strong><p><code>${esc(row.user_id)}</code>${row.username ? ` · @${esc(row.username)}` : ''}</p></div><div class="metric-grid">${metric('VIP', row.vip_active ? 'ACTIVE' : '—', row.vip_expires_at ? date(row.vip_expires_at) : '', row.vip_active ? 'good' : '')}${metric(state.lang === 'fa' ? 'امتیاز' : 'Points', num(row.points || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'وضعیت' : 'Status', row.banned ? (state.lang === 'fa' ? 'مسدود' : 'Banned') : (state.lang === 'fa' ? 'فعال' : 'Active'), row.ban?.reason || '', row.banned ? 'warn' : 'good')}</div>`;
        const canBan = adminCan('users') || adminCan('user_ban_manage');
        const actions = !canBan ? [] : row.banned ? [{ label: state.lang === 'fa' ? 'رفع مسدودی' : 'Unban', kind: 'primary', action: async () => { await action('admin_user_unban', { user_id: row.user_id }, false); invalidate('adminUsers', 'overview'); closeModal(); toast(t('success')); adminUsersCenter(); } }] : [{ label: state.lang === 'fa' ? 'مسدودسازی' : 'Ban user', kind: 'danger', action: () => adminUserBanModal(row) }];
        openModal('USER CONTROL', name, body, actions);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
function adminUserBanModal(row) {
    openModal('USER CONTROL', state.lang === 'fa' ? 'مسدودسازی کاربر' : 'Ban user', `<form id="adminUserBanForm"><div class="field"><label>${state.lang === 'fa' ? 'مدت به روز؛ خالی = دائم' : 'Days; blank = permanent'}</label><input id="adminBanDays" inputmode="numeric" type="number" min="1"></div><div class="field field-span"><label>${t('reason')}</label><textarea id="adminBanReason" rows="3" required></textarea></div></form>`, [{ label: state.lang === 'fa' ? 'تأیید مسدودی' : 'Confirm ban', kind: 'danger', action: async () => { const form = $('#adminUserBanForm'); if (!form?.reportValidity()) return; await action('admin_user_ban', { user_id: row.user_id, days: $('#adminBanDays').value || undefined, reason: $('#adminBanReason').value }, false); invalidate('adminUsers', 'overview'); closeModal(); toast(t('success')); adminUsersCenter(); } }]);
}
function adminAccessCard(row) {
    return `<article class="journal-card"><div class="row-between"><div><strong>${esc(row.first_name || row.username || row.user_id)}</strong><p><code>${esc(row.user_id)}</code>${row.username ? ` · @${esc(row.username)}` : ''}</p></div><span class="status-badge ${row.active !== false ? 'good' : 'bad'}">${row.active !== false ? 'ACTIVE' : 'OFF'}</span></div>${row.role_preset_label ? `<p><span class="status-badge warn">${esc(row.role_preset_label)}</span></p>` : ''}<p>${(row.permissions || []).map(x => `<span class="status-badge info">${esc(x)}</span>`).join(' ') || '—'}</p><div class="card-actions"><button class="button primary small" data-admin-access-edit="${esc(row.user_id)}">${state.lang === 'fa' ? 'ویرایش دسترسی' : 'Edit access'}</button><button class="button danger small" data-admin-access-remove="${esc(row.user_id)}">${state.lang === 'fa' ? 'حذف ادمین' : 'Remove admin'}</button></div></article>`;
}
async function adminAdminsCenter() {
    setBusy(true);
    try {
        const data = await loadResource('adminAdmins', true), rows = data?.items || [];
        openModal('ADMIN ACCESS', state.lang === 'fa' ? 'افزودن و مدیریت ادمین‌ها' : 'Add and manage administrators', `<div class="notice info"><strong>${num(rows.length, 0)} ${state.lang === 'fa' ? 'ادمین واگذارشده' : 'delegated admins'}</strong><p>${state.lang === 'fa' ? 'مجوزهای این صفحه همان مجوزهای ربات تلگرام است.' : 'These are the exact same permissions used by the Telegram bot.'}</p></div><div class="card-actions"><button class="button primary" data-admin-access-new>${icon('plus')}${state.lang === 'fa' ? 'افزودن ادمین' : 'Add admin'}</button></div><div class="journal-list">${rows.map(adminAccessCard).join('') || empty()}</div>`, []);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
function adminAccessModal(row = null) {
    const data = state.resources.adminAdmins || {}, current = new Set(row?.permissions || []), permissions = data.permissions || [], presets = data.role_presets || [];
    const presetOptions = presets.map(p => `<option value="${esc(p.key)}">${esc(state.lang === 'fa' ? p.label : p.key)}</option>`).join('');
    const presetBox = presets.length ? `<div class="field-span notice info"><strong>${state.lang === 'fa' ? 'نقش آماده با حداقل دسترسی' : 'Least-privilege role preset'}</strong><p>${state.lang === 'fa' ? 'نقش را انتخاب و روی «اعمال در فرم» بزنید؛ سپس می‌توانید مجوزها را دستی اصلاح کنید.' : 'Choose a role, apply it to the form, then adjust individual permissions.'}</p><div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'نقش آماده' : 'Role preset'}</label><select id="adminRolePreset">${presetOptions}</select></div><div class="field"><label>&nbsp;</label><button type="button" class="button secondary" data-admin-role-preview>${state.lang === 'fa' ? 'اعمال در فرم' : 'Apply to form'}</button></div></div><small id="adminRoleDescription"></small></div>` : '';
    openModal('ADMIN ACCESS', row ? (state.lang === 'fa' ? 'ویرایش مجوزهای ادمین' : 'Edit admin permissions') : (state.lang === 'fa' ? 'افزودن ادمین جدید' : 'Add administrator'), `<form id="adminAccessForm"><div class="field"><label>${state.lang === 'fa' ? 'آیدی عددی تلگرام' : 'Telegram numeric ID'}</label><input id="adminAccessUserId" inputmode="numeric" value="${esc(row?.user_id || '')}" ${row ? 'readonly' : ''} required></div>${presetBox}<div class="field-span permission-grid">${permissions.map(p => `<label class="check-row ${p.owner_only ? 'permission-owner-only' : ''}"><input type="checkbox" data-admin-permission="${esc(p.value)}" ${current.has(p.value) ? 'checked' : ''} ${p.owner_only ? 'disabled' : ''}> <span>${esc(state.lang === 'fa' ? p.label : p.value)}${p.owner_only ? ` · ${state.lang === 'fa' ? 'فقط مالک اصلی' : 'owner only'}` : ''}</span></label>`).join('')}</div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const form = $('#adminAccessForm'); if (!form?.reportValidity()) return; const values = $$('[data-admin-permission]:checked:not(:disabled)', form).map(x => x.dataset.adminPermission); if (!values.length) { toast(state.lang === 'fa' ? 'حداقل یک مجوز انتخاب کنید.' : 'Select at least one permission.', 'error'); return; } const presetKey = $('#adminRolePreset')?.value || ''; const preset = presets.find(item => item.key === presetKey); const selected = new Set(values), presetValues = new Set(preset?.permissions || []), exactPreset = Boolean(preset && selected.size === presetValues.size && [...selected].every(value => presetValues.has(value))); if (exactPreset) await action('delegated_admin_role_preset', { user_id: $('#adminAccessUserId').value, preset: presetKey }, false); else await action(row ? 'delegated_admin_permissions_set' : 'delegated_admin_upsert', { user_id: $('#adminAccessUserId').value, permissions: values }, false); invalidate('adminAdmins', 'adminCapabilities', 'overview'); closeModal(); toast(t('success')); adminAdminsCenter(); } }]);
}

function adminSignalCard(row) {
    return `<article class="journal-card"><div class="row-between"><div><strong>#${num(row.display_number || row.id, 0)} · ${esc(row.symbol || '—')}</strong><p>${esc(row.side)} · ${esc(row.entry || (row.entries || []).join(' - '))}</p></div><span class="status-badge ${row.status === 'open' ? 'good' : row.status === 'stop' ? 'bad' : 'info'}">${esc(row.status)}</span></div><p>TP: ${esc((row.targets || []).join(' · ') || '—')} · SL: ${esc(row.stop || '—')}</p><div class="card-actions"><button class="button primary small" data-admin-signal-detail="${esc(row.id)}">${state.lang === 'fa' ? 'ویرایش و نتیجه' : 'Edit & result'}</button></div></article>`;
}
async function adminSignalsCenter() {
    setBusy(true);
    try {
        const data = await loadResource('adminSignals', true), rows = data?.items || [];
        openModal('SIGNAL MANAGEMENT', state.lang === 'fa' ? 'مدیریت سیگنال‌های منتشرشده' : 'Published signal management', `<div class="notice info"><strong>${num(data?.total || rows.length, 0)} ${state.lang === 'fa' ? 'سیگنال' : 'signals'}</strong><p>${state.lang === 'fa' ? 'ویرایش و نتیجه فوراً در ربات، کانال و مینی‌اپ همگام می‌شود.' : 'Edits and results are immediately synchronized with the bot, channels and Mini App.'}</p></div><div class="journal-list">${rows.map(adminSignalCard).join('') || empty()}</div>`, []);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
async function adminSignalDetail(signalId) {
    setBusy(true);
    try {
        const row = await request(`./api/v1/admin/signals/${encodeURIComponent(signalId)}`), canEdit = adminCan('signal_edit'), canResult = adminCan('signal_status_manage') || adminCan('signal_results'), canDelete = adminCan('signal_delete');
        const body = `<div class="notice info"><strong>#${num(row.display_number || row.id, 0)} · ${esc(row.symbol || '—')} · ${esc(row.side)}</strong><p>${state.lang === 'fa' ? 'ورود' : 'Entry'}: ${esc(row.entry || (row.entries || []).join(' - '))} · SL: ${esc(row.stop || '—')}</p><p>TP: ${esc((row.targets || []).join(' · ') || '—')}</p></div><div class="metric-grid">${metric(t('status'), esc(row.status), row.result_at ? date(row.result_at) : '', row.status === 'open' ? 'good' : 'info')}${metric(t('riskPercent'), esc(row.risk || '—'), '', '')}</div>`;
        const actions = [];
        if (canEdit && row.can_edit) actions.push({ label: state.lang === 'fa' ? 'ویرایش سیگنال' : 'Edit signal', kind: 'primary', action: () => adminSignalEditModal(row) });
        if (canResult) actions.push({ label: row.status === 'open' ? (state.lang === 'fa' ? 'ثبت نتیجه' : 'Set result') : (state.lang === 'fa' ? 'بازکردن نتیجه' : 'Reset result'), kind: 'secondary', action: () => row.status === 'open' ? adminSignalResultModal(row) : adminSignalResetResult(row) });
        if (canDelete) actions.push({ label: state.lang === 'fa' ? 'حذف کامل' : 'Delete', kind: 'danger', action: async () => { if (!confirm(state.lang === 'fa' ? 'این سیگنال برای همیشه حذف شود؟' : 'Permanently delete this signal?')) return; await action('signal_delete', { signal_id: row.id }, false); invalidate('adminSignals', 'signals', 'overview'); closeModal(); toast(t('success')); adminSignalsCenter(); } });
        openModal('SIGNAL MANAGEMENT', `${row.symbol || ''} #${row.display_number || row.id}`, body, actions);
    } catch (err) { toast(localizedError(err), 'error'); } finally { setBusy(false); }
}
function adminSignalEditModal(row) {
    const targetOptions = (row.targets || []).map((_, index) => `<option value="target_${index + 1}">TP${index + 1}</option>`).join('');
    openModal('SIGNAL MANAGEMENT', state.lang === 'fa' ? 'ویرایش سیگنال' : 'Edit signal', `<form id="adminSignalEditForm"><div class="field"><label>${state.lang === 'fa' ? 'فیلد' : 'Field'}</label><select id="adminSignalEditField"><option value="entry">Entry</option><option value="stop">Stop</option>${targetOptions}<option value="add_target">${state.lang === 'fa' ? 'افزودن تارگت' : 'Add target'}</option><option value="note">${state.lang === 'fa' ? 'یادداشت بروزرسانی' : 'Update note'}</option></select></div><div class="field"><label>${state.lang === 'fa' ? 'مقدار جدید' : 'New value'}</label><input id="adminSignalEditValue" required></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const form = $('#adminSignalEditForm'); if (!form?.reportValidity()) return; await action('signal_edit', { signal_id: row.id, field: $('#adminSignalEditField').value, value: $('#adminSignalEditValue').value }, false); invalidate('adminSignals', 'signals', 'revisions', 'overview'); closeModal(); toast(t('success')); adminSignalDetail(row.id); } }]);
}
function adminSignalResultModal(row) {
    const options = [['target','تارگت'],['tp1','TP1'],['tp2','TP2'],['tp3','TP3'],['tp4','TP4'],['tp5','TP5'],['breakeven','ریسک‌فری'],['partial_close','بستن بخشی'],['manual_close','بستن دستی'],['no_entry','ورود نداده'],['stop','استاپ'],['cancelled','کنسل‌شده']];
    openModal('SIGNAL RESULT', state.lang === 'fa' ? 'ثبت نتیجه سیگنال' : 'Set signal result', `<form id="adminSignalResultForm"><div class="field"><label>${t('status')}</label><select id="adminSignalResult">${options.map(([value,label]) => `<option value="${value}">${state.lang === 'fa' ? label : value.replaceAll('_',' ')}</option>`).join('')}</select></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { await action('signal_result_set', { signal_id: row.id, result: $('#adminSignalResult').value }, false); invalidate('adminSignals', 'signals', 'overview', 'track'); closeModal(); toast(t('success')); adminSignalDetail(row.id); } }]);
}
async function adminSignalResetResult(row) {
    if (!confirm(state.lang === 'fa' ? 'نتیجه قبلی پاک و سیگنال دوباره باز شود؟' : 'Clear the result and reopen this signal?')) return;
    await action('signal_result_reset', { signal_id: row.id }, false); invalidate('adminSignals', 'signals', 'overview', 'track'); closeModal(); toast(t('success')); adminSignalDetail(row.id);
}

document.addEventListener('click', async event => {
    const el = event.target.closest('[data-admin-users],[data-admin-user-detail],[data-admin-admins],[data-admin-access-new],[data-admin-access-edit],[data-admin-access-remove],[data-admin-role-preview],[data-admin-signals],[data-admin-signal-detail]');
    if (!el) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (el.dataset.adminUsers !== undefined) return adminUsersCenter();
    if (el.dataset.adminUserDetail) return adminUserDetail(el.dataset.adminUserDetail);
    if (el.dataset.adminAdmins !== undefined) return adminAdminsCenter();
    if (el.dataset.adminAccessNew !== undefined) return adminAccessModal();
    if (el.dataset.adminAccessEdit) { const row = (state.resources.adminAdmins?.items || []).find(x => String(x.user_id) === String(el.dataset.adminAccessEdit)); return adminAccessModal(row); }
    if (el.dataset.adminAccessRemove) { if (!confirm(state.lang === 'fa' ? 'این ادمین حذف شود؟' : 'Remove this administrator?')) return; await action('delegated_admin_remove', { user_id: el.dataset.adminAccessRemove }, false); invalidate('adminAdmins', 'adminCapabilities', 'overview'); toast(t('success')); return adminAdminsCenter(); }
    if (el.dataset.adminRolePreview !== undefined) { const key = $('#adminRolePreset')?.value || ''; const preset = (state.resources.adminAdmins?.role_presets || []).find(x => x.key === key); if (!preset) return; const allowed = new Set(preset.permissions || []); $$('[data-admin-permission]').forEach(box => { if (!box.disabled) box.checked = allowed.has(box.dataset.adminPermission); }); const desc = $('#adminRoleDescription'); if (desc) desc.textContent = preset.description || ''; toast(state.lang === 'fa' ? 'نقش در فرم اعمال شد؛ برای ثبت، ذخیره را بزنید.' : 'Role applied to the form; press Save to persist.'); return; }
    if (el.dataset.adminSignals !== undefined) return adminSignalsCenter();
    if (el.dataset.adminSignalDetail) return adminSignalDetail(el.dataset.adminSignalDetail);
}, true);

function moduleControlValue(field) {
    if (field.kind === 'bool') return field.value ? (state.lang === 'fa' ? 'روشن' : 'On') : (state.lang === 'fa' ? 'خاموش' : 'Off');
    return String(field.value ?? '—');
}
function moduleControlTone(field) { return field.capability_status === 'planned' ? 'warn' : field.kind === 'bool' ? (field.value ? 'good' : 'bad') : 'info'; }
function moduleControlCard(row) {
    return `<article class="journal-card" data-module-search="${esc(`${row.label} ${row.key} ${row.category} ${row.description}`.toLowerCase())}"><div class="row-between"><div><strong>${esc(row.label)}</strong><p>${esc(row.description || row.key)}</p></div><span class="status-badge ${row.enabled ? 'good' : 'bad'}">${row.enabled ? (state.lang === 'fa' ? 'فعال' : 'ON') : (state.lang === 'fa' ? 'خاموش' : 'OFF')}</span></div><small>${esc(row.category)} · ${num(row.connected_fields || 0, 0)}/${num((row.fields || []).length, 0)} ${state.lang === 'fa' ? 'تنظیم عملیاتی' : 'operational controls'}</small><div class="card-actions"><button class="button primary small" data-admin-module="${esc(row.key)}">${state.lang === 'fa' ? 'کنترل ماژول' : 'Control module'}</button></div></article>`;
}
function governanceCard(row) {
    const approvals = Array.isArray(row.approvals) ? row.approvals.length : 0;
    return `<article class="journal-card"><div class="row-between"><strong>#${esc(row.id)} · ${esc(row.title || row.action)}</strong><span class="status-badge ${row.status === 'approved' ? 'good' : row.status === 'failed' ? 'bad' : 'warn'}">${esc(row.status)}</span></div><p>${esc(row.action)} · ${esc(row.risk_level)} · ${approvals}/${num(row.required_approvals || 0, 0)}</p><div class="card-actions">${['pending','pending_second_approval'].includes(row.status) ? `<button class="button success small" data-governance-approve="${esc(row.id)}">${state.lang === 'fa' ? 'تأیید' : 'Approve'}</button><button class="button danger small" data-governance-reject="${esc(row.id)}">${state.lang === 'fa' ? 'رد' : 'Reject'}</button>` : ''}${row.status === 'approved' ? `<button class="button primary small" data-governance-apply="${esc(row.id)}">${state.lang === 'fa' ? 'اجرا' : 'Apply'}</button>` : ''}${row.status === 'failed' ? `<button class="button secondary small" data-governance-retry="${esc(row.id)}">${state.lang === 'fa' ? 'تلاش مجدد' : 'Retry'}</button>` : ''}</div></article>`;
}
async function adminModuleControlCenter() {
    setBusy(true);
    try {
        const d = await loadResource('adminPlatform', true), modules = d?.control_modules || [], governance = d?.governance?.pending || [], summary = d?.control_summary || {};
        state.adminControlModules = Object.fromEntries(modules.map(x => [x.key, x]));
        openModal('PLATFORM CONTROL', state.lang === 'fa' ? 'کنترل کامل ماژول‌های ربات و مینی‌اپ' : 'Full bot and Mini App module control', `<div class="notice info"><strong>${num(summary.modules || modules.length, 0)} ${state.lang === 'fa' ? 'ماژول مشترک' : 'shared modules'}</strong><p>${state.lang === 'fa' ? 'هر تغییر روی همان دیتابیس و رجیستری ربات تلگرام اعمال می‌شود. تغییرات حساس ابتدا وارد صف تأیید می‌شوند.' : 'Every change uses the same Telegram bot database and registry. Sensitive changes enter approval first.'}</p></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'فعال' : 'Enabled', num(summary.enabled_modules || 0, 0), '', 'good')}${metric(state.lang === 'fa' ? 'خاموش' : 'Disabled', num(summary.disabled_modules || 0, 0), '', 'warn')}${metric(state.lang === 'fa' ? 'کنترل‌ها' : 'Controls', num(summary.boolean_controls || 0, 0), '', 'info')}${metric(state.lang === 'fa' ? 'در انتظار تأیید' : 'Pending review', num(governance.length, 0), '', governance.length ? 'warn' : 'good')}</div><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجوی ماژول' : 'Search modules'}</label><input data-module-control-search placeholder="${state.lang === 'fa' ? 'بازار، سیگنال، کاربران، امنیت...' : 'Markets, signals, users, security...'}"></div><div class="card-actions"><button class="button secondary" data-control-preset="safe">${state.lang === 'fa' ? 'درخواست حالت ایمن' : 'Request safe preset'}</button><button class="button secondary" data-control-preset="default">${state.lang === 'fa' ? 'درخواست پیش‌فرض' : 'Request defaults'}</button><button class="button secondary" data-control-preset="full">${state.lang === 'fa' ? 'درخواست کامل' : 'Request full preset'}</button></div><div id="moduleControlList" class="journal-list">${modules.map(moduleControlCard).join('') || empty()}</div>${governance.length ? `<details class="details-block" open><summary>${state.lang === 'fa' ? 'صف تغییرات حساس' : 'Sensitive change queue'}</summary><div class="journal-list">${governance.map(governanceCard).join('')}</div></details>` : ''}`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}
function adminModuleDetail(moduleKey) {
    const row = state.adminControlModules?.[moduleKey]; if (!row) return;
    const fields = row.fields || [];
    openModal('MODULE CONTROL', `${row.label} · ${row.key}`, `<div class="notice info"><strong>${esc(row.label)}</strong><p>${esc(row.description || '')}</p></div><div class="journal-list">${fields.map(field => `<article class="journal-card"><div class="row-between"><div><strong>${esc(field.label)}</strong><p><code>${esc(field.key)}</code>${field.help_text ? ` · ${esc(field.help_text)}` : ''}</p></div><span class="status-badge ${moduleControlTone(field)}">${esc(moduleControlValue(field))}</span></div><small>${esc(field.capability_status)}${field.free_mode_locked ? ` · ${state.lang === 'fa' ? 'قفل حالت رایگان' : 'free-mode locked'}` : ''}</small><div class="card-actions">${field.editable ? field.kind === 'bool' ? `<button class="button ${field.value ? 'danger' : 'success'} small" data-control-toggle="${esc(row.key)}:${esc(field.key)}" data-control-value="${field.value ? 'false' : 'true'}">${field.value ? (state.lang === 'fa' ? 'خاموش‌کردن' : 'Turn off') : (state.lang === 'fa' ? 'روشن‌کردن' : 'Turn on')}</button>` : `<button class="button secondary small" data-control-edit="${esc(row.key)}:${esc(field.key)}">${state.lang === 'fa' ? 'تغییر مقدار' : 'Edit value'}</button>` : `<span class="status-badge warn">${state.lang === 'fa' ? 'غیرقابل تغییر' : 'Read only'}</span>`}</div></article>`).join('')}</div>`, [{ label: state.lang === 'fa' ? 'بازنشانی ماژول' : 'Reset module', kind: 'danger', action: async () => { if (!confirm(state.lang === 'fa' ? 'تنظیمات این ماژول بازنشانی شود؟' : 'Reset this module?')) return; const result = await action('control_reset', { module: row.key }, false); invalidate('adminPlatform','overview'); closeModal(); toast(result?.result?.status === 'review_required' ? (state.lang === 'fa' ? 'درخواست تأیید ساخته شد.' : 'Approval request created.') : t('success')); adminModuleControlCenter(); } }]);
}
function adminModuleEdit(moduleKey, fieldKey) {
    const module = state.adminControlModules?.[moduleKey], field = (module?.fields || []).find(x => x.key === fieldKey); if (!field) return;
    const choices = Array.isArray(field.choices) ? field.choices : [];
    const control = field.kind === 'choice' ? `<select id="moduleControlInput">${choices.map(x => `<option value="${esc(x)}" ${String(x) === String(field.value) ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>` : `<input id="moduleControlInput" type="${['int','float'].includes(field.kind) ? 'number' : 'text'}" value="${esc(field.value ?? '')}" ${field.minimum != null ? `min="${esc(field.minimum)}"` : ''} ${field.maximum != null ? `max="${esc(field.maximum)}"` : ''} required>`;
    openModal('MODULE SETTING', field.label, `<form id="moduleControlEditForm"><div class="field"><label>${esc(field.label)}</label>${control}<small class="field-help">${esc(field.help_text || `${moduleKey}.${fieldKey}`)}</small></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const form = $('#moduleControlEditForm'); if (!form?.reportValidity()) return; let value = $('#moduleControlInput').value; if (field.kind === 'int') value = Number.parseInt(value, 10); if (field.kind === 'float') value = Number(value); const result = await action('control_change', { module: moduleKey, field: fieldKey, value }, false); invalidate('adminPlatform','overview'); closeModal(); toast(result?.result?.status === 'review_required' ? (state.lang === 'fa' ? 'درخواست تأیید ساخته شد.' : 'Approval request created.') : t('success')); adminModuleControlCenter(); } }]);
}

document.addEventListener('input', event => {
    const input = event.target.closest('[data-module-control-search]'); if (!input) return;
    const needle = String(input.value || '').trim().toLowerCase(); $$('[data-module-search]').forEach(card => card.hidden = needle && !String(card.dataset.moduleSearch || '').includes(needle));
});
document.addEventListener('click', async event => {
    const el = event.target.closest('[data-admin-module],[data-control-toggle],[data-control-edit],[data-control-preset],[data-governance-approve],[data-governance-reject],[data-governance-apply],[data-governance-retry]'); if (!el) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (el.dataset.adminModule) return adminModuleDetail(el.dataset.adminModule);
    if (el.dataset.controlToggle) { const [module, field] = el.dataset.controlToggle.split(':'); const value = el.dataset.controlValue === 'true'; const result = await action('control_change', { module, field, value }, false); invalidate('adminPlatform','overview'); closeModal(); toast(result?.result?.status === 'review_required' ? (state.lang === 'fa' ? 'درخواست تأیید ساخته شد.' : 'Approval request created.') : t('success')); return adminModuleControlCenter(); }
    if (el.dataset.controlEdit) { const [module, field] = el.dataset.controlEdit.split(':'); return adminModuleEdit(module, field); }
    if (el.dataset.controlPreset) { if (!confirm(state.lang === 'fa' ? 'درخواست تغییر سراسری ثبت شود؟' : 'Submit global preset request?')) return; await action('control_preset', { preset: el.dataset.controlPreset }, false); invalidate('adminPlatform'); toast(state.lang === 'fa' ? 'درخواست حاکمیت ساخته شد.' : 'Governance request created.'); return adminModuleControlCenter(); }
    if (el.dataset.governanceApprove) { await action('governance_request_approve', { request_id: el.dataset.governanceApprove }, false); invalidate('adminPlatform'); toast(t('success')); return adminModuleControlCenter(); }
    if (el.dataset.governanceReject) { const reason = prompt(state.lang === 'fa' ? 'دلیل رد:' : 'Rejection reason:') || ''; await action('governance_request_reject', { request_id: el.dataset.governanceReject, reason }, false); invalidate('adminPlatform'); toast(t('success')); return adminModuleControlCenter(); }
    if (el.dataset.governanceApply) { await action('governance_request_apply', { request_id: el.dataset.governanceApply }, false); invalidate('adminPlatform','overview'); toast(t('success')); return adminModuleControlCenter(); }
    if (el.dataset.governanceRetry) { await action('governance_request_retry', { request_id: el.dataset.governanceRetry }, false); invalidate('adminPlatform'); toast(t('success')); return adminModuleControlCenter(); }
}, true);


function aiAnswerMarkup(row) {
    const findings = Array.isArray(row?.findings) ? row.findings : [];
    const execution = row?.execution || {}, executed = execution?.executions || [], queued = execution?.queued || [], rejected = execution?.rejected || [];
    const executionMarkup = (executed.length || queued.length || rejected.length) ? `<div class="notice ${executed.some(x => x.status === 'failed') ? 'warning' : 'success'}"><strong>${state.lang === 'fa' ? 'نتیجه اجرای ابزارها' : 'Tool execution result'}</strong><p>${state.lang === 'fa' ? 'اجراشده' : 'Executed'}: ${num(executed.filter(x => x.status === 'executed').length,0)} · ${state.lang === 'fa' ? 'ناموفق' : 'Failed'}: ${num(executed.filter(x => x.status === 'failed').length,0)} · ${state.lang === 'fa' ? 'در انتظار' : 'Queued'}: ${num(queued.length,0)}</p></div>` : '';
    return `<article class="journal-card"><div class="row-between"><strong>${esc(row?.scope || (state.lang === 'fa' ? 'دستیار شخصی' : 'Personal assistant'))}</strong><span class="status-badge info">${esc(row?.engine || row?.model || 'SENTINEL AI')}</span></div><p class="field-help">${date(row?.created_at || new Date().toISOString())}</p><div class="notice info"><strong>${state.lang === 'fa' ? 'پرسش' : 'Question'}</strong><p>${esc(row?.question || '')}</p></div><div class="ai-answer"><p>${esc(row?.answer || '').replaceAll('\n', '<br>')}</p></div>${executionMarkup}${findings.length ? `<div class="journal-list">${findings.map(x => `<div class="notice"><p>${esc(typeof x === 'string' ? x : JSON.stringify(x))}</p></div>`).join('')}</div>` : ''}</article>`;
}

async function userAiCenter(latest = null) {
    setBusy(true);
    try {
        const d = await loadResource('ai', true), status = d?.status || {}, access = d?.access || {}, rows = d?.items || [];
        const allowed = access.allowed !== false, mode = access.mode || status?.user_access?.user_access_mode || 'vip_only';
        const current = latest ? `<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'نتیجه بررسی جدید' : 'New review result'}</h3></div><div class="panel-body">${aiAnswerMarkup({...latest, question: state.lang === 'fa' ? 'بررسی هوشمند حساب و رفتار' : 'Account and behavior review', created_at: new Date().toISOString()})}</div></section>` : '';
        const accessText = mode === 'all' ? (state.lang === 'fa' ? 'برای همه کاربران فعال' : 'Available to all users') : (state.lang === 'fa' ? 'فقط کاربران VIP' : 'VIP users only');
        openModal('SENTINEL AI REVIEW', state.lang === 'fa' ? 'بررسی هوشمند حساب' : 'Smart account review', `<div class="notice ${allowed ? (status.enabled ? 'success' : 'warning') : 'danger'}"><strong>${allowed ? (status.enabled ? (state.lang === 'fa' ? 'Gemini آماده بررسی است' : 'Gemini is ready') : (state.lang === 'fa' ? 'موتور جایگزین Sentinel فعال است' : 'Sentinel fallback is active')) : (state.lang === 'fa' ? 'دسترسی این حساب فعال نیست' : 'This account is not eligible')}</strong><p>${state.lang === 'fa' ? 'کاربر گفت‌وگوی مستقیم با AI ندارد. با زدن دکمه، فقط حساب‌های MT5، ژورنال، نگهبان پراپ، مربی ریسک و رفتار معاملاتی خودش بررسی می‌شود.' : 'There is no direct AI chat. The button reviews only the user’s own MT5, journal, prop-guardian, risk-coach and trading behavior data.'}</p><small>${esc(accessText)}</small></div><div class="card-actions"><button class="button primary wide" data-user-ai-review ${allowed ? '' : 'disabled'}>${state.lang === 'fa' ? '🧠 بررسی هوشمند' : '🧠 Run smart review'}</button></div>${current}<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'بررسی‌های قبلی' : 'Previous reviews'}</h3></div><div class="panel-body journal-list">${rows.map(aiAnswerMarkup).join('') || empty()}</div></section>`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}

async function _adminAiCenterLegacy(latest = null) {
    setBusy(true);
    try {
        const d = await loadResource('adminAI', true), status = d?.status || {}, usage = d?.usage || {}, access = d?.access || {}, scopes = (d?.scopes || []).filter(x => x.enabled), rows = d?.items || [], proposals = (d?.proposals || []).filter(x => x.status === 'pending');
        const commands = d?.pending_commands || [], pendingAdmins = d?.pending_admins || [], execution = d?.execution_settings || {}, isPrimary = d?.is_primary_admin === true;
        const proposalMarkup = proposals.map(p => `<article class="journal-card"><div class="row-between"><strong>#${num(p.id,0)} · ${esc(p.title || p.type)}</strong><span class="status-badge warn">${esc(p.type)}</span></div><p>${esc(p.reason || '')}</p><pre class="code-block" dir="ltr">${esc(JSON.stringify(p.payload || {}, null, 2))}</pre><div class="card-actions">${d.can_confirm_standard ? `<button class="button primary small" data-ai-proposal-approve="${esc(p.id)}">${state.lang === 'fa' ? 'تأیید انسانی' : 'Human approve'}</button><button class="button danger small" data-ai-proposal-reject="${esc(p.id)}">${state.lang === 'fa' ? 'رد پیشنهاد' : 'Reject'}</button>` : ''}</div></article>`).join('');
        const commandMarkup = commands.map(c => `<article class="journal-card"><div class="row-between"><strong>#${num(c.id,0)} · ${esc(c.action || '')}</strong><span class="status-badge warn">${state.lang === 'fa' ? 'منتظر ادمین اصلی' : 'Awaiting primary'}</span></div><p>${esc(c.reason || c.question || '')}</p><small>${state.lang === 'fa' ? 'درخواست‌کننده' : 'Requested by'}: ${esc(c.requested_by || '')}</small><pre class="code-block" dir="ltr">${esc(JSON.stringify(c.payload || {}, null, 2))}</pre>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-ai-command-approve="${esc(c.id)}">${state.lang === 'fa' ? 'تأیید و اجرا' : 'Approve & execute'}</button><button class="button danger small" data-ai-command-reject="${esc(c.id)}">${state.lang === 'fa' ? 'رد دستور' : 'Reject command'}</button></div>` : ''}</article>`).join('');
        const adminMarkup = pendingAdmins.map(a => `<article class="journal-card"><div class="row-between"><strong>${esc(a.user_id || '')}</strong><span class="status-badge warn">${state.lang === 'fa' ? 'ادمین در انتظار تأیید' : 'Pending admin'}</span></div><p>${esc((a.permissions || []).join(' · '))}</p>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-delegated-admin-approve="${esc(a.user_id)}">${state.lang === 'fa' ? 'تأیید ادمین' : 'Approve admin'}</button><button class="button danger small" data-delegated-admin-reject="${esc(a.user_id)}">${state.lang === 'fa' ? 'رد درخواست' : 'Reject request'}</button></div>` : ''}</article>`).join('');
        const latestMarkup = latest ? `<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'پاسخ جدید' : 'New answer'}</h3></div><div class="panel-body">${aiAnswerMarkup({...latest, created_at: new Date().toISOString()})}</div></section>` : '';
        const mode = access.user_access_mode || 'vip_only', healthTone = status.authenticated && status.model_available ? 'success' : status.configured ? 'warning' : 'danger';
        const daily = usage.today || {}, monthly = usage.month || {}, remaining = usage.remaining || {};
        const directMode = isPrimary && execution.autonomous_primary_admin && execution.execution_enabled;
        const executionText = directMode ? (state.lang === 'fa' ? 'دستورات ادمین اصلی بدون تأیید اضافه اجرا می‌شوند.' : 'Primary-admin commands execute without extra confirmation.') : isPrimary ? (state.lang === 'fa' ? 'اجرای ابزارها با کلید اضطراری متوقف شده است.' : 'Tool execution is stopped by the emergency switch.') : (state.lang === 'fa' ? 'دستورات شما برای تأیید ادمین اصلی ارسال می‌شوند.' : 'Your commands are sent to the primary admin for approval.');
        openModal('AI COMMAND CENTER', state.lang === 'fa' ? 'مرکز فرماندهی هوش مصنوعی' : 'AI Command Center', `<div class="notice ${healthTone}"><strong>${status.authenticated && status.model_available ? (state.lang === 'fa' ? 'Gemini فعال و احراز هویت شده' : 'Gemini authenticated and ready') : status.configured ? (state.lang === 'fa' ? 'کلید تنظیم شده؛ تست زنده لازم است' : 'Key configured; live test required') : (state.lang === 'fa' ? 'Gemini تنظیم نشده است' : 'Gemini is not configured')}</strong><p>${executionText}</p><small>${state.lang === 'fa' ? 'ادمین اصلی' : 'Primary admin'}: ${esc(d.primary_admin_id || '—')} · ${state.lang === 'fa' ? 'آخرین تست' : 'Last check'}: ${esc(status.last_checked_at || '—')} · ${num(status.latency_ms || 0,0)} ms · ${esc(status.last_error || 'OK')}</small></div><div class="metric-grid">${metric(state.lang === 'fa' ? 'درخواست امروز' : 'Requests today', num(daily.requests || 0,0),'','info')}${metric(state.lang === 'fa' ? 'توکن امروز' : 'Tokens today', num(daily.total_tokens || 0,0),'','info')}${metric(state.lang === 'fa' ? 'توکن ماه' : 'Monthly tokens', num(monthly.total_tokens || 0,0),'','warn')}${metric(state.lang === 'fa' ? 'دستور منتظر' : 'Pending commands', num(commands.length,0),'','warn')}</div><div class="card-actions"><button class="button secondary" data-admin-ai-health-test>${state.lang === 'fa' ? 'تست زنده Gemini' : 'Live Gemini test'}</button><button class="button secondary" data-admin-ai-daily-report>${state.lang === 'fa' ? 'گزارش روزانه مدیر' : 'Daily manager report'}</button>${d.can_confirm_standard ? `<button class="button ${mode === 'all' ? 'success' : 'warning'}" data-admin-ai-access-toggle>${mode === 'all' ? (state.lang === 'fa' ? 'AI کاربران: همه' : 'User AI: everyone') : (state.lang === 'fa' ? 'AI کاربران: فقط VIP' : 'User AI: VIP only')}</button>` : ''}${isPrimary ? `<button class="button ${execution.execution_enabled ? 'danger' : 'success'}" data-admin-ai-execution-toggle data-enabled="${execution.execution_enabled ? 'false' : 'true'}">${execution.execution_enabled ? (state.lang === 'fa' ? '⛔ توقف اجرای AI' : '⛔ Stop AI execution') : (state.lang === 'fa' ? '✅ فعال‌کردن اجرای AI' : '✅ Enable AI execution')}</button>` : ''}</div><form id="adminAiForm"><div class="form-grid"><div class="field"><label for="adminAiScope">${state.lang === 'fa' ? 'حوزه تحلیل و کنترل' : 'Analysis and control scope'}</label><select id="adminAiScope">${scopes.map(x => `<option value="${esc(x.key)}">${esc(state.lang === 'fa' ? x.label_fa : x.key)}</option>`).join('')}</select></div><div class="field"><label for="adminAiTargetUser">${state.lang === 'fa' ? 'آیدی کاربر هدف (اختیاری)' : 'Target user ID (optional)'}</label><input id="adminAiTargetUser" inputmode="numeric" placeholder="123456789"></div><div class="field field-span"><label for="adminAiQuestion">${state.lang === 'fa' ? 'دستور یا سؤال مدیریتی' : 'Administrative instruction or question'}</label><textarea id="adminAiQuestion" required minlength="2" maxlength="4000" rows="5" placeholder="${state.lang === 'fa' ? 'مثلاً آخرین عکس را قالب BUY کن و یک پیش‌نمایش بساز.' : 'Use the latest image as the BUY template and create a preview.'}"></textarea></div></div></form><div class="card-actions"><button class="button primary" data-admin-ai-send>${state.lang === 'fa' ? (directMode ? 'اجرا با Gemini' : 'ارسال دستور') : (directMode ? 'Execute with Gemini' : 'Send command')}</button></div>${latestMarkup}<section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'دستورهای ادمین‌های دیگر' : 'Delegated-admin commands'}</h3><span class="status-badge warn">${num(commands.length,0)}</span></div><div class="panel-body journal-list">${commandMarkup || empty()}</div></section><section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'ادمین‌های در انتظار تأیید' : 'Admins pending approval'}</h3><span class="status-badge warn">${num(pendingAdmins.length,0)}</span></div><div class="panel-body journal-list">${adminMarkup || empty()}</div></section><section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'پیشنهادهای قدیمی در انتظار تأیید' : 'Legacy proposals pending approval'}</h3><span class="status-badge warn">${num(proposals.length,0)}</span></div><div class="panel-body journal-list">${proposalMarkup || empty()}</div></section><section class="panel compact-panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'تاریخچه فرمان‌ها' : 'Command history'}</h3></div><div class="panel-body journal-list">${rows.map(aiAnswerMarkup).join('') || empty()}</div></section>`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}


async function adminAiCenter(latest = null) {
    setBusy(true);
    try {
        const d = await loadResource('adminAI', true);
        const status = d?.status || {}, usage = d?.usage || {}, access = d?.access || {};
        const scopes = (d?.scopes || []).filter(item => item.enabled);
        const history = d?.items || [], proposals = (d?.proposals || []).filter(item => item.status === 'pending');
        const commands = d?.pending_commands || [], pendingAdmins = d?.pending_admins || [];
        const execution = d?.execution_settings || {}, isPrimary = d?.is_primary_admin === true;
        const fa = state.lang === 'fa', mode = access.user_access_mode || 'vip_only';
        const healthTone = status.authenticated && status.model_available ? 'success' : status.configured ? 'warning' : 'danger';
        const directMode = isPrimary && execution.autonomous_primary_admin && execution.execution_enabled;
        const daily = usage.today || {}, monthly = usage.month || {};
        const latestMarkup = latest ? `<section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'پاسخ جدید Gemini' : 'New Gemini answer'}</h3></div><div class="panel-body">${aiAnswerMarkup({...latest, created_at:new Date().toISOString()})}</div></section>` : '';
        const commandMarkup = commands.map(item => `<article class="journal-card"><div class="row-between"><strong>#${num(item.id,0)} · ${esc(item.action || '')}</strong><span class="status-badge warn">${fa ? 'منتظر تأیید انسانی' : 'Awaiting human approval'}</span></div><p>${esc(item.reason || item.question || '')}</p><pre class="code-block" dir="ltr">${esc(JSON.stringify(item.payload || {}, null, 2))}</pre>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-ai-command-approve="${esc(item.id)}">${fa ? 'تأیید و اجرا' : 'Approve & execute'}</button><button class="button danger small" data-ai-command-reject="${esc(item.id)}">${fa ? 'رد دستور' : 'Reject'}</button></div>` : ''}</article>`).join('');
        const proposalMarkup = proposals.map(item => `<article class="journal-card"><div class="row-between"><strong>#${num(item.id,0)} · ${esc(item.title || item.type)}</strong><span class="status-badge warn">${esc(item.type || '')}</span></div><p>${esc(item.reason || '')}</p><pre class="code-block" dir="ltr">${esc(JSON.stringify(item.payload || {}, null, 2))}</pre>${d.can_confirm_standard ? `<div class="card-actions"><button class="button primary small" data-ai-proposal-approve="${esc(item.id)}">${fa ? 'تأیید انسانی' : 'Human approve'}</button><button class="button danger small" data-ai-proposal-reject="${esc(item.id)}">${fa ? 'رد' : 'Reject'}</button></div>` : ''}</article>`).join('');
        const adminMarkup = pendingAdmins.map(item => `<article class="journal-card"><div class="row-between"><strong>${esc(item.user_id || '')}</strong><span class="status-badge warn">${fa ? 'ادمین منتظر تأیید' : 'Pending admin'}</span></div><p>${esc((item.permissions || []).join(' · '))}</p>${isPrimary ? `<div class="card-actions"><button class="button primary small" data-delegated-admin-approve="${esc(item.user_id)}">${fa ? 'تأیید ادمین' : 'Approve admin'}</button><button class="button danger small" data-delegated-admin-reject="${esc(item.user_id)}">${fa ? 'رد درخواست' : 'Reject'}</button></div>` : ''}</article>`).join('');
        const executionText = directMode
            ? (fa ? 'فرمان‌های مجاز ادمین اصلی مستقیم اجرا می‌شوند؛ کد تخفیف و دسترسی ادمین همیشه تأیید انسانی می‌خواهند.' : 'Allowed primary-admin commands execute directly; discounts and admin access always require human approval.')
            : isPrimary
                ? (fa ? 'اجرای خودکار متوقف است؛ فرمان‌ها برای تأیید انسانی در صف می‌مانند.' : 'Automatic execution is stopped; commands stay queued for human approval.')
                : (fa ? 'فرمان‌های شما پس از کنترل مجوز برای تأیید ادمین اصلی ارسال می‌شوند.' : 'Your permission-checked commands are sent to the primary admin for approval.');
        const html = `
          <div class="notice ${healthTone}">
            <strong>${status.authenticated && status.model_available ? (fa ? 'Gemini آماده گفت‌وگو و فرمان است' : 'Gemini is ready for chat and commands') : status.configured ? (fa ? 'کلید تنظیم شده؛ تست زنده لازم است' : 'Key configured; live test required') : (fa ? 'Gemini تنظیم نشده است' : 'Gemini is not configured')}</strong>
            <p>${executionText}</p>
            <small>${fa ? 'مدل' : 'Model'}: ${esc(status.model || '—')} · ${fa ? 'آخرین بررسی' : 'Last check'}: ${esc(status.last_checked_at || '—')} · ${num(status.latency_ms || 0,0)} ms</small>
          </div>
          <div class="notice info">
            <strong>${fa ? 'فرمان مستقیم به کل بخش‌های عملیاتی مجاز' : 'Direct command access to allowed operations'}</strong>
            <p>${fa ? 'می‌توانید درباره کاربران، CRM، کمپین، کانال، تیکت، سیگنال، آموزش، مسابقه، ریسک و سلامت سیستم صحبت کنید. نمونه: «کمپین کاربران غیرفعال را بساز» یا «کد WELCOME15 با ۱۵٪ تخفیف و اعتبار ۷ روز بساز».' : 'Talk about users, CRM, campaigns, channels, tickets, signals, education, contests, risk and system health. Example: create a dormant-user campaign or a 15% seven-day WELCOME15 code.'}</p>
            <small>${fa ? 'پرداخت، رسید، TXID، بازپرداخت، تغییر VIP، Shell، SQL، Deploy و اسرار مسدود هستند.' : 'Payments, receipts, TXIDs, refunds, VIP changes, Shell, SQL, deploy and secrets are blocked.'}</small>
          </div>
          <div class="metric-grid">
            ${metric(fa ? 'درخواست امروز' : 'Requests today', num(daily.requests || 0,0),'','info')}
            ${metric(fa ? 'توکن امروز' : 'Tokens today', num(daily.total_tokens || 0,0),'','info')}
            ${metric(fa ? 'توکن ماه' : 'Monthly tokens', num(monthly.total_tokens || 0,0),'','warn')}
            ${metric(fa ? 'دستور منتظر' : 'Pending commands', num(commands.length,0),'','warn')}
          </div>
          <div class="card-actions">
            <button class="button secondary" data-admin-ai-health-test>${fa ? 'تست زنده Gemini' : 'Live Gemini test'}</button>
            <button class="button secondary" data-admin-ai-daily-report>${fa ? 'گزارش روزانه مدیر' : 'Daily manager report'}</button>
            ${d.can_confirm_standard ? `<button class="button ${mode === 'all' ? 'success' : 'warning'}" data-admin-ai-access-toggle>${mode === 'all' ? (fa ? 'AI کاربران: همه' : 'User AI: everyone') : (fa ? 'AI کاربران: فقط VIP' : 'User AI: VIP only')}</button>` : ''}
            ${isPrimary ? `<button class="button ${execution.execution_enabled ? 'danger' : 'success'}" data-admin-ai-execution-toggle data-enabled="${execution.execution_enabled ? 'false' : 'true'}">${execution.execution_enabled ? (fa ? '⛔ توقف اجرای AI' : '⛔ Stop AI execution') : (fa ? '✅ فعال‌کردن اجرای AI' : '✅ Enable AI execution')}</button>` : ''}
          </div>
          <form id="adminAiForm">
            <div class="form-grid">
              <div class="field"><label for="adminAiScope">${fa ? 'حوزه گفت‌وگو و کنترل' : 'Chat and control scope'}</label><select id="adminAiScope">${scopes.map(item => `<option value="${esc(item.key)}">${esc(fa ? item.label_fa : item.key)}</option>`).join('')}</select></div>
              <div class="field"><label for="adminAiTargetUser">${fa ? 'آیدی کاربر هدف (اختیاری)' : 'Target user ID (optional)'}</label><input id="adminAiTargetUser" inputmode="numeric" placeholder="123456789"></div>
              <div class="field field-span"><label for="adminAiQuestion">${fa ? 'با Gemini صحبت کنید یا فرمان بدهید' : 'Talk to Gemini or issue a command'}</label><textarea id="adminAiQuestion" required minlength="2" maxlength="4000" rows="8" placeholder="${fa ? 'مثال: یک کمپین برای کاربران غیرفعال بساز و سپس کد تخفیف عمومی WELCOME15 با ۱۵ درصد، ۷ روز اعتبار و یک‌بار مصرف برای هر کاربر آماده کن.' : 'Example: create a dormant-user campaign, then prepare public code WELCOME15 at 15% for seven days and one use per user.'}"></textarea></div>
            </div>
          </form>
          <div class="card-actions"><button class="button primary wide" data-admin-ai-send>${fa ? (directMode ? 'ارسال و اجرای امن با Gemini' : 'ارسال فرمان برای بررسی') : (directMode ? 'Send and safely execute' : 'Send command for review')}</button></div>
          ${latestMarkup}
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'دستورهای منتظر تأیید' : 'Commands awaiting approval'}</h3><span class="status-badge warn">${num(commands.length,0)}</span></div><div class="panel-body journal-list">${commandMarkup || empty()}</div></section>
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'درخواست ادمین جدید' : 'Pending admins'}</h3><span class="status-badge warn">${num(pendingAdmins.length,0)}</span></div><div class="panel-body journal-list">${adminMarkup || empty()}</div></section>
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'پیشنهادهای منتظر' : 'Pending proposals'}</h3><span class="status-badge warn">${num(proposals.length,0)}</span></div><div class="panel-body journal-list">${proposalMarkup || empty()}</div></section>
          <section class="panel compact-panel"><div class="panel-head"><h3>${fa ? 'تاریخچه گفت‌وگو و فرمان' : 'Chat and command history'}</h3></div><div class="panel-body journal-list">${history.map(aiAnswerMarkup).join('') || empty()}</div></section>`;
        openModal('GEMINI ADMIN CHAT', fa ? 'گفت‌وگو و فرمان به Gemini' : 'Chat and command Gemini', html, []);
    } catch (err) {
        toast(localizedError(err), 'error');
    } finally {
        setBusy(false);
    }
}

function vipPlanFormMarkup(plan = {}) {
    return `<form id="vipPlanForm"><div class="form-grid"><div class="field"><label for="vipPlanName">${state.lang === 'fa' ? 'نام پلن' : 'Plan name'}</label><input id="vipPlanName" required minlength="2" maxlength="80" value="${esc(plan.name || '')}"></div><div class="field"><label for="vipPlanPrice">${state.lang === 'fa' ? 'قیمت' : 'Price'}</label><input id="vipPlanPrice" type="number" min="0" max="10000000000" required value="${esc(plan.price ?? 0)}"></div><div class="field"><label for="vipPlanDays">${state.lang === 'fa' ? 'مدت (روز)' : 'Duration (days)'}</label><input id="vipPlanDays" type="number" min="1" max="3650" required value="${esc(plan.duration_days ?? 30)}"></div><div class="field"><label for="vipPlanOriginalPrice">${state.lang === 'fa' ? 'قیمت قبلی' : 'Original price'}</label><input id="vipPlanOriginalPrice" type="number" min="0" value="${esc(plan.original_price ?? 0)}"></div><div class="field"><label for="vipPlanAudience">${state.lang === 'fa' ? 'مخاطب' : 'Audience'}</label><select id="vipPlanAudience"><option value="all">all</option><option value="new">new</option><option value="renewal">renewal</option></select></div><div class="field"><label for="vipPlanSalesLimit">${state.lang === 'fa' ? 'سقف فروش (۰ نامحدود)' : 'Sales limit (0 unlimited)'}</label><input id="vipPlanSalesLimit" type="number" min="0" value="${esc(plan.sales_limit ?? 0)}"></div><div class="field field-span"><label for="vipPlanDescription">${state.lang === 'fa' ? 'توضیحات' : 'Description'}</label><textarea id="vipPlanDescription" maxlength="500" rows="3">${esc(plan.description || '')}</textarea></div><div class="field field-span"><label for="vipPlanFeatures">${state.lang === 'fa' ? 'امکانات؛ هر خط یک مورد' : 'Features; one per line'}</label><textarea id="vipPlanFeatures" rows="5">${esc((plan.features || []).join('\n'))}</textarea></div></div></form>`;
}

async function adminVipPlanCenter() {
    setBusy(true);
    try {
        const d = await loadResource('adminVipPlans', true), perms = d?.permissions || {}, rows = d?.items || [];
        openModal('VIP PLAN ADMIN', state.lang === 'fa' ? 'مدیریت پلن‌های VIP' : 'VIP plan management', `<div class="notice warning"><strong>${state.lang === 'fa' ? 'دسترسی Gemini ادمین اصلی فعال است' : 'Primary-admin Gemini access is enabled'}</strong><p>${state.lang === 'fa' ? 'ادمین اصلی می‌تواند همین عملیات ثبت‌شده را از مرکز فرماندهی Gemini نیز اجرا کند.' : 'The primary admin can also execute these registered actions from Gemini Command Center.'}</p></div><div class="card-actions">${perms.settings ? `<button class="button primary" data-vip-settings-edit>${state.lang === 'fa' ? 'شماره کارت، نام و قیمت پیش‌فرض' : 'Card, owner & defaults'}</button>` : ''}${perms.create ? `<button class="button primary" data-vip-plan-create>${state.lang === 'fa' ? 'ساخت پلن جدید' : 'Create new plan'}</button>` : ''}</div><div class="journal-list">${rows.map(p => `<article class="journal-card"><div class="row-between"><div><strong>#${num(p.id,0)} · ${esc(p.name || '')}</strong><p>${num(p.duration_days,0)} ${state.lang === 'fa' ? 'روز' : 'days'} · ${money(p.price || 0, 'T')}</p></div><span class="status-badge ${p.archived ? 'bad' : p.active ? 'good' : 'warn'}">${p.archived ? 'ARCHIVED' : p.active ? 'ACTIVE' : 'OFF'}</span></div><p>${esc(p.description || '')}</p><div class="metric-grid">${metric(state.lang === 'fa' ? 'فروش' : 'Sales', num(p.sales_count || 0,0),'','info')}${metric(state.lang === 'fa' ? 'مخاطب' : 'Audience', esc(p.audience || 'all'),'','')}</div><div class="card-actions">${perms.edit ? `<button class="button secondary small" data-vip-plan-edit="${esc(p.id)}">${state.lang === 'fa' ? 'ویرایش' : 'Edit'}</button>` : ''}${perms.activate ? `<button class="button small" data-vip-plan-mode="${p.active ? 'deactivate' : 'activate'}" data-plan-id="${esc(p.id)}">${p.active ? (state.lang === 'fa' ? 'غیرفعال' : 'Deactivate') : (state.lang === 'fa' ? 'فعال' : 'Activate')}</button>` : ''}${perms.archive && !p.archived ? `<button class="button danger small" data-vip-plan-mode="archive" data-plan-id="${esc(p.id)}">${state.lang === 'fa' ? 'آرشیو' : 'Archive'}</button>` : ''}${perms.delete ? `<button class="button danger small" data-vip-plan-delete="${esc(p.id)}">${state.lang === 'fa' ? 'حذف' : 'Delete'}</button>` : ''}</div></article>`).join('') || empty()}</div>`, []);
    } catch (err) { toast(localizedError(err), 'error'); }
    finally { setBusy(false); }
}

function adminVipSettingsModal() {
    const d = state.resources.adminVipPlans || {}, x = d.settings || {};
    openModal('VIP SETTINGS', state.lang === 'fa' ? 'تنظیمات پرداخت و پیش‌فرض VIP' : 'VIP payment defaults', `<form id="vipSettingsForm"><div class="form-grid"><div class="field"><label for="vipSettingsCard">${state.lang === 'fa' ? 'شماره کارت ۱۶ رقمی' : '16-digit card number'}</label><input id="vipSettingsCard" inputmode="numeric" required minlength="16" maxlength="24" value="${esc(x.card_number || '')}"></div><div class="field"><label for="vipSettingsOwner">${state.lang === 'fa' ? 'نام صاحب کارت' : 'Card holder'}</label><input id="vipSettingsOwner" required minlength="2" maxlength="60" value="${esc(x.owner_name || '')}"></div><div class="field"><label for="vipSettingsPrice">${state.lang === 'fa' ? 'قیمت پیش‌فرض (تومان)' : 'Default price'}</label><input id="vipSettingsPrice" type="number" min="0" max="10000000000" required value="${esc(x.price ?? 0)}"></div><div class="field"><label for="vipSettingsDays">${state.lang === 'fa' ? 'مدت پیش‌فرض (روز)' : 'Default duration'}</label><input id="vipSettingsDays" type="number" min="1" max="3650" required value="${esc(x.duration_days ?? 30)}"></div></div></form>`, [{label: state.lang === 'fa' ? 'ذخیره تنظیمات' : 'Save settings', kind:'primary', action: async () => {
        const f=$('#vipSettingsForm'); if(!f?.reportValidity()) return;
        const values=[['card_number',$('#vipSettingsCard').value],['owner_name',$('#vipSettingsOwner').value],['price',Number($('#vipSettingsPrice').value)],['duration_days',Number($('#vipSettingsDays').value)]];
        setBusy(true); try { for(const [field,value] of values) await action('admin_vip_settings_update',{field,value},false); invalidate('adminVipPlans','overview'); closeModal(); await adminVipPlanCenter(); toast(t('success')); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); }
    }}]);
}

function adminVipPlanCreateModal() {
    openModal('VIP PLAN', state.lang === 'fa' ? 'ساخت پلن جدید' : 'Create a new plan', vipPlanFormMarkup(), [{label: state.lang === 'fa' ? 'ساخت پلن' : 'Create plan', kind:'primary', action: async () => {
        const f = $('#vipPlanForm'); if (!f?.reportValidity()) return;
        const payload = {name: $('#vipPlanName').value.trim(), price: Number($('#vipPlanPrice').value), duration_days: Number($('#vipPlanDays').value), original_price: Number($('#vipPlanOriginalPrice').value || 0), audience: $('#vipPlanAudience').value, sales_limit: Number($('#vipPlanSalesLimit').value || 0), description: $('#vipPlanDescription').value.trim(), features: $('#vipPlanFeatures').value.split('\n').map(x => x.trim()).filter(Boolean)};
        await action('admin_vip_plan_create', payload, false); invalidate('adminVipPlans','overview'); closeModal(); await adminVipPlanCenter(); toast(t('success'));
    }}]);
}

async function adminVipPlanEditModal(planId) {
    const d = state.resources.adminVipPlans || await loadResource('adminVipPlans', true), p = (d.items || []).find(x => String(x.id) === String(planId));
    if (!p) return toast('VIP_PLAN_NOT_FOUND','error');
    openModal('VIP PLAN', state.lang === 'fa' ? 'ویرایش پلن' : 'Edit plan', vipPlanFormMarkup(p), [{label: state.lang === 'fa' ? 'ذخیره تغییرات' : 'Save changes', kind:'primary', action: async () => {
        const f = $('#vipPlanForm'); if (!f?.reportValidity()) return;
        const updates = [['name',$('#vipPlanName').value.trim()],['price',Number($('#vipPlanPrice').value)],['duration_days',Number($('#vipPlanDays').value)],['original_price',Number($('#vipPlanOriginalPrice').value || 0)],['sales_limit',Number($('#vipPlanSalesLimit').value || 0)],['description',$('#vipPlanDescription').value.trim()],['audience',$('#vipPlanAudience').value],['features',$('#vipPlanFeatures').value.split('\n').map(x=>x.trim()).filter(Boolean)]];
        setBusy(true); try { for (const [field,value] of updates) await action('admin_vip_plan_update',{plan_id: planId,field,value},false); invalidate('adminVipPlans','overview'); closeModal(); await adminVipPlanCenter(); toast(t('success')); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); }
    }}]);
    $('#vipPlanAudience').value = p.audience || 'all';
}

document.addEventListener('click', async event => {
    const userReview = event.target.closest('[data-user-ai-review]');
    if (userReview) { event.preventDefault(); setBusy(true); try { const r=await action('user_ai_review',{language:state.lang},false); invalidate('ai'); closeModal(); await userAiCenter(r); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    if (event.target.closest('[data-admin-ai-health-test]')) { event.preventDefault(); setBusy(true); try { await action('admin_ai_health_test',{generation_test:true},false); invalidate('adminAI'); closeModal(); await adminAiCenter(); toast(state.lang==='fa'?'تست زنده انجام شد':'Live test completed'); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    if (event.target.closest('[data-admin-ai-access-toggle]')) { event.preventDefault(); if(!confirm(state.lang==='fa'?'حالت دسترسی کاربران بین فقط VIP و همه تغییر کند؟':'Toggle user AI access between VIP-only and everyone?')) return; await action('admin_ai_user_access_toggle',{},true); invalidate('adminAI','ai','overview'); closeModal(); await adminAiCenter(); return; }
    if (event.target.closest('[data-admin-ai-daily-report]')) { event.preventDefault(); setBusy(true); try { const r=await action('admin_ai_daily_report',{language:state.lang,force:true},false); invalidate('adminAI'); closeModal(); await adminAiCenter({...r,scope:'management',question:state.lang==='fa'?'گزارش روزانه مدیر':'Daily manager report'}); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    const adminSend = event.target.closest('[data-admin-ai-send]');
    if (adminSend) { event.preventDefault(); const f=$('#adminAiForm'), q=$('#adminAiQuestion')?.value.trim(), selectedScope=$('#adminAiScope')?.value || 'management', targetUser=$('#adminAiTargetUser')?.value.trim() || null; if(!f?.reportValidity()) return; setBusy(true); try { const r=await action('admin_ai_query',{question:q,scope:selectedScope,target_user_id:targetUser,language:state.lang},false); invalidate('adminAI'); closeModal(); await adminAiCenter({...r,question:q,scope:selectedScope}); } catch(err){ toast(localizedError(err),'error'); } finally { setBusy(false); } return; }
    const approve = event.target.closest('[data-ai-proposal-approve]');
    if (approve) { event.preventDefault(); if(!confirm(state.lang==='fa'?'این پیشنهاد فقط پس از تأیید انسانی اجرا شود؟':'Approve this proposal as a human admin?')) return; await action('admin_ai_proposal_approve',{proposal_id:Number(approve.dataset.aiProposalApprove)},true); invalidate('adminAI','adminCampaigns','adminTickets','adminOps'); closeModal(); await adminAiCenter(); return; }
    const reject = event.target.closest('[data-ai-proposal-reject]');
    if (reject) { event.preventDefault(); await action('admin_ai_proposal_reject',{proposal_id:Number(reject.dataset.aiProposalReject),reason:'rejected_by_human_admin'},true); invalidate('adminAI'); closeModal(); await adminAiCenter(); return; }
    const commandApprove = event.target.closest('[data-ai-command-approve]');
    if (commandApprove) { event.preventDefault(); await action('admin_ai_command_approve',{command_id:Number(commandApprove.dataset.aiCommandApprove)},true); invalidate('adminAI','overview'); closeModal(); await adminAiCenter(); return; }
    const commandReject = event.target.closest('[data-ai-command-reject]');
    if (commandReject) { event.preventDefault(); const reason=prompt(state.lang==='fa'?'دلیل رد دستور:':'Rejection reason:') || 'rejected_by_primary_admin'; await action('admin_ai_command_reject',{command_id:Number(commandReject.dataset.aiCommandReject),reason},true); invalidate('adminAI'); closeModal(); await adminAiCenter(); return; }
    const adminApprove = event.target.closest('[data-delegated-admin-approve]');
    if (adminApprove) { event.preventDefault(); await action('delegated_admin_approve',{user_id:adminApprove.dataset.delegatedAdminApprove},true); invalidate('adminAI','adminAdmins','overview'); closeModal(); await adminAiCenter(); return; }
    const adminReject = event.target.closest('[data-delegated-admin-reject]');
    if (adminReject) { event.preventDefault(); const reason=prompt(state.lang==='fa'?'دلیل رد ادمین:':'Rejection reason:') || 'rejected_by_primary_admin'; await action('delegated_admin_reject',{user_id:adminReject.dataset.delegatedAdminReject,reason},true); invalidate('adminAI','adminAdmins','overview'); closeModal(); await adminAiCenter(); return; }
    const executionToggle = event.target.closest('[data-admin-ai-execution-toggle]');
    if (executionToggle) { event.preventDefault(); const enabled=executionToggle.dataset.enabled==='true'; if(!confirm(enabled ? (state.lang==='fa'?'اجرای دستورات Gemini فعال شود؟':'Enable Gemini tool execution?') : (state.lang==='fa'?'اجرای دستورات Gemini فوراً متوقف شود؟':'Immediately stop Gemini tool execution?'))) return; await action('admin_ai_execution_toggle',{enabled},true); invalidate('adminAI'); closeModal(); await adminAiCenter(); return; }
    if (event.target.closest('[data-admin-ai-center]')) { event.preventDefault(); adminAiCenter(); return; }
    if (event.target.closest('[data-admin-vip-plans]')) { event.preventDefault(); adminVipPlanCenter(); return; }
    if (event.target.closest('[data-vip-settings-edit]')) { event.preventDefault(); adminVipSettingsModal(); return; }
    if (event.target.closest('[data-vip-plan-create]')) { event.preventDefault(); adminVipPlanCreateModal(); return; }
    const edit = event.target.closest('[data-vip-plan-edit]'); if(edit){event.preventDefault();adminVipPlanEditModal(edit.dataset.vipPlanEdit);return;}
    const mode = event.target.closest('[data-vip-plan-mode]'); if(mode){event.preventDefault();await action('admin_vip_plan_toggle',{plan_id:Number(mode.dataset.planId),mode:mode.dataset.vipPlanMode},true);invalidate('adminVipPlans','overview');closeModal();await adminVipPlanCenter();return;}
    const del = event.target.closest('[data-vip-plan-delete]'); if(del){event.preventDefault();if(!confirm(state.lang==='fa'?'پلن بدون سابقه فروش حذف شود؟':'Delete this plan only if it has no sales history?'))return;await action('admin_vip_plan_delete',{plan_id:Number(del.dataset.vipPlanDelete)},true);invalidate('adminVipPlans','overview');closeModal();await adminVipPlanCenter();return;}
}, true);
/* SENTINEL v8.12 unified support UI. Loaded after the legacy views so these
 * functions become the single user/admin presentation boundary. */
function supportAttachmentLabel(att) { const type = String(att?.type || 'document'); const labels = { photo: state.lang === 'fa' ? 'تصویر' : 'Image', video: state.lang === 'fa' ? 'ویدئو' : 'Video', voice: state.lang === 'fa' ? 'وویس' : 'Voice', audio: state.lang === 'fa' ? 'فایل صوتی' : 'Audio', document: state.lang === 'fa' ? 'فایل/PDF' : 'File/PDF' }; return labels[type] || labels.document; }
function supportAttachmentMarkup(att) { if (!att || typeof att !== 'object')
    return ''; const href = String(att.download_url || '').trim(), name = esc(att.file_name || supportAttachmentLabel(att)), size = Number(att.file_size || 0), sizeLabel = size ? `${(size / 1024 / 1024).toFixed(size > 1024 * 1024 ? 1 : 2)} MB` : ''; if (!href)
    return `<div class="notice warning"><strong>${esc(supportAttachmentLabel(att))}</strong><small>${name}${sizeLabel ? ` · ${sizeLabel}` : ''}</small></div>`; return `<a class="notice info support-attachment" href="${esc(href)}" target="_blank" rel="noopener"><strong>📎 ${esc(supportAttachmentLabel(att))}</strong><small>${name}${sizeLabel ? ` · ${sizeLabel}` : ''}</small></a>`; }
function supportMessageMarkup(m, adminView = false) { const isAdmin = String(m?.sender || '') === 'admin', title = adminView ? (isAdmin ? (state.lang === 'fa' ? 'پاسخ مدیر' : 'Admin reply') : (state.lang === 'fa' ? 'پیام کاربر' : 'User message')) : (isAdmin ? (state.lang === 'fa' ? 'پشتیبانی SENTINEL' : 'SENTINEL Support') : (state.lang === 'fa' ? 'شما' : 'You')); return `<div class="timeline-item ${isAdmin ? 'admin-message' : 'user-message'}"><strong>${esc(title)}</strong>${m?.text ? `<p>${esc(m.text)}</p>` : ''}${supportAttachmentMarkup(m?.attachment)}<small>${date(m?.created_at)}</small></div>`; }
async function uploadSupportAttachment(inputId) { const input = document.getElementById(inputId), file = input?.files?.[0]; if (!file)
    return null; const max = 15 * 1024 * 1024; if (file.size > max)
    throw new Error(state.lang === 'fa' ? 'حداکثر حجم فایل ۱۵ مگابایت است.' : 'Maximum file size is 15 MB.'); const form = new FormData(); form.append('file', file, file.name); return request('./api/v1/support/attachments', { method: 'POST', csrf: true, body: form }, 60000); }
function supportFileInput(id) { return `<div class="field"><label for="${id}">${state.lang === 'fa' ? 'ضمیمه اختیاری' : 'Optional attachment'}</label><input id="${id}" type="file" accept="image/jpeg,image/png,image/webp,application/pdf,video/mp4,audio/ogg,audio/mpeg,audio/mp4"><small>${state.lang === 'fa' ? 'تصویر، ویدئو، وویس، MP3 یا PDF تا ۱۵ مگابایت' : 'Image, video, voice, MP3 or PDF up to 15 MB'}</small></div>`; }
function supportModal() { const d = state.resources.tickets || {}, items = d.items || [], counts = items.reduce((a, x) => (a[x.status] = (a[x.status] || 0) + 1, a), {}); openModal('SUPPORT', t('support'), `<div class="notice info"><strong>${state.lang === 'fa' ? 'پشتیبانی یکپارچه ربات و مینی‌اپ' : 'Unified Bot & Mini App support'}</strong><p>${state.lang === 'fa' ? 'پیام و فایل از هر دو محیط در یک گفت‌وگو ذخیره می‌شود و پاسخ تلگرامی نیز از صف پایدار ارسال می‌شود.' : 'Messages and files share one conversation and Telegram notifications use the durable queue.'}</p></div><div class="row-between"><button class="button" data-ticket-new>${icon('plus')}${esc(t('createTicket'))}</button><span class="status-badge info">${num(d.total || items.length, 0)} ${state.lang === 'fa' ? 'تیکت' : 'tickets'}</span></div><div class="filters" style="margin-top:13px">${['all', 'open', 'pending', 'answered', 'closed'].map(x => `<button class="filter-chip ${state.ticketFilter === x ? 'active' : ''}" data-ticket-filter="${x}">${esc(x === 'all' ? t('all') : ticketStatusLabel(x))}${x !== 'all' && counts[x] ? ` · ${num(counts[x], 0)}` : ''}</button>`).join('')}</div><div class="ticket-list" style="margin-top:13px">${items.map(x => { const messages = x.messages || [], last = messages[messages.length - 1] || {}, hasFile = messages.some(m => m?.attachment); return `<article class="ticket-card"><div class="row-between"><h3>#${num(x.id, 0)} · ${esc(x.subject)}</h3><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${esc(x.category || 'general')} · ${esc(x.priority || 'normal')} · ${date(x.updated_at || x.created_at)}</p><div class="notice ${x.waiting_for === 'user' ? 'good' : 'info'}"><strong>${x.waiting_for === 'user' ? (state.lang === 'fa' ? 'پاسخ مدیر آماده است' : 'Admin reply available') : (state.lang === 'fa' ? 'در انتظار بررسی پشتیبانی' : 'Waiting for support')}</strong>${last.text ? `<small>${esc(String(last.text).slice(0, 160))}</small>` : ''}${hasFile ? `<small>📎 ${state.lang === 'fa' ? 'دارای فایل ضمیمه' : 'Has attachment'}</small>` : ''}</div><div class="card-actions"><button class="button secondary small" data-ticket-detail="${x.id}">${esc(t('details'))} · ${num(messages.length, 0)}</button></div></article>`; }).join('') || empty()}</div>${moreButton('tickets', d)}`, []); }
function ticketNewModal() { openModal('SUPPORT', t('createTicket'), `<form id="ticketForm"><div class="form-grid"><div class="field"><label for="ticketSubject">${esc(t('ticketSubject'))}</label><input id="ticketSubject" required maxlength="200"></div><div class="field"><label for="ticketCategory">${state.lang === 'fa' ? 'دسته' : 'Category'}</label><select id="ticketCategory"><option value="general">${state.lang === 'fa' ? 'عمومی' : 'General'}</option><option value="account">${state.lang === 'fa' ? 'حساب' : 'Account'}</option><option value="payment">${state.lang === 'fa' ? 'پرداخت' : 'Payment'}</option><option value="signal">${state.lang === 'fa' ? 'سیگنال' : 'Signal'}</option><option value="education">${state.lang === 'fa' ? 'آموزش' : 'Education'}</option><option value="technical">${state.lang === 'fa' ? 'فنی' : 'Technical'}</option></select></div><div class="field"><label for="ticketPriority">${esc(t('priority'))}</label><select id="ticketPriority"><option value="low">${state.lang === 'fa' ? 'کم' : 'Low'}</option><option value="normal" selected>${state.lang === 'fa' ? 'عادی' : 'Normal'}</option><option value="high">${state.lang === 'fa' ? 'مهم' : 'High'}</option><option value="urgent">${state.lang === 'fa' ? 'فوری' : 'Urgent'}</option></select></div></div><div class="field"><label for="ticketMessage">${esc(t('message'))}</label><textarea id="ticketMessage" maxlength="4000" placeholder="${state.lang === 'fa' ? 'متن پیام یا توضیح فایل را بنویسید' : 'Write a message or file description'}"></textarea></div>${supportFileInput('ticketNewAttachment')}</form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#ticketForm'); if (!f.reportValidity())
            return; const text = $('#ticketMessage').value.trim(), hasFile = Boolean($('#ticketNewAttachment')?.files?.[0]); if (!text && !hasFile) {
            toast(state.lang === 'fa' ? 'متن یا یک فایل اضافه کنید.' : 'Add text or a file.', 'error');
            return;
        } setBusy(true); try {
            const attachment = await uploadSupportAttachment('ticketNewAttachment');
            const row = await action('ticket_create', { subject: $('#ticketSubject').value.trim(), priority: $('#ticketPriority').value, text: text || 'فایل ضمیمه', category: $('#ticketCategory').value, attachment }, false);
            invalidate('tickets', 'overview');
            await Promise.all([loadResource('tickets', true), loadOverview(true)]);
            closeModal();
            await ticketDetail(row.id);
            toast(t('success'));
        }
        catch (err) {
            toast(localizedError?.(err) || err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function ticketDetail(id) {
    setBusy(true);
    try {
        const x = await request(`./api/v1/tickets/${encodeURIComponent(id)}`);
        const closed = x.status === 'closed', score = Number(x.satisfaction || 0);
        const replyBlock = !closed ? `<form id="ticketReplyForm"><div class="field"><label for="ticketReply">${esc(t('message'))}</label><textarea id="ticketReply" maxlength="4000"></textarea></div>${supportFileInput('ticketReplyAttachment')}<div class="card-actions"><button type="button" class="button" data-ticket-reply-enhanced="${x.id}">${esc(t('submit'))}</button><button type="button" class="button danger" data-ticket-status="${x.id}" data-status="closed">${state.lang === 'fa' ? 'بستن تیکت' : 'Close ticket'}</button></div></form>` : '';
        let closedBlock = '';
        if (closed) {
            const rating = score > 0 ? `<div class="notice good"><strong>${state.lang === 'fa' ? 'امتیاز شما به پشتیبانی' : 'Your support rating'}: ${'★'.repeat(score)}${'☆'.repeat(5 - score)}</strong></div>` : `<div class="notice info"><strong>${state.lang === 'fa' ? 'از پاسخ پشتیبانی راضی بودید؟' : 'How was the support?'}</strong><div class="card-actions">${[1, 2, 3, 4, 5].map(v => `<button class="button secondary small" data-ticket-satisfaction="${x.id}" data-score="${v}">${v} ★</button>`).join('')}</div></div>`;
            closedBlock = `<div class="notice warning"><strong>${state.lang === 'fa' ? 'تیکت بسته است' : 'Ticket is closed'}</strong><button class="button secondary small" data-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button></div>${rating}`;
        }
        openModal('TICKET', `#${x.id} · ${x.subject}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'منتظر پاسخ' : 'Waiting for', esc(x.waiting_for || 'admin'), '', 'info')}${metric(state.lang === 'fa' ? 'پیام‌ها' : 'Messages', num((x.messages || []).length, 0), '', '')}</div><div class="timeline">${(x.messages || []).map(m => supportMessageMarkup(m, false)).join('') || empty()}</div>${replyBlock}${closedBlock}`, []);
    }
    catch (err) {
        toast(localizedError?.(err) || err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
async function loadAdminTicketsWithFilters() { const q = new URLSearchParams({ limit: '100' }), status = $('#adminTicketStatusFilter')?.value || '', priority = $('#adminTicketPriorityFilter')?.value || '', query = $('#adminTicketQuery')?.value?.trim() || '', assigned = $('#adminTicketAssignedFilter')?.value?.trim() || ''; if (status)
    q.set('status', status); if (priority)
    q.set('priority', priority); if (query)
    q.set('q', query); if (assigned)
    q.set('assigned_admin', assigned); if ($('#adminTicketOverdueFilter')?.checked)
    q.set('overdue_only', 'true'); const data = await request(`./api/v1/admin/tickets?${q}`); state.resources.adminTickets = data; state.loaded.add('adminTickets'); return data; }
async function adminTicketCenter() { setBusy(true); try {
    const d = await loadResource('adminTickets', true), rows = d?.items || [];
    openModal('ADMIN SUPPORT', state.lang === 'fa' ? 'مدیریت کامل پشتیبانی' : 'Complete support management', `<div class="notice info"><strong>${state.lang === 'fa' ? 'پشتیبانی فعال ربات و مینی‌اپ' : 'Live Bot & Mini App support'}</strong><p>${state.lang === 'fa' ? 'پاسخ، فایل، تخصیص، اولویت، SLA و یادداشت داخلی از همین صفحه مدیریت می‌شوند.' : 'Reply, attachments, assignment, priority, SLA and internal notes are managed here.'}</p></div><div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجو' : 'Search'}</label><input id="adminTicketQuery" placeholder="#123 / user / subject"></div><div class="field"><label>${state.lang === 'fa' ? 'وضعیت' : 'Status'}</label><select id="adminTicketStatusFilter"><option value="">${state.lang === 'fa' ? 'همه' : 'All'}</option>${['open', 'pending', 'answered', 'closed'].map(v => `<option value="${v}">${ticketStatusLabel(v)}</option>`).join('')}</select></div><div class="field"><label>${state.lang === 'fa' ? 'اولویت' : 'Priority'}</label><select id="adminTicketPriorityFilter"><option value="">${state.lang === 'fa' ? 'همه' : 'All'}</option>${['low', 'normal', 'high', 'urgent'].map(v => `<option value="${v}">${v}</option>`).join('')}</select></div><div class="field"><label>${state.lang === 'fa' ? 'شناسه مدیر مسئول' : 'Assigned admin ID'}</label><input id="adminTicketAssignedFilter" inputmode="numeric"></div></div><label class="check"><input id="adminTicketOverdueFilter" type="checkbox"> ${state.lang === 'fa' ? 'فقط تیکت‌های عبورکرده از SLA' : 'Only overdue SLA tickets'}</label><div class="card-actions"><button class="button primary" data-admin-ticket-filter-apply>${state.lang === 'fa' ? 'اعمال فیلتر' : 'Apply filters'}</button></div><div id="adminTicketResults">${adminTicketCards(rows)}</div>`, []);
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    setBusy(false);
} }
function adminTicketCards(rows) { return `<div class="journal-list">${(rows || []).map(x => { const due = x.sla_due_at ? new Date(x.sla_due_at) : null, overdue = due && due.getTime() < Date.now() && x.status !== 'closed'; return `<article class="journal-card"><div class="row-between"><strong>#${num(x.id, 0)} · ${esc(x.subject || 'Support')}</strong><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${state.lang === 'fa' ? 'کاربر' : 'User'} ${esc(x.user_id)} · ${esc(x.priority || 'normal')} · ${state.lang === 'fa' ? 'مسئول' : 'Assigned'}: ${esc(x.assigned_admin || '—')}</p><small>${date(x.updated_at || x.created_at)} · ${num((x.messages || []).length, 0)} ${state.lang === 'fa' ? 'پیام' : 'messages'} · ${num(x.internal_notes_count || 0, 0)} ${state.lang === 'fa' ? 'یادداشت داخلی' : 'notes'}</small>${overdue ? `<div class="notice danger"><strong>${state.lang === 'fa' ? 'SLA عبور کرده است' : 'SLA overdue'}</strong></div>` : ''}<div class="card-actions"><button class="button primary small" data-admin-ticket="${x.id}">${state.lang === 'fa' ? 'بازکردن و مدیریت' : 'Open & manage'}</button></div></article>`; }).join('') || empty()}</div>`; }
async function adminTicketDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/admin/tickets/${encodeURIComponent(id)}`), closed = x.status === 'closed', due = x.sla_due_at ? new Date(x.sla_due_at) : null, overdue = due && due.getTime() < Date.now() && !closed;
    openModal('SUPPORT ADMIN', `#${x.id} · ${x.subject || 'Support'}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric(state.lang === 'fa' ? 'کاربر' : 'User', esc(x.user_id), '', 'info')}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'مدیر مسئول' : 'Assigned admin', esc(x.assigned_admin || '—'), '', 'warn')}</div>${overdue ? `<div class="notice danger"><strong>${state.lang === 'fa' ? 'مهلت پاسخ SLA گذشته است' : 'SLA response deadline has passed'}</strong><small>${date(x.sla_due_at)}</small></div>` : `<div class="notice info"><strong>SLA</strong><small>${x.sla_due_at ? date(x.sla_due_at) : '—'}</small></div>`}<div class="timeline">${(x.messages || []).map(m => supportMessageMarkup(m, true)).join('') || empty()}</div><section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'یادداشت‌های داخلی' : 'Internal notes'}</h3></div><div class="panel-body timeline">${(x.internal_notes || []).map(n => `<div class="timeline-item admin-message"><strong>${state.lang === 'fa' ? 'مدیر' : 'Admin'} ${esc(n.admin_id)}</strong><p>${esc(n.text)}</p><small>${date(n.created_at)}</small></div>`).join('') || empty()}</div></section><div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'تخصیص به مدیر' : 'Assign to admin'}</label><input id="adminTicketAssignee" inputmode="numeric" value="${esc(x.assigned_admin || '')}"><button class="button secondary small" data-admin-ticket-assign-enhanced="${x.id}">${state.lang === 'fa' ? 'تخصیص' : 'Assign'}</button></div><div class="field"><label>${state.lang === 'fa' ? 'اولویت و SLA' : 'Priority & SLA'}</label><select id="adminTicketPriorityEdit">${['low', 'normal', 'high', 'urgent'].map(v => `<option value="${v}" ${x.priority === v ? 'selected' : ''}>${v}</option>`).join('')}</select><button class="button secondary small" data-admin-ticket-priority-enhanced="${x.id}">${state.lang === 'fa' ? 'به‌روزرسانی' : 'Update'}</button></div></div><div class="field"><label>${state.lang === 'fa' ? 'یادداشت داخلی (برای کاربر نمایش داده نمی‌شود)' : 'Internal note (hidden from user)'}</label><textarea id="adminTicketInternalNote" maxlength="2000"></textarea><button class="button secondary small" data-admin-ticket-note-enhanced="${x.id}">${state.lang === 'fa' ? 'ثبت یادداشت' : 'Save note'}</button></div>${!closed ? `<form id="adminTicketReplyForm"><div class="field"><label for="adminTicketReply">${esc(t('message'))}</label><textarea id="adminTicketReply" maxlength="4000"></textarea></div>${supportFileInput('adminTicketReplyAttachment')}</form>` : ''}<div class="card-actions">${!closed ? `<button class="button primary" data-admin-ticket-reply-enhanced="${x.id}">${state.lang === 'fa' ? 'ارسال پاسخ' : 'Send reply'}</button><button class="button secondary" data-admin-ticket-status="${x.id}" data-status="pending">${state.lang === 'fa' ? 'در انتظار بررسی' : 'Mark pending'}</button><button class="button secondary" data-admin-ticket-status="${x.id}" data-status="answered">${state.lang === 'fa' ? 'پاسخ داده شد' : 'Mark answered'}</button><button class="button danger" data-admin-ticket-status="${x.id}" data-status="closed">${esc(t('close'))}</button>` : `<button class="button secondary" data-admin-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button>`}</div>`, []);
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    setBusy(false);
} }
function journalPdfFilterModal() { const accounts = state.resources.risk?.accounts || state.resources.overview?.risk?.accounts || []; openModal('PDF', state.lang === 'fa' ? 'خروجی PDF ژورنال' : 'Journal PDF export', `<div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'حساب' : 'Account'}</label><select id="journalPdfAccount"><option value="">${state.lang === 'fa' ? 'همه حساب‌ها' : 'All accounts'}</option>${accounts.map(a => `<option value="${esc(a.id)}">${esc(a.name || a.id)}</option>`).join('')}</select></div><div class="field"><label>${state.lang === 'fa' ? 'وضعیت' : 'Status'}</label><select id="journalPdfStatus"><option value="">${state.lang === 'fa' ? 'همه' : 'All'}</option><option value="open">${state.lang === 'fa' ? 'باز' : 'Open'}</option><option value="closed">${state.lang === 'fa' ? 'بسته' : 'Closed'}</option></select></div><div class="field"><label>${state.lang === 'fa' ? 'از تاریخ' : 'From date'}</label><input id="journalPdfFrom" type="date"></div><div class="field"><label>${state.lang === 'fa' ? 'تا تاریخ' : 'To date'}</label><input id="journalPdfTo" type="date"></div></div>`, [{ label: state.lang === 'fa' ? 'ساخت PDF' : 'Generate PDF', kind: 'primary', action: async () => downloadJournalPdf(true) }]); }
async function downloadJournalPdf(fromModal = false) { if (!fromModal) {
    journalPdfFilterModal();
    return;
} setBusy(true); try {
    const q = new URLSearchParams({ lang: state.lang }), account = $('#journalPdfAccount')?.value || '', status = $('#journalPdfStatus')?.value || '', dateFrom = $('#journalPdfFrom')?.value || '', dateTo = $('#journalPdfTo')?.value || '';
    if (account)
        q.set('account_id', account);
    if (status)
        q.set('status', status);
    if (dateFrom)
        q.set('date_from', dateFrom);
    if (dateTo)
        q.set('date_to', dateTo);
    const response = await fetch(`./api/v1/journal/export.pdf?${q}`, { credentials: 'include', headers: { Accept: 'application/pdf' } });
    if (!response.ok) {
        let message = 'PDF_EXPORT_FAILED';
        try {
            const body = await response.json();
            message = body?.error?.message || body?.detail || message;
        }
        catch { }
        throw new Error(message);
    }
    const blob = await response.blob();
    if (!blob.size)
        throw new Error('PDF_EXPORT_EMPTY');
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url;
    a.download = `sentinel-journal-${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    closeModal();
    toast(state.lang === 'fa' ? 'گزارش PDF ژورنال آماده شد.' : 'Journal PDF downloaded.');
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    setBusy(false);
} }
async function enhancedSupportClick(e) { const el = e.target.closest('button'); if (!el)
    return; let handled = true; try {
    if (el.dataset.ticketReplyEnhanced) {
        const id = el.dataset.ticketReplyEnhanced, text = $('#ticketReply')?.value.trim() || '', hasFile = Boolean($('#ticketReplyAttachment')?.files?.[0]);
        if (!text && !hasFile) {
            toast(state.lang === 'fa' ? 'متن یا فایل را اضافه کنید.' : 'Add text or a file.', 'error');
            return;
        }
        setBusy(true);
        const attachment = await uploadSupportAttachment('ticketReplyAttachment');
        await action('ticket_reply', { ticket_id: id, text: text || 'فایل ضمیمه', attachment }, false);
        invalidate('tickets', 'overview');
        await Promise.all([loadResource('tickets', true), loadOverview(true)]);
        await ticketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.ticketSatisfaction) {
        setBusy(true);
        await action('ticket_satisfaction', { ticket_id: el.dataset.ticketSatisfaction, score: Number(el.dataset.score) }, false);
        invalidate('tickets');
        await loadResource('tickets', true);
        await ticketDetail(el.dataset.ticketSatisfaction);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketReplyEnhanced) {
        const id = el.dataset.adminTicketReplyEnhanced, text = $('#adminTicketReply')?.value.trim() || '', hasFile = Boolean($('#adminTicketReplyAttachment')?.files?.[0]);
        if (!text && !hasFile) {
            toast(state.lang === 'fa' ? 'متن یا فایل را اضافه کنید.' : 'Add text or a file.', 'error');
            return;
        }
        setBusy(true);
        const attachment = await uploadSupportAttachment('adminTicketReplyAttachment');
        await action('ticket_admin_reply', { ticket_id: id, text: text || 'فایل ضمیمه', attachment }, false);
        invalidate('adminTickets', 'tickets', 'overview');
        await Promise.all([loadResource('adminTickets', true), loadOverview(true)]);
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketAssignEnhanced) {
        const id = el.dataset.adminTicketAssignEnhanced, adminId = $('#adminTicketAssignee')?.value.trim();
        if (!adminId)
            return;
        setBusy(true);
        await action('ticket_admin_assign', { ticket_id: id, admin_id: adminId }, false);
        invalidate('adminTickets');
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketPriorityEnhanced) {
        const id = el.dataset.adminTicketPriorityEnhanced, priority = $('#adminTicketPriorityEdit')?.value;
        setBusy(true);
        await action('ticket_admin_priority_update', { ticket_id: id, priority }, false);
        invalidate('adminTickets');
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketNoteEnhanced) {
        const id = el.dataset.adminTicketNoteEnhanced, text = $('#adminTicketInternalNote')?.value.trim();
        if (!text)
            return;
        setBusy(true);
        await action('ticket_admin_internal_note', { ticket_id: id, text }, false);
        invalidate('adminTickets');
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketFilterApply !== undefined) {
        setBusy(true);
        const d = await loadAdminTicketsWithFilters();
        const target = $('#adminTicketResults');
        if (target)
            target.innerHTML = adminTicketCards(d.items || []);
    }
    else
        handled = false;
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    if (handled) {
        e.preventDefault();
        e.stopImmediatePropagation();
        setBusy(false);
    }
} }
document.addEventListener('click', enhancedSupportClick, true);
/* Calm, data-driven trading workspace. No fabricated performance charts. */
const WORKSPACE_COPY = {
    fa: { title:'میز معامله‌گری', subtitle:'تصمیم روشن، ریسک مشخص، اجرای منظم.', portfolio:'نمای حساب', equity:'ارزش حساب', balance:'موجودی', capacity:'ظرفیت ریسک امروز', positions:'معامله باز', signals:'رصد سیگنال‌ها', journal:'مرور ژورنال', risk:'برنامه ریسک', tools:'ابزارهای روزانه', activity:'آخرین سیگنال‌ها', performance:'روند عملکرد', noHistory:'پس از ثبت معاملات، روند واقعی عملکرد اینجا نمایش داده می‌شود.', unknown:'هنوز داده‌ای ثبت نشده', account:'انتخاب یا افزودن حساب', unavailable:'داده در دسترس نیست', updated:'براساس آخرین اطلاعات دریافت‌شده', summary:'خلاصه امروز', calendar:'تقویم اقتصادی', market:'بازار و واچ‌لیست', calculator:'محاسبه حجم', support:'پشتیبانی', admin:'مرکز مدیریت', search:'جست‌وجو', day:'روز معاملاتی', riskUsed:'ریسک مصرف‌شده', noAccount:'برای مشاهده وضعیت مالی، حساب معامله‌گری خود را اضافه کنید.' },
    en: { title:'Trading workspace', subtitle:'Clear decisions. Defined risk. Disciplined execution.', portfolio:'Account overview', equity:'Account equity', balance:'Balance', capacity:'Daily risk capacity', positions:'Open positions', signals:'Watch signals', journal:'Review journal', risk:'Risk plan', tools:'Daily tools', activity:'Latest signals', performance:'Performance history', noHistory:'Your actual performance history appears here after trades are recorded.', unknown:'No recorded data yet', account:'Select or add account', unavailable:'Data unavailable', updated:'Based on the latest received data', summary:'Today at a glance', calendar:'Economic calendar', market:'Market & watchlist', calculator:'Position sizing', support:'Support', admin:'Administration', search:'Search', day:'Trading day', riskUsed:'Risk used', noAccount:'Add a trading account to see your financial overview.' }
};
function workspaceCopy() { return WORKSPACE_COPY[state.lang] || WORKSPACE_COPY.en; }
function workspaceNumber(value, suffix = '') { return value == null || !Number.isFinite(Number(value)) ? '—' : `${num(Number(value), 2)}${suffix}`; }
function workspaceHistory(values) {
    const w = workspaceCopy();
    if (!values.length) return `<div class="workspace-history-empty">${icon('chart')}<p>${esc(w.noHistory)}</p></div>`;
    const width = 600, height = 112, min = Math.min(...values), max = Math.max(...values), span = max - min || 1;
    const points = values.map((v, i) => `${16 + i * (width-32)/Math.max(1,values.length-1)},${height-14-(v-min)/span*(height-28)}`).join(' ');
    return `<svg class="workspace-history" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(w.performance)}"><path d="M16 28H584 M16 56H584 M16 84H584" class="chart-grid"/><polyline points="${points}" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
}
renderHome = function () {
    const w = workspaceCopy(), o = state.resources.overview || {}, risk = o.risk || {}, exposure = risk.account_exposure || {}, account = risk.default_account || {}, journal = o.journal_stats || {};
    const hasAccount = Boolean(account.id), currency = String(account.currency || 'USD');
    const series = Array.isArray(journal.equity_curve) ? journal.equity_curve : [];
    const curve = series.filter(p => p != null).map(p => Number(p.value ?? p)).filter(Number.isFinite).slice(-60);
    const remainingRisk = exposure.remaining_daily_risk_percent ?? risk.exposure?.remaining_daily_risk_percent ?? risk.prop?.daily_loss_remaining_percent;
    const dateLabel = new Intl.DateTimeFormat(state.lang === 'fa' ? 'fa-IR' : 'en-GB', { dateStyle:'long', timeZone:'Asia/Tehran' }).format(new Date());
    $('#page-home').innerHTML = `
    <header class="workspace-heading"><div><span class="eyebrow">SENTINEL / WORKSPACE</span><h1>${esc(w.title)}</h1><p>${esc(w.subtitle)}</p></div><button class="button secondary" data-open="search">${icon('search')}<span>${esc(w.search)}</span></button></header>
    <div class="workspace-date"><span>${esc(dateLabel)}</span><span>${esc(w.updated)} · ${date(o.generated_at)}</span></div>
    <section class="panel home-services"><div class="panel-head"><h2>${esc(state.lang==='fa'?'دسترسی سریع':'Quick access')}</h2><button class="button ghost small" data-page-target="more">${esc(state.lang==='fa'?'تمام خدمات':'All services')}${icon('chevron')}</button></div><div class="panel-body">${userMenuHtml(true).replace('class="user-menu-grid"','class="user-menu-grid" data-compact="true"')}</div></section>
    ${todayActionsHtml(o.today_actions || [])}
    <div class="workspace-layout">
      <section class="panel workspace-account"><div class="panel-head"><div><span class="eyebrow">${esc(w.portfolio)}</span><h2>${esc(account.name || w.account)}</h2></div><button class="icon-button touch" data-page-target="risk" aria-label="${esc(w.account)}">${icon('chevron')}</button></div>
        <div class="panel-body"><div class="workspace-equity"><span>${esc(w.equity)}</span><strong dir="ltr">${workspaceNumber(hasAccount ? account.equity : null)} <small>${esc(currency)}</small></strong></div>
        ${!hasAccount ? `<p class="workspace-muted">${esc(w.noAccount)}</p>` : ''}
        <div class="workspace-metrics"><div><span>${esc(w.balance)}</span><strong dir="ltr">${workspaceNumber(hasAccount ? account.balance : null)}</strong></div><div><span>${esc(w.capacity)}</span><strong dir="ltr">${workspaceNumber(hasAccount ? remainingRisk : null, '%')}</strong></div><div><span>${esc(w.positions)}</span><strong>${hasAccount && exposure.open_trades != null ? num(exposure.open_trades,0) : '—'}</strong></div></div>
        <div class="workspace-chart-head"><span>${esc(w.performance)}</span><span>${curve.length ? esc(currency) : '—'}</span></div>${workspaceHistory(curve)}
        <div class="workspace-actions"><button class="button primary" data-page-target="risk">${icon('shield')}${esc(w.risk)}</button><button class="button secondary" data-page-target="journal">${icon('journal')}${esc(w.journal)}</button></div></div>
      </section>
      <aside class="panel workspace-tools"><div class="panel-head"><div><span class="eyebrow">ESSENTIALS</span><h2>${esc(w.tools)}</h2></div></div><div class="panel-body">
      ${[['market','market','market'],['calendar','calendar','calendar'],['chart','calculator','calculator'],['support','support','tickets']].map(([ic,label,target])=>`<button class="workspace-tool" data-open="${target}">${icon(ic)}<span>${esc(w[label])}</span>${icon('chevron')}</button>`).join('')}
      <button class="workspace-tool workspace-signal-link" data-page-target="signals">${icon('signal')}<span>${esc(w.signals)}</span><b>${o.account?.active_signals == null ? '—' : num(o.account.active_signals,0)}</b></button>
      </div></aside>
    </div>
    <section class="panel workspace-signals"><div class="panel-head"><div><span class="eyebrow">SIGNAL DESK</span><h2>${esc(w.activity)}</h2></div><button class="button ghost" data-page-target="signals">${esc(t('viewAll'))}${icon('chevron')}</button></div><div class="panel-body signal-list">${(o.recent_signals || []).slice(0,4).map(signalCard).join('') || empty()}</div></section>`;
    if (state.lang === 'en') localizeUiTree($('#page-home'));
};
/* Client recovery is a convenience only; server auth, RBAC and ledgers remain authoritative. */
function safeSessionRead(key, fallback = null) { try { return JSON.parse(sessionStorage.getItem(key)) ?? fallback; } catch { return fallback; } }
function safeSessionWrite(key, value) { try { sessionStorage.setItem(key, JSON.stringify(value)); } catch { /* Storage may be unavailable in a WebView. */ } }
function recoveryScope() { return String(state.resources.overview?.user?.id || state.resources.overview?.user?.user_id || ''); }
const pendingActionKeys = new Map();
async function stableActionKey(name, payload) {
    const fingerprint = `${recoveryScope()}:${name}:${JSON.stringify(payload)}`;
    const bytes = new TextEncoder().encode(fingerprint);
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))).map(x => x.toString(16).padStart(2,'0')).join('');
    const storageKey = `sentinelPending:${hash}`;
    let record = pendingActionKeys.get(storageKey) || safeSessionRead(storageKey);
    if (record && Date.now() - record.at >= 23 * 3600000) {
        throw Object.assign(new Error(state.lang === 'fa' ? 'نتیجه درخواست قبلی هنوز نامشخص است؛ پیش از ثبت دوباره، تاریخچه یا پشتیبانی را بررسی کنید.' : 'The previous result is uncertain. Check history or support before submitting again.'), {code:'OUTCOME_REVIEW_REQUIRED'});
    }
    if (!record) record = {id:`${name}:${crypto.randomUUID()}`, at:Date.now()};
    pendingActionKeys.set(storageKey,record); safeSessionWrite(storageKey,record);
    return {id:record.id, storageKey};
}
function completeActionKey(key) {
    pendingActionKeys.delete(key.storageKey);
    try { sessionStorage.removeItem(key.storageKey); } catch { }
}
function draftKey(form) { const scope=recoveryScope(); return scope && form.id ? `sentinelDraft:${scope}:${form.id}:${state.modalDraftContext || state.page}` : ''; }
function saveFormDraft(form) {
    const key=draftKey(form); if (!key || form.dataset.draftCommitted==='true') return;
    const values={};
    for (const input of form.querySelectorAll('input,textarea,select')) {
        const id=input.id || input.name;
        if (!id || ['file','password','hidden'].includes(input.type) || input.autocomplete === 'one-time-code') continue;
        values[id]=input.type === 'checkbox' || input.type === 'radio' ? input.checked : input.value;
    }
    safeSessionWrite(key,{at:Date.now(),values});
}
function restoreFormDrafts() {
    for (const form of document.querySelectorAll('#modalBody form')) {
        const row=safeSessionRead(draftKey(form));
        if (!row || Date.now()-row.at > 24*3600000) continue;
        for (const input of form.querySelectorAll('input,textarea,select')) {
            const value=row.values?.[input.id || input.name];
            if (value == null || ['file','password','hidden'].includes(input.type)) continue;
            if (input.type==='checkbox' || input.type==='radio') input.checked=Boolean(value); else input.value=String(value);
        }
        const hint=document.createElement('p'); hint.className='draft-hint';
        hint.textContent=state.lang==='fa'?'پاسخ‌های ذخیره‌شده بازیابی شدند. فایل‌ها را دوباره انتخاب کنید.':'Saved answers restored. Select attachments again.';
        form.prepend(hint);
    }
}
function clearCurrentDrafts() { for (const form of document.querySelectorAll('#modalBody form')) { try {sessionStorage.removeItem(draftKey(form));} catch {} } }
function saveVisibleDrafts() { document.querySelectorAll('#modalBody form').forEach(saveFormDraft); }
let connectionRecoveryInflight=null;
async function recoverConnection() {
    if (connectionRecoveryInflight || state.preview || !navigator.onLine || !state.csrf) return connectionRecoveryInflight;
    saveVisibleDrafts();
    connectionRecoveryInflight=(async()=>{
        for (let attempt=0;attempt<3;attempt++) {
            try {
                setConnection('loading',state.lang==='fa'?'در حال بازیابی اتصال…':'Reconnecting…');
                await loadOverview(true);
                renderChrome();
                if ($('#modalLayer')?.hidden) await navigate(state.page,false);
                return;
            } catch (err) {
                setConnection('offline',state.lang==='fa'?'اتصال برقرار نشد؛ فرم شما حفظ شده است.':'Connection unavailable. Your form is preserved.');
                if (['UNAUTHORIZED','INIT_DATA_MISSING'].includes(err.code)) return;
                if (attempt<2) await sleep(1000*(2**attempt));
            }
        }
    })();
    try {return await connectionRecoveryInflight;} finally {connectionRecoveryInflight=null;}
}
document.addEventListener('input',event=>{const form=event.target.closest?.('#modalBody form');if(form) {delete form.dataset.draftCommitted;saveFormDraft(form);}});
document.addEventListener('change',event=>{const form=event.target.closest?.('#modalBody form');if(form) {delete form.dataset.draftCommitted;saveFormDraft(form);}});
window.addEventListener('pagehide',saveVisibleDrafts);
window.addEventListener('online',()=>recoverConnection());
window.addEventListener('offline',saveVisibleDrafts);
/* Extend existing pages and domain services; no parallel economy or account system. */
Object.assign(I18N.fa,{trading:'معامله‌گری',rewards:'جوایز',allServices:'خدمات'});
Object.assign(I18N.en,{trading:'Trading',rewards:'Rewards',allServices:'Services'});
const HUB_COPY={
 fa:{rewards:'جوایز',available:'جوایز موجود',mine:'جوایز من',history:'تاریخچه امتیاز',points:'امتیاز',earned:'دریافتی ثبت‌شده',spent:'مصرف ثبت‌شده',source:'منبع',valid:'اعتبار',conditions:'شرایط استفاده',claim:'مشاهده و دریافت در ربات',referral:'دعوت دوستان',copy:'کپی لینک',share:'اشتراک‌گذاری',invited:'دعوت‌ها',buyers:'خریداران',noCode:'برای دریافت لینک اختصاصی وارد بخش دعوت ربات شوید.',bot:'باز کردن ربات',missions:'مأموریت‌ها',education:'آموزش',rank:'رتبه‌بندی و باشگاه',account:'حساب و تمام خدمات',services:'همه قابلیت‌ها با حفظ دسترسی‌های قبلی',trading:'میز معامله‌گری',risk:'برنامه ریسک',journal:'ژورنال معاملاتی',tools:'تمرین و ابزارها',next:'صفحه بعد',before:'صفحه قبل',used:'استفاده‌شده',expired:'منقضی',active:'قابل استفاده',scheduled:'هنوز شروع نشده',reserved:'رزرو برای سفارش',disabled:'غیرفعال',cost:'هزینه دریافت',confirm:'تأیید دریافت جایزه',delivering:'در حال دریافت…',claimHere:'دریافت جایزه',notEnough:'امتیاز کافی ندارید',pending:'در انتظار تحویل',delivered:'تحویل‌شده',cancelled:'لغوشده',date:'تاریخ',balance:'مانده',noExpiry:'بدون انقضای ثبت‌شده',perUser:'سقف استفاده هر نفر',renewal:'فقط تمدید VIP',plans:'پلن‌های مجاز',allPlans:'همه پلن‌ها',minimum:'حداقل خرید',copied:'کپی شد',support:'پشتیبانی',faq:'سؤالات متداول',myToday:'امروز من',ai:'بررسی هوشمند حساب'},
 en:{rewards:'Rewards',available:'Available rewards',mine:'My rewards',history:'Point history',points:'Points',earned:'Recorded earnings',spent:'Recorded spending',source:'Source',valid:'Validity',conditions:'Conditions',claim:'View and claim in bot',referral:'Invite friends',copy:'Copy link',share:'Share',invited:'Invitations',buyers:'Buyers',noCode:'Open referrals in the bot to get your personal link.',bot:'Open bot',missions:'Missions',education:'Education',rank:'Rankings & club',account:'Account & all services',services:'All features with existing access preserved',trading:'Trading workspace',risk:'Risk plan',journal:'Trading journal',tools:'Practice & tools',next:'Next page',before:'Previous page',used:'Used',expired:'Expired',active:'Available',scheduled:'Not started yet',reserved:'Reserved for order',disabled:'Disabled',cost:'Redemption cost',confirm:'Confirm reward claim',delivering:'Claiming…',claimHere:'Claim reward',notEnough:'Not enough points',pending:'Awaiting delivery',delivered:'Delivered',cancelled:'Cancelled',date:'Date',balance:'Balance',noExpiry:'No recorded expiry',perUser:'Uses per user',renewal:'VIP renewal only',plans:'Applicable plans',allPlans:'All plans',minimum:'Minimum purchase',copied:'Copied',support:'Support',faq:'FAQ',myToday:'My today',ai:'Smart account review'}
};
function hubCopy(){return HUB_COPY[state.lang]||HUB_COPY.en;}
const BOT_DESTINATIONS=new Set(['web_account', 'web_account_hub', 'web_calc', 'web_club', 'web_contests', 'web_edu', 'web_faq', 'web_journal', 'web_journal_crypto', 'web_journal_forex', 'web_kpi', 'web_missions', 'web_my_rewards', 'web_news', 'web_prices', 'web_referral', 'web_reward_catalog', 'web_rewards', 'web_services', 'web_rules', 'web_signals', 'web_signals_crypto', 'web_signals_forex', 'web_support', 'web_today', 'web_tools', 'web_trade', 'web_vip', 'web_watchlist', 'web_watchlist_crypto', 'web_watchlist_forex']);
function botBridge(destination){
    if(!BOT_DESTINATIONS.has(destination))return toast(t('notAvailable'),'error');
    const username=String(state.resources.overview?.bot_username||'').replace(/^@/,'');
    if(!/^[A-Za-z0-9_]{5,32}$/.test(username))return toast(t('notAvailable'),'error');
    const url=`https://t.me/${username}?start=${encodeURIComponent(destination)}`;
    if(tg?.openTelegramLink)tg.openTelegramLink(url);else window.open(url,'_blank','noopener');
}
function referralLink(data){
    const username=String(state.resources.overview?.bot_username||'').replace(/^@/,'');
    const code=String(data?.referral?.code||'');
    return /^[A-Za-z0-9_]{5,32}$/.test(username)&&/^[A-Za-z0-9_-]{4,64}$/.test(code)?`https://t.me/${username}?start=${encodeURIComponent(code)}`:'';
}
function hubBridgeCard(ic,label,destination){return `<button class="service-card" data-bot-bridge="${esc(destination)}">${icon(ic)}<span><strong>${esc(label)}</strong><small>${esc(hubCopy().bot)}</small></span>${icon('chevron')}</button>`;}
let rewardTab='available',pointCursor=0;
function rewardCard(item){
    const h=hubCopy(),status=String(item.status||'delivered'),c=item.conditions||{};
    return `<article class="reward-card"><div class="row-between"><h3>${esc(item.title||h.rewards)}${item.unread?' <span class="status-badge warn">●</span>':''}</h3><span class="status-badge ${['expired','cancelled','disabled'].includes(status)?'muted':['pending','scheduled','reserved'].includes(status)?'warn':'good'}">${esc(h[status]||status)}</span></div><p class="mono" dir="auto">${esc(item.detail||'')}</p>${item.code?`<button class="button secondary" data-copy-reward="${esc(item.code)}">${esc(state.lang==='fa'?'کپی کد':'Copy code')}</button>`:''}<dl class="reward-details"><dt>${esc(h.source)}</dt><dd>${esc(item.source_label||h.rewards)}</dd><dt>${esc(h.date)}</dt><dd>${date(item.created_at)}</dd><dt>${esc(h.valid)}</dt><dd>${item.expires_at?date(item.expires_at):esc(h.noExpiry)}</dd></dl>${item.conditions?`<div class="notice info"><strong>${esc(h.conditions)}</strong><p>${esc(h.perUser)}: ${esc(c.per_user_limit||'∞')} · ${esc(c.renewal_only?h.renewal:h.plans)}: ${c.plans?.length?esc(c.plans.join(', ')):esc(h.allPlans)}</p>${c.minimum_purchase?`<p>${esc(h.minimum)}: ${num(c.minimum_purchase,0)} IRT</p>`:''}${c.starts_at?`<small>${date(c.starts_at)}</small>`:''}</div>`:''}</article>`;
}
async function renderRewardsWorkspace(force=false){
    const page=$('#page-rewards'),h=hubCopy();
    page.innerHTML=pageHead('REWARDS',h.rewards,'')+skeleton(2);
    try{
        const d=await loadResource('hub',force)||{},p=d.points||{};
        let body='';
        if(rewardTab==='available')body=(d.available||[]).map(item=>{
            const affordable=Number(p.balance||0)>=Number(item.points||0);
            const prize=item.prize||{points:item.type==='points'?item.value:0,vip_days:item.type==='vip_days'?item.value:0,coupon_percent:item.discountPct};
            return `<article class="reward-card"><div class="row-between"><h3>${esc(item.name||h.rewards)}</h3><span class="status-badge info">${num(item.points,0)} ${esc(h.points)}</span></div><p>${esc(clientPrizeLabel(prize)||item.description||'')}</p><p>${esc(h.valid)}: ${item.expires_at?date(item.expires_at):esc(h.noExpiry)}</p><button class="button ${affordable?'primary':'secondary'}" data-reward-claim="${esc(item.id)}" ${affordable?'':'disabled'}>${esc(affordable?h.claimHere:h.notEnough)}</button></article>`;
        }).join('')||empty();
        if(rewardTab==='mine')body=(d.wallet||[]).map(rewardCard).join('')||empty();
        if(rewardTab==='history')body=pointHistoryHtml(p);
        if(p.recovery_due>0)body=`<div class="notice warn">${state.lang==='fa'?'امتیاز برگشتی باقیمانده از خرید بازپرداخت‌شده، از امتیازهای بعدی تسویه می‌شود:':'Outstanding points from a refunded purchase will be recovered from future earnings:'} ${num(p.recovery_due,0)}</div>`+body;
        page.innerHTML=pageHead('REWARDS',h.rewards,'')+`<div class="metric-grid">${metric(h.points,num(p.balance??0,0),'','info')}${metric(h.earned,num(p.earned??0,0),'','good')}${metric(h.spent,num(p.spent??0,0),'','')}</div><div class="segmented reward-tabs" role="tablist">${['available','mine','history'].map(key=>`<button role="tab" aria-selected="${rewardTab===key}" class="${rewardTab===key?'active':''}" data-reward-tab="${key}">${esc(h[key])}${key==='mine'?`<span data-reward-count ${d.unread_rewards?'':'hidden'}> · ${num(d.unread_rewards||0,0)} ${state.lang==='fa'?'جدید':'new'}</span>`:''}</button>`).join('')}</div><div class="reward-list">${body}</div><div class="card-actions"><button class="button secondary" data-open="referral">${icon('user')}${esc(h.referral)}</button><button class="button ghost" data-page-target="home">${esc(t('home'))}</button></div>`;
        if(rewardTab==='mine'){
            const keys=(d.wallet||[]).filter(item=>item.unread).map(item=>item.seen_key);
            if(keys.length){
                try{const result=await action('reward_seen',{keys:keys.slice(0,5000)},false);syncRewardBadges(result.unread_rewards);invalidate('hub','overview');}
                catch(error){console.warn('Reward acknowledgement pending');}
            }
        }
    }catch(err){page.innerHTML=errorPanel(err,'rewards');}
}
function clientPrizeLabel(p){return [['points',state.lang==='fa'?'امتیاز':'points'],['vip_days',state.lang==='fa'?'روز VIP':'VIP days'],['coupon_percent',state.lang==='fa'?'٪ تخفیف':'% coupon']].filter(([key])=>p[key]).map(([key,label])=>`${num(p[key],0)} ${label}`).join(' + ');}
function pointHistoryHtml(p){
    const h=hubCopy();
    return `<div class="point-history">${(p.history||[]).map(row=>`<article class="point-event"><strong class="${row.amount>=0?'text-good':'text-bad'}" dir="ltr">${row.amount>=0?'+':''}${num(row.amount,0)}</strong><div><p>${esc(row.reason_label||row.reason||h.rewards)}</p><small>${date(row.created_at)} · ${esc(h.balance)}: ${num(row.balance_after??0,0)}</small><details><summary>${esc(h.source)}</summary><code dir="ltr">${esc(row.source_event||'—')}</code></details></div></article>`).join('')||empty()}</div><div class="card-actions">${pointCursor?`<button class="button secondary" data-point-cursor="${Math.max(0,pointCursor-20)}">${esc(h.before)}</button>`:''}${p.next_cursor!=null?`<button class="button secondary" data-point-cursor="${p.next_cursor}">${esc(h.next)}</button>`:''}</div>`;
}
async function referralModal(force=true,guard=null){
    const h=hubCopy(),d=await loadResource('hub',force)||{},link=referralLink(d);
    if(guard&&!guard())return;
    openModal('REFERRAL',h.referral,`<div class="metric-grid">${metric(h.invited,num(d.referral?.invited??0,0),'','')}${metric(h.buyers,num(d.referral?.buyers??0,0),'','')}</div>${link?`<div class="referral-link" dir="ltr"><code>${esc(link)}</code></div><div class="card-actions"><button class="button primary" data-copy-referral>${esc(h.copy)}</button><button class="button secondary" data-share-referral>${esc(h.share)}</button></div>`:`<p>${esc(h.noCode)}</p>`}<button class="button ghost" data-bot-bridge="web_referral">${esc(h.bot)}</button>`,[]);
}
async function missionsModal(force=true,guard=null){
    const h=hubCopy(),d=await loadResource('hub',force)||{};
    if(guard&&!guard())return;
    openModal('MISSIONS',h.missions,`<div class="reward-list">${(d.missions||[]).map(m=>`<article class="reward-card"><h3>${esc(m.title)}</h3><p>${esc(m.description||'')}</p><span class="status-badge ${m.progress.completed?'good':'info'}">${m.progress.completed?'✓ ':''}${num(m.progress.progress,0)}/${num(m.progress.target,0)}</span><p>${esc(m.prize_label)}</p>${m.ends_at?`<small>${date(m.ends_at)}</small>`:''}</article>`).join('')||empty()}</div><button class="button secondary" data-bot-bridge="web_missions">${esc(h.bot)}</button>`,[]);
}
function renderTradingWorkspace(){
    const h=hubCopy();
    $('#page-trading').innerHTML=pageHead('TRADING',h.trading,'')+`<div class="service-list"><button class="service-card" data-page-target="risk">${icon('shield')}<span><strong>${esc(h.risk)}</strong><small>${esc(t('whatIf'))}</small></span>${icon('chevron')}</button><button class="service-card" data-page-target="journal">${icon('journal')}<span><strong>${esc(h.journal)}</strong><small>${esc(t('tradeJournal'))}</small></span>${icon('chevron')}</button>${sentinelService('shield',h.tools,'Paper / Prop / Risk Coach','tradeCenter')}${sentinelService('chart',t('market'),t('marketRegime'),'market')}${sentinelService('chart',h.ai,'AI','ai')}${hubBridgeCard('shield',h.tools,'web_tools')}</div>`;
}
/* The same task order as the Telegram menu; existing destinations are reused. */
function userMenuItems() {
    const fa = state.lang === 'fa', o = state.resources.overview || {};
    const item = (id, ic, faTitle, enTitle, kind, target, tone = '') => ({id, ic, title: fa ? faTitle : enTitle, kind, target, tone});
    return [
        {...item('vip','crown',o.account?.vip_active ? 'مدیریت اشتراک' : 'خرید اشتراک',o.account?.vip_active ? 'Manage subscription' : 'Buy subscription','open','vip','success'),wide:true},
        item('education','education','آموزش','Education','open','education'),
        item('calculator','calculator','ماشین‌حساب','Calculator','open','calculator'),
        item('market','market','قیمت بازار','Market prices','open','market'),
        item('account','account','حساب من','My account','open','settings'),
        item('contests','trophy','مسابقه','Contests','open','contests'),
        item('missions','mission','مأموریت','Missions','open','missions'),
        item('signals','signal','سیگنال‌ها','Signals','page','signals','primary'),
        item('trading','shield','مرکز معاملات','Trading center','page','trading','primary'),
        item('rewards','gift','جوایز','Rewards','open','rewards'),
        item('referral','link','لینک دعوت من','My referral link','open','referral'),
        item('today','calendar','امروز من','My today','bridge','web_today'),
        item('calendar','calendar','اخبار و تقویم','News & calendar','open','calendar'),
        item('tools','shield','ابزارهای معامله','Trading tools','open','tradeCenter'),
        item('rankings','trophy','رتبه‌بندی','Rankings','open','rankings'),
        item('settings','settings','تنظیمات','Settings','open','settings'),
        item('support','support','پشتیبانی','Support','open','support'),
        item('search','search','جست‌وجو و خدمات','Search & services','open','search'),
        item('rules','journal','قوانین','Rules','bridge','web_rules'),
        item('orders','wallet','سفارش‌ها و پرداخت','Orders & payments','open','orders'),
        item('notifications','bell','اعلان‌ها','Notifications','open','notifications'),
        item('journal','journal','ژورنال معاملاتی','Trading journal','page','journal'),
        item('risk','shield','برنامه ریسک','Risk plan','page','risk'),
        item('ai','chart','بررسی هوشمند','Smart review','open','ai'),
        item('language','language','زبان','Language','language','toggle'),
        item('faq','support','سؤالات متداول','FAQ','bridge','web_faq'),
        item('bot-tools','shield','ابزارهای ربات','Bot tools','bridge','web_tools'),
        item('bot-account','account','حساب در ربات','Bot account','bridge','web_account'),
    ];
}
function unreadRewardCount() {
    const value = state.resources.overview?.account?.unread_rewards ?? state.resources.hub?.unread_rewards;
    return Math.max(0, Math.floor(Number(value) || 0));
}
function userMenuHtml(compact = false) {
    const unread = unreadRewardCount(), fa = state.lang === 'fa';
    const items = userMenuItems().slice(0, compact ? 13 : undefined);
    return `<nav class="user-menu-grid" aria-label="${fa ? 'خدمات SENTINEL' : 'SENTINEL services'}">${items.map(item => {
        const attribute = item.kind === 'page' ? 'data-page-target' : item.kind === 'bridge' ? 'data-bot-bridge' : item.kind === 'reward' ? 'data-reward-open' : item.kind === 'language' ? 'data-menu-language' : 'data-open';
        const badge = ['rewards','my-rewards'].includes(item.id) && unread > 0 ? `<em class="menu-unread" aria-label="${num(unread,0)} ${fa ? 'جایزه جدید' : 'new rewards'}">${num(unread,0)} <span>${fa ? 'جدید' : 'new'}</span></em>` : '';
        return `<button type="button" class="user-menu-tile ${item.tone} ${item.wide ? 'menu-wide' : ''}" data-menu-id="${item.id}" ${attribute}="${esc(item.target)}">${icon(item.ic)}<strong>${esc(item.title)}</strong>${badge}${item.wide ? icon('chevron') : ''}</button>`;
    }).join('')}</nav>`;
}
function syncRewardBadges(count) {
    const safe = Math.max(0, Math.floor(Number(count) || 0));
    const o = state.resources.overview;
    if(o?.account) o.account.unread_rewards = safe;
    if(state.resources.hub) state.resources.hub.unread_rewards = safe;
    const badge = $('#rewardNavBadge');
    if(badge){badge.hidden = !safe;badge.textContent = num(safe,0);badge.setAttribute('aria-label',`${num(safe,0)} ${state.lang === 'fa' ? 'جایزه جدید' : 'new rewards'}`);}
    $$('[data-reward-count]').forEach(badge=>{badge.hidden=!safe;badge.textContent=` · ${num(safe,0)} ${state.lang==='fa'?'جدید':'new'}`;});
    // Update only badges: preserve keyboard focus and the user's current layout.
    $$('[data-menu-id="rewards"], [data-menu-id="my-rewards"]').forEach(tile => {
        let marker = tile.querySelector('.menu-unread');
        if(!safe){marker?.remove();return;}
        if(!marker){marker=document.createElement('em');marker.className='menu-unread';tile.append(marker);}
        marker.setAttribute('aria-label',`${num(safe,0)} ${state.lang==='fa'?'جایزه جدید':'new rewards'}`);
        marker.innerHTML=`${num(safe,0)} <span>${state.lang==='fa'?'جدید':'new'}</span>`;
    });
}
const menuChromeRender = renderChrome;
renderChrome = function(){menuChromeRender();syncRewardBadges(unreadRewardCount());};
const fullUserMenuRender = renderMore;
renderMore = async function(force=false){
    await fullUserMenuRender(force);
    const page=$('#page-more');
    // Reuse additional current services, without duplicating catalog entries.
    const covered = new Set(['tradeCenter','calculator','journal-route','market','vip','orders','contests','notifications','calendar','support','search','settings']);
    const supplement=[];
    page.querySelectorAll('.service-groups > section:not(.admin-service-group)').forEach(section=>{
        section.querySelectorAll('.service-card').forEach(button=>{if(!covered.has(button.dataset.open))supplement.push(button);});section.remove();
    });
    page.querySelector('.page-header')?.remove();
    const catalog=document.createElement('section');catalog.className='panel user-access-catalog';
    catalog.innerHTML=`<div class="panel-head"><div><span class="eyebrow">SENTINEL SERVICES</span><h2>${esc(state.lang==='fa'?'تمام خدمات':'All services')}</h2><p>${esc(state.lang==='fa'?'دسترسی مستقیم به تمام بخش‌ها':'Direct access to every workspace')}</p></div></div><div class="panel-body">${userMenuHtml()}</div>`;
    page.prepend(catalog);
    if(supplement.length){const extra=document.createElement('section');extra.className='panel supplementary-services';extra.innerHTML=`<div class="panel-head"><h2>${esc(state.lang==='fa'?'پیگیری و شفافیت':'Activity & transparency')}</h2></div><div class="panel-body service-list"></div>`;extra.querySelector('.service-list').append(...supplement);catalog.after(extra);}
    if(state.lang==='en')localizeUiTree(page);
    syncRewardBadges(unreadRewardCount());
};
const hubLegacyOpenMore=openMore;
openMore=async function(target){
    if(target==='education')return botBridge('web_edu');
    if(target==='rankings')return rankingModal();
    if(target==='referral')return referralModal();
    if(target==='missions')return missionsModal();
    if(target==='rewards'){rewardTab='available';closeModal();return navigate('rewards');}
    if(target==='trading'){closeModal();return navigate('trading');}
    return hubLegacyOpenMore(target);
};
document.addEventListener('click',async event=>{
    const el=event.target.closest('[data-menu-language],[data-reward-open],[data-page-back],[data-reward-claim],[data-reward-tab],[data-point-cursor],[data-copy-reward],[data-bot-bridge],[data-copy-referral],[data-share-referral]');
    if(!el)return;event.preventDefault();event.stopImmediatePropagation();
    try{
        if(el.dataset.menuLanguage)return await toggleLanguage();
        if(el.dataset.rewardOpen){rewardTab=el.dataset.rewardOpen;closeModal();return await navigate('rewards');}
        if(el.dataset.pageBack!==undefined)return await navigateWorkspaceBack();
        if(el.dataset.botBridge)return botBridge(el.dataset.botBridge);
        if(el.dataset.rewardClaim)return confirmRewardClaim(el.dataset.rewardClaim);
        if(el.dataset.rewardTab){rewardTab=el.dataset.rewardTab;return await renderRewardsWorkspace();}
        if(el.dataset.pointCursor!==undefined){pointCursor=Math.max(0,Number(el.dataset.pointCursor)||0);invalidate('hub');await loadResource('hub',true);return await renderRewardsWorkspace();}
        const link=referralLink(state.resources.hub);
        if(el.dataset.shareReferral!==undefined&&link&&navigator.share){try{await navigator.share({title:'SENTINEL',url:link});}catch(err){if(err.name!=='AbortError')throw err;}return;}
        const value=el.dataset.copyReward||link;if(!value)return;
        await copyHubText(value);
    }catch(err){toast(err.message||t('error'),'error');}
},true);

async function rankingModal(force=true,guard=null){
 const h=hubCopy(),d=await loadResource('hub',force)||{};
 if(guard&&!guard())return;
 openModal('CLUB',h.rank,`<div class="notice info">${state.lang==='fa'?'رتبه من':'My rank'}: ${d.my_rank?num(d.my_rank,0):'—'}</div><div class="ranking-list">${(d.leaderboard||[]).map(row=>`<article class="ranking-row ${row.rank<=3?'podium':''} ${row.is_me?'is-me':''}"><strong class="rank-number">${['🥇','🥈','🥉'][row.rank-1]||'#'+num(row.rank,0)}</strong><span>${esc(row.name)}${row.is_me?' · '+(state.lang==='fa'?'شما':'You'):''}</span><b>${num(row.points,0)} <small>${esc(h.points)}</small></b></article>`).join('')||empty()}</div><button class="button ghost" data-bot-bridge="web_club">${esc(h.bot)}</button>`,[]);
}

async function copyHubText(value){
    if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(value);toast(hubCopy().copied);return;}catch{}}
    openModal('COPY',state.lang==='fa'?'کپی لینک یا کد':'Copy link or code',`<div class="field"><input id="hubCopyValue" readonly dir="ltr" value="${esc(value)}" aria-label="${esc(hubCopy().copy)}"><small>${state.lang==='fa'?'متن را انتخاب و کپی کنید.':'Select and copy the text.'}</small></div>`,[]);
    $('#hubCopyValue')?.select();
}
function confirmRewardClaim(id){
    const item=state.resources.hub?.available?.find(row=>String(row.id)===String(id));if(!item)return;
    const h=hubCopy();
    openModal('REWARD CLAIM',h.confirm,`<h3>${esc(item.name)}</h3><p>${esc(h.cost)}: ${num(item.points,0)} ${esc(h.points)}</p>`,[{label:h.claimHere,kind:'primary',action:async()=>{
        setBusy(true);try{
            await action('reward_claim',{reward_id:Number(item.id)},false);
            closeModal();rewardTab='mine';pointCursor=0;invalidate('hub','overview');
            await Promise.all([loadResource('hub',true),loadOverview(true)]);renderChrome();await renderRewardsWorkspace();toast(t('success'));
        }catch(err){toast(err.message||t('error'),'error');}finally{setBusy(false);}
    }}]);
}

const navigateWithBotBridge=navigate;
navigate=async function(page,scroll=true){
    await navigateWithBotBridge(page,scroll);
    const target={signals:'web_signals',trading:'web_trade',risk:'web_calc',journal:'web_journal',rewards:'web_rewards',more:'web_account_hub'}[state.page];
    const container=$(`#page-${state.page}`);if(!container||!target||container.querySelector('.telegram-continue'))return;
    const footer=document.createElement('div');footer.className='card-actions telegram-continue';
    footer.innerHTML=`<button class="button ghost" data-bot-bridge="${target}">${esc(state.lang==='fa'?'ادامه این بخش در ربات تلگرام':'Continue this section in Telegram')}</button>`;container.append(footer);
};

function hubFingerprint(data){if(!data)return '';const {generated_at,...content}=data;return JSON.stringify(content);}
async function refreshVisibleHub(){
    if(state.busy)return false;
    const modalName=!$('#modalLayer')?.hidden?$('#modalEyebrow')?.textContent:'';
    const modalGeneration=state.modalGeneration||0,page=state.page,cursor=pointCursor;
    const sameModal=()=>!$('#modalLayer')?.hidden&&$('#modalEyebrow')?.textContent===modalName&&(state.modalGeneration||0)===modalGeneration;
    if(state.page!=='rewards' && !['REFERRAL','MISSIONS','CLUB'].includes(modalName))return false;
    const before=hubFingerprint(state.resources.hub),fresh=await loadResource('hub',true);
    if(hubFingerprint(fresh)===before)return false;
    await loadOverview(true);renderChrome();
    if(page==='rewards'&&state.page===page&&pointCursor===cursor)await renderRewardsWorkspace();
    if(sameModal()){
        if(modalName==='REFERRAL')await referralModal(false,sameModal);
        if(modalName==='MISSIONS')await missionsModal(false,sameModal);
        if(modalName==='CLUB')await rankingModal(false,sameModal);
    }
    return true;
}
async function handleClick(e) { const el = e.target.closest('button,[data-page-target],[data-open]'); if (!el)
    return; if (el.dataset.authRetry !== undefined) {
    await retryTelegramAuthentication();
    return;
} if (el.dataset.closeApp !== undefined) {
    releaseTelegramNavigation(true);
    tg?.close?.();
    return;
} if (el.dataset.loadMore) {
    await loadMore(el.dataset.loadMore);
    return;
} if (el.dataset.pageTarget) {
    await navigate(el.dataset.pageTarget);
    return;
} if (el.dataset.open) {
    await openMore(el.dataset.open);
    return;
} if (el.dataset.featureDisabled !== undefined) {
    featureDisabledModal();
    return;
} if (el.dataset.closeModal !== undefined) {
    closeModal();
    return;
} if (el.dataset.modalAction !== undefined) {
    const a = state.modalActions?.[Number(el.dataset.modalAction)];
    await a?.action?.();
    return;
} if (el.dataset.signalReplay) {
    await signalReplayModal(el.dataset.signalReplay);
    return;
} if (el.dataset.signalShare) {
    await shareSignalCard(el.dataset.signalShare);
    return;
} if (el.dataset.signalDetail) {
    await openSignal(el.dataset.signalDetail);
    return;
} if (el.dataset.copySignal) {
    copySignal(el.dataset.copySignal);
    return;
} if (el.dataset.signalFilter) {
    state.signalFilter = el.dataset.signalFilter;
    invalidate('signals');
    await renderSignals(true);
    return;
} if (el.dataset.retry) {
    invalidate(el.dataset.retry);
    if(el.dataset.retry==='rewards')invalidate('hub');
    await navigate(state.page, false);
    return;
} if (el.dataset.reload !== undefined) {
    location.reload();
    return;
} if (el.dataset.journalFilter) {
    state.journalFilter = el.dataset.journalFilter;
    invalidate('journal');
    await renderJournal(true);
    return;
} if (el.dataset.orderFilter) {
    state.orderFilter = el.dataset.orderFilter;
    invalidate('orders');
    await loadResource('orders', true);
    ordersModal();
    return;
} if (el.dataset.ticketFilter) {
    state.ticketFilter = el.dataset.ticketFilter;
    invalidate('tickets');
    await loadResource('tickets', true);
    supportModal();
    return;
} if (el.dataset.accountSelect) {
    state.selectedAccount = el.dataset.accountSelect;
    invalidate('risk');
    await renderRisk(true);
    return;
} if (el.dataset.accountEdit) {
    accountModal(el.dataset.accountEdit);
    return;
} if (el.dataset.brokerSync) {
    setBusy(true);
    try {
        await action('broker_snapshot_sync', { account_id: el.dataset.brokerSync }, false);
        invalidate('risk', 'overview');
        await Promise.all([loadResource('risk', true), loadOverview(true)]);
        renderChrome();
        await renderRisk();
        toast(state.lang === 'fa' ? 'اطلاعات فقط‌خواندنی بروکر همگام شد' : 'Read-only broker data synchronized');
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
 } if (el.dataset.mt5Pair) {
    mt5PairModal(el.dataset.mt5Pair);
    return;
} if (el.dataset.mt5Revoke) {
    if (!confirm(state.lang === 'fa' ? 'اتصال این متاتریدر قطع شود؟' : 'Revoke this MetaTrader connection?')) return;
    setBusy(true);
    try { await action('mt5_connector_revoke', {connector_id: el.dataset.mt5Revoke}, false); invalidate('risk','expansion'); await renderRisk(true); toast(t('success')); }
    catch(err) { toast(err.message,'error'); }
    finally { setBusy(false); }
    return;
} if (el.dataset.riskPlan) {
    riskPlanModal(el.dataset.riskPlan);
    return;
} if (el.dataset.riskPlanAccept) {
    setBusy(true);
    try { await action('risk_daily_plan_accept', {account_id: el.dataset.riskPlanAccept}, false); invalidate('risk','expansion'); await renderRisk(true); toast(t('success')); }
    catch(err) { toast(err.message,'error'); }
    finally { setBusy(false); }
    return;
} if (el.dataset.riskCheckin) {
    riskCheckinModal(el.dataset.riskCheckin);
    return;
} if (el.dataset.positionClose) {
    closePositionModal(el.dataset.positionClose);
    return;
} if (el.dataset.journalNew !== undefined) {
    journalNewModal();
    return;
} if (el.dataset.journalClose) {
    journalCloseModal(el.dataset.journalClose, false);
    return;
} if (el.dataset.journalPartial) {
    journalCloseModal(el.dataset.journalPartial, true);
    return;
} if (el.dataset.journalArchive) {
    setBusy(true);
    try {
        await action('journal_delete', { id: el.dataset.journalArchive }, false);
        invalidate('journal');
        await loadResource('journal', true);
        renderJournal();
        toast(t('archived'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.journalExport !== undefined) {
    exportJournal();
    return;
} if (el.dataset.journalPdf !== undefined) {
    await downloadJournalPdf();
    return;
} if (el.dataset.journalImport !== undefined) {
    importJournal();
    return;
} if (el.dataset.brokerImport !== undefined) {
    importBroker();
    return;
} if (el.dataset.watchAdd !== undefined) {
    const symbol = $('#watchSymbol').value.trim();
    if (!symbol)
        return;
    setBusy(true);
    try {
        await action('watchlist_toggle', { symbol }, false);
        invalidate('market');
        await loadResource('market', true);
        marketModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.marketRefresh !== undefined) {
    setBusy(true);
    try {
        invalidate('market');
        await loadResource('market', true);
        marketModal();
        toast(t('refreshDone'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.watchRemove || el.dataset.watchQuick) {
    const symbol = el.dataset.watchRemove || el.dataset.watchQuick;
    if (!symbol)
        return;
    setBusy(true);
    try {
        await action('watchlist_toggle', { symbol }, false);
        invalidate('market');
        await loadResource('market', true);
        marketModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.calendarSettings !== undefined) {
    calendarPreferencesModal();
    return;
} if (el.dataset.revisionAck) {
    setBusy(true);
    try {
        await action('revision_ack', { signal_id: el.dataset.revisionAck, revision: Number(el.dataset.revision) }, false);
        invalidate('revisions', 'overview');
        await Promise.all([loadResource('revisions', true), loadOverview(true)]);
        renderChrome();
        revisionsModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.planCheckout) {
    checkoutModal(el.dataset.planCheckout);
    return;
} if (el.dataset.orderSubmit !== undefined) {
    await submitOrder();
    return;
} if (el.dataset.orderDetail) {
    await orderDetailModal(el.dataset.orderDetail);
    return;
} if (el.dataset.orderResubmit) {
    orderResubmitModal(el.dataset.orderResubmit);
    return;
} if (el.dataset.orderCancel) {
    setBusy(true);
    try {
        await action('vip_order_cancel', { order_id: el.dataset.orderCancel, reason: 'user_cancelled' }, false);
        invalidate('orders');
        await loadResource('orders', true);
        ordersModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.searchTarget) {
    const target = el.dataset.searchTarget;
    closeModal();
    if (target.startsWith('signal:'))
        await openSignal(target.split(':')[1]);
    else if (target.startsWith('ticket:'))
        await ticketDetail(target.split(':')[1]);
    else if (['orders', 'support', 'market', 'calendar', 'track', 'revisions'].includes(target))
        await openMore(target);
    else if (['home', 'signals', 'risk', 'journal', 'more'].includes(target))
        await navigate(target);
    return;
} if (el.dataset.ticketNew !== undefined) {
    ticketNewModal();
    return;
} if (el.dataset.ticketDetail) {
    await ticketDetail(el.dataset.ticketDetail);
    return;
} if (el.dataset.ticketReply) {
    const id = el.dataset.ticketReply, text = $('#ticketReply').value.trim();
    if (!text)
        return;
    setBusy(true);
    try {
        await action('ticket_reply', { ticket_id: id, text }, false);
        invalidate('tickets', 'overview');
        await Promise.all([loadResource('tickets', true), loadOverview(true)]);
        await ticketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.ticketStatus) {
    const id = el.dataset.ticketStatus, status = el.dataset.status;
    setBusy(true);
    try {
        await action('ticket_status_update', { ticket_id: id, status }, false);
        invalidate('tickets', 'overview');
        await Promise.all([loadResource('tickets', true), loadOverview(true)]);
        await ticketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.miniappToggle) {
    const enabled = el.dataset.miniappToggle === 'on';
    setBusy(true);
    try {
        await action('miniapp_runtime_toggle', { enabled, reason: 'admin_miniapp_workspace' }, false);
        closeModal();
        invalidate('overview', 'adminOps');
        await loadOverview(true);
        await adminWorkspace();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.integrationReconcile !== undefined) {
    setBusy(true);
    try {
        await action('integration_reconcile', { reason: 'admin_miniapp_workspace' }, false);
        invalidate('adminIntegration', 'signals', 'orders', 'market', 'overview');
        closeModal();
        await Promise.all([loadOverview(true), loadResource('adminIntegration', true)]);
        await adminWorkspace();
        toast(state.lang === 'fa' ? 'اطلاعات مشترک ربات و مینی‌اپ دوباره تطبیق داده شد.' : 'Bot and Mini App shared data reconciled.');
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.adminPayments !== undefined) {
    state.adminPaymentFilter = state.adminPaymentFilter || 'pending';
    await adminPaymentsModal(true);
    return;
} if (el.dataset.adminPaymentFilter) {
    state.adminPaymentFilter = el.dataset.adminPaymentFilter;
    await adminPaymentsModal(false);
    return;
} if (el.dataset.adminOrder) {
    await adminOrderDetail(el.dataset.adminOrder);
    return;
} if (el.dataset.adminOrderApprove) {
    setBusy(true);
    try {
        await action('payment_approve', { order_id: el.dataset.adminOrderApprove }, false);
        closeModal();
        invalidate('adminOrders', 'orders', 'overview');
        await Promise.all([loadOverview(true), loadResource('adminOrders', true)]);
        await adminPaymentsModal(false);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.adminOrderReject) {
    adminOrderRejectModal(el.dataset.adminOrderReject);
    return;
} if (el.dataset.adminTicket) {
    await adminTicketDetail(el.dataset.adminTicket);
    return;
} if (el.dataset.adminTicketReply) {
    const id = el.dataset.adminTicketReply, text = $('#adminTicketReply').value.trim();
    if (!text)
        return;
    setBusy(true);
    try {
        await action('ticket_admin_reply', { ticket_id: id, text }, false);
        invalidate('adminTickets', 'tickets', 'overview');
        await Promise.all([loadResource('adminTickets', true), loadOverview(true)]);
        await adminTicketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.adminTicketStatus) {
    const id = el.dataset.adminTicketStatus, status = el.dataset.status;
    setBusy(true);
    try {
        await action('ticket_admin_status_update', { ticket_id: id, status }, false);
        invalidate('adminTickets', 'tickets', 'overview');
        await Promise.all([loadResource('adminTickets', true), loadOverview(true)]);
        await adminTicketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.templateUpload) {
    await uploadSignalTemplate(el.dataset.templateUpload);
    return;
} if (el.dataset.templateReset) {
    await resetSignalTemplate(el.dataset.templateReset);
    return;
} if (el.dataset.adminAudit !== undefined) {
    await adminAuditModal();
    return;
} if (el.dataset.propTemplateNew !== undefined) {
    propTemplateCreateModal();
    return;
} if (el.dataset.adminHandoffNew !== undefined) {
    handoffCreateModal();
    return;
} if (el.dataset.handoffStatus) {
    setBusy(true);
    try {
        await action('shift_handoff_status_update', { handoff_id: el.dataset.handoffId, status: el.dataset.handoffStatus }, false);
        closeModal();
        invalidate('adminOps');
        await adminWorkspace();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.experimentNew !== undefined) {
    experimentCreateModal();
    return;
} if (el.dataset.experimentStatus) {
    setBusy(true);
    try {
        await action('experiment_status_update', { experiment_id: el.dataset.experimentId, status: el.dataset.experimentStatus }, false);
        closeModal();
        invalidate('adminExperiments');
        await adminWorkspace();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.languageToggle !== undefined) {
    toggleLanguage();
    closeModal();
    return;
} if (el.dataset.rulesAccept !== undefined) {
    setBusy(true);
    try {
        await action('rules_accept', { language: state.lang }, false);
        await loadOverview(true);
        closeModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.appReload !== undefined) {
    try {
        const reg = await navigator.serviceWorker?.getRegistration?.();
        await reg?.update?.();
    }
    catch { }
    location.reload();
    return;
} if (el.dataset.logout !== undefined) {
    await request('./api/v1/auth/logout', { method: 'POST' });
    try { for (const key of Object.keys(sessionStorage)) if (key.startsWith('sentinelDraft:') || key.startsWith('sentinelPending:')) sessionStorage.removeItem(key); } catch {}
    location.reload();
    return;
} }
function handleInput(e) { if (e.target.id === 'signalSearch') {
    state.signalQuery = e.target.value;
    clearTimeout(handleInput.timer);
    handleInput.timer = setTimeout(() => { invalidate('signals'); renderSignals(true); }, 320);
} if (e.target.id === 'journalSearch') {
    state.journalQuery = e.target.value;
    clearTimeout(handleInput.journalTimer);
    handleInput.journalTimer = setTimeout(() => { invalidate('journal'); renderJournal(true); }, 320);
} if (e.target.id === 'globalSearchInput') {
    clearTimeout(handleInput.searchTimer);
    handleInput.searchTimer = setTimeout(() => runGlobalSearch(e.target.value), 260);
} if (['asSymbol', 'asEntries', 'asTargets', 'asStop', 'asSide'].includes(e.target.id)) {
    clearTimeout(handleInput.adminQuoteTimer);
    handleInput.adminQuoteTimer = setTimeout(() => refreshAdminSignalQuote(true), 700);
} }
function bind() { document.addEventListener('click', handleClick); document.addEventListener('input', handleInput); window.addEventListener('pagehide', () => releaseTelegramNavigation(true), { capture: true }); window.addEventListener('beforeunload', () => releaseTelegramNavigation(true), { capture: true }); window.addEventListener('pageshow', () => { installTelegramNavigation(); syncTelegramNavigation(); }, { capture: true }); $('#refreshButton').addEventListener('click', async () => { setBusy(true); try {
    invalidate('overview', state.page, 'feed');
    await Promise.all([loadOverview(true), refreshFeed(false)]);
    if (state.page !== 'home')
        await loadResource(state.page, true);
    renderChrome();
    await navigate(state.page, false);
    toast(t('refreshDone'));
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }); $('#languageButton').addEventListener('click', toggleLanguage); $('#profileButton').addEventListener('click', settingsModal); $('#revisionButton').addEventListener('click', () => openMore('revisions')); window.addEventListener('online', () => { recoverConnection().catch(() => {}); }); window.addEventListener('offline', () => setConnection('offline')); document.addEventListener('visibilitychange', () => { if (document.hidden) releaseTelegramNavigation(true); else { installTelegramNavigation(); syncTelegramNavigation(); resumeBackgroundVideo(); } if (!document.hidden && state.online && !state.preview)
    syncActiveView().catch(() => { }); }); }
function registerSW() { if (!('serviceWorker' in navigator))
    return; window.addEventListener('load', async () => { try {
    const reg = await navigator.serviceWorker.register(`./sw.js?v=${encodeURIComponent(APP_VERSION)}`, { updateViaCache: 'none' });
    reg.update();
    if (reg.waiting)
        toast(state.lang === 'fa' ? 'نسخه جدید آماده است؛ برنامه را باز کنید.' : 'A new version is ready. Reopen the app.');
}
catch { } }); }
prepareMotionExperience();
bind();
registerSW();
bootstrap();
})();
