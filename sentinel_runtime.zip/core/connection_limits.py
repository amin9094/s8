from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import secrets
import time
from dataclasses import dataclass
from threading import RLock
from typing import Any
from weakref import WeakKeyDictionary

from config import SETTINGS
from core.runtime_topology import replica_count

LOGGER = logging.getLogger(__name__)
_LOCK = RLock()
_LOCAL: dict[str, dict[str, float]] = {}
_REDIS_CLIENT: Any | None = None
_REDIS_CLIENT_LOCK: asyncio.Lock | None = None
_REDIS_CLIENT_LOOP: Any | None = None
_REDIS_CLIENTS: WeakKeyDictionary = WeakKeyDictionary()
_REDIS_CLIENT_LOCKS: WeakKeyDictionary = WeakKeyDictionary()
_REDIS_SCRIPT_ACQUIRE = """
local tm = redis.call('TIME')
local now = tonumber(tm[1]) + tonumber(tm[2])/1000000
redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', now)
if redis.call('ZCARD', KEYS[1]) >= tonumber(ARGV[1]) then return 0 end
redis.call('ZADD', KEYS[1], now+tonumber(ARGV[2]), ARGV[3])
redis.call('EXPIRE', KEYS[1], tonumber(ARGV[2])+1)
return 1
"""
_REDIS_SCRIPT_RELEASE = """
return redis.call('ZREM', KEYS[1], ARGV[1])
"""


def _key(scope: str, value: str) -> str:
    digest = hashlib.sha256(value.encode()).hexdigest()[:32]
    return f"sentinel:connection-leases:{scope}:{digest}"


async def _redis() -> Any | None:
    global _REDIS_CLIENT, _REDIS_CLIENT_LOCK, _REDIS_CLIENT_LOOP
    if not SETTINGS.redis_url:
        return None
    loop = asyncio.get_running_loop()
    with _LOCK:
        client_lock = _REDIS_CLIENT_LOCKS.setdefault(loop, asyncio.Lock())
        _REDIS_CLIENT_LOCK = client_lock
        _REDIS_CLIENT_LOOP = loop
    # Compatibility aliases may be overwritten by another event-loop thread.
    # Synchronization and returned values must always use our local references.
    async with client_lock:
        with _LOCK:
            existing = _REDIS_CLIENTS.get(loop)
        if existing is not None:
            return existing
        try:
            import redis.asyncio as redis
            client = redis.Redis.from_url(
                SETTINGS.redis_url,
                decode_responses=True,
                socket_connect_timeout=1.5,
                socket_timeout=2.0,
                health_check_interval=30,
                max_connections=max(8, int(os.getenv("REDIS_MAX_CONNECTIONS", "64") or 64)),
            )
            with _LOCK:
                _REDIS_CLIENT = client
                _REDIS_CLIENTS[loop] = client
            return client
        except Exception:
            _REDIS_CLIENT = None
            return None


async def _discard_redis(client: Any) -> None:
    global _REDIS_CLIENT
    loop = asyncio.get_running_loop()
    with _LOCK:
        if client is _REDIS_CLIENT:
            _REDIS_CLIENT = None
        if _REDIS_CLIENTS.get(loop) is client:
            _REDIS_CLIENTS.pop(loop, None)
    try:
        await client.aclose()
    except Exception:
        LOGGER.debug("Redis connection-limit client close failed", exc_info=True)


async def close_connection_limit_client() -> None:
    global _REDIS_CLIENT
    with _LOCK:
        client = _REDIS_CLIENTS.pop(asyncio.get_running_loop(), None)
        if client is _REDIS_CLIENT:
            _REDIS_CLIENT = None
    if client is not None:
        try:
            await client.aclose()
        except Exception:
            LOGGER.debug("Redis connection-limit client close during shutdown failed", exc_info=True)


@dataclass
class ConnectionLease:
    keys: tuple[str, ...]
    redis_client: Any | None = None
    released: bool = False
    token: str = ""

    async def release(self) -> None:
        if self.released:
            return
        self.released = True
        if self.redis_client is not None:
            for key in self.keys:
                try:
                    await self.redis_client.eval(_REDIS_SCRIPT_RELEASE, 1, key, self.token)
                except Exception:
                    LOGGER.debug("Redis connection-limit release failed for %s", key, exc_info=True)
            return
        with _LOCK:
            for key in self.keys:
                owners = _LOCAL.get(key, {})
                owners.pop(self.token, None)
                if not owners:
                    _LOCAL.pop(key, None)


async def acquire_connection_limits(limits: tuple[tuple[str, str, int], ...], *, ttl_seconds: int = 90) -> ConnectionLease | None:
    """Atomically-ish acquire bounded connection counters.

    Redis makes limits shared across replicas. The local fallback is bounded and
    used only for development or explicitly allowed single-replica staging.
    """
    token = secrets.token_urlsafe(24)
    normalized = tuple((_key(scope, value), max(1, int(limit))) for scope, value, limit in limits)
    client = await _redis()
    acquired: list[str] = []
    if client is not None:
        try:
            for key, limit in normalized:
                result = int(await client.eval(_REDIS_SCRIPT_ACQUIRE, 1, key, limit, max(10, ttl_seconds), token))
                if result <= 0:
                    for previous in acquired:
                        await client.eval(_REDIS_SCRIPT_RELEASE, 1, previous, token)
                    return None
                acquired.append(key)
            return ConnectionLease(tuple(acquired), redis_client=client, token=token)
        except BaseException as error:
            for previous in acquired:
                try:
                    await client.eval(_REDIS_SCRIPT_RELEASE, 1, previous, token)
                except Exception:
                    LOGGER.debug("Redis connection-limit rollback failed for %s", previous, exc_info=True)
            if isinstance(error, asyncio.CancelledError):
                raise
            await _discard_redis(client)
            replicas = replica_count()
            if (
                replicas > 1
                and os.getenv("ALLOW_LOCAL_RATE_LIMIT", "false").lower()
                not in {"1", "true", "yes", "on"}
            ):
                return None
    if client is None and replica_count() > 1 and os.getenv('ALLOW_LOCAL_RATE_LIMIT','false').lower() not in {'true','1','yes','on'}:
        return None
    now = time.monotonic()
    with _LOCK:
        for key, owners in list(_LOCAL.items()):
            for owner, expiry in list(owners.items()):
                if expiry <= now: owners.pop(owner, None)
            if not owners: _LOCAL.pop(key, None)
        if len(_LOCAL) + len({key for key, _ in normalized if key not in _LOCAL}) > 20000: return None
        if any(len(_LOCAL.get(key, {})) >= limit for key, limit in normalized): return None
        for key, _ in normalized:
            _LOCAL.setdefault(key, {})[token] = now + max(10, ttl_seconds)
    return ConnectionLease(tuple(key for key, _ in normalized), token=token)


def reset_connection_limits_for_tests() -> None:
    global _REDIS_CLIENT
    _REDIS_CLIENT = None
    with _LOCK:
        _REDIS_CLIENTS.clear()
        _LOCAL.clear()
