/* Calm, data-driven trading workspace. No fabricated performance charts. */
const WORKSPACE_COPY = {
    fa: { title:'میز معامله‌گری', subtitle:'تصمیم روشن، ریسک مشخص، اجرای منظم.', portfolio:'نمای حساب', equity:'ارزش حساب', balance:'موجودی', capacity:'ظرفیت ریسک امروز', positions:'معامله باز', signals:'رصد سیگنال‌ها', journal:'مرور ژورنال', risk:'برنامه ریسک', tools:'ابزارهای روزانه', activity:'آخرین سیگنال‌ها', performance:'روند عملکرد', noHistory:'پس از ثبت معاملات، روند واقعی عملکرد اینجا نمایش داده می‌شود.', unknown:'هنوز داده‌ای ثبت نشده', account:'انتخاب یا افزودن حساب', unavailable:'داده در دسترس نیست', updated:'براساس آخرین اطلاعات دریافت‌شده', summary:'خلاصه امروز', calendar:'تقویم اقتصادی', market:'بازار و واچ‌لیست', calculator:'محاسبه حجم', support:'پشتیبانی', admin:'مرکز مدیریت', search:'جست‌وجو', day:'روز معاملاتی', riskUsed:'ریسک مصرف‌شده', noAccount:'برای مشاهده وضعیت مالی، حساب معامله‌گری خود را اضافه کنید.' },
    en: { title:'Trading workspace', subtitle:'Clear decisions. Defined risk. Disciplined execution.', portfolio:'Account overview', equity:'Account equity', balance:'Balance', capacity:'Daily risk capacity', positions:'Open positions', signals:'Watch signals', journal:'Review journal', risk:'Risk plan', tools:'Daily tools', activity:'Latest signals', performance:'Performance history', noHistory:'Your actual performance history appears here after trades are recorded.', unknown:'No recorded data yet', account:'Select or add account', unavailable:'Data unavailable', updated:'Based on the latest received data', summary:'Today at a glance', calendar:'Economic calendar', market:'Market & watchlist', calculator:'Position sizing', support:'Support', admin:'Administration', search:'Search', day:'Trading day', riskUsed:'Risk used', noAccount:'Add a trading account to see your financial overview.' }
};
function workspaceCopy() { return WORKSPACE_COPY[state.lang] || WORKSPACE_COPY.en; }
function workspaceNumber(value, suffix = '') { return value == null || !Number.isFinite(Number(value)) ? '—' : `${num(Number(value), 2)}${suffix}`; }
function workspaceHistory(values) {
    const w = workspaceCopy();
    if (!values.length) return `<div class="workspace-history-empty">${icon('chart')}<p>${esc(w.noHistory)}</p></div>`;
    const width = 600, height = 112, min = Math.min(...values), max = Math.max(...values), span = max - min || 1;
    const points = values.map((v, i) => `${16 + i * (width-32)/Math.max(1,values.length-1)},${height-14-(v-min)/span*(height-28)}`).join(' ');
    return `<svg class="workspace-history" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(w.performance)}"><path d="M16 28H584 M16 56H584 M16 84H584" class="chart-grid"/><polyline points="${points}" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
}
renderHome = function () {
    const w = workspaceCopy(), o = state.resources.overview || {}, risk = o.risk || {}, exposure = risk.account_exposure || {}, account = risk.default_account || {}, journal = o.journal_stats || {};
    const hasAccount = Boolean(account.id), currency = String(account.currency || 'USD');
    const series = Array.isArray(journal.equity_curve) ? journal.equity_curve : [];
    const curve = series.filter(p => p != null).map(p => Number(p.value ?? p)).filter(Number.isFinite).slice(-60);
    const remainingRisk = exposure.remaining_daily_risk_percent ?? risk.exposure?.remaining_daily_risk_percent ?? risk.prop?.daily_loss_remaining_percent;
    const dateLabel = new Intl.DateTimeFormat(state.lang === 'fa' ? 'fa-IR' : 'en-GB', { dateStyle:'long', timeZone:'Asia/Tehran' }).format(new Date());
    $('#page-home').innerHTML = `
    <header class="workspace-heading"><div><span class="eyebrow">SENTINEL / WORKSPACE</span><h1>${esc(w.title)}</h1><p>${esc(w.subtitle)}</p></div><button class="button secondary" data-open="search">${icon('search')}<span>${esc(w.search)}</span></button></header>
    <div class="workspace-date"><span>${esc(dateLabel)}</span><span>${esc(w.updated)} · ${date(o.generated_at)}</span></div>
    <section class="panel home-services"><div class="panel-head"><h2>${esc(state.lang==='fa'?'دسترسی سریع':'Quick access')}</h2><button class="button ghost small" data-page-target="more">${esc(state.lang==='fa'?'تمام خدمات':'All services')}${icon('chevron')}</button></div><div class="panel-body">${userMenuHtml(true).replace('class="user-menu-grid"','class="user-menu-grid" data-compact="true"')}</div></section>
    ${todayActionsHtml(o.today_actions || [])}
    <div class="workspace-layout">
      <section class="panel workspace-account"><div class="panel-head"><div><span class="eyebrow">${esc(w.portfolio)}</span><h2>${esc(account.name || w.account)}</h2></div><button class="icon-button touch" data-page-target="risk" aria-label="${esc(w.account)}">${icon('chevron')}</button></div>
        <div class="panel-body"><div class="workspace-equity"><span>${esc(w.equity)}</span><strong dir="ltr">${workspaceNumber(hasAccount ? account.equity : null)} <small>${esc(currency)}</small></strong></div>
        ${!hasAccount ? `<p class="workspace-muted">${esc(w.noAccount)}</p>` : ''}
        <div class="workspace-metrics"><div><span>${esc(w.balance)}</span><strong dir="ltr">${workspaceNumber(hasAccount ? account.balance : null)}</strong></div><div><span>${esc(w.capacity)}</span><strong dir="ltr">${workspaceNumber(hasAccount ? remainingRisk : null, '%')}</strong></div><div><span>${esc(w.positions)}</span><strong>${hasAccount && exposure.open_trades != null ? num(exposure.open_trades,0) : '—'}</strong></div></div>
        <div class="workspace-chart-head"><span>${esc(w.performance)}</span><span>${curve.length ? esc(currency) : '—'}</span></div>${workspaceHistory(curve)}
        <div class="workspace-actions"><button class="button primary" data-page-target="risk">${icon('shield')}${esc(w.risk)}</button><button class="button secondary" data-page-target="journal">${icon('journal')}${esc(w.journal)}</button></div></div>
      </section>
      <aside class="panel workspace-tools"><div class="panel-head"><div><span class="eyebrow">ESSENTIALS</span><h2>${esc(w.tools)}</h2></div></div><div class="panel-body">
      ${[['market','market','market'],['calendar','calendar','calendar'],['chart','calculator','calculator'],['support','support','tickets']].map(([ic,label,target])=>`<button class="workspace-tool" data-open="${target}">${icon(ic)}<span>${esc(w[label])}</span>${icon('chevron')}</button>`).join('')}
      <button class="workspace-tool workspace-signal-link" data-page-target="signals">${icon('signal')}<span>${esc(w.signals)}</span><b>${o.account?.active_signals == null ? '—' : num(o.account.active_signals,0)}</b></button>
      </div></aside>
    </div>
    <section class="panel workspace-signals"><div class="panel-head"><div><span class="eyebrow">SIGNAL DESK</span><h2>${esc(w.activity)}</h2></div><button class="button ghost" data-page-target="signals">${esc(t('viewAll'))}${icon('chevron')}</button></div><div class="panel-body signal-list">${(o.recent_signals || []).slice(0,4).map(signalCard).join('') || empty()}</div></section>`;
    if (state.lang === 'en') localizeUiTree($('#page-home'));
};
