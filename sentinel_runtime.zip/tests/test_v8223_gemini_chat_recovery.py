from __future__ import annotations

import json
from pathlib import Path

import pytest

from modules import gemini_ai
from services import ai_control_service

ROOT = Path(__file__).resolve().parents[1]
ADMIN_ID = 354678485


def _provider_payload(*, tool_calls=None) -> dict:
    return {
        "text": json.dumps(
            {
                "answer": "تیکت‌های اخیر بررسی شدند.",
                "findings": ["۲ تیکت باز است"],
                "recommended_actions": [],
                "tool_calls": tool_calls or [],
            },
            ensure_ascii=False,
        ),
        "model": "gemini-test",
        "usage": {"totalTokenCount": 42},
    }


def _patch_common(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        gemini_ai,
        "admin_ai_context",
        lambda *_args, **_kwargs: {
            "scope": "tickets",
            "tickets": {
                "total": 2,
                "statuses": {"open": 2},
                "priorities": {"normal": 2},
                "sample": [],
            },
        },
    )
    monkeypatch.setattr(gemini_ai, "ai_execution_settings", lambda: {"execution_enabled": True})
    monkeypatch.setattr(gemini_ai, "operational_tool_catalog", lambda: [])
    monkeypatch.setattr(
        gemini_ai,
        "_record_ai_result",
        lambda **_kwargs: {"conversation": {"id": 701}, "proposals": []},
    )
    monkeypatch.setattr(gemini_ai, "_update_ai_conversation_execution", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(gemini_ai, "gemini_status", lambda: {"configured": True, "reachable": True})


def test_malformed_model_tool_call_is_dropped_without_losing_answer(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_common(monkeypatch)
    monkeypatch.setattr(
        gemini_ai,
        "_gemini_request",
        lambda *_args, **_kwargs: _provider_payload(
            tool_calls=[
                {
                    "action": "ticket_admin_reply",
                    "payload": {"ticket_id": "ticket_missing_text"},
                    "reason": "مدل فیلد متن را جا انداخته است",
                    "risk": "reversible",
                }
            ]
        ),
    )
    monkeypatch.setattr(
        ai_control_service,
        "execute_or_queue_ai_tool_calls",
        lambda *_args, **_kwargs: {"mode": "analysis_only", "executions": [], "queued": [], "tool_calls": []},
    )

    result = gemini_ai.admin_ai_query(ADMIN_ID, "تیکت‌های اخیر را بررسی کن", scope="tickets")

    assert result["answer"] == "تیکت‌های اخیر بررسی شدند."
    assert result["tool_calls"] == []
    assert len(result["rejected_tool_calls"]) == 1
    assert result["execution"]["mode"] == "analysis_only"


def test_execution_pipeline_failure_is_contained_and_answer_is_returned(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_common(monkeypatch)
    monkeypatch.setattr(gemini_ai, "_gemini_request", lambda *_args, **_kwargs: _provider_payload())
    monkeypatch.setattr(
        ai_control_service,
        "execute_or_queue_ai_tool_calls",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(TypeError("unexpected execution backend mismatch")),
    )

    result = gemini_ai.admin_ai_query(ADMIN_ID, "تیکت‌های اخیر را بررسی کن", scope="tickets")

    assert result["answer"] == "تیکت‌های اخیر بررسی شدند."
    assert result["execution"]["mode"] == "execution_recovery"
    assert result["execution"]["retryable"] is True
    assert len(result["execution"]["error_ref"]) == 10


def test_persistence_failure_does_not_crash_gemini_chat(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_common(monkeypatch)
    monkeypatch.setattr(gemini_ai, "_gemini_request", lambda *_args, **_kwargs: _provider_payload())
    monkeypatch.setattr(
        gemini_ai,
        "_record_ai_result",
        lambda **_kwargs: (_ for _ in ()).throw(OSError("temporary database write failure")),
    )
    monkeypatch.setattr(
        ai_control_service,
        "execute_or_queue_ai_tool_calls",
        lambda *_args, **_kwargs: {"mode": "analysis_only", "executions": [], "queued": [], "tool_calls": []},
    )

    result = gemini_ai.admin_ai_query(ADMIN_ID, "تیکت‌های اخیر را بررسی کن", scope="tickets")

    assert result["answer"] == "تیکت‌های اخیر بررسی شدند."
    assert result["conversation_id"] == 0
    assert len(result["persistence_error_ref"]) == 10


def test_ticket_recovery_response_contains_recent_ticket_summary(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        gemini_ai,
        "admin_ai_context",
        lambda *_args, **_kwargs: {
            "scope": "tickets",
            "tickets": {
                "total": 3,
                "statuses": {"open": 2, "closed": 1},
                "priorities": {"high": 1, "normal": 2},
                "sample": [
                    {
                        "ticket_id": "ticket_AB12",
                        "subject": "مشکل ورود",
                        "status": "open",
                        "created_at": "2026-07-30T09:00:00+00:00",
                    }
                ],
            },
        },
    )
    monkeypatch.setattr(gemini_ai, "gemini_status", lambda: {"reachable": False})

    result = gemini_ai.admin_ai_recovery_response(
        ADMIN_ID,
        "تیکت‌های اخیر را بررسی کن",
        scope="tickets",
        error_ref="ABCDEF1234",
    )

    assert "کل تیکت‌ها: 3" in result["answer"]
    assert "تیکت‌های باز یا نیازمند پیگیری: 2" in result["answer"]
    assert "ticket_AB12" in result["answer"]
    assert result["execution"]["mode"] == "recovery_analysis_only"
    assert result["recovered"] is True


def test_telegram_ai_router_has_local_recovery_instead_of_global_error() -> None:
    source = (ROOT / "bot_runtime" / "platform_expansion.py").read_text(encoding="utf-8")
    router = source[source.index("async def ai_chat_message_router"):source.index("async def ai_chat_stop")]
    assert "except Exception" in router
    assert "admin_ai_recovery_response" in router
    assert 'return "AI_CHAT_INPUT"' in router
    assert "Gemini in-bot chat recovered" in router


def test_primary_admin_ticket_request_is_routed_to_ticket_scope(monkeypatch: pytest.MonkeyPatch) -> None:
    from bot_runtime import platform_expansion

    monkeypatch.setattr(platform_expansion, "is_primary_admin", lambda _actor_id: True)
    assert platform_expansion._infer_primary_admin_ai_scope(
        "تیکت ها اخیر بررسی کن", "management", ADMIN_ID
    ) == "tickets"


def test_delegated_admin_is_not_auto_routed_across_scopes(monkeypatch: pytest.MonkeyPatch) -> None:
    from bot_runtime import platform_expansion

    monkeypatch.setattr(platform_expansion, "is_primary_admin", lambda _actor_id: False)
    assert platform_expansion._infer_primary_admin_ai_scope(
        "تیکت های اخیر را بررسی کن", "management", 998877
    ) == "management"


def test_global_error_handler_uses_ai_specific_recovery_message() -> None:
    source = (ROOT / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    handler = source[source.index("async def error_handler"):source.index("async def unknown_callback")]
    assert 'context.user_data.get("sentinel_ai_chat")' in handler
    assert "گفت‌وگوی Gemini همچنان فعال است" in handler
    assert "عملیات ذخیره شد" not in handler
