#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _truthy(name: str, default: bool = False) -> bool:
    raw = str(os.getenv(name, "true" if default else "false")).strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _database_fingerprint(database_url: str) -> str:
    parsed = urlsplit(database_url)
    database = parsed.path.lstrip("/")
    canonical = f"{(parsed.hostname or '').lower()}:{parsed.port or 5432}/{database}"
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:32]


def _verify_remote_backup(reference: str, checksum: str) -> dict[str, str | int]:
    """Verify that the attested backup exists and is non-empty.

    A matching remote SHA-256 metadata value is enforced when present. Operators
    can require such metadata with MIGRATION_BACKUP_REQUIRE_REMOTE_CHECKSUM=true.
    """
    if not _truthy("MIGRATION_BACKUP_VERIFY_REMOTE", True):
        return {"verification": "disabled"}
    parsed = urlsplit(reference)
    require_remote_checksum = _truthy("MIGRATION_BACKUP_REQUIRE_REMOTE_CHECKSUM", False)
    metadata_checksum = ""
    size = 0
    if parsed.scheme == "https":
        request = Request(reference, method="HEAD", headers={"User-Agent": "sentinel-migration-preflight/1"})
        timeout = max(2, min(60, int(os.getenv("MIGRATION_BACKUP_VERIFY_TIMEOUT_SECONDS", "15") or 15)))
        with urlopen(request, timeout=timeout) as response:  # nosec B310 -- validated HTTPS only
            status = int(getattr(response, "status", 0) or 0)
            if status < 200 or status >= 300:
                raise RuntimeError(f"migration backup HEAD returned HTTP {status}")
            size = int(response.headers.get("Content-Length") or 0)
            metadata_checksum = str(
                response.headers.get("X-Sentinel-SHA256")
                or response.headers.get("X-Amz-Meta-Sha256")
                or response.headers.get("X-Checksum-Sha256")
                or ""
            ).strip().lower()
    elif parsed.scheme == "s3":
        bucket = str(parsed.netloc or "").strip()
        key = str(parsed.path or "").lstrip("/")
        if not bucket or not key:
            raise RuntimeError("s3 migration backup reference must include bucket and object key")
        import boto3
        from botocore.config import Config
        timeout = max(2, min(30, int(os.getenv("MIGRATION_BACKUP_VERIFY_TIMEOUT_SECONDS", "15") or 15)))
        kwargs: dict[str, object] = {"config": Config(connect_timeout=timeout, read_timeout=timeout, retries={"mode": "standard", "total_max_attempts": 3})}
        region = str(os.getenv("BACKUP_S3_REGION") or os.getenv("AWS_REGION") or "").strip()
        if region:
            kwargs["region_name"] = region
        endpoint = str(os.getenv("BACKUP_S3_ENDPOINT") or "").strip()
        if endpoint:
            if not endpoint.startswith("https://") and (urlsplit(endpoint).hostname or "").lower() not in {"localhost", "127.0.0.1", "::1", "minio"}:
                raise RuntimeError("BACKUP_S3_ENDPOINT must use HTTPS")
            kwargs["endpoint_url"] = endpoint
        response = boto3.client("s3", **kwargs).head_object(Bucket=bucket, Key=key)
        size = int(response.get("ContentLength") or 0)
        metadata = response.get("Metadata") if isinstance(response.get("Metadata"), dict) else {}
        metadata_checksum = str((metadata or {}).get("sha256") or "").strip().lower()
    else:
        raise RuntimeError("unsupported migration backup reference")
    if size <= 0:
        raise RuntimeError("migration backup is empty or Content-Length is unavailable")
    if metadata_checksum and metadata_checksum != checksum:
        raise RuntimeError("remote migration backup checksum metadata does not match MIGRATION_BACKUP_SHA256")
    if require_remote_checksum and not metadata_checksum:
        raise RuntimeError("remote migration backup does not expose required SHA-256 metadata")
    return {"verification": "reachable", "size_bytes": size, "metadata_sha256": metadata_checksum}


def _validate_backup_attestation(database_url: str) -> dict[str, object]:
    reference = str(os.getenv("MIGRATION_BACKUP_REFERENCE") or "").strip()
    checksum = str(os.getenv("MIGRATION_BACKUP_SHA256") or "").strip().lower()
    created_raw = str(os.getenv("MIGRATION_BACKUP_CREATED_AT") or "").strip()
    supplied_fingerprint = str(os.getenv("MIGRATION_BACKUP_DATABASE_FINGERPRINT") or "").strip().lower()
    if not reference:
        raise RuntimeError("MIGRATION_BACKUP_REFERENCE is required before importing legacy PostgreSQL data")
    parsed = urlsplit(reference)
    if parsed.scheme not in {"https", "s3"}:
        raise RuntimeError("MIGRATION_BACKUP_REFERENCE must use https:// or s3://")
    if not re.fullmatch(r"[0-9a-f]{64}", checksum):
        raise RuntimeError("MIGRATION_BACKUP_SHA256 must contain the verified 64-character backup checksum")
    try:
        created = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
        if created.tzinfo is None:
            created = created.replace(tzinfo=UTC)
        created = created.astimezone(UTC)
    except ValueError as exc:
        raise RuntimeError("MIGRATION_BACKUP_CREATED_AT must be an ISO-8601 timestamp") from exc
    now = datetime.now(UTC)
    max_age_hours = max(1, min(720, int(os.getenv("MIGRATION_BACKUP_MAX_AGE_HOURS", "72") or 72)))
    age_seconds = (now - created).total_seconds()
    if age_seconds < -300 or age_seconds > max_age_hours * 3600:
        raise RuntimeError("Migration backup is outside the permitted freshness window")
    expected_fingerprint = _database_fingerprint(database_url)
    if not supplied_fingerprint or supplied_fingerprint != expected_fingerprint:
        raise RuntimeError("MIGRATION_BACKUP_DATABASE_FINGERPRINT does not match DATABASE_URL")
    remote = _verify_remote_backup(reference, checksum)
    return {
        "reference": reference,
        "sha256": checksum,
        "created_at": created.isoformat(),
        "database_fingerprint": expected_fingerprint,
        "remote": remote,
    }


def _run_once() -> int:
    # Railway pre-deploy containers do not mount Volumes. Only shared PostgreSQL
    # migrations belong here; SQLite-volume migration remains in startup.
    database_url = str(os.getenv("DATABASE_URL") or os.getenv("POSTGRES_URL") or "").strip()
    if not database_url:
        print("PREDEPLOY MIGRATION SKIPPED: DATABASE_URL is not configured")
        return 0
    from core.storage.engine import normalized_engine
    from core.storage.migration import legacy_source_summary, migrate_legacy_state, migration_status

    engine = normalized_engine()
    engine.ensure_schema()
    before = migration_status(engine)
    source_summary = legacy_source_summary()
    legacy_records = sum(source_summary.values())
    backup_attestation: dict[str, object] | None = None
    if not before.get("complete") and legacy_records > 0 and _truthy("REQUIRE_MIGRATION_BACKUP_REFERENCE", True):
        backup_attestation = _validate_backup_attestation(database_url)
    result = migrate_legacy_state(engine)
    after = migration_status(engine)
    if not after.get("complete"):
        raise RuntimeError("migration marker was not committed")
    from scripts.vip_database_integrity import audit_database
    integrity = audit_database(engine, repair_safe=True, project_legacy=True)
    if not integrity.get("healthy"):
        raise RuntimeError(
            "VIP database integrity preflight failed: "
            + json.dumps(integrity.get("issues", [])[:20], ensure_ascii=False, default=str)
        )
    print(json.dumps({
        "ok": True,
        "at": datetime.now(UTC).isoformat(),
        "before": before,
        "source_summary": source_summary,
        "backup_attestation": backup_attestation,
        "result": result,
        "after": after,
        "vip_database_integrity": integrity,
    }, ensure_ascii=False, default=str))
    return 0



def _retryable_predeploy_error(exc: BaseException) -> bool:
    """Return True only for transient connectivity/provider failures."""
    seen: set[int] = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, (TimeoutError, ConnectionError, OSError)):
            return True
        name = current.__class__.__name__.lower()
        message = str(current).lower()
        if any(token in name for token in (
            "operationalerror", "pooltimeout", "connectiontimeout", "connecterror",
            "networkerror", "readtimeout", "writetimeout", "serverdisconnected",
        )):
            return True
        if any(token in message for token in (
            "could not connect", "connection refused", "connection reset",
            "connection timed out", "connection timeout", "server closed the connection",
            "temporary failure in name resolution", "name or service not known",
            "network is unreachable", "connection pool timeout",
        )):
            return True
        current = current.__cause__ or current.__context__
    return False


def main() -> int:
    attempts = max(1, min(8, int(os.getenv("PREDEPLOY_MAX_ATTEMPTS", "5") or 5)))
    base_delay = max(0.25, min(5.0, float(os.getenv("PREDEPLOY_RETRY_BASE_SECONDS", "1") or 1)))
    for attempt in range(1, attempts + 1):
        try:
            return _run_once()
        except Exception as exc:
            if attempt >= attempts or not _retryable_predeploy_error(exc):
                raise
            delay = min(12.0, base_delay * (2 ** (attempt - 1)))
            print(
                f"PREDEPLOY transient failure attempt {attempt}/{attempts}: "
                f"{exc.__class__.__name__}: {str(exc)[:300]}; retrying in {delay:.1f}s",
                file=sys.stderr,
                flush=True,
            )
            import time
            time.sleep(delay)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
