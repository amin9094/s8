from __future__ import annotations

import re
from pathlib import Path

from tests.telegram_test_stub import install as install_telegram_test_stub
install_telegram_test_stub()

from core import miniapp_server
from services.actions_v2 import action_specs

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "webapp" / "src"


def _sources() -> str:
    return "\n".join(path.read_text(encoding="utf-8") for path in sorted(SRC.glob("*.js")))


def test_every_frontend_action_is_registered_by_backend() -> None:
    source = _sources()
    called = set(re.findall(r"\baction\(\s*['\"]([A-Za-z0-9_:-]+)['\"]", source))
    registered = set(action_specs())
    assert called
    assert called <= registered, sorted(called - registered)


def test_every_literal_frontend_api_path_has_backend_route() -> None:
    source = _sources()
    paths = set(re.findall(r"(?:request|fetch)\(\s*[`'\"]\.?(/api/v1/[A-Za-z0-9_./{}-]+)", source))
    app = miniapp_server.create_app()
    backend = {getattr(route, "path", "") for route in app.routes}

    def normalized(path: str) -> str:
        # Frontend dynamic ids are interpolated and therefore end before ${};
        # compare their stable route prefix to the registered parameter route.
        return path.rstrip("/")

    unresolved = []
    for path in paths:
        stable = normalized(path)
        if stable in backend:
            continue
        if any(route.startswith(stable + "/{") or stable.startswith(route.split("/{", 1)[0] + "/") for route in backend if "/{" in route):
            continue
        unresolved.append(path)
    assert not unresolved, sorted(unresolved)


def test_no_frontend_calls_removed_legacy_endpoints() -> None:
    source = _sources()
    assert "./api/dashboard" not in source
    assert "./api/action" not in source
    assert '"/api/dashboard"' not in source
    assert '"/api/action"' not in source


def test_market_watchlist_journal_and_price_tracker_are_linked() -> None:
    source = _sources()
    required = {
        "watchlist_toggle",
        "journal_add",
        "journal_result_update",
        "journal_delete",
        "/api/v1/market",
        "/api/v1/market/quote",
        "/api/v1/journal",
        "/api/v1/journal/export.pdf",
    }
    missing = {item for item in required if item not in source}
    assert not missing, sorted(missing)
    # Enriched backend watchlist quote must win over a stale local lookup.
    commerce = (SRC / "commerce-support.js").read_text(encoding="utf-8")
    assert "w.quote||[...quotes,...iran].find" in commerce.replace(" ", "")


def test_built_assets_and_service_worker_reference_current_bundle() -> None:
    index = (ROOT / "webapp" / "index.html").read_text(encoding="utf-8")
    manifest = (ROOT / "webapp" / "manifest.webmanifest").read_text(encoding="utf-8")
    sw = (ROOT / "webapp" / "sw.js").read_text(encoding="utf-8")
    assets = list((ROOT / "webapp" / "assets").glob("app.*.js"))
    styles = list((ROOT / "webapp" / "assets").glob("app.*.css"))
    assert len(assets) == 1
    assert len(styles) == 1
    assert assets[0].name in index and assets[0].name in sw
    assert styles[0].name in index and styles[0].name in sw
    assert "SENTINEL" in manifest


def test_signal_tracker_renders_all_three_information_sections() -> None:
    source = (ROOT / "webapp" / "src" / "signals-home.js").read_text(encoding="utf-8")
    assert "nearby_news_meta" in source
    assert "ALL_RISK_CHECKS_PASSED" in source
    assert "TRADING_ACCOUNT_REQUIRED" in source
    assert "revision_chain_valid" in source
    assert "evidence_hash" in source
    assert "Economic calendar is not synced yet" in source


def test_account_form_templates_and_session_recovery_are_wired() -> None:
    core = (SRC / "core.js").read_text(encoding="utf-8")
    risk = (SRC / "risk-journal.js").read_text(encoding="utf-8")
    read_service = (ROOT / "services" / "miniapp_read_service_v2.py").read_text(encoding="utf-8")
    server = (ROOT / "core" / "miniapp_server.py").read_text(encoding="utf-8")
    assert "renewAuthenticatedSession" in core
    assert "['UNAUTHORIZED', 'CSRF_INVALID']" in core
    assert "authRecovery: false" in core
    assert "accountRuleTemplates" in risk
    assert 'id="accRuleTemplate" required' in risk
    assert '"prop_templates": templates' in read_service
    assert 'WEBAPP_AUTH_MAX_AGE_SECONDS", "86400"' in server
