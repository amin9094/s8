from __future__ import annotations

from types import SimpleNamespace

import pytest

def _runtime():
    from telegram.ext import ConversationHandler
    from bot_runtime import navigation
    from ui.button_factory import InlineKeyboardButton, state_button

    return ConversationHandler, navigation, InlineKeyboardButton, state_button


def _inline_buttons(rows):
    return [button for row in rows for button in row]


def test_legacy_reply_keyboard_is_removed_for_user_and_admin(monkeypatch):
    _, navigation, _, _ = _runtime()
    monkeypatch.setattr(navigation, "_language_for_user", lambda _uid: "fa")

    for user_id in (123, 999):
        markup = navigation.quick_access_keyboard(user_id)
        assert markup.remove_keyboard is True
        assert markup.selective is True


def test_main_menu_matches_current_unified_layout(monkeypatch):
    _, navigation, _, _ = _runtime()
    monkeypatch.setattr(navigation, "_language_for_user", lambda _uid: "fa")
    monkeypatch.setattr(navigation, "is_vip", lambda *_args: False)
    monkeypatch.setattr(navigation, "load_db", lambda: {})
    monkeypatch.setattr(navigation, "_visible_user_items", lambda _db, items: items)
    monkeypatch.setattr(navigation, "_is_any_admin", lambda _uid: False)
    monkeypatch.setattr(navigation, "_has_any_admin_permission", lambda *_args, **_kwargs: False)
    monkeypatch.setattr(navigation, "with_webapp", lambda rows: rows)

    rows = navigation.main_menu(123)
    buttons = _inline_buttons(rows)
    by_callback = {button.callback_data: button for button in buttons if button.callback_data}

    assert by_callback["u_vip"].style == "success"
    assert by_callback["u_vip"].text.startswith("💎")
    assert "🟡" not in by_callback["u_vip"].text
    assert by_callback["u_account"].style is None
    assert by_callback["nav_user:trade"].style == "primary"
    assert by_callback["u_edu"].style is None
    assert by_callback["u_price"].style is None
    assert by_callback["u_calc"].style is None
    assert by_callback["language_menu"].text == "🌐 زبان"
    assert "u_ai_chat_start" not in by_callback
    assert [button.callback_data for button in rows[0]] == ['u_vip']
    assert [button.callback_data for button in rows[1]] == ['u_edu', 'u_calc']
    assert [button.callback_data for button in rows[2]] == ['u_price', 'u_account']
    assert [button.callback_data for button in rows[3]] == ['u_contests', 'u_missions']
    assert {'u_today','nav_user:tools','nav_user:support','learning_rules'} <= set(by_callback)
    assert {"u_referral", "u_rewards", "u_settings", "u_signal_portal"} <= set(by_callback)
    assert "account_rewards" not in by_callback
    assert "u_challenges" not in by_callback
    assert "cancel_current" not in by_callback
    assert "restart_bot" not in by_callback
    assert "u_support" in by_callback


@pytest.mark.asyncio
async def test_cancel_keyboard_button_clears_flow_and_returns_menu(monkeypatch):
    ConversationHandler, navigation, _, _ = _runtime()
    calls = []

    async def fake_cancel(update, context):
        calls.append((update, context))
        return ConversationHandler.END

    monkeypatch.setattr(navigation, "cancel_command", fake_cancel)
    monkeypatch.setattr(navigation, "_language_for_user", lambda _uid: "fa")
    update = SimpleNamespace(
        effective_user=SimpleNamespace(id=1),
        effective_message=SimpleNamespace(text=navigation.CANCEL_OPERATION_BUTTON_FA),
    )
    context = SimpleNamespace(user_data={})

    result = await navigation.keyboard_shortcut_button(update, context)
    assert result == ConversationHandler.END
    assert len(calls) == 1


def test_native_button_theme_contract():
    _, _, InlineKeyboardButton, state_button = _runtime()
    enabled = state_button("Feature", True, callback_data="feature_toggle")
    disabled = state_button("Feature", False, callback_data="feature_toggle")
    account = InlineKeyboardButton("My accounts", callback_data="u_account", style="primary")
    vip = InlineKeyboardButton("Buy VIP", callback_data="u_vip")
    market = InlineKeyboardButton("Market", callback_data="nav_user:markets")
    calculator = InlineKeyboardButton("Calculator", callback_data="u_calc")
    admin = InlineKeyboardButton("Admin", callback_data="admin_home")
    back = InlineKeyboardButton("↩️ Back", callback_data="u_signal_portal", style="primary")
    operation = InlineKeyboardButton("اجرای عملیات", callback_data="gov_apply:123")

    assert enabled.style == "success"
    assert disabled.style == "danger"
    assert account.style is None
    assert vip.style == "success" and vip.text.startswith("💎") and "🟡" not in vip.text
    assert market.style is None
    assert calculator.style is None
    assert admin.style is None
    assert back.style is None
    assert operation.style is None
    assert "✅" not in enabled.text and "⛔" not in disabled.text
