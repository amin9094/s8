from types import SimpleNamespace

import pytest

from modules.job_control import (
    apply_persisted_job_controls,
    job_is_protected,
    job_token,
    set_job_paused,
    summarize_jobs,
)


class FakeJob:
    def __init__(self, name, enabled=True):
        self.name = name
        self.enabled = enabled
        self.next_t = None


class FakeQueue:
    def __init__(self, jobs):
        self._jobs = jobs

    def jobs(self):
        return tuple(self._jobs)


def test_job_control_protects_heartbeat():
    db = {}
    assert job_is_protected("application-heartbeat")
    with pytest.raises(ValueError):
        set_job_paused(db, "application-heartbeat", True, actor_id=1, updated_at="now")


def test_job_control_persists_and_reapplies_pause():
    db = {}
    set_job_paused(db, "campaign-scheduler", True, actor_id=7, updated_at="now")
    job = FakeJob("campaign-scheduler")
    result = apply_persisted_job_controls(FakeQueue([job]), db)
    assert result == {"applied": 1, "ignored": 0}
    assert job.enabled is False


def test_job_control_summary_and_tokens_are_stable():
    jobs = [FakeJob("alpha"), FakeJob("beta", enabled=False)]
    summary = summarize_jobs(jobs)
    assert summary["total"] == 2
    assert summary["paused"] == 1
    assert job_token("alpha") == job_token("alpha")
    assert len(job_token("alpha")) == 12
