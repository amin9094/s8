from __future__ import annotations

import copy
import hashlib
import io
import os
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from PIL import Image, ImageColor, ImageFilter, ImageOps, ImageStat, UnidentifiedImageError

from config import SETTINGS

TEMPLATE_SIDES = ("buy", "sell")
TEMPLATE_FIELDS = ("symbol", "entry", "stop", "tp1", "tp2", "tp3", "risk")
FIELD_LABELS = {
    "symbol": "نماد",
    "entry": "نقطه ورود",
    "stop": "حد ضرر",
    "tp1": "تارگت ۱",
    "tp2": "تارگت ۲",
    "tp3": "تارگت ۳",
    "risk": "ریسک",
}

DEFAULT_FIELD_COLORS = {
    "symbol": "#EFF4FA", "entry": "#69FFC4", "stop": "#FF7E7E",
    "tp1": "#69FFC4", "tp2": "#69FFC4", "tp3": "#69FFC4", "risk": "#FFD166",
}


def normalize_field_color(value: Any) -> str:
    text = str(value or "").strip()
    if text.lower() in ImageColor.colormap:
        text = "#" + "".join(f"{part:02X}" for part in ImageColor.getrgb(text.lower()))
    if re.fullmatch(r"#[0-9a-fA-F]{3}", text):
        text = "#" + "".join(char * 2 for char in text[1:])
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", text):
        raise ValueError("رنگ باید نام استاندارد رنگ یا کد HEX مانند #00FFAA باشد.")
    return text.upper()


def signal_color_palette() -> list[tuple[str, str]]:
    common = [("سبز", "#69FFC4"), ("قرمز", "#FF7E7E"), ("آبی", "#75D2FF"),
              ("سفید", "#EFF4FA"), ("طلایی", "#FFD166"), ("نارنجی", "#FF9900"),
              ("بنفش", "#BB88FF"), ("صورتی", "#FF88CC"), ("زرد", "#FFFF00"),
              ("فیروزه‌ای", "#00FFFF"), ("نقره‌ای", "#C0C0C0"), ("مشکی", "#000000")]
    return common + [(name, normalize_field_color(name)) for name in sorted(ImageColor.colormap)]


def set_signal_template_color(db: dict[str, Any], side: str, field: str, color: str) -> dict[str, Any]:
    if side not in TEMPLATE_SIDES or field not in TEMPLATE_FIELDS:
        raise ValueError("قالب یا فیلد نامعتبر است")
    value = normalize_field_color(color)
    row = ensure_signal_template_settings(db)[side]["fields"][field]
    row["color"] = value
    return copy.deepcopy(row)

# v6.5 keeps the two owner-approved 1229x1536 PNG artworks pixel-for-pixel at
# their native size. Every value, including RISK, is drawn only inside the
# matching blank box already present in the supplied artwork.
TEMPLATE_WIDTH = 1229
SOURCE_TEMPLATE_HEIGHT = 1536
CONTENT_TEMPLATE_HEIGHT = 1536
OUTPUT_TEMPLATE_HEIGHT = 1536
_DEFAULT_BOXES_BY_SIDE: dict[str, dict[str, tuple[int, int, int, int]]] = {
    "buy": {
        "symbol": (520, 642, 1133, 710),
        "entry": (520, 751, 1133, 817),
        "stop": (520, 859, 1133, 927),
        "tp1": (520, 968, 1133, 1036),
        "tp2": (520, 1077, 1133, 1145),
        "tp3": (520, 1185, 1133, 1253),
        "risk": (520, 1295, 1133, 1363),
    },
    "sell": {
        "symbol": (490, 635, 1094, 700),
        "entry": (490, 748, 1094, 814),
        "stop": (490, 861, 1094, 927),
        "tp1": (490, 973, 1094, 1040),
        "tp2": (490, 1086, 1094, 1152),
        "tp3": (490, 1198, 1094, 1265),
        "risk": (490, 1310, 1094, 1377),
    },
}


def default_signal_template_settings() -> dict[str, Any]:
    return {
        side: {
            "font_size": 46,
            "fields": {
                key: {"box": list(box), "font_size": 43 if key == "risk" else 46, "color": DEFAULT_FIELD_COLORS[key]}
                for key, box in _DEFAULT_BOXES_BY_SIDE[side].items()
            },
        }
        for side in TEMPLATE_SIDES
    }


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _sanitize_box(value: Any, default: tuple[int, int, int, int]) -> list[int]:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return list(default)
    x1, y1, x2, y2 = (_safe_int(item, fallback) for item, fallback in zip(value, default, strict=True))
    x1 = max(0, min(TEMPLATE_WIDTH - 29, x1))
    y1 = max(0, min(OUTPUT_TEMPLATE_HEIGHT - 30, y1))
    x2 = max(x1 + 60, min(TEMPLATE_WIDTH, x2))
    y2 = max(y1 + 30, min(OUTPUT_TEMPLATE_HEIGHT, y2))
    return [x1, y1, x2, y2]


def sanitize_signal_template_settings(value: Any) -> dict[str, Any]:
    defaults = default_signal_template_settings()
    source = value if isinstance(value, dict) else {}
    result: dict[str, Any] = {}
    for side in TEMPLATE_SIDES:
        side_candidate = source.get(side)
        side_source: dict[str, Any] = side_candidate if isinstance(side_candidate, dict) else {}
        global_font = max(18, min(72, _safe_int(side_source.get("font_size"), 46)))
        field_candidate = side_source.get("fields")
        field_source: dict[str, Any] = field_candidate if isinstance(field_candidate, dict) else {}
        fields: dict[str, Any] = {}
        for key in TEMPLATE_FIELDS:
            row_candidate = field_source.get(key)
            row: dict[str, Any] = row_candidate if isinstance(row_candidate, dict) else {}
            default_box = tuple(defaults[side]["fields"][key]["box"])
            default_font = int(defaults[side]["fields"][key]["font_size"])
            try:
                color = normalize_field_color(row.get("color") or DEFAULT_FIELD_COLORS[key])
            except ValueError:
                color = DEFAULT_FIELD_COLORS[key]
            fields[key] = {
                "box": _sanitize_box(row.get("box"), default_box),
                "font_size": max(18, min(72, _safe_int(row.get("font_size"), default_font))),
                "color": color,
            }
        result[side] = {"font_size": global_font, "fields": fields}
    return result


def ensure_signal_template_settings(db: dict[str, Any]) -> dict[str, Any]:
    current = db.get("signal_template_settings")
    normalized = sanitize_signal_template_settings(current)
    db["signal_template_settings"] = normalized
    return normalized


def signal_template_layout(db: dict[str, Any], side: str) -> dict[str, Any]:
    normalized_side = str(side or "").strip().lower()
    if normalized_side not in TEMPLATE_SIDES:
        raise ValueError("نوع قالب باید BUY یا SELL باشد")
    settings = ensure_signal_template_settings(db)
    return copy.deepcopy(settings[normalized_side])


def move_signal_template_field(
    db: dict[str, Any],
    side: str,
    field: str,
    *,
    dx: int = 0,
    dy: int = 0,
) -> dict[str, Any]:
    normalized_side = str(side or "").strip().lower()
    normalized_field = str(field or "").strip().lower()
    if normalized_side not in TEMPLATE_SIDES or normalized_field not in TEMPLATE_FIELDS:
        raise ValueError("قالب یا فیلد نامعتبر است")
    settings = ensure_signal_template_settings(db)
    row = settings[normalized_side]["fields"][normalized_field]
    x1, y1, x2, y2 = row["box"]
    width, height = x2 - x1, y2 - y1
    x1 = max(0, min(TEMPLATE_WIDTH - width, x1 + max(-100, min(100, int(dx)))))
    y1 = max(0, min(OUTPUT_TEMPLATE_HEIGHT - height, y1 + max(-100, min(100, int(dy)))))
    row["box"] = [x1, y1, x1 + width, y1 + height]
    return copy.deepcopy(row)


def change_signal_template_font(
    db: dict[str, Any],
    side: str,
    field: str,
    delta: int,
) -> dict[str, Any]:
    normalized_side = str(side or "").strip().lower()
    normalized_field = str(field or "").strip().lower()
    if normalized_side not in TEMPLATE_SIDES or normalized_field not in TEMPLATE_FIELDS:
        raise ValueError("قالب یا فیلد نامعتبر است")
    settings = ensure_signal_template_settings(db)
    row = settings[normalized_side]["fields"][normalized_field]
    row["font_size"] = max(18, min(72, int(row.get("font_size", 46)) + max(-10, min(10, int(delta)))))
    return copy.deepcopy(row)


def reset_signal_template_side(db: dict[str, Any], side: str) -> dict[str, Any]:
    normalized_side = str(side or "").strip().lower()
    if normalized_side not in TEMPLATE_SIDES:
        raise ValueError("نوع قالب نامعتبر است")
    settings = ensure_signal_template_settings(db)
    settings[normalized_side] = default_signal_template_settings()[normalized_side]
    return copy.deepcopy(settings[normalized_side])


def _signal_template_storage_root() -> Path:
    configured = str(os.getenv("SIGNAL_TEMPLATE_STORAGE_DIR") or "").strip()
    if configured:
        root = Path(configured)
    else:
        mount = str(
            os.getenv("PERSISTENT_DATA_DIR")
            or os.getenv("RAILWAY_VOLUME_MOUNT_PATH")
            or os.getenv("VOLUME_MOUNT_PATH")
            or ""
        ).strip()
        root = Path(mount) / "signal_templates" if mount else SETTINGS.db_file.parent / "signal_templates"
    root = root.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_template_side(side: str) -> str:
    value = str(side or "").strip().lower()
    if value not in TEMPLATE_SIDES:
        raise ValueError("نوع قالب باید BUY یا SELL باشد")
    return value


def signal_template_backgrounds(db: dict[str, Any]) -> dict[str, Any]:
    raw = db.get("signal_template_backgrounds")
    return raw if isinstance(raw, dict) else {}


def signal_template_background_info(db: dict[str, Any], side: str) -> dict[str, Any]:
    value = _safe_template_side(side)
    row = signal_template_backgrounds(db).get(value)
    if not isinstance(row, dict):
        return {"side": value, "custom": False, "width": TEMPLATE_WIDTH, "height": OUTPUT_TEMPLATE_HEIGHT}
    path = signal_template_background_path(db, value)
    return {
        "side": value,
        "custom": bool(path),
        "width": int(row.get("width") or TEMPLATE_WIDTH),
        "height": int(row.get("height") or OUTPUT_TEMPLATE_HEIGHT),
        "checksum": str(row.get("checksum") or ""),
        "uploaded_at": row.get("uploaded_at"),
        "original_name": str(row.get("original_name") or ""),
    }


def signal_template_background_path(db: dict[str, Any], side: str) -> str | None:
    value = _safe_template_side(side)
    row = signal_template_backgrounds(db).get(value)
    if not isinstance(row, dict):
        return None
    raw = str(row.get("path") or "").strip()
    if not raw:
        return None
    try:
        path = Path(raw).expanduser().resolve()
        path.relative_to(_signal_template_storage_root())
    except (OSError, ValueError):
        return None
    return str(path) if path.is_file() else None


def store_signal_template_background(
    db: dict[str, Any],
    side: str,
    payload: bytes,
    *,
    original_name: str = "template",
) -> dict[str, Any]:
    value = _safe_template_side(side)
    if not payload or len(payload) > 12 * 1024 * 1024:
        raise ValueError("حجم تصویر قالب باید بین ۱ بایت و ۱۲ مگابایت باشد")
    try:
        with Image.open(io.BytesIO(payload)) as source:
            source.load()
            if source.width < 600 or source.height < 800:
                raise ValueError("ابعاد تصویر قالب بیش از حد کوچک است")
            image = ImageOps.exif_transpose(source).convert("RGB")
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError("فایل ارسالی تصویر معتبر نیست") from exc
    resized = image.size != (TEMPLATE_WIDTH, OUTPUT_TEMPLATE_HEIGHT)
    if resized:
        fitted = ImageOps.fit(
            image,
            (TEMPLATE_WIDTH, OUTPUT_TEMPLATE_HEIGHT),
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        )
        image.close()
        image = fitted
    output = io.BytesIO()
    try:
        image.save(output, format="PNG", optimize=True, compress_level=8)
    finally:
        image.close()
    normalized = output.getvalue()
    checksum = hashlib.sha256(normalized).hexdigest()
    root = _signal_template_storage_root()
    destination = (root / f"sentinel_{value}_custom.png").resolve()
    destination.relative_to(root)
    temporary = destination.with_suffix(".png.tmp")
    temporary.write_bytes(normalized)
    temporary.replace(destination)
    backgrounds = db.setdefault("signal_template_backgrounds", {})
    if not isinstance(backgrounds, dict):
        backgrounds = {}
        db["signal_template_backgrounds"] = backgrounds
    backgrounds[value] = {
        "path": str(destination),
        "checksum": checksum,
        "width": TEMPLATE_WIDTH,
        "height": OUTPUT_TEMPLATE_HEIGHT,
        "uploaded_at": datetime.now(UTC).isoformat(),
        "original_name": Path(str(original_name or "template")).name[:160],
        "normalized_to_canvas": resized,
    }
    return signal_template_background_info(db, value)


def reset_signal_template_background(db: dict[str, Any], side: str) -> dict[str, Any]:
    value = _safe_template_side(side)
    backgrounds = db.get("signal_template_backgrounds")
    if isinstance(backgrounds, dict):
        row = backgrounds.pop(value, None)
        if isinstance(row, dict):
            raw = str(row.get("path") or "").strip()
            if raw:
                try:
                    path = Path(raw).expanduser().resolve()
                    path.relative_to(_signal_template_storage_root())
                    path.unlink(missing_ok=True)
                except (OSError, ValueError):
                    pass
    return signal_template_background_info(db, value)


def auto_detect_signal_template_layout(payload: bytes, side: str) -> dict[str, Any]:
    """Suggest text boxes around visually quiet regions of a supplied artwork.

    The detector stays close to SENTINEL's known seven-row layout, then searches
    nearby pixels for the least busy rectangular area. It is deterministic and
    bounded, so an unusual background still falls back to the safe defaults.
    """
    value = _safe_template_side(side)
    try:
        with Image.open(io.BytesIO(payload)) as source:
            source.load()
            image = ImageOps.fit(
                ImageOps.exif_transpose(source).convert("RGB"),
                (TEMPLATE_WIDTH, OUTPUT_TEMPLATE_HEIGHT),
                method=Image.Resampling.LANCZOS,
                centering=(0.5, 0.5),
            )
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError("فایل ارسالی تصویر معتبر نیست") from exc
    gray = image.convert("L")
    edges = gray.filter(ImageFilter.FIND_EDGES)
    defaults = default_signal_template_settings()[value]
    result = copy.deepcopy(defaults)
    improvements: list[float] = []
    try:
        for field in TEMPLATE_FIELDS:
            x1, y1, x2, y2 = defaults["fields"][field]["box"]
            width, height = x2 - x1, y2 - y1

            def score(cx: int, cy: int) -> float:
                crop = gray.crop((cx, cy, cx + width, cy + height))
                edge = edges.crop((cx, cy, cx + width, cy + height))
                variance = float(ImageStat.Stat(crop).var[0])
                edge_mean = float(ImageStat.Stat(edge).mean[0])
                # Quiet, low-edge boxes are safer for overlaid numbers.
                return edge_mean * 4.0 + variance ** 0.5

            base_score = score(x1, y1)
            best = (base_score, x1, y1)
            for dy in range(-70, 71, 10):
                cy = max(0, min(OUTPUT_TEMPLATE_HEIGHT - height, y1 + dy))
                for dx in range(-80, 81, 10):
                    cx = max(0, min(TEMPLATE_WIDTH - width, x1 + dx))
                    candidate = score(cx, cy) + (abs(dx) + abs(dy)) * 0.015
                    if candidate < best[0]:
                        best = (candidate, cx, cy)
            _, bx, by = best
            result["fields"][field]["box"] = [bx, by, bx + width, by + height]
            improvements.append(max(0.0, (base_score - best[0]) / max(base_score, 1.0)))
    finally:
        edges.close()
        gray.close()
        image.close()
    confidence = round(sum(improvements) / max(len(improvements), 1), 4)
    return {"side": value, "layout": result, "confidence": confidence, "method": "quiet_box_near_known_rows_v1"}


def store_and_autodetect_signal_template_background(
    db: dict[str, Any],
    side: str,
    payload: bytes,
    *,
    original_name: str = "template",
) -> dict[str, Any]:
    detection = auto_detect_signal_template_layout(payload, side)
    background = store_signal_template_background(db, side, payload, original_name=original_name)
    settings = ensure_signal_template_settings(db)
    settings[detection["side"]] = sanitize_signal_template_settings({detection["side"]: detection["layout"]})[detection["side"]]
    return {"background": background, "detection": detection, "layout": copy.deepcopy(settings[detection["side"]])}
