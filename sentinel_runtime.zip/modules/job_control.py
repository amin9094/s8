from __future__ import annotations

import hashlib
from typing import Any, Iterable

# Jobs required for liveness, dependency visibility or persistence safety cannot
# be paused from Telegram. This keeps the control center from becoming a new
# outage mechanism.
PROTECTED_JOB_NAMES = {
    "application-heartbeat",
    "runtime-dependency-health",
    "operations-governance-watchdog",
}


def job_token(name: str) -> str:
    return hashlib.sha256(str(name).encode("utf-8")).hexdigest()[:12]


def job_is_protected(name: str) -> bool:
    return str(name) in PROTECTED_JOB_NAMES


def job_control_settings(db: dict[str, Any]) -> dict[str, Any]:
    operations = db.setdefault("operations", {})
    settings = operations.setdefault("job_control", {})
    paused = settings.setdefault("paused_names", [])
    if not isinstance(paused, list):
        settings["paused_names"] = []
    settings.setdefault("updated_at", None)
    settings.setdefault("updated_by", None)
    return settings


def set_job_paused(db: dict[str, Any], name: str, paused: bool, *, actor_id: int | str, updated_at: str) -> list[str]:
    clean = str(name or "").strip()
    if not clean:
        raise ValueError("نام Job خالی است")
    if paused and job_is_protected(clean):
        raise ValueError("این Job حیاتی است و قابل توقف نیست")
    settings = job_control_settings(db)
    values = {str(item) for item in settings.get("paused_names", []) if str(item)}
    if paused:
        values.add(clean)
    else:
        values.discard(clean)
    settings["paused_names"] = sorted(values)
    settings["updated_at"] = str(updated_at)
    settings["updated_by"] = str(actor_id)
    return list(settings["paused_names"])


def paused_job_names(db: dict[str, Any]) -> set[str]:
    return {str(item) for item in job_control_settings(db).get("paused_names", []) if str(item)}


def summarize_jobs(jobs: Iterable[Any], *, observability: dict[str, Any] | None = None) -> dict[str, Any]:
    obs_jobs = dict((observability or {}).get("jobs") or {})
    rows: list[dict[str, Any]] = []
    for job in jobs:
        name = str(getattr(job, "name", "") or "unnamed-job")
        enabled = bool(getattr(job, "enabled", True))
        next_t = getattr(job, "next_t", None)
        # Observability keys are logical names and may differ from scheduler
        # names. Exact name is preferred; otherwise retain scheduler truth.
        observed = dict(obs_jobs.get(name) or {})
        rows.append(
            {
                "name": name,
                "token": job_token(name),
                "enabled": enabled,
                "protected": job_is_protected(name),
                "next_run_at": next_t.isoformat() if hasattr(next_t, "isoformat") else (str(next_t) if next_t else None),
                "status": str(observed.get("status") or ("scheduled" if enabled else "paused")),
                "last_success_at": observed.get("last_success_at"),
                "last_error": str(observed.get("last_error") or ""),
                "duration_seconds": float(observed.get("duration_seconds", 0) or 0),
                "consecutive_failures": int(observed.get("consecutive_failures", 0) or 0),
            }
        )
    rows.sort(key=lambda row: (not row["protected"], row["name"]))
    return {
        "total": len(rows),
        "enabled": sum(1 for row in rows if row["enabled"]),
        "paused": sum(1 for row in rows if not row["enabled"]),
        "protected": sum(1 for row in rows if row["protected"]),
        "rows": rows,
    }


def apply_persisted_job_controls(job_queue: Any, db: dict[str, Any]) -> dict[str, int]:
    paused = paused_job_names(db)
    applied = 0
    ignored = 0
    for job in tuple(job_queue.jobs() if job_queue is not None else ()):
        name = str(getattr(job, "name", "") or "")
        if name not in paused:
            continue
        if job_is_protected(name):
            ignored += 1
            continue
        try:
            job.enabled = False
            applied += 1
        except Exception:
            ignored += 1
    return {"applied": applied, "ignored": ignored}
