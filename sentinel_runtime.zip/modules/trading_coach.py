from __future__ import annotations

import logging
import math
from collections import defaultdict
from datetime import datetime
from decimal import Decimal
from typing import Any

from modules.portfolio import journal_entries, journal_stats

logger = logging.getLogger(__name__)

def _result(row: dict[str, Any]) -> float:
    for key in ("result_r", "pnl_percent", "pnl_amount"):
        try:
            if row.get(key) not in {None, ""}:
                value = float(row.get(key) or 0)
                if math.isfinite(value):
                    return value
        except (TypeError, ValueError):
            continue
    return 0.0


def _hour(row: dict[str, Any]) -> int | None:
    raw = row.get("created_at") or row.get("opened_at")
    if not raw:
        return None
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00")).hour
    except (TypeError, ValueError):
        return None


def trading_coach_snapshot(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    try:
        from modules.feature_flags import feature_enabled
        if not feature_enabled(db, "trading.coach", default=True):
            return {"status": "disabled", "sample_size": 0, "stats": {}, "best_hours": [], "best_setups": [], "findings": [], "disclaimer": ""}
    except Exception:
        logger.exception("Trading coach feature configuration could not be read")
        return {"status": "unavailable", "sample_size": 0, "stats": {}, "best_hours": [], "best_setups": [], "findings": [], "disclaimer": ""}
    rows = [row for row in journal_entries(db, user_id, limit=5000) if isinstance(row, dict) and row.get("status") not in {"open", "partial"}]
    stats = journal_stats(db, user_id)
    by_hour: dict[int, list[float]] = defaultdict(list)
    by_setup: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        value = _result(row)
        hour = _hour(row)
        if hour is not None:
            by_hour[hour].append(value)
        setup = str(row.get("setup") or "").strip()
        if setup:
            by_setup[setup[:80]].append(value)

    def score_map(source: dict[Any, list[float]], *, min_count: int = 2) -> list[dict[str, Any]]:
        output = []
        for key, values in source.items():
            if len(values) < min_count:
                continue
            average = float(sum((Decimal(str(value)) for value in values), Decimal(0)) / len(values))
            output.append({"key": str(key), "count": len(values), "average": round(average, 3), "wins": sum(1 for value in values if value > 0)})
        output.sort(key=lambda item: (item["average"], item["wins"], item["count"]), reverse=True)
        return output

    hours = score_map(by_hour)
    setups = score_map(by_setup)
    findings: list[str] = []
    if len(rows) < 10:
        findings.append("برای تحلیل رفتاری قابل اتکا، حداقل ۱۰ معامله بسته‌شده ثبت کنید.")
    else:
        if hours:
            findings.append(f"بهترین ساعت ثبت‌شده: {hours[0]['key']}:00 با میانگین نتیجه {hours[0]['average']:.2f}.")
        if setups:
            findings.append(f"بهترین ستاپ ثبت‌شده: {setups[0]['key']} با میانگین نتیجه {setups[0]['average']:.2f}.")
        if float(stats.get("win_rate", 0) or 0) < 40:
            findings.append("نرخ برد زیر ۴۰٪ است؛ قبل از افزایش حجم، کیفیت ورودی و حد ضرر را مرور کنید.")
        if float(stats.get("max_drawdown", 0) or 0) > 10:
            findings.append("افت سرمایه ژورنال بالا است؛ ریسک هر معامله را کاهش دهید و هم‌بستگی معاملات باز را بررسی کنید.")
    return {
        "sample_size": len(rows),
        "stats": stats,
        "best_hours": hours[:5],
        "best_setups": setups[:5],
        "findings": findings[:6],
        "disclaimer": "این گزارش توصیفی است و توصیه خرید یا فروش محسوب نمی‌شود.",
    }
