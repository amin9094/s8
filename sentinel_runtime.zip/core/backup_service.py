from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import secrets
import sqlite3
import subprocess  # nosec B404
import tempfile
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlsplit

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from core.async_runtime import run_blocking
from core.http_client import request

logger = logging.getLogger(__name__)
MAGIC = b"SENTINEL-AESGCM-1\n"
STREAM_MAGIC = b"SENTINEL-AESGCM-STREAM-1\n"


def _backup_stamp() -> str:
    return f"{datetime.now(UTC).strftime('%Y%m%dT%H%M%S.%fZ')}-{uuid.uuid4().hex[:8]}"


def _fsync_path(path: Path) -> None:
    with path.open("rb") as handle:
        os.fsync(handle.fileno())


def _atomic_write_bytes(target: Path, payload: bytes, *, mode: int = 0o600) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(temp, mode)
        except OSError:
            pass
        os.replace(temp, target)
        try:
            directory_fd = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError:
            pass
    finally:
        temp.unlink(missing_ok=True)


def _derive_key(secret: str) -> bytes:
    return hashlib.sha256(secret.encode("utf-8")).digest()


def encrypt_backup(payload: bytes, secret: str) -> bytes:
    if not secret:
        return payload
    nonce = secrets.token_bytes(12)
    encrypted = AESGCM(_derive_key(secret)).encrypt(nonce, payload, MAGIC)
    return MAGIC + base64.urlsafe_b64encode(nonce + encrypted)


def decrypt_backup(payload: bytes, secret: str) -> bytes:
    if not payload.startswith(MAGIC):
        return payload
    if not secret:
        raise ValueError("backup is encrypted but BACKUP_ENCRYPTION_KEY is missing")
    raw = base64.urlsafe_b64decode(payload[len(MAGIC):])
    return AESGCM(_derive_key(secret)).decrypt(raw[:12], raw[12:], MAGIC)


def _write_metadata(target: Path, *, source: str, plaintext_sha256: str, encrypted: bool, key_version: str = "") -> None:
    metadata = {
        "created_at": datetime.now(UTC).isoformat(),
        "source": source,
        "filename": target.name,
        "sha256": _file_sha256(target),
        "plaintext_sha256": plaintext_sha256,
        "size": target.stat().st_size,
        "encrypted": encrypted,
        "encryption_algorithm": "AES-256-GCM" if encrypted else "none",
        "key_version": key_version if encrypted else "",
    }
    _atomic_write_bytes(
        target.with_suffix(target.suffix + ".meta.json"),
        json.dumps(metadata, ensure_ascii=False, indent=2).encode("utf-8"),
    )




def _file_sha256(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _encrypt_file_stream(source: Path, target: Path, secret: str, *, chunk_size: int = 1024 * 1024) -> None:
    nonce = secrets.token_bytes(12)
    encryptor = Cipher(algorithms.AES(_derive_key(secret)), modes.GCM(nonce)).encryptor()
    encryptor.authenticate_additional_data(STREAM_MAGIC)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
    temp = Path(temp_name)
    try:
        with source.open("rb") as src, os.fdopen(fd, "wb") as dst:
            dst.write(STREAM_MAGIC)
            dst.write(nonce)
            while True:
                chunk = src.read(chunk_size)
                if not chunk:
                    break
                dst.write(encryptor.update(chunk))
            dst.write(encryptor.finalize())
            dst.write(encryptor.tag)
            dst.flush()
            os.fsync(dst.fileno())
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)


def _decrypt_file_stream(source: Path, target: Path, secret: str, *, chunk_size: int = 1024 * 1024) -> None:
    size = source.stat().st_size
    header = len(STREAM_MAGIC) + 12
    if size < header + 16:
        raise ValueError("encrypted streaming backup is truncated")
    with source.open("rb") as src:
        if src.read(len(STREAM_MAGIC)) != STREAM_MAGIC:
            raise ValueError("not a streaming encrypted backup")
        nonce = src.read(12)
        src.seek(-16, os.SEEK_END)
        tag = src.read(16)
        ciphertext_end = size - 16
        src.seek(header)
        decryptor = Cipher(algorithms.AES(_derive_key(secret)), modes.GCM(nonce, tag)).decryptor()
        decryptor.authenticate_additional_data(STREAM_MAGIC)
        fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
        temp = Path(temp_name)
        try:
            with os.fdopen(fd, "wb") as dst:
                remaining = ciphertext_end - header
                while remaining > 0:
                    chunk = src.read(min(chunk_size, remaining))
                    if not chunk:
                        raise ValueError("encrypted streaming backup ended unexpectedly")
                    remaining -= len(chunk)
                    dst.write(decryptor.update(chunk))
                dst.write(decryptor.finalize())
                dst.flush()
                os.fsync(dst.fileno())
            os.replace(temp, target)
        finally:
            temp.unlink(missing_ok=True)


def _pg_env(database_url: str) -> dict[str, str]:
    parsed = urlsplit(database_url)
    if parsed.scheme not in {"postgres", "postgresql"}:
        raise ValueError("DATABASE_URL must be PostgreSQL for pg_dump backup")
    env = os.environ.copy()
    if parsed.hostname:
        env["PGHOST"] = parsed.hostname
    if parsed.port:
        env["PGPORT"] = str(parsed.port)
    if parsed.username:
        env["PGUSER"] = unquote(parsed.username)
    if parsed.password:
        env["PGPASSWORD"] = unquote(parsed.password)
    env["PGDATABASE"] = unquote(parsed.path.lstrip("/"))
    query = parse_qs(parsed.query)
    if query.get("sslmode"):
        env["PGSSLMODE"] = str(query["sslmode"][-1])
    return env


def create_postgres_dump_backup(
    database_url: str,
    backup_dir: Path,
    *,
    encryption_key: str = "",
    key_version: str = "v1",
    timeout_seconds: int = 300,
) -> Path:
    """Create a streaming pg_dump backup without materializing the DB in Python RAM."""
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = _backup_stamp()
    raw = backup_dir / f"sentinel-postgres-{stamp}.dump"
    fd, temp_name = tempfile.mkstemp(prefix=f".{raw.name}.", suffix=".tmp", dir=str(backup_dir))
    os.close(fd)
    temp = Path(temp_name)
    try:
        # Fixed pg_dump arguments, shell disabled, bounded timeout; credentials use the child environment.
        subprocess.run(  # nosec B603 B607
            ["pg_dump", "--format=custom", "--no-owner", "--no-privileges", "--file", str(temp)],
            env=_pg_env(database_url),
            check=True,
            timeout=max(30, int(timeout_seconds)),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        _fsync_path(temp)
        plaintext_sha = _file_sha256(temp)
        if encryption_key:
            final = raw.with_suffix(raw.suffix + ".enc")
            _encrypt_file_stream(temp, final, encryption_key)
            temp.unlink(missing_ok=True)
        else:
            os.replace(temp, raw)
            final = raw
        _write_metadata(
            final,
            source="postgresql-pg_dump",
            plaintext_sha256=plaintext_sha,
            encrypted=bool(encryption_key),
            key_version=key_version,
        )
        return final
    finally:
        temp.unlink(missing_ok=True)


def run_postgres_dump_restore_drill(
    path: Path,
    backup_dir: Path,
    *,
    encryption_key: str = "",
    decryption_keys: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Verify a pg_dump archive can be decrypted and parsed by pg_restore."""
    resolved = path.resolve()
    root = backup_dir.resolve()
    if root not in resolved.parents or not resolved.is_file():
        raise ValueError("invalid PostgreSQL backup path")
    metadata = backup_metadata(resolved)
    expected_hash = str(metadata.get("sha256") or "")
    actual_hash = _file_sha256(resolved)
    if expected_hash and expected_hash != actual_hash:
        raise ValueError("PostgreSQL backup stored hash mismatch")
    candidate = resolved
    temp: Path | None = None
    try:
        with resolved.open("rb") as handle:
            streaming_encrypted = handle.read(len(STREAM_MAGIC)) == STREAM_MAGIC
        if streaming_encrypted:
            keys = tuple(dict.fromkeys(key for key in (encryption_key, *decryption_keys) if key))
            last_error: Exception | None = None
            for key in keys:
                fd, name = tempfile.mkstemp(prefix="sentinel-pgdump-drill-", suffix=".dump", dir=str(backup_dir))
                os.close(fd)
                temp = Path(name)
                try:
                    _decrypt_file_stream(resolved, temp, key)
                    candidate = temp
                    last_error = None
                    break
                except Exception as exc:
                    last_error = exc
                    temp.unlink(missing_ok=True)
                    temp = None
            if temp is None:
                raise ValueError("PostgreSQL backup decryption failed") from last_error
        expected_plain = str(metadata.get("plaintext_sha256") or "")
        if expected_plain and _file_sha256(candidate) != expected_plain:
            raise ValueError("PostgreSQL backup plaintext hash mismatch")
        # Fixed pg_restore arguments and an already validated backup path; no shell, bounded timeout.
        subprocess.run(  # nosec B603 B607
            ["pg_restore", "--list", str(candidate)],
            check=True,
            timeout=120,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        return {
            **metadata,
            "valid": True,
            "restore_drill": "passed",
            "format": "pg_dump_custom",
            "tested_at": datetime.now(UTC).isoformat(),
        }
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


def create_operational_backup(
    db_file: Path,
    backup_dir: Path,
    *,
    encryption_key: str = "",
    key_version: str = "v1",
) -> Path:
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = _backup_stamp()
    suffix = ".sqlite3" if db_file.suffix.lower() in {".sqlite", ".sqlite3", ".db"} else ".json"
    raw_target = backup_dir / f"sentinel-full-{stamp}{suffix}"
    if suffix == ".sqlite3":
        temp_target = raw_target.with_name(f".{raw_target.name}.{uuid.uuid4().hex}.tmp")
        source = sqlite3.connect(db_file)
        target_connection = sqlite3.connect(temp_target)
        try:
            source.backup(target_connection)
        finally:
            target_connection.close()
            source.close()
        _fsync_path(temp_target)
        os.replace(temp_target, raw_target)
    else:
        _atomic_write_bytes(raw_target, db_file.read_bytes())
    raw = raw_target.read_bytes()
    plaintext_sha = hashlib.sha256(raw).hexdigest()
    if encryption_key:
        final_target = raw_target.with_suffix(raw_target.suffix + ".enc")
        _atomic_write_bytes(final_target, encrypt_backup(raw, encryption_key))
        raw_target.unlink(missing_ok=True)
    else:
        final_target = raw_target
    try:
        os.chmod(final_target, 0o600)
    except OSError:
        pass
    _write_metadata(
        final_target,
        source=str(db_file.name),
        plaintext_sha256=plaintext_sha,
        encrypted=bool(encryption_key),
        key_version=key_version,
    )
    return final_target


def create_payload_backup(
    data: dict[str, Any],
    backup_dir: Path,
    *,
    encryption_key: str = "",
    key_version: str = "v1",
) -> Path:
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = _backup_stamp()
    raw = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")
    plaintext_sha = hashlib.sha256(raw).hexdigest()
    target = backup_dir / f"sentinel-full-{stamp}.json"
    if encryption_key:
        target = target.with_suffix(target.suffix + ".enc")
        _atomic_write_bytes(target, encrypt_backup(raw, encryption_key))
    else:
        _atomic_write_bytes(target, raw)
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    _write_metadata(
        target,
        source="database-payload",
        plaintext_sha256=plaintext_sha,
        encrypted=bool(encryption_key),
        key_version=key_version,
    )
    return target


async def upload_external_backup(path: Path, url: str, *, timeout_seconds: int = 30, attempts: int = 4) -> bool:
    if not url:
        return False
    digest = await run_blocking(_file_sha256, path, timeout=max(10, timeout_seconds))
    headers = {
        "Content-Type": "application/octet-stream",
        "X-SENTINEL-Filename": path.name,
        "X-SENTINEL-SHA256": digest,
        "Idempotency-Key": hashlib.sha256((path.name + digest).encode()).hexdigest(),
    }

    async def stream_file():
        handle = await run_blocking(path.open, "rb", timeout=5)
        try:
            while True:
                chunk = await run_blocking(handle.read, 1024 * 1024, timeout=max(10, timeout_seconds))
                if not chunk:
                    break
                yield chunk
        finally:
            await run_blocking(handle.close, timeout=5)

    last_error: Exception | None = None
    for attempt in range(max(1, int(attempts))):
        try:
            await request(
                "PUT",
                url,
                headers=headers,
                content=stream_file(),
                timeout_seconds=max(10, timeout_seconds),
                follow_redirects=False,
                retries=0,
                allow_circuit_open=True,
            )
            return True
        except Exception as exc:
            last_error = exc
            if attempt + 1 < max(1, int(attempts)):
                await asyncio.sleep(min(30, 2 ** attempt))
    if last_error:
        logger.error("External backup upload failed after retries: %s", last_error)
    return False


def prune_operational_backups(backup_dir: Path, keep: int = 30) -> int:
    patterns = ("sentinel-full-*", "sentinel-postgres-*")
    rows: list[Path] = []
    for pattern in patterns:
        rows.extend(path for path in backup_dir.glob(pattern) if not path.name.endswith(".meta.json"))
    rows.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    removed = 0
    for old in rows[max(1, int(keep)):]:
        old.unlink(missing_ok=True)
        old.with_suffix(old.suffix + ".meta.json").unlink(missing_ok=True)
        removed += 1
    return removed


def list_payload_backups(backup_dir: Path, limit: int = 30) -> list[Path]:
    """Return restorable JSON backups, including encrypted and legacy files."""
    if not backup_dir.exists():
        return []
    rows: list[Path] = []
    for pattern in ("sentinel-full-*.json", "sentinel-full-*.json.enc", "database-*.json"):
        rows.extend(path for path in backup_dir.glob(pattern) if path.is_file() and not path.name.endswith(".meta.json"))
    unique = {path.resolve(): path for path in rows}
    ordered = sorted(unique.values(), key=lambda path: path.stat().st_mtime, reverse=True)
    return ordered[: max(1, int(limit))]


def backup_metadata(path: Path) -> dict[str, Any]:
    """Read metadata when present and otherwise derive a safe minimal record."""
    meta_path = path.with_suffix(path.suffix + ".meta.json")
    if meta_path.is_file():
        try:
            raw = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                return raw
        except (OSError, json.JSONDecodeError):
            logger.warning("Could not read backup metadata for %s", path.name)
    with path.open("rb") as handle:
        prefix = handle.read(max(len(MAGIC), len(STREAM_MAGIC)))
    return {
        "created_at": datetime.fromtimestamp(path.stat().st_mtime, UTC).isoformat(),
        "source": "legacy-database-payload",
        "filename": path.name,
        "sha256": _file_sha256(path),
        "plaintext_sha256": "",
        "size": path.stat().st_size,
        "encrypted": prefix.startswith(MAGIC) or prefix.startswith(STREAM_MAGIC),
    }


def load_payload_backup(
    path: Path,
    backup_dir: Path,
    *,
    encryption_key: str = "",
    decryption_keys: tuple[str, ...] = (),
    key_version: str = "",
) -> dict[str, Any]:
    """Safely decrypt, decode and validate a JSON payload backup.

    ``decryption_keys`` keeps old encrypted backups restorable after key
    rotation. ``key_version`` is accepted for API compatibility and audit
    context; the actual version is read from the backup metadata.
    """
    del key_version
    resolved = path.resolve()
    root = backup_dir.resolve()
    if root not in resolved.parents or not resolved.is_file():
        raise ValueError("فایل بکاپ معتبر نیست")
    if not (resolved.name.endswith(".json") or resolved.name.endswith(".json.enc")):
        raise ValueError("این فایل برای بازیابی مستقیم دیتابیس مناسب نیست")
    stored = resolved.read_bytes()
    metadata = backup_metadata(resolved)
    expected_stored_hash = str(metadata.get("sha256") or "")
    actual_stored_hash = hashlib.sha256(stored).hexdigest()
    if expected_stored_hash and expected_stored_hash != actual_stored_hash:
        raise ValueError("هش فایل بکاپ با متادیتا مطابقت ندارد")

    keys = tuple(dict.fromkeys(key for key in (encryption_key, *decryption_keys) if key))
    if not stored.startswith(MAGIC):
        plaintext = stored
    else:
        plaintext = b""
        last_error: Exception | None = None
        for candidate in keys:
            try:
                plaintext = decrypt_backup(stored, candidate)
                break
            except Exception as exc:  # Every candidate must be attempted for key rotation.
                last_error = exc
        if not plaintext:
            raise ValueError("رمزگشایی بکاپ ناموفق بود؛ کلید فعلی یا کلیدهای قبلی را بررسی کنید") from last_error

    expected_plain_hash = str(metadata.get("plaintext_sha256") or "")
    actual_plain_hash = hashlib.sha256(plaintext).hexdigest()
    if expected_plain_hash and expected_plain_hash != actual_plain_hash:
        raise ValueError("محتوای رمزگشایی‌شده بکاپ آسیب دیده است")
    try:
        raw = json.loads(plaintext.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("محتوای بکاپ JSON معتبر نیست") from exc
    from core.db import validate_database_payload

    return validate_database_payload(raw)


def verify_payload_backup(
    path: Path,
    backup_dir: Path,
    *,
    encryption_key: str = "",
    decryption_keys: tuple[str, ...] = (),
    key_version: str = "",
) -> dict[str, Any]:
    """Verify integrity and schema without applying the backup."""
    payload = load_payload_backup(
        path,
        backup_dir,
        encryption_key=encryption_key,
        decryption_keys=decryption_keys,
        key_version=key_version,
    )
    metadata = backup_metadata(path)
    return {
        **metadata,
        "valid": True,
        "schema_version": payload.get("schema_version"),
        "user_count": len(payload.get("users", {})),
        "signal_count": len(payload.get("signals", [])),
    }


def run_payload_restore_drill(
    path: Path,
    backup_dir: Path,
    *,
    encryption_key: str = "",
    decryption_keys: tuple[str, ...] = (),
    key_version: str = "",
) -> dict[str, Any]:
    """Restore a backup into an isolated SQLite database and verify key records.

    The production database is never opened or mutated. A successful result
    proves that the archive can be decrypted, migrated, persisted, indexed and
    read back by the same storage engine used in production fallback mode.
    """
    payload = load_payload_backup(
        path,
        backup_dir,
        encryption_key=encryption_key,
        decryption_keys=decryption_keys,
        key_version=key_version,
    )
    from core.db import SQLiteStore, validate_database_payload

    sections = {
        "users": "dict",
        "signals": "list",
        "vip_orders": "list",
        "tickets": "list",
        "marketing_campaigns": "dict",
        "automation_outbox": "dict",
    }

    def section_count(data: dict[str, Any], key: str, expected: str) -> int:
        value = data.get(key)
        if expected == "dict":
            return len(value) if isinstance(value, dict) else -1
        return len(value) if isinstance(value, list) else -1

    expected_counts = {
        key: section_count(payload, key, expected)
        for key, expected in sections.items()
    }
    with tempfile.TemporaryDirectory(prefix="sentinel-restore-drill-") as temp_root:
        root = Path(temp_root)
        store = SQLiteStore(root / "restore.sqlite3", root / "backups")
        store.write(payload)
        restored = validate_database_payload(store._read())
        restored_counts = {
            key: section_count(restored, key, expected)
            for key, expected in sections.items()
        }
        if restored_counts != expected_counts:
            raise ValueError(
                f"Restore drill record counts differ: expected={expected_counts}, restored={restored_counts}"
            )

        probe_key = f"restore-drill-{secrets.token_hex(4)}"

        def write_probe(db: dict[str, Any]) -> bool:
            db.setdefault("operations", {}).setdefault(
                "restore_drill_probe",
                {},
            )[probe_key] = utc_value
            return True

        utc_value = datetime.now(UTC).isoformat()
        store.transaction(write_probe)
        reread = store._read()
        actual_probe = (
            reread.get("operations", {})
            .get("restore_drill_probe", {})
            .get(probe_key)
        )
        if actual_probe != utc_value:
            raise ValueError("Restore drill write/read probe failed.")
        connection = store._connect()
        try:
            sqlite_integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            connection.close()
        if str(sqlite_integrity).lower() != "ok":
            raise ValueError(f"Restore drill SQLite integrity failed: {sqlite_integrity}")

    return {
        **backup_metadata(path),
        "valid": True,
        "restore_drill": "passed",
        "schema_version": restored.get("schema_version"),
        "record_counts": restored_counts,
        "write_read_probe": True,
        "sqlite_integrity": "ok",
        "tested_at": datetime.now(UTC).isoformat(),
    }
