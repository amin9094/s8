from __future__ import annotations

from typing import Any

def _normalize(value: Any) -> str:
    text = str(value or "").strip().casefold()
    replacements = {"ي": "ی", "ك": "ک", "ۀ": "ه", "ة": "ه", "‌": " "}
    for source, target in replacements.items():
        text = text.replace(source, target)
    return " ".join(text.split())


def search_internal(
    db: dict[str, Any],
    user_id: int | str,
    query: str,
    *,
    limit: int = 12,
    language: str = "fa",
) -> list[dict[str, Any]]:
    english = str(language or "").lower().startswith("en")
    term = _normalize(query)
    if len(term) < 2:
        return []
    results: list[dict[str, Any]] = []

    def add(kind: str, title: str, subtitle: str, callback: str, haystack: str, score: int) -> None:
        normalized = _normalize(haystack)
        if term not in normalized:
            tokens = [token for token in term.split() if token]
            if not tokens or not all(token in normalized for token in tokens):
                return
        results.append({"kind": kind, "title": title[:80], "subtitle": subtitle[:160], "callback": callback, "score": score})



    navigation = ([
        ("VIP subscription", "Choose a plan and submit payment", "u_vip"),
        ("Education", "Free and paid lessons", "u_edu"),
        ("Market prices", "Forex, metals, crypto, equities and energy", "u_price"),
        ("Risk calculator", "Estimate position size and risk", "u_calc"),
        ("Contests", "Challenges and points", "u_contests"),
        ("Trading center", "Signals, watchlist and journal", "nav_user:trade"),
        ("Account and club", "Subscription, rewards and referrals", "u_account"),
        ("Support", "Tickets and frequently asked questions", "nav_user:growth"),
    ] if english else [
        ("خرید اشتراک VIP", "انتخاب پلن و ثبت پرداخت", "u_vip"),
        ("آموزش", "آموزش رایگان و پولی", "u_edu"),
        ("قیمت بازار", "طلا، ارز، رمزارز، سهام و انرژی", "u_price"),
        ("ماشین حساب ریسک", "محاسبه حجم و ریسک معامله", "u_calc"),
        ("مسابقه‌ها", "چالش و امتیاز", "u_contests"),
        ("مرکز معامله‌گری", "سیگنال، واچ‌لیست و ژورنال", "nav_user:trade"),
        ("حساب و باشگاه", "اشتراک، جوایز و معرفی دوستان", "u_account"),
        ("پشتیبانی", "تیکت و سوالات متداول", "nav_user:growth"),
    ])
    for title, subtitle, callback in navigation:
        add("menu", title, subtitle, callback, f"{title} {subtitle}", 90)

    for faq in db.get("faqs", []):
        if not isinstance(faq, dict) or not faq.get("active", True):
            continue
        question = str(faq.get("q_en") or faq.get("q") or faq.get("question") or ("FAQ" if english else "سوال متداول")) if english else str(faq.get("q") or faq.get("question") or "سوال متداول")
        answer = str(faq.get("a_en") or faq.get("a") or faq.get("answer") or "") if english else str(faq.get("a") or faq.get("answer") or "")
        add("faq", question, answer[:140], f"faq:{faq.get('id')}", f"{question} {answer}", 75)

    for lesson in db.get("lessons", []):
        if not isinstance(lesson, dict) or not lesson.get("active", True) or lesson.get("status", "published") != "published":
            continue
        title = str(lesson.get("title_en") or lesson.get("title") or ("Lesson" if english else "آموزش")) if english else str(lesson.get("title") or "آموزش")
        category = str(lesson.get("category_en") or lesson.get("category") or lesson.get("course") or ("Education" if english else "آموزش")) if english else str(lesson.get("category") or lesson.get("course") or "آموزش")
        content = str(lesson.get("text_en") or lesson.get("text") or "") if english else str(lesson.get("text") or "")
        add("lesson", title, category, f"lesson:{lesson.get('id')}", f"{title} {category} {content}", 70)

    vip_users = db.get("vip_users", {})
    is_vip_user = False
    try:
        from core.domain import is_vip
        is_vip_user = is_vip(db, user_id)
    except Exception:
        is_vip_user = str(user_id) in vip_users
    from modules.signal_portal import user_visible_signals
    for signal in user_visible_signals(db, vip=is_vip_user)[:100]:
        symbol = str(signal.get("symbol") or "")
        add("signal", f"Signal {symbol}" if english else f"سیگنال {symbol}", f"{str(signal.get('side') or '').upper()} | {'Entry' if english else 'ورود'} {signal.get('entry')}", f"user_signal_view:{signal.get('id')}", f"{symbol} {signal.get('side')} {signal.get('entry')} {signal.get('targets')} {signal.get('status')}", 65)

    results.sort(key=lambda row: (-int(row["score"]), row["title"]))
    unique: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for row in results:
        key = (row["kind"], row["callback"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(row)
        if len(unique) >= max(1, min(limit, 20)):
            break
    return unique
