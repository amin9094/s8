from __future__ import annotations

import hashlib
import json
import math
from collections import defaultdict
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any
from zoneinfo import ZoneInfo

from core.db import next_id
from core.utils import parse_dt, utc_iso
from modules.calculator import calculate_crypto_position_size, calculate_position_size
from modules.market_scope import MARKET_CRYPTO, classify_market_symbol, signal_market_category
from modules.outcome_engine import FINAL_SIGNAL_STATUSES, calculate_signal_outcome
from modules.signal_versioning import signal_version_history, verify_revision_chain

ACCOUNT_TYPES = {"personal", "prop_challenge", "prop_funded", "demo"}
ACCOUNT_PHASES = {"personal", "phase_1", "phase_2", "funded", "demo"}
POSITION_STATES = {"planned", "open", "partial", "closed", "cancelled", "voided"}
ACTIVE_POSITION_STATES = {"planned", "open", "partial"}
DECISION_STATES = {"taken", "skipped", "watching", "late_entry"}

DEFAULT_ACCOUNT: dict[str, Any] = {
    "name": "Primary Account",
    "type": "personal",
    "phase": "personal",
    "currency": "USD",
    "balance": 0.0,
    "equity": 0.0,
    "starting_balance": 0.0,
    "high_water_mark": 0.0,
    "floating_pnl": 0.0,
    "leverage": 1.0,
    "timezone": "UTC",
    "daily_reset_hour": 0,
    "risk_enabled": False,
    "default_risk_percent": 1.0,
    "max_daily_risk_percent": 3.0,
    "max_open_risk_percent": 5.0,
    "max_open_trades": 5,
    "max_daily_loss_percent": 5.0,
    "max_total_loss_percent": 10.0,
    "profit_target_percent": 8.0,
    "min_trading_days": 5,
    "current_trading_days": 0,
    "loss_basis": "equity",
    "consistency_rule_percent": 0.0,
    "enabled": True,
    "archived": False,
}


def _number(value: Any, fallback: float = 0.0) -> float:
    try:
        result = Decimal(str(value).replace(",", "").strip())
    except (InvalidOperation, TypeError, ValueError, AttributeError):
        return fallback
    if not result.is_finite():
        return fallback
    return float(result)


def _int(value: Any, fallback: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def _root(db: dict[str, Any], key: str, default: Any) -> Any:
    value = db.setdefault(key, default)
    if not isinstance(value, type(default)):
        value = type(default)()
        db[key] = value
    return value


def ensure_trading_os(db: dict[str, Any]) -> None:
    _root(db, "trading_accounts", {})
    _root(db, "user_positions", {})
    _root(db, "position_audit", {})
    _root(db, "position_pnl_events", {})
    _root(db, "signal_revision_acknowledgements", {})
    _root(db, "miniapp_event_stream", [])
    _root(db, "behavioral_insights", {})


def _legacy_profile(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    profiles = db.setdefault("personal_risk_profiles", {})
    profile = profiles.setdefault(str(user_id), {}) if isinstance(profiles, dict) else {}
    return profile if isinstance(profile, dict) else {}


def _account_from_legacy(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    profile = _legacy_profile(db, user_id)
    balance = max(0.0, _number(profile.get("balance")))
    account = {
        **DEFAULT_ACCOUNT,
        "id": next_id(db, "trading_account"),
        "user_id": str(user_id),
        "name": str(profile.get("account_name") or "Primary Account")[:80],
        "currency": str(profile.get("account_currency") or "USD").upper(),
        "balance": balance,
        "equity": max(0.0, _number(profile.get("current_equity"), balance) or balance),
        "starting_balance": max(0.0, _number(profile.get("starting_balance"), balance) or balance),
        "high_water_mark": max(0.0, _number(profile.get("current_equity"), balance) or balance),
        "leverage": max(1.0, _number(profile.get("leverage"), 1.0)),
        "timezone": str(profile.get("timezone") or "UTC"),
        "risk_enabled": bool(profile.get("enabled", False)),
        "default_risk_percent": max(0.1, _number(profile.get("default_risk_percent"), 1.0)),
        "max_daily_risk_percent": max(0.1, _number(profile.get("max_daily_risk_percent"), 3.0)),
        "max_open_risk_percent": max(0.1, _number(profile.get("max_open_risk_percent"), 5.0)),
        "max_open_trades": max(1, _int(profile.get("max_open_trades"), 5)),
        "max_daily_loss_percent": max(0.1, _number(profile.get("max_daily_loss_percent"), 5.0)),
        "max_total_loss_percent": max(0.1, _number(profile.get("max_total_loss_percent"), 10.0)),
        "profit_target_percent": max(0.1, _number(profile.get("profit_target_percent"), 8.0)),
        "min_trading_days": max(1, _int(profile.get("min_trading_days"), 5)),
        "current_trading_days": max(0, _int(profile.get("current_trading_days"), 0)),
        "type": "prop_challenge" if profile.get("prop_firm_enabled") else "personal",
        "phase": "phase_1" if profile.get("prop_firm_enabled") else "personal",
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
        "migration_source": "personal_risk_profile",
    }
    return account


def accounts_for_user(db: dict[str, Any], user_id: int | str, *, include_archived: bool = False) -> list[dict[str, Any]]:
    ensure_trading_os(db)
    uid = str(user_id)
    rows = db["trading_accounts"].setdefault(uid, [])
    if not isinstance(rows, list):
        rows = []
        db["trading_accounts"][uid] = rows
    if not any(isinstance(row, dict) for row in rows):
        rows.append(_account_from_legacy(db, uid))
    normalized: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        for key, value in DEFAULT_ACCOUNT.items():
            row.setdefault(key, value)
        row.setdefault("id", next_id(db, "trading_account"))
        row.setdefault("user_id", uid)
        row.setdefault("created_at", utc_iso())
        row.setdefault("updated_at", row.get("created_at"))
        normalized.append(row)
    rows[:] = normalized
    visible = [row for row in rows if include_archived or not row.get("archived")]
    visible.sort(key=lambda row: (not bool(row.get("is_default")), int(row.get("id", 0) or 0)))
    if visible and not any(row.get("is_default") for row in visible):
        visible[0]["is_default"] = True
    return visible


def get_account(db: dict[str, Any], user_id: int | str, account_id: int | str | None = None) -> dict[str, Any]:
    rows = accounts_for_user(db, user_id)
    if account_id is None or str(account_id).strip() == "":
        return next((row for row in rows if row.get("is_default")), rows[0])
    target = _int(account_id, -1)
    account = next((row for row in rows if _int(row.get("id"), -2) == target), None)
    if not account:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    return account


def _validate_timezone(value: str) -> str:
    clean = str(value or "UTC").strip() or "UTC"
    try:
        ZoneInfo(clean)
    except Exception as exc:
        raise ValueError("INVALID_TIMEZONE") from exc
    return clean


def create_or_update_account(
    db: dict[str, Any], user_id: int | str, values: dict[str, Any], *, account_id: int | str | None = None
) -> dict[str, Any]:
    ensure_trading_os(db)
    uid = str(user_id)
    if account_id is None:
        rows = accounts_for_user(db, uid, include_archived=True)
        if len([row for row in rows if not row.get("archived")]) >= 10:
            raise ValueError("ACCOUNT_LIMIT_REACHED")
        account = {
            **DEFAULT_ACCOUNT,
            "id": next_id(db, "trading_account"),
            "user_id": uid,
            "created_at": utc_iso(),
            "updated_at": utc_iso(),
        }
        db["trading_accounts"].setdefault(uid, []).append(account)
    else:
        account = get_account(db, uid, account_id)

    if "name" in values:
        name = str(values.get("name") or "").strip()
        if not 2 <= len(name) <= 80:
            raise ValueError("INVALID_ACCOUNT_NAME")
        account["name"] = name
    if "type" in values:
        account_type = str(values.get("type") or "personal").lower()
        if account_type not in ACCOUNT_TYPES:
            raise ValueError("INVALID_ACCOUNT_TYPE")
        account["type"] = account_type
    if "phase" in values:
        phase = str(values.get("phase") or "personal").lower()
        if phase not in ACCOUNT_PHASES:
            raise ValueError("INVALID_ACCOUNT_PHASE")
        account["phase"] = phase
    if "currency" in values:
        currency = str(values.get("currency") or "USD").upper()
        if currency not in {"USD", "USDT", "EUR", "GBP", "AED", "IRR"}:
            raise ValueError("UNSUPPORTED_ACCOUNT_CURRENCY")
        account["currency"] = currency
    for key, minimum, maximum in (
        ("balance", 0.0, 1_000_000_000_000.0),
        ("equity", 0.0, 1_000_000_000_000.0),
        ("starting_balance", 0.0, 1_000_000_000_000.0),
        ("high_water_mark", 0.0, 1_000_000_000_000.0),
        ("floating_pnl", -1_000_000_000_000.0, 1_000_000_000_000.0),
        ("leverage", 1.0, 1000.0),
        ("default_risk_percent", 0.05, 20.0),
        ("max_daily_risk_percent", 0.1, 50.0),
        ("max_open_risk_percent", 0.1, 100.0),
        ("max_daily_loss_percent", 0.1, 50.0),
        ("max_total_loss_percent", 0.1, 80.0),
        ("profit_target_percent", 0.1, 500.0),
        ("consistency_rule_percent", 0.0, 100.0),
    ):
        if key in values:
            parsed = _number(values.get(key), math.nan)
            if not math.isfinite(parsed) or not minimum <= parsed <= maximum:
                raise ValueError(f"INVALID_{key.upper()}")
            account[key] = parsed
    if "max_open_trades" in values:
        count = _int(values.get("max_open_trades"), -1)
        if not 1 <= count <= 100:
            raise ValueError("INVALID_MAX_OPEN_TRADES")
        account["max_open_trades"] = count
    for key, minimum, maximum in (
        ("min_trading_days", 1, 365),
        ("current_trading_days", 0, 3650),
        ("daily_reset_hour", 0, 23),
    ):
        if key in values:
            parsed = _int(values.get(key), -1)
            if not minimum <= parsed <= maximum:
                raise ValueError(f"INVALID_{key.upper()}")
            account[key] = parsed
    if "timezone" in values:
        account["timezone"] = _validate_timezone(str(values.get("timezone") or "UTC"))
    for key in ("risk_enabled", "enabled"):
        if key in values:
            account[key] = bool(values.get(key))
    if "loss_basis" in values:
        basis = str(values.get("loss_basis") or "equity").lower()
        if basis not in {"equity", "balance"}:
            raise ValueError("INVALID_LOSS_BASIS")
        account["loss_basis"] = basis
    if values.get("is_default"):
        for row in accounts_for_user(db, uid, include_archived=True):
            row["is_default"] = False
        account["is_default"] = True
    account["updated_at"] = utc_iso()
    if _number(account.get("high_water_mark")) < _number(account.get("equity")):
        account["high_water_mark"] = _number(account.get("equity"))
    _sync_legacy_profile(db, uid, account)
    emit_event(db, uid, "account.updated", {"account_id": account["id"]})
    return dict(account)


def archive_account(db: dict[str, Any], user_id: int | str, account_id: int | str) -> dict[str, Any]:
    account = get_account(db, user_id, account_id)
    if any(
        str(row.get("status")) in ACTIVE_POSITION_STATES
        for row in positions_for_user(db, user_id, account_id=account_id)
    ):
        raise ValueError("ACCOUNT_HAS_OPEN_POSITIONS")
    active = accounts_for_user(db, user_id)
    if len(active) <= 1:
        raise ValueError("CANNOT_ARCHIVE_ONLY_ACCOUNT")
    account["archived"] = True
    account["enabled"] = False
    account["updated_at"] = utc_iso()
    if account.get("is_default"):
        account["is_default"] = False
        replacement = next(row for row in active if int(row.get("id")) != int(account.get("id")))
        replacement["is_default"] = True
    emit_event(db, user_id, "account.archived", {"account_id": account["id"]})
    return dict(account)


def _sync_legacy_profile(db: dict[str, Any], user_id: int | str, account: dict[str, Any]) -> None:
    profile = _legacy_profile(db, user_id)
    profile.update(
        {
            "balance": account.get("balance", 0.0),
            "account_currency": account.get("currency", "USD"),
            "default_risk_percent": account.get("default_risk_percent", 1.0),
            "max_daily_risk_percent": account.get("max_daily_risk_percent", 3.0),
            "max_open_risk_percent": account.get("max_open_risk_percent", 5.0),
            "max_open_trades": account.get("max_open_trades", 5),
            "leverage": account.get("leverage", 1.0),
            "enabled": account.get("risk_enabled", False),
            "prop_firm_enabled": account.get("type") in {"prop_challenge", "prop_funded"},
            "starting_balance": account.get("starting_balance", account.get("balance", 0.0)),
            "current_equity": account.get("equity", account.get("balance", 0.0)),
            "max_daily_loss_percent": account.get("max_daily_loss_percent", 5.0),
            "max_total_loss_percent": account.get("max_total_loss_percent", 10.0),
            "profit_target_percent": account.get("profit_target_percent", 8.0),
            "min_trading_days": account.get("min_trading_days", 5),
            "current_trading_days": account.get("current_trading_days", 0),
            "timezone": account.get("timezone", "UTC"),
            "account_name": account.get("name", "Primary Account"),
            "updated_at": utc_iso(),
        }
    )


def positions_for_user(
    db: dict[str, Any], user_id: int | str, *, account_id: int | str | None = None, include_voided: bool = False
) -> list[dict[str, Any]]:
    ensure_trading_os(db)
    uid = str(user_id)
    rows = db["user_positions"].setdefault(uid, [])
    if not isinstance(rows, list):
        rows = []
        db["user_positions"][uid] = rows
    output = [row for row in rows if isinstance(row, dict)]
    if account_id is not None:
        output = [row for row in output if _int(row.get("account_id"), -1) == _int(account_id, -2)]
    if not include_voided:
        output = [row for row in output if str(row.get("status")) not in {"voided"}]
    output.sort(key=lambda row: str(row.get("opened_at") or row.get("created_at") or ""), reverse=True)
    return output


def find_position(db: dict[str, Any], user_id: int | str, position_id: int | str) -> dict[str, Any] | None:
    target = _int(position_id, -1)
    return next((row for row in positions_for_user(db, user_id, include_voided=True) if _int(row.get("id"), -2) == target), None)


def position_for_signal_record(db: dict[str, Any], user_id: int | str, signal_id: int | str) -> dict[str, Any] | None:
    target = _int(signal_id, -1)
    candidates = [
        row
        for row in positions_for_user(db, user_id, include_voided=True)
        if _int(row.get("signal_id"), -2) == target
    ]
    candidates.sort(key=lambda row: str(row.get("opened_at") or row.get("created_at") or ""), reverse=True)
    return candidates[0] if candidates else None


def parse_signal_entries(signal: dict[str, Any]) -> dict[str, Any]:
    raw_values = signal.get("entries")
    values: list[float] = []
    if isinstance(raw_values, list):
        for value in raw_values:
            number = _number(value, math.nan)
            if math.isfinite(number) and number > 0:
                values.append(number)
    if not values:
        raw = str(signal.get("entry") or "").replace(",", "").strip()
        separators = ("-", "–", "—", "to", "تا")
        pieces = [raw]
        for separator in separators:
            if separator in raw:
                pieces = [part.strip() for part in raw.split(separator, 1)]
                break
        for part in pieces:
            number = _number(part, math.nan)
            if math.isfinite(number) and number > 0:
                values.append(number)
    unique = list(dict.fromkeys(round(value, 10) for value in values))
    if not unique:
        return {"entry_type": "unknown", "entries": [], "entry_low": None, "entry_high": None, "planned_entry": None}
    low = min(unique)
    high = max(unique)
    return {
        "entry_type": "single" if len(unique) == 1 or abs(high - low) < 1e-12 else "range",
        "entries": unique,
        "entry_low": low,
        "entry_high": high,
        "planned_entry": round(sum(unique) / len(unique), 10),
    }


def _local_trade_day(account: dict[str, Any], value: str | None = None) -> str:
    dt = parse_dt(value) or datetime.now(UTC)
    try:
        local = dt.astimezone(ZoneInfo(str(account.get("timezone") or "UTC")))
    except Exception:
        local = dt
    reset_hour = max(0, min(23, _int(account.get("daily_reset_hour"), 0)))
    if local.hour < reset_hour:
        local = local.replace(hour=0, minute=0, second=0, microsecond=0)
        from datetime import timedelta

        local -= timedelta(days=1)
    return local.date().isoformat()


def account_exposure(db: dict[str, Any], user_id: int | str, account_id: int | str | None = None) -> dict[str, Any]:
    account = get_account(db, user_id, account_id)
    all_rows = positions_for_user(db, user_id, account_id=account["id"], include_voided=True)
    active = [row for row in all_rows if str(row.get("status")) in ACTIVE_POSITION_STATES]
    today = _local_trade_day(account)
    open_risk = sum(max(0.0, _number(row.get("remaining_risk_percent"), _number(row.get("actual_risk_percent")))) for row in active)
    # Daily risk is a cumulative execution budget. Closing a trade must not recycle
    # the risk allowance and permit unlimited same-day re-entry. Only voided or
    # cancelled executions are excluded; the trade day is derived from opened_at
    # in the account timezone (not the signal publication date).
    daily_risk = sum(
        max(0.0, _number(row.get("actual_risk_percent")))
        for row in all_rows
        if str(row.get("status")) not in {"voided", "cancelled"}
        and _local_trade_day(account, str(row.get("opened_at") or row.get("created_at") or "")) == today
    )
    max_open = max(0.0, _number(account.get("max_open_risk_percent"), 5.0))
    max_daily = max(0.0, _number(account.get("max_daily_risk_percent"), 3.0))
    return {
        "account_id": account["id"],
        "trade_day": today,
        "open_trades": len(active),
        "open_risk_percent": round(open_risk, 6),
        "daily_risk_percent": round(daily_risk, 6),
        "remaining_open_risk_percent": round(max(0.0, max_open - open_risk), 6),
        "remaining_daily_risk_percent": round(max(0.0, max_daily - daily_risk), 6),
        "remaining_trade_slots": max(0, _int(account.get("max_open_trades"), 5) - len(active)),
        "risk_exhausted": open_risk >= max_open - 1e-9 or daily_risk >= max_daily - 1e-9,
    }


def portfolio_exposure(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    rows = [account_exposure(db, user_id, account["id"]) for account in accounts_for_user(db, user_id)]
    return {
        "accounts": rows,
        "open_trades": sum(row["open_trades"] for row in rows),
        "open_risk_percent": round(sum(row["open_risk_percent"] for row in rows), 6),
        "daily_risk_percent": round(sum(row["daily_risk_percent"] for row in rows), 6),
    }


def _calculation_volume(calculation: dict[str, Any]) -> float:
    return max(0.0, _number(calculation.get("lot"), _number(calculation.get("quantity"))))


def calculate_position_plan(
    db: dict[str, Any],
    user_id: int | str,
    signal: dict[str, Any],
    *,
    account_id: int | str | None = None,
    risk_percent: float | None = None,
    entry_price: float | None = None,
    stop_price: float | None = None,
) -> dict[str, Any]:
    account = get_account(db, user_id, account_id)
    exposure = account_exposure(db, user_id, account["id"])
    entry_struct = parse_signal_entries(signal)
    entry = _number(entry_price, _number(entry_struct.get("planned_entry")))
    stop = _number(stop_price, _number(signal.get("stop")))
    requested = _number(risk_percent, _number(signal.get("risk"), _number(account.get("default_risk_percent"), 1.0)))
    allowed = min(requested, exposure["remaining_daily_risk_percent"], exposure["remaining_open_risk_percent"])
    if exposure["remaining_trade_slots"] <= 0:
        allowed = 0.0
    result: dict[str, Any] = {
        "available": False,
        "account": dict(account),
        "account_id": account["id"],
        "entry": entry,
        "stop": stop,
        "entry_structure": entry_struct,
        "requested_risk_percent": round(max(0.0, requested), 6),
        "allowed_risk_percent": round(max(0.0, allowed), 6),
        "budget_limited": allowed + 1e-9 < requested,
        "exposure": exposure,
        "reason": "",
    }
    if not account.get("enabled", True) or not account.get("risk_enabled"):
        result["reason"] = "RISK_PROFILE_DISABLED"
        return result
    balance = _number(account.get("balance"))
    if balance <= 0 or entry <= 0 or stop <= 0 or allowed <= 0:
        result["reason"] = "RISK_PROFILE_INCOMPLETE_OR_BUDGET_EXHAUSTED"
        return result
    try:
        if signal_market_category(signal) == MARKET_CRYPTO:
            calculation = calculate_crypto_position_size(
                balance,
                allowed,
                entry,
                stop,
                leverage=min(125.0, max(1.0, _number(account.get("leverage"), 1.0))),
            )
        else:
            calculation = calculate_position_size(
                str(signal.get("symbol") or ""),
                balance,
                allowed,
                entry,
                stop,
                current_price=entry,
                leverage=max(1.0, _number(account.get("leverage"), 1.0)),
            )
    except ValueError as exc:
        result["reason"] = str(exc)
        return result
    effective_money = max(0.0, _number(calculation.get("effective_risk"), _number(calculation.get("risk_amount"))))
    actual_risk = effective_money / balance * 100 if balance > 0 else 0.0
    result.update(
        {
            "available": _calculation_volume(calculation) > 0,
            "calculation": calculation,
            "planned_volume": _calculation_volume(calculation),
            "risk_money": round(effective_money, 6),
            "actual_risk_percent": round(actual_risk, 6),
            "reason": "" if _calculation_volume(calculation) > 0 else "POSITION_BELOW_MINIMUM",
        }
    )
    return result


def _signal_direction(signal: dict[str, Any]) -> str:
    side = str(signal.get("side") or "").upper()
    return "sell" if side in {"SELL", "SHORT"} else "buy"


def late_entry_snapshot(signal: dict[str, Any], current_price: float | None) -> dict[str, Any]:
    entry_struct = parse_signal_entries(signal)
    current = _number(current_price, 0.0)
    stop = _number(signal.get("stop"))
    targets = [_number(value) for value in signal.get("targets", []) if _number(value) > 0]
    planned = _number(entry_struct.get("planned_entry"))
    if current <= 0 or stop <= 0 or not targets:
        return {"available": False, "reason": "MARKET_PRICE_UNAVAILABLE"}
    side = _signal_direction(signal)
    risk_distance = abs(current - stop)
    reward_distance = abs(targets[0] - current)
    rr = reward_distance / risk_distance if risk_distance > 0 else 0.0
    if side == "buy":
        stop_valid = stop < current
        target_valid = targets[0] > current
        missed = current > max(_number(entry_struct.get("entry_high"), planned), planned) and current >= targets[0]
    else:
        stop_valid = stop > current
        target_valid = targets[0] < current
        missed = current < min(_number(entry_struct.get("entry_low"), planned), planned) and current <= targets[0]
    distance_percent = ((current - planned) / planned * 100) if planned else 0.0
    valid = stop_valid and target_valid and rr >= 2.0 and not missed
    return {
        "available": True,
        "current_price": current,
        "planned_entry": planned,
        "distance_from_entry_percent": round(distance_percent, 6),
        "risk_reward": round(rr, 4),
        "valid": valid,
        "missed": missed,
        "status": "valid" if valid else "missed" if missed else "caution",
    }


def _cluster_for_symbol(symbol: str) -> str:
    clean = "".join(ch for ch in str(symbol or "").upper() if ch.isalnum())
    if clean.startswith(("BTC", "ETH", "SOL", "XRP", "ADA", "DOGE", "BNB")) or clean.endswith("USDT"):
        return "crypto"
    if clean in {"XAUUSD", "GOLD", "XAGUSD", "SILVER"}:
        return "metals"
    if clean in {"US100", "NAS100", "US30", "US500", "SPX500", "GER40", "UK100"}:
        return "indices"
    if len(clean) >= 6 and clean[:6].isalpha():
        currencies = [clean[:3], clean[3:6]]
        return "usd" if "USD" in currencies else "/".join(sorted(currencies))
    return classify_market_symbol(clean) or "other"


def correlation_snapshot(db: dict[str, Any], user_id: int | str, *, candidate_symbol: str = "") -> dict[str, Any]:
    active = [row for row in positions_for_user(db, user_id) if str(row.get("status")) in ACTIVE_POSITION_STATES]
    clusters: dict[str, dict[str, Any]] = defaultdict(lambda: {"positions": 0, "risk_percent": 0.0, "symbols": []})
    for row in active:
        cluster = str(row.get("correlation_cluster") or _cluster_for_symbol(str(row.get("symbol") or "")))
        bucket = clusters[cluster]
        bucket["positions"] += 1
        bucket["risk_percent"] += max(0.0, _number(row.get("remaining_risk_percent"), _number(row.get("actual_risk_percent"))))
        bucket["symbols"].append(str(row.get("symbol") or ""))
    candidate_cluster = _cluster_for_symbol(candidate_symbol) if candidate_symbol else ""
    candidate = clusters.get(candidate_cluster, {"positions": 0, "risk_percent": 0.0, "symbols": []})
    rows = [
        {
            "cluster": key,
            "positions": value["positions"],
            "risk_percent": round(value["risk_percent"], 6),
            "symbols": sorted(set(value["symbols"])),
            "severity": "high" if value["risk_percent"] >= 3 else "medium" if value["risk_percent"] >= 1.5 else "low",
        }
        for key, value in clusters.items()
    ]
    rows.sort(key=lambda row: row["risk_percent"], reverse=True)
    return {
        "clusters": rows,
        "candidate_cluster": candidate_cluster,
        "candidate_existing_positions": candidate["positions"],
        "candidate_existing_risk_percent": round(candidate["risk_percent"], 6),
    }


def pretrade_safety_gate(
    db: dict[str, Any],
    user_id: int | str,
    signal: dict[str, Any],
    *,
    account_id: int | str | None = None,
    entry_price: float | None = None,
    stop_price: float | None = None,
    risk_percent: float | None = None,
    current_price: float | None = None,
) -> dict[str, Any]:
    """Evaluate a trade using explicit hard blocks and soft warnings.

    Hard blocks protect account invariants and can never be bypassed. Soft
    warnings may be acknowledged by an experienced user with an audit reason.
    """
    plan = calculate_position_plan(
        db,
        user_id,
        signal,
        account_id=account_id,
        risk_percent=risk_percent,
        entry_price=entry_price,
        stop_price=stop_price,
    )
    account = plan["account"]
    correlation = correlation_snapshot(db, user_id, candidate_symbol=str(signal.get("symbol") or ""))
    late = late_entry_snapshot(signal, current_price or entry_price)
    reasons: list[dict[str, Any]] = []

    def add(code: str, level: str, *, block_type: str = "soft", **params: Any) -> None:
        reasons.append({"code": code, "level": level, "block_type": block_type, "params": params})

    if not plan.get("available"):
        add(str(plan.get("reason") or "POSITION_UNAVAILABLE"), "danger", block_type="hard")
    if plan.get("budget_limited"):
        add(
            "RISK_REDUCED_BY_ACCOUNT_LIMITS",
            "warning",
            requested=plan.get("requested_risk_percent"),
            allowed=plan.get("allowed_risk_percent"),
        )
    if plan["exposure"].get("remaining_trade_slots", 0) <= 0:
        add("MAX_OPEN_TRADES_REACHED", "danger", block_type="hard")
    if correlation.get("candidate_existing_positions", 0) >= 2 or correlation.get("candidate_existing_risk_percent", 0) >= 2.0:
        add(
            "CORRELATION_CONCENTRATION",
            "warning" if correlation.get("candidate_existing_risk_percent", 0) < 3 else "danger",
            cluster=correlation.get("candidate_cluster"),
            risk=correlation.get("candidate_existing_risk_percent"),
        )
    if late.get("available") and late.get("risk_reward", 0) < 2:
        add("RISK_REWARD_BELOW_2", "danger", rr=late.get("risk_reward"))
    if late.get("missed"):
        add("ENTRY_ALREADY_MISSED", "danger", block_type="hard")
    signal_status = str(signal.get("status") or "open").strip().lower()
    if signal_status in FINAL_SIGNAL_STATUSES or signal_status in {"closed", "inactive", "archived", "deleted"}:
        add("SIGNAL_NOT_ACTIVE", "danger", block_type="hard")
    if account.get("type") in {"prop_challenge", "prop_funded"}:
        prop = prop_account_snapshot(db, user_id, account["id"])
        if prop.get("status") == "breached":
            add("PROP_RULE_ALREADY_BREACHED", "danger", block_type="hard", breaches=prop.get("breaches"))
        elif prop.get("breach_buffer_percent", 100) < 1:
            add("PROP_BREACH_BUFFER_LOW", "warning", buffer=prop.get("breach_buffer_percent"))
    if not reasons:
        add("ENTRY_WITHIN_CONFIGURED_LIMITS", "info", block_type="none")

    hard_blocks = [row for row in reasons if row.get("block_type") == "hard"]
    soft_warnings = [row for row in reasons if row.get("block_type") == "soft" and row.get("level") in {"warning", "danger"}]
    soft_dangers = [row for row in soft_warnings if row.get("level") == "danger"]
    status = "red" if hard_blocks or soft_dangers else "yellow" if soft_warnings else "green"
    can_execute = bool(plan.get("available")) and not hard_blocks and not soft_dangers
    return {
        "status": status,
        "can_execute": can_execute,
        "can_override": bool(plan.get("available")) and not hard_blocks and bool(soft_warnings),
        "hard_blocks": hard_blocks,
        "soft_warnings": soft_warnings,
        "reasons": reasons,
        "plan": plan,
        "correlation": correlation,
        "late_entry": late,
    }


def _audit(db: dict[str, Any], user_id: int | str, position_id: int | str, event: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    ensure_trading_os(db)
    uid = str(user_id)
    row = {
        "id": next_id(db, "position_audit"),
        "position_id": _int(position_id),
        "event": str(event),
        "payload": dict(payload or {}),
        "created_at": utc_iso(),
    }
    db["position_audit"].setdefault(uid, []).append(row)
    db["position_audit"][uid] = db["position_audit"][uid][-10000:]
    return row


def position_audit_for_user(db: dict[str, Any], user_id: int | str, position_id: int | str | None = None) -> list[dict[str, Any]]:
    ensure_trading_os(db)
    rows = [row for row in db["position_audit"].get(str(user_id), []) if isinstance(row, dict)]
    if position_id is not None:
        rows = [row for row in rows if _int(row.get("position_id"), -1) == _int(position_id, -2)]
    return rows[-500:]


def open_position(
    db: dict[str, Any],
    user_id: int | str,
    signal: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    uid = str(user_id)
    account = get_account(db, uid, payload.get("account_id"))
    entry = _number(payload.get("actual_entry"), _number(parse_signal_entries(signal).get("planned_entry")))
    stop = _number(payload.get("actual_stop"), _number(signal.get("stop")))
    requested_risk = _number(payload.get("risk_percent"), _number(signal.get("risk"), _number(account.get("default_risk_percent"), 1.0)))
    current_price = _number(payload.get("current_price"), entry)
    gate = pretrade_safety_gate(
        db,
        uid,
        signal,
        account_id=account["id"],
        entry_price=entry,
        stop_price=stop,
        risk_percent=requested_risk,
        current_price=current_price,
    )
    override_reason = str(payload.get("override_reason") or "").strip()
    if gate.get("hard_blocks"):
        raise ValueError("PRETRADE_HARD_BLOCK")
    if not gate["can_execute"]:
        if not gate.get("can_override") or not payload.get("override") or len(override_reason) < 8:
            raise ValueError("PRETRADE_GATE_BLOCKED")
    plan = gate["plan"]
    volume = _number(payload.get("actual_volume"), _number(plan.get("planned_volume")))
    if volume <= 0:
        raise ValueError("INVALID_EXECUTION_VOLUME")
    balance = max(0.0, _number(account.get("balance")))
    planned_volume = max(0.0, _number(plan.get("planned_volume")))
    volume_ratio = volume / planned_volume if planned_volume > 0 else 1.0
    risk_money = max(0.0, _number(plan.get("risk_money"))) * volume_ratio
    actual_risk = risk_money / balance * 100 if balance > 0 else 0.0
    # Overrides may acknowledge soft warnings (correlation, late entry), but they
    # never bypass the account's hard daily/open-risk ceilings.
    exposure = account_exposure(db, uid, account["id"])
    max_open_risk = max(0.0, _number(account.get("max_open_risk_percent"), 5.0))
    max_daily_risk = max(0.0, _number(account.get("max_daily_risk_percent"), 3.0))
    if actual_risk <= 0 or actual_risk > 20.0:
        raise ValueError("EXECUTION_RISK_OUT_OF_RANGE")
    if exposure["open_risk_percent"] + actual_risk > max_open_risk + 1e-9:
        raise ValueError("MAX_OPEN_RISK_EXCEEDED")
    if exposure["daily_risk_percent"] + actual_risk > max_daily_risk + 1e-9:
        raise ValueError("MAX_DAILY_RISK_EXCEEDED")
    previous = position_for_signal_record(db, uid, signal.get("id"))
    if previous and str(previous.get("status")) in ACTIVE_POSITION_STATES:
        raise ValueError("SIGNAL_POSITION_ALREADY_OPEN")
    entry_struct = parse_signal_entries(signal)
    now = utc_iso()
    position = {
        "id": next_id(db, "user_position"),
        "user_id": uid,
        "account_id": account["id"],
        "signal_id": _int(signal.get("id")),
        "signal_display_number": _int(signal.get("display_number"), _int(signal.get("id"))),
        "symbol": str(signal.get("symbol") or "").upper(),
        "market_category": signal_market_category(signal),
        "side": str(signal.get("side") or "").upper(),
        "decision": "taken",
        "status": "open",
        "entry_structure": entry_struct,
        "planned_entry": entry_struct.get("planned_entry"),
        "actual_entry": entry,
        "actual_stop": stop,
        "actual_volume": volume,
        "planned_risk_percent": max(0.0, _number(signal.get("risk"))),
        "requested_risk_percent": requested_risk,
        "allowed_risk_percent": _number(plan.get("allowed_risk_percent")),
        "actual_risk_percent": round(actual_risk, 6),
        "remaining_risk_percent": round(actual_risk, 6),
        "risk_money": round(risk_money, 6),
        "remaining_risk_money": round(risk_money, 6),
        "targets": list(signal.get("targets") or []),
        "current_price_at_entry": current_price,
        "late_entry": bool(payload.get("late_entry")) or str(gate.get("late_entry", {}).get("status")) in {"caution", "missed"},
        "correlation_cluster": _cluster_for_symbol(str(signal.get("symbol") or "")),
        "pretrade_gate": gate,
        "override": bool(payload.get("override")),
        "override_reason": override_reason[:500],
        "opened_at": now,
        "created_at": now,
        "updated_at": now,
        "closed_at": None,
        "journal_entry_id": None,
        "fees": 0.0,
        "commission": 0.0,
        "swap": 0.0,
        "realized_pnl_amount": 0.0,
        "realized_pnl_percent": 0.0,
        "partial_closes": [],
    }
    db["user_positions"].setdefault(uid, []).append(position)
    _audit(db, uid, position["id"], "opened", {"gate_status": gate["status"], "override": position["override"]})
    emit_event(db, uid, "position.opened", {"position_id": position["id"], "signal_id": position["signal_id"]})
    return dict(position)


def update_position_from_signal_choice(
    db: dict[str, Any], user_id: int | str, signal_id: int | str, choice: str
) -> dict[str, Any] | None:
    position = position_for_signal_record(db, user_id, signal_id)
    if not position:
        return None
    choice = str(choice or "").lower()
    position["decision"] = choice
    position["updated_at"] = utc_iso()
    if choice != "taken" and str(position.get("status")) in {"planned", "open"}:
        position["status"] = "voided"
        position["void_reason"] = f"choice_changed_to_{choice}"
        position["closed_at"] = utc_iso()
        position["remaining_risk_percent"] = 0.0
        position["remaining_risk_money"] = 0.0
        _audit(db, user_id, position["id"], "voided", {"choice": choice})
        emit_event(db, user_id, "position.voided", {"position_id": position["id"], "choice": choice})
    return dict(position)


def _record_pnl_event(
    db: dict[str, Any],
    user_id: int | str,
    position: dict[str, Any],
    *,
    event_type: str,
    realized_pnl: float,
    gross_pnl: float,
    commission: float,
    fees: float,
    swap: float,
    closed_fraction: float,
    exit_price: float | None,
    occurred_at: str | None = None,
) -> dict[str, Any]:
    ensure_trading_os(db)
    uid = str(user_id)
    event = {
        "id": next_id(db, "position_pnl_event"),
        "user_id": uid,
        "account_id": _int(position.get("account_id")),
        "position_id": _int(position.get("id")),
        "signal_id": _int(position.get("signal_id")),
        "event_type": str(event_type),
        "realized_pnl": round(realized_pnl, 6),
        "gross_pnl": round(gross_pnl, 6),
        "commission": round(commission, 6),
        "fees": round(fees, 6),
        "swap": round(swap, 6),
        "closed_fraction": round(closed_fraction, 6),
        "exit_price": exit_price,
        "occurred_at": occurred_at or utc_iso(),
    }
    rows = db["position_pnl_events"].setdefault(uid, [])
    rows.append(event)
    db["position_pnl_events"][uid] = rows[-20000:]
    return event


def pnl_events_for_account(
    db: dict[str, Any], user_id: int | str, account_id: int | str
) -> list[dict[str, Any]]:
    """Return canonical P&L events plus a compatibility view for old closes."""
    ensure_trading_os(db)
    uid = str(user_id)
    target = _int(account_id, -1)
    rows = [
        dict(row) for row in db["position_pnl_events"].get(uid, [])
        if isinstance(row, dict) and _int(row.get("account_id"), -2) == target
    ]
    recorded_ids = {int(row.get("id", 0) or 0) for row in rows}
    synthetic_id = -1
    for position in positions_for_user(db, uid, account_id=target, include_voided=True):
        for close in position.get("partial_closes", []) if isinstance(position.get("partial_closes"), list) else []:
            if not isinstance(close, dict):
                continue
            event_id = _int(close.get("pnl_event_id"))
            if event_id and event_id in recorded_ids:
                continue
            rows.append({
                "id": synthetic_id,
                "user_id": uid,
                "account_id": target,
                "position_id": _int(position.get("id")),
                "signal_id": _int(position.get("signal_id")),
                "event_type": "legacy_close",
                "realized_pnl": _number(close.get("net_pnl_amount"), _number(close.get("gross_pnl_amount"))),
                "gross_pnl": _number(close.get("gross_pnl_amount")),
                "commission": _number(close.get("commission")),
                "fees": _number(close.get("fees")),
                "swap": _number(close.get("swap")),
                "closed_fraction": _number(close.get("fraction"), 1.0),
                "exit_price": close.get("exit_price"),
                "occurred_at": close.get("created_at") or position.get("closed_at") or position.get("updated_at"),
                "synthetic": True,
            })
            synthetic_id -= 1
    rows.sort(key=lambda row: str(row.get("occurred_at") or ""))
    return rows


def close_position(
    db: dict[str, Any], user_id: int | str, position_id: int | str, payload: dict[str, Any]
) -> dict[str, Any]:
    position = find_position(db, user_id, position_id)
    if not position:
        raise ValueError("POSITION_NOT_FOUND")
    if str(position.get("status")) not in ACTIVE_POSITION_STATES:
        raise ValueError("POSITION_NOT_OPEN")
    close_fraction = _number(payload.get("close_fraction"), 1.0)
    if not 0 < close_fraction <= 1:
        raise ValueError("INVALID_CLOSE_FRACTION")
    exit_price = _number(payload.get("exit_price"), 0.0)
    pnl_amount = _number(payload.get("pnl_amount"), math.nan)
    pnl_percent = _number(payload.get("pnl_percent"), math.nan)
    if not math.isfinite(pnl_amount) and not math.isfinite(pnl_percent):
        raise ValueError("PNL_REQUIRED")
    if not math.isfinite(pnl_amount):
        account = get_account(db, user_id, position.get("account_id"))
        pnl_amount = _number(account.get("balance")) * pnl_percent / 100
    if not math.isfinite(pnl_percent):
        account = get_account(db, user_id, position.get("account_id"))
        balance = max(_number(account.get("balance")), 1e-9)
        pnl_percent = pnl_amount / balance * 100
    fees = max(0.0, _number(payload.get("fees")))
    commission = max(0.0, _number(payload.get("commission")))
    swap = _number(payload.get("swap"))
    net_amount = pnl_amount - fees - commission + swap
    record = {
        "id": next_id(db, "position_partial_close"),
        "fraction": round(close_fraction, 6),
        "exit_price": exit_price or None,
        "gross_pnl_amount": round(pnl_amount, 6),
        "net_pnl_amount": round(net_amount, 6),
        "pnl_percent": round(pnl_percent, 6),
        "fees": fees,
        "commission": commission,
        "swap": swap,
        "note": str(payload.get("note") or "")[:1000],
        "created_at": utc_iso(),
    }
    position.setdefault("partial_closes", []).append(record)
    pnl_event = _record_pnl_event(
        db,
        user_id,
        position,
        event_type="full_close" if close_fraction >= 0.999999 else "partial_close",
        realized_pnl=net_amount,
        gross_pnl=pnl_amount,
        commission=commission,
        fees=fees,
        swap=swap,
        closed_fraction=close_fraction,
        exit_price=exit_price or None,
        occurred_at=record["created_at"],
    )
    record["pnl_event_id"] = pnl_event["id"]
    position["fees"] = round(_number(position.get("fees")) + fees, 6)
    position["commission"] = round(_number(position.get("commission")) + commission, 6)
    position["swap"] = round(_number(position.get("swap")) + swap, 6)
    position["realized_pnl_amount"] = round(_number(position.get("realized_pnl_amount")) + net_amount, 6)
    position["realized_pnl_percent"] = round(_number(position.get("realized_pnl_percent")) + pnl_percent, 6)
    remaining = max(0.0, _number(position.get("remaining_risk_percent"), _number(position.get("actual_risk_percent"))) * (1 - close_fraction))
    position["remaining_risk_percent"] = round(remaining, 6)
    position["remaining_risk_money"] = round(max(0.0, _number(position.get("remaining_risk_money"), _number(position.get("risk_money"))) * (1 - close_fraction)), 6)
    position["updated_at"] = utc_iso()
    if close_fraction >= 0.999999 or remaining <= 1e-9:
        position["status"] = "closed"
        position["closed_at"] = utc_iso()
        position["exit_price"] = exit_price or position.get("exit_price")
    else:
        position["status"] = "partial"
    _audit(db, user_id, position["id"], "closed" if position["status"] == "closed" else "partial_close", record)
    emit_event(db, user_id, "position.closed" if position["status"] == "closed" else "position.risk_changed", {"position_id": position["id"]})
    return dict(position)


def prop_account_snapshot(db: dict[str, Any], user_id: int | str, account_id: int | str | None = None) -> dict[str, Any]:
    account = get_account(db, user_id, account_id)
    starting = _number(account.get("starting_balance"), _number(account.get("balance"))) or _number(account.get("balance"))
    equity = _number(account.get("equity"), _number(account.get("balance"))) + _number(account.get("floating_pnl"))
    high_water = max(_number(account.get("high_water_mark"), starting), equity)
    account["high_water_mark"] = high_water
    today = _local_trade_day(account)
    pnl_events = pnl_events_for_account(db, user_id, account["id"])
    daily_realized = sum(
        _number(row.get("realized_pnl"))
        for row in pnl_events
        if _local_trade_day(account, str(row.get("occurred_at") or "")) == today
    )
    daily_basis = max(starting, 1e-9)
    daily_pnl_percent = (daily_realized + _number(account.get("floating_pnl"))) / daily_basis * 100
    basis = high_water if str(account.get("loss_basis")) == "equity" else starting
    total_drawdown = max(0.0, (basis - equity) / max(basis, 1e-9) * 100)
    total_return = (equity - starting) / max(starting, 1e-9) * 100
    daily_loss_used = max(0.0, -daily_pnl_percent)
    daily_limit = _number(account.get("max_daily_loss_percent"), 5.0)
    total_limit = _number(account.get("max_total_loss_percent"), 10.0)
    target = _number(account.get("profit_target_percent"), 8.0)
    breaches: list[str] = []
    if daily_loss_used >= daily_limit:
        breaches.append("daily_loss")
    if total_drawdown >= total_limit:
        breaches.append("total_loss")
    consistency_limit = _number(account.get("consistency_rule_percent"))
    largest_day = 0.0
    days: dict[str, float] = defaultdict(float)
    for row in pnl_events:
        days[_local_trade_day(account, str(row.get("occurred_at") or ""))] += _number(row.get("realized_pnl"))
    if days:
        largest_day = max(days.values())
    total_profit = sum(max(0.0, value) for value in days.values())
    consistency_used = largest_day / total_profit * 100 if total_profit > 0 else 0.0
    if consistency_limit > 0 and consistency_used > consistency_limit:
        breaches.append("consistency")
    remaining_daily = max(0.0, daily_limit - daily_loss_used)
    remaining_total = max(0.0, total_limit - total_drawdown)
    return {
        "account_id": account["id"],
        "enabled": account.get("type") in {"prop_challenge", "prop_funded"},
        "type": account.get("type"),
        "phase": account.get("phase"),
        "starting_balance": starting,
        "balance": _number(account.get("balance")),
        "equity": equity,
        "current_equity": equity,
        "floating_pnl": _number(account.get("floating_pnl")),
        "high_water_mark": high_water,
        "daily_realized_pnl": round(daily_realized, 6),
        "daily_pnl_percent": round(daily_pnl_percent, 6),
        "daily_loss_used_percent": round(daily_loss_used, 6),
        "daily_loss_remaining_percent": round(remaining_daily, 6),
        "total_return_percent": round(total_return, 6),
        "total_drawdown_percent": round(total_drawdown, 6),
        "total_loss_remaining_percent": round(remaining_total, 6),
        "breach_buffer_percent": round(min(remaining_daily, remaining_total), 6),
        "profit_target_percent": target,
        "profit_progress_percent": round(max(0.0, min(100.0, total_return / max(target, 1e-9) * 100)), 4),
        "trading_days": _int(account.get("current_trading_days")),
        "min_trading_days": _int(account.get("min_trading_days"), 5),
        "consistency_rule_percent": consistency_limit,
        "consistency_used_percent": round(consistency_used, 6),
        "breaches": breaches,
        "status": "breached" if breaches else "safe",
        "trade_day": today,
    }


def what_if_snapshot(db: dict[str, Any], user_id: int | str, account_id: int | str | None = None) -> dict[str, Any]:
    account = get_account(db, user_id, account_id)
    active = [row for row in positions_for_user(db, user_id, account_id=account["id"]) if str(row.get("status")) in ACTIVE_POSITION_STATES]
    total_stop_loss = -sum(max(0.0, _number(row.get("remaining_risk_money"), _number(row.get("risk_money")))) for row in active)
    current_equity = _number(account.get("equity"), _number(account.get("balance"))) + _number(account.get("floating_pnl"))
    worst_equity = current_equity + total_stop_loss
    starting = max(_number(account.get("starting_balance"), _number(account.get("balance"))), 1e-9)
    worst_drawdown = max(0.0, (starting - worst_equity) / starting * 100)
    clusters: dict[str, float] = defaultdict(float)
    for row in active:
        clusters[str(row.get("correlation_cluster") or "other")] += max(0.0, _number(row.get("remaining_risk_money")))
    worst_cluster = max(clusters.items(), key=lambda item: item[1], default=("none", 0.0))
    return {
        "account_id": account["id"],
        "all_stops_loss_amount": round(total_stop_loss, 6),
        "worst_case_equity": round(worst_equity, 6),
        "worst_case_drawdown_percent": round(worst_drawdown, 6),
        "largest_correlation_cluster": worst_cluster[0],
        "largest_cluster_loss_amount": round(-worst_cluster[1], 6),
        "open_positions": len(active),
        "would_breach_total_loss": worst_drawdown >= _number(account.get("max_total_loss_percent"), 10.0),
    }


def revision_inbox(db: dict[str, Any], user_id: int | str) -> list[dict[str, Any]]:
    ensure_trading_os(db)
    uid = str(user_id)
    acknowledgements = db["signal_revision_acknowledgements"].setdefault(uid, {})
    active_signal_ids = {
        _int(row.get("signal_id"))
        for row in positions_for_user(db, uid)
        if str(row.get("status")) in ACTIVE_POSITION_STATES and _int(row.get("signal_id")) > 0
    }
    output: list[dict[str, Any]] = []
    for signal in db.get("signals", []):
        if not isinstance(signal, dict) or _int(signal.get("id")) not in active_signal_ids:
            continue
        history = signal_version_history(signal, db.get("signal_revisions"))
        for item in history:
            revision = _int(item.get("revision"), _int(item.get("version"), 1))
            if revision <= 1:
                continue
            key = f"{signal.get('id')}:{revision}"
            if acknowledgements.get(key):
                continue
            changed = [str(value) for value in item.get("changed_fields", [])]
            if not set(changed) & {"entries", "entry", "stop", "targets", "risk", "expires_at"}:
                continue
            output.append(
                {
                    "key": key,
                    "signal_id": _int(signal.get("id")),
                    "display_number": _int(signal.get("display_number"), _int(signal.get("id"))),
                    "symbol": str(signal.get("symbol") or ""),
                    "revision": revision,
                    "changed_fields": changed,
                    "reason": str(item.get("reason") or ""),
                    "created_at": item.get("created_at"),
                    "hash": str(item.get("hash") or ""),
                }
            )
    output.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    return output


def acknowledge_revision(db: dict[str, Any], user_id: int | str, signal_id: int | str, revision: int | str) -> dict[str, Any]:
    ensure_trading_os(db)
    key = f"{_int(signal_id)}:{_int(revision)}"
    db["signal_revision_acknowledgements"].setdefault(str(user_id), {})[key] = {
        "acknowledged_at": utc_iso(),
    }
    emit_event(db, user_id, "signal.revision_acknowledged", {"signal_id": _int(signal_id), "revision": _int(revision)})
    return {"key": key, "acknowledged": True}


def trust_passport(db: dict[str, Any], signal: dict[str, Any]) -> dict[str, Any]:
    history = signal_version_history(signal, db.get("signal_revisions"))
    outcome = calculate_signal_outcome(signal)
    payload = {
        "signal_id": _int(signal.get("id")),
        "display_number": _int(signal.get("display_number"), _int(signal.get("id"))),
        "symbol": str(signal.get("symbol") or ""),
        "market_category": signal_market_category(signal),
        "side": str(signal.get("side") or "").upper(),
        "created_at": signal.get("created_at"),
        "status": signal.get("status"),
        "revision": _int(signal.get("revision"), len(history) or 1),
        "revision_chain_valid": verify_revision_chain(history),
        "revisions": history,
        "outcome": {
            "bucket": outcome.bucket,
            "net_r": outcome.net_r,
            "final": outcome.final,
        },
    }
    digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()
    payload["evidence_hash"] = digest
    return payload


def track_record_explorer(
    db: dict[str, Any], *, symbol: str = "", market: str = "", analyst: str = "", limit: int = 100
) -> dict[str, Any]:
    rows = [row for row in db.get("signals", []) if isinstance(row, dict)]
    if symbol:
        rows = [row for row in rows if str(row.get("symbol") or "").upper() == str(symbol).upper()]
    if market:
        rows = [row for row in rows if signal_market_category(row) == market]
    if analyst:
        rows = [row for row in rows if str(row.get("admin_id") or "") == str(analyst)]
    rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    passports = [trust_passport(db, row) for row in rows[: max(1, min(limit, 500))]]
    settled = [row for row in passports if row["outcome"]["final"]]
    net_values = [float(row["outcome"]["net_r"] or 0) for row in settled]
    ordered = sorted(net_values)
    median = 0.0
    if ordered:
        middle = len(ordered) // 2
        median = ordered[middle] if len(ordered) % 2 else (ordered[middle - 1] + ordered[middle]) / 2
    equity = 0.0
    peak = 0.0
    max_drawdown = 0.0
    for value in reversed(net_values):
        equity += value
        peak = max(peak, equity)
        max_drawdown = max(max_drawdown, peak - equity)
    wins = sum(1 for value in net_values if value > 0)
    losses = sum(1 for value in net_values if value < 0)
    return {
        "summary": {
            "signals": len(rows),
            "sample_size": len(settled),
            "wins": wins,
            "losses": losses,
            "win_rate": round(wins / max(1, wins + losses) * 100, 6),
            "average_r": round(sum(net_values) / max(1, len(net_values)), 6),
            "median_r": round(median, 6),
            "net_r": round(sum(net_values), 6),
            "maximum_drawdown_r": round(max_drawdown, 6),
            "revision_chain_failures": sum(1 for row in passports if not row["revision_chain_valid"]),
        },
        "ledger": passports,
    }


def behavioral_review(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    positions = positions_for_user(db, user_id, include_voided=True)
    closed = [row for row in positions if str(row.get("status")) == "closed"]
    late = [row for row in closed if row.get("late_entry")]
    late_losses = [row for row in late if _number(row.get("realized_pnl_amount")) < 0]
    by_symbol: dict[str, list[float]] = defaultdict(list)
    by_hour: dict[int, list[float]] = defaultdict(list)
    overrides = 0
    planned_actual_slippage: list[float] = []
    for row in closed:
        pnl = _number(row.get("realized_pnl_percent"))
        by_symbol[str(row.get("symbol") or "UNKNOWN")].append(pnl)
        dt = parse_dt(str(row.get("opened_at") or ""))
        if dt:
            by_hour[dt.hour].append(pnl)
        if row.get("override"):
            overrides += 1
        planned = _number(row.get("planned_entry"))
        actual = _number(row.get("actual_entry"))
        if planned > 0 and actual > 0:
            planned_actual_slippage.append(abs(actual - planned) / planned * 100)
    weak_symbols = sorted(
        (
            {"symbol": symbol, "trades": len(values), "average_pnl_percent": round(sum(values) / len(values), 6)}
            for symbol, values in by_symbol.items()
            if len(values) >= 2
        ),
        key=lambda row: row["average_pnl_percent"],
    )[:5]
    weak_hours = sorted(
        (
            {"hour_utc": hour, "trades": len(values), "average_pnl_percent": round(sum(values) / len(values), 6)}
            for hour, values in by_hour.items()
            if len(values) >= 2
        ),
        key=lambda row: row["average_pnl_percent"],
    )[:5]
    result = {
        "closed_trades": len(closed),
        "late_entry_trades": len(late),
        "late_entry_loss_rate": round(len(late_losses) / max(1, len(late)) * 100, 4),
        "risk_overrides": overrides,
        "average_entry_slippage_percent": round(sum(planned_actual_slippage) / max(1, len(planned_actual_slippage)), 6),
        "weak_symbols": weak_symbols,
        "weak_hours": weak_hours,
        "generated_at": utc_iso(),
    }
    db.setdefault("behavioral_insights", {})[str(user_id)] = result
    return result


def emit_event(db: dict[str, Any], user_id: int | str | None, event: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    ensure_trading_os(db)
    row = {
        "id": next_id(db, "miniapp_event"),
        "user_id": str(user_id) if user_id is not None else "*",
        "event": str(event),
        "payload": dict(payload or {}),
        "created_at": utc_iso(),
    }
    db["miniapp_event_stream"].append(row)
    db["miniapp_event_stream"] = db["miniapp_event_stream"][-5000:]
    return row


def events_since(db: dict[str, Any], user_id: int | str, last_id: int = 0, *, limit: int = 100) -> list[dict[str, Any]]:
    ensure_trading_os(db)
    uid = str(user_id)
    return [
        row
        for row in db["miniapp_event_stream"]
        if isinstance(row, dict)
        and _int(row.get("id")) > last_id
        and str(row.get("user_id")) in {uid, "*"}
    ][: max(1, min(limit, 500))]
