from __future__ import annotations

from pathlib import Path
import json

import pytest

from modules import admin_access
from modules import gemini_ai
from modules.gemini_admin_control import sanitize_tool_calls
from services import ai_control_service
from services.actions_v2.registry import action_specs


ROOT = Path(__file__).resolve().parents[1]


def test_ai_and_human_finance_permissions_are_granular_and_unique() -> None:
    assert len(admin_access.ALL_PERMISSIONS) == len(set(admin_access.ALL_PERMISSIONS))
    expected = {
        "ai_command_center", "ai_crm_analysis", "ai_user_behavior", "ai_channel_content",
        "ai_ticket_assistant", "ai_signal_analysis", "ai_risk_supervision", "ai_system_monitoring",
        "vip_plan_create", "vip_plan_edit", "vip_plan_activate", "vip_plan_archive", "vip_plan_delete",
        "payment_dashboard_view", "payment_receipts_view", "payment_receipt_approve",
        "payment_receipt_reject", "payment_manual_review", "payment_refund_approve",
    }
    assert expected.issubset(set(admin_access.ALL_PERMISSIONS))


def test_primary_admin_financial_intents_reach_provider_without_app_level_block(monkeypatch: pytest.MonkeyPatch) -> None:
    called = False

    def provider(*args, **kwargs):
        nonlocal called
        called = True
        return {
            "text": json.dumps({"answer": "انجام می‌شود", "findings": [], "recommended_actions": [], "tool_calls": []}),
            "model": "gemini-test",
            "usage": {},
        }

    monkeypatch.setattr(gemini_ai, "_gemini_request", provider)
    result = gemini_ai.admin_ai_query(
        354678485, "این رسید را بررسی کن و در صورت تطابق VIP را فعال کن", scope="management"
    )
    assert called is True
    assert result["answer"] == "انجام می‌شود"


def test_public_discount_tool_requires_explicit_primary_approval(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = sanitize_tool_calls(
        [{
            "action": "public_discount_create",
            "payload": {
                "code": "WELCOME15",
                "percent": 15,
                "days": 7,
                "max_uses": 100,
                "one_per_user": True,
            },
            "reason": "کمپین بازگشت کاربران",
        }],
        admin_command="کد تخفیف WELCOME15 با ۱۵ درصد و اعتبار ۷ روز بساز",
    )
    assert calls[0]["action"] == "public_discount_create"
    queued: list[dict] = []
    executed: list[tuple] = []
    monkeypatch.setattr(ai_control_service, "sanitize_tool_calls", lambda *_args, **_kwargs: calls)
    monkeypatch.setattr(ai_control_service, "ai_execution_settings", lambda: {
        "execution_enabled": True,
        "autonomous_primary_admin": True,
        "primary_admin_full_bot_access": True,
    })
    monkeypatch.setattr(ai_control_service, "is_primary_admin", lambda _actor: True)
    monkeypatch.setattr(ai_control_service, "_record_plan", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        ai_control_service,
        "queue_ai_admin_commands",
        lambda _actor, rows, **_kwargs: queued.extend(rows) or [{"id": 91, **rows[0]}],
    )
    monkeypatch.setattr(ai_control_service, "create_undo_snapshot", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        ai_control_service,
        "execute_registered_admin_action",
        lambda *args, **kwargs: executed.append((args, kwargs)) or {"discount": {"code": "WELCOME15"}},
    )

    result = ai_control_service.execute_or_queue_ai_tool_calls(
        1, calls, conversation_id=1, question="کد تخفیف بساز", response_id="r1"
    )

    assert result["mode"] == "primary_autonomous_with_admin_approval"
    assert result["executions"] == []
    assert result["queued"][0]["id"] == 91
    assert queued and queued[0]["action"] == "public_discount_create"
    assert executed == []


def test_ai_proposals_cannot_smuggle_payment_plan_or_vip_payloads() -> None:
    rows = gemini_ai._sanitize_proposals([
        {"type": "channel_draft", "title": "safe", "payload": {"message": "hello"}},
        {"type": "channel_draft", "title": "payment", "payload": {"payment": "approve"}},
        {"type": "crm_campaign_draft", "title": "plan", "payload": {"plan": "vip"}},
        {"type": "refund", "title": "blocked", "payload": {}},
    ])
    assert rows == [{"type": "channel_draft", "title": "safe", "reason": "", "payload": {"message": "hello"}}]


def test_action_registry_separates_ai_from_human_plan_and_payment_actions() -> None:
    specs = action_specs()
    for name in (
        "user_ai_query", "admin_ai_query", "admin_ai_proposal_approve", "admin_ai_proposal_reject",
        "admin_vip_plan_create", "admin_vip_plan_update", "admin_vip_plan_toggle", "admin_vip_plan_delete",
        "payment_approve", "payment_reject",
    ):
        assert name in specs
    assert specs["admin_vip_plan_create"].permission == "vip_plan_create"
    assert specs["admin_vip_plan_delete"].permission == "vip_plan_delete"
    assert specs["admin_ai_query"].permission == "ai_command_center"
    assert specs["public_discount_create"].permission == "discounts"
    assert any(
        row["action"] == "public_discount_create" for row in gemini_ai.operational_tool_catalog()
    )
    assert not any("payment" in kind or "receipt" in kind or "vip" in kind or "plan" in kind for kind in gemini_ai._ALLOWED_PROPOSAL_TYPES)


def test_miniapp_has_dedicated_user_admin_ai_and_human_vip_plan_surfaces() -> None:
    server = (ROOT / "core" / "miniapp_server.py").read_text(encoding="utf-8")
    core = (ROOT / "webapp" / "src" / "core.js").read_text(encoding="utf-8")
    admin = (ROOT / "webapp" / "src" / "admin-parity.js").read_text(encoding="utf-8")
    shell = (ROOT / "webapp" / "src" / "shell-events.js").read_text(encoding="utf-8")
    for route in ("/api/v1/ai", "/api/v1/admin/ai", "/api/v1/admin/vip-plans"):
        assert route in server
    assert "adminAI" in core and "adminVipPlans" in core
    assert "function userAiCenter" in admin
    assert "function adminAiCenter" in admin
    assert "function adminVipPlanCenter" in admin
    assert "data-admin-ai-center" in shell
    assert "data-admin-vip-plans" in shell


def test_gemini_secret_is_never_embedded_and_server_side_env_is_documented() -> None:
    env = (ROOT / ".env.example").read_text(encoding="utf-8")
    config = (ROOT / "config.py").read_text(encoding="utf-8")
    frontend = "\n".join(path.read_text(encoding="utf-8") for path in (ROOT / "webapp" / "src").glob("*.js"))
    assert "GEMINI_API_KEY=" in env
    assert '_first_env("GEMINI_API_KEY")' in config
    assert "GEMINI_API_KEY" not in frontend
    leaked_prefix = "AQ." + "Ab8RN6"
    assert leaked_prefix not in "\n".join(
        path.read_text(encoding="utf-8", errors="ignore")
        for path in ROOT.rglob("*")
        if path.is_file() and path != Path(__file__) and path.suffix not in {".zip", ".pyc"}
    )


def test_telegram_exposes_user_and_full_access_admin_ai() -> None:
    platform = (ROOT / "bot_runtime" / "platform_expansion.py").read_text(encoding="utf-8")
    routes = (ROOT / "handlers" / "registration_plan.py").read_text(encoding="utf-8")
    callbacks = (ROOT / "handlers" / "callback_routes.py").read_text(encoding="utf-8")
    assert "user_ai_query" in platform
    assert "admin_ai_query" in platform
    assert "admin_ai_command" in routes
    assert "a_ai_command_center" in callbacks
    assert "دسترسی کامل به عملیات ثبت‌شده ربات" in platform
    assert "خارج از محدوده امن Gemini" not in platform


def test_telegram_payment_and_plan_handlers_accept_granular_human_permissions() -> None:
    commerce = (ROOT / "bot_runtime" / "commerce_calculator.py").read_text(encoding="utf-8")
    plans = (ROOT / "bot_runtime" / "admin_operations.py").read_text(encoding="utf-8")
    navigation = (ROOT / "bot_runtime" / "navigation.py").read_text(encoding="utf-8")
    assert "PERMISSION_PAYMENT_RECEIPT_APPROVE" in commerce
    assert "PERMISSION_PAYMENT_RECEIPT_REJECT" in commerce
    assert "PERMISSION_PAYMENT_REFUND_APPROVE" in commerce
    assert "PERMISSION_VIP_PLAN_CREATE" in plans
    assert "PERMISSION_VIP_PLAN_EDIT" in plans
    assert "PERMISSION_VIP_PLAN_DELETE" in plans
    assert '("🧩 مدیریت پلن‌های VIP", "a_vip_plans", PERMISSION_VIP_PLAN_VIEW)' in navigation
