from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from core.storage.engine import DatabaseEngine
from repositories.v2.common import json_dump, json_load
from repositories.v2.commerce import CommerceRepository
from scripts.vip_database_integrity import audit_database


def repo_for(tmp_path: Path) -> CommerceRepository:
    engine = DatabaseEngine(database_url="", sqlite_path=tmp_path / "resilience.sqlite3")
    engine.ensure_schema()
    return CommerceRepository(engine)


def add_receipt(repo: CommerceRepository, user: str, key: str) -> dict:
    checksum = (key.encode().hex() + "0" * 64)[:64]
    return repo.create_receipt(user, {
        "id": f"receipt-{user}-{key}",
        "receipt_id": f"receipt-{user}-{key}",
        "checksum": checksum,
        "object_key": f"receipts/{user}/{key}.webp",
        "storage_backend": "local",
        "mime_type": "image/webp",
        "size_bytes": 512,
    })


def add_quote(repo: CommerceRepository, user: str, key: str, *, method: str = "card", payable: int = 1_000_000) -> dict:
    return repo.create_quote(user, {
        "quote_id": f"quote-{user}-{key}",
        "plan_id": "vip-30",
        "plan_name": "VIP 30",
        "duration_days": 30,
        "base_price": payable,
        "discount_amount": 0,
        "payable_toman": payable,
        "payment_method": method,
        "expires_at": "2999-01-01T00:00:00+00:00",
    })


def add_order(repo: CommerceRepository, user: str, key: str, *, method: str = "card") -> dict:
    receipt = add_receipt(repo, user, key)
    quote = add_quote(repo, user, key, method=method)
    return repo.submit_order_from_quote(
        user,
        quote_id=quote["quote_id"],
        receipt_id=receipt["id"],
        transaction_hash=f"tx-{user}-{key}" if method == "usdt" else "",
    )


def age_claim(repo: CommerceRepository, order_id: str, *, with_invite: bool) -> None:
    old = (datetime.now(UTC) - timedelta(hours=2)).isoformat()
    with repo.engine.transaction() as cursor:
        row = cursor.execute("SELECT payload FROM v8_vip_orders WHERE id=?", (order_id,)).fetchone()
        payload = json_load(row["payload"], {})
        payload["processing_started_at"] = old
        if with_invite:
            payload["processing_invite_link"] = "https://t.me/+stale-one-use"
            payload["processing_invite_created_at"] = old
        cursor.execute(
            "UPDATE v8_vip_orders SET updated_at=?,payload=? WHERE id=?",
            (old, json_dump(payload), order_id),
        )


def test_persisted_invite_is_idempotent_and_must_match_on_finalize(tmp_path):
    repo = repo_for(tmp_path)
    order = add_order(repo, "10", "a")
    repo.claim_order_for_approval(order["id"], actor_id="1")
    stored = repo.store_order_approval_invite(
        order["id"], actor_id="1", invite_link="https://t.me/+one-use"
    )
    assert stored["processing_invite_link"] == "https://t.me/+one-use"
    repeated = repo.store_order_approval_invite(
        order["id"], actor_id="1", invite_link="https://t.me/+one-use"
    )
    assert repeated["processing_invite_link"] == "https://t.me/+one-use"
    with pytest.raises(ValueError, match="ORDER_APPROVAL_INVITE_CONFLICT"):
        repo.finalize_order_approval(
            order["id"], actor_id="1", invite_link="https://t.me/+different"
        )
    approved = repo.finalize_order_approval(
        order["id"], actor_id="1", invite_link="https://t.me/+one-use"
    )
    assert approved["status"] == "approved"


def test_stale_claim_with_invite_requires_recovery_before_another_admin(tmp_path):
    repo = repo_for(tmp_path)
    order = add_order(repo, "10", "b")
    repo.claim_order_for_approval(order["id"], actor_id="1")
    repo.store_order_approval_invite(order["id"], actor_id="1", invite_link="https://t.me/+stale")
    age_claim(repo, order["id"], with_invite=True)
    with pytest.raises(ValueError, match="ORDER_STALE_APPROVAL_REQUIRES_RECOVERY"):
        repo.claim_order_for_approval(order["id"], actor_id="2")
    recovered = repo.recover_stale_approval_claims(lease_seconds=60)
    assert recovered and recovered[0]["processing_invite_link"] == "https://t.me/+stale-one-use"
    locked = repo.get(order["id"])
    assert locked["status"] == "approving"
    assert locked["processing_by"] == "system:approval-recovery"
    with pytest.raises(ValueError, match="ORDER_NOT_PENDING"):
        repo.claim_order_for_approval(order["id"], actor_id="2")

    failed = repo.complete_stale_approval_recovery(
        order["id"], invite_revoked=False, error="Telegram unavailable"
    )
    assert failed["status"] == "approving"
    assert failed["processing_invite_link"] == "https://t.me/+stale-one-use"

    pending = repo.complete_stale_approval_recovery(order["id"], invite_revoked=True)
    assert pending["status"] == "pending"
    assert not pending.get("processing_invite_link")
    claimed = repo.claim_order_for_approval(order["id"], actor_id="2")
    assert claimed["processing_by"] == "2"


def test_stale_claim_without_invite_can_be_reclaimed_atomically(tmp_path):
    repo = repo_for(tmp_path)
    order = add_order(repo, "10", "c")
    repo.claim_order_for_approval(order["id"], actor_id="1")
    age_claim(repo, order["id"], with_invite=False)
    claimed = repo.claim_order_for_approval(order["id"], actor_id="2")
    assert claimed["status"] == "approving"
    assert claimed["processing_by"] == "2"


def test_two_simultaneous_submissions_for_one_user_create_only_one_open_order(tmp_path):
    repo = repo_for(tmp_path)
    r1 = add_receipt(repo, "50", "a")
    r2 = add_receipt(repo, "50", "b")
    q1 = add_quote(repo, "50", "a")
    q2 = add_quote(repo, "50", "b")

    def submit(pair):
        quote, receipt = pair
        try:
            return repo.submit_order_from_quote("50", quote_id=quote["quote_id"], receipt_id=receipt["id"])["id"]
        except ValueError as exc:
            return str(exc)

    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = list(pool.map(submit, [(q1, r1), (q2, r2)]))
    assert sum(value.startswith("ord_") for value in outcomes) == 1
    assert outcomes.count("ORDER_ALREADY_PENDING") == 1
    page = repo.list_for_user("50")
    assert len([row for row in page["items"] if row["status"] in {"pending", "approving"}]) == 1


def test_integrity_audit_repairs_only_safe_nonfinancial_damage(tmp_path):
    repo = repo_for(tmp_path)
    order = add_order(repo, "70", "a")
    with repo.engine.transaction() as cursor:
        cursor.execute("DELETE FROM v8_receipts WHERE id=?", (order["receipt_id"],))
    before = audit_database(repo.engine, repair_safe=False)
    kinds = {row["kind"] for row in before["issues"]}
    assert "payable_order_without_attached_receipt" in kinds
    repaired = audit_database(repo.engine, repair_safe=True)
    assert repaired["repair_count"] >= 1
    assert repaired["projection_changes"] == 0
    assert repo.get(order["id"])["status"] == "needs_receipt"


def test_integrity_audit_never_silently_repairs_financial_contradiction(tmp_path):
    repo = repo_for(tmp_path)
    order = add_order(repo, "80", "a")
    repo.claim_order_for_approval(order["id"], actor_id="1")
    repo.finalize_order_approval(order["id"], actor_id="1", invite_link="https://t.me/+valid")
    with repo.engine.transaction() as cursor:
        cursor.execute("DELETE FROM v8_vip_entitlements WHERE order_id=?", (order["id"],))
    report = audit_database(repo.engine, repair_safe=True)
    issue = next(row for row in report["issues"] if row["kind"] == "approved_order_without_entitlement")
    assert issue["severity"] == "critical"
    assert issue["safe_repair_available"] is False
    assert repo.get(order["id"])["status"] == "approved"


def test_manual_payment_repository_stress_preserves_invariants(tmp_path):
    repo = repo_for(tmp_path)
    expected_approved = 0
    for index in range(120):
        user = str(10_000 + index)
        method = "usdt" if index % 2 else "card"
        order = add_order(repo, user, "a", method=method)
        if index % 3 == 0:
            repo.reject_order(order["id"], actor_id="900", reason="receipt is unreadable")
            fresh = add_receipt(repo, user, "b")
            order = repo.resubmit_order(user, order["id"], receipt_id=fresh["id"])
        if index % 5 == 0:
            repo.claim_order_for_approval(order["id"], actor_id="901")
            repo.release_order_approval(order["id"], actor_id="901", error="simulated telegram outage")
        repo.claim_order_for_approval(order["id"], actor_id="902")
        repo.store_order_approval_invite(
            order["id"], actor_id="902", invite_link=f"https://t.me/+stress{index}"
        )
        approved = repo.finalize_order_approval(
            order["id"], actor_id="902", invite_link=f"https://t.me/+stress{index}"
        )
        assert approved["status"] == "approved"
        expected_approved += 1

    report = audit_database(repo.engine, repair_safe=False)
    assert report["healthy"] is True, report["issues"]
    assert len(repo.list_entitlements()) == expected_approved
    with repo.engine.transaction(read_only=True) as cursor:
        open_count = cursor.execute(
            "SELECT COUNT(*) AS total FROM v8_vip_orders WHERE status IN ('pending','approving')"
        ).fetchone()["total"]
    assert int(open_count) == 0
